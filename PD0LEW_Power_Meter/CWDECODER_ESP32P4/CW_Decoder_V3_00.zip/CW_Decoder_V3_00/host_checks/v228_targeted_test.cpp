#include "CWDecoder.cpp"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstring>

static void train(float dot) {
  weakActive = false;
  activeCwType = 1;
  fadeAssistActive = true;
  cycleTimingReady = true;
  dotMs = dot;
  displayDotMs = dot;
  guentherTiming.reset(dot);
  for (int i = 0; i < 60; ++i)
    assert(guentherTiming.observeMark((i & 1) ? 3.0f * dot : dot, 95.0f));
}

static void load(const float *marks, const float *gaps, const float *confidence, size_t n) {
  symbolLength = guentherMarkCount = n;
  for (size_t i = 0; i < n; ++i) {
    guentherMarks[i] = marks[i];
    guentherGaps[i] = gaps ? gaps[i] : 0.0f;
    guentherMarkConfidence[i] = confidence ? confidence[i] : 0.0f;
    symbolBuffer[i] = guentherTiming.classifyDashForDecode(marks[i]) ? '-' : '.';
  }
  symbolBuffer[n] = 0;
}

int main() {
  // The exact failure mechanism seen on the receiver at 50 WPM: two clean
  // leading dots in V (...-) can look mergeable if the measured first gap is
  // compressed by the narrow detector. V2.28 must preserve the valid V rather
  // than rewrite it as K (-.-) when both fragments are high confidence.
  train(24.0f); // 50 WPM
  const float vMarks[] = {24,24,24,72};
  const float vGaps[] = {10,24,24,0};
  const float clean[] = {95,95,95,95};
  load(vMarks, vGaps, clean, 4);
  assert(std::strcmp(symbolBuffer, "...-") == 0);
  char chosen[16] = {};
  assert(!chooseGuentherHypothesis(chosen, sizeof(chosen)));
  assert(std::strcmp(chosen, "...-") == 0);

  // Genuine QSB split-dash recovery must still work when the physical evidence
  // is strong: two low-confidence fragments separated by a very short gap.
  train(60.0f);
  const float splitMarks[] = {70,70};
  const float splitGaps[] = {20,0};
  const float faded[] = {20,20};
  load(splitMarks, splitGaps, faded, 2);
  assert(std::strcmp(symbolBuffer, "..") == 0);
  assert(chooseGuentherHypothesis(chosen, sizeof(chosen)));
  assert(std::strcmp(chosen, "-") == 0);

  // Deep-QSB character boundaries get a conservative hold, while strong
  // conditions preserve the normal threshold.
  train(40.0f); // 30 WPM
  normalToneLocked = true;
  spectralSnrDb = 7.0f;
  signalEnvelope = 100.0f;
  noiseEnvelope = 10.0f;
  float held = qsbProtectedCharacterGapThreshold(80.0f);
  assert(std::fabs(held - 106.0f) < 0.1f); // 2.65 * 40 ms

  spectralSnrDb = 20.0f;
  signalEnvelope = 300.0f;
  noiseEnvelope = 10.0f;
  float cleanGap = qsbProtectedCharacterGapThreshold(80.0f);
  assert(std::fabs(cleanGap - 80.0f) < 0.1f);

  std::puts("PASS: V2.28 fast-CW micro-gap guard and deep-QSB boundary hold");
  return 0;
}
