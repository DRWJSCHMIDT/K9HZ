#ifndef AUDIO_ENGINE_H
#define AUDIO_ENGINE_H

#include <Arduino.h>
#include <Wire.h>
#include "AudioSGTL5000.h"

struct AudioMetrics {
  bool i2sOk = false;
  bool codecPresent = false;
  bool codecOk = false;
  bool streamOk = false;
  bool monitorEnabled = false;
  uint16_t codecId = 0;
  uint8_t lineInLevel = 5;
  uint8_t inputGainIndex = 4;
  float peakDbLeft = -120.0f;
  float peakDbRight = -120.0f;
  float rmsDbLeft = -120.0f;
  float rmsDbRight = -120.0f;
  uint32_t framesPerSecond = 0;
  uint32_t overruns = 0;
  int16_t rawMinLeft = 0;
  int16_t rawMaxLeft = 0;
  int16_t rawMinRight = 0;
  int16_t rawMaxRight = 0;
  uint16_t nonZeroPermille = 0;
  bool rawDataActive = false;
  static constexpr size_t kWaveformPoints = 256;
  int16_t waveformLeft[kWaveformPoints] = {};
  int16_t waveformRight[kWaveformPoints] = {};
};

namespace AudioEngine {

// Wiring used by this project:
// I2C: SDA GPIO7, SCL GPIO8 (shared with GT911)
// I2S1: MCLK GPIO28, BCLK GPIO29, LRCLK GPIO30, TX/DIN GPIO31, RX/DOUT GPIO32
constexpr int PIN_MCLK  = 28;
constexpr int PIN_BCLK  = 29;
constexpr int PIN_LRCLK = 30;
constexpr int PIN_DOUT  = 31; // ESP32-P4 -> SGTL5000 I2S_DIN
constexpr int PIN_DIN   = 32; // SGTL5000 I2S_DOUT -> ESP32-P4 (non-strapping GPIO)
constexpr uint32_t SAMPLE_RATE_48K = 48000;
constexpr uint32_t SAMPLE_RATE_96K = 96000;
constexpr uint32_t DEFAULT_SAMPLE_RATE = SAMPLE_RATE_96K;

void setSerialDiagnosticsEnabled(bool enabled);

bool begin(uint32_t sampleRateHz = DEFAULT_SAMPLE_RATE);
// Switch 48/96 kHz without rebooting the ESP32-P4. The audio stream is briefly
// muted/stopped, clocks are changed, DSP transient state is reset, then streaming resumes.
bool switchSampleRate(uint32_t sampleRateHz);
uint32_t sampleRateHz();
bool isRunning();
AudioMetrics getMetrics();

bool setMonitorEnabled(bool enabled);
bool monitorEnabled();
void setMonitorFiltered(bool enabled);
bool monitorFiltered();

bool setLineInLevel(uint8_t level);
uint8_t lineInLevel();

bool setInputGainIndex(uint8_t index);
uint8_t inputGainIndex();
float inputGainDb();

bool setHeadphoneVolumePercent(uint8_t percent);
uint8_t headphoneVolumePercent();


} // namespace AudioEngine

#endif
