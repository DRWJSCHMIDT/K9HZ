/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_WiFiLink.h"
#include "PSWR_WiFiConfig.h"
#include "PSWR_State.h"
#include "PSWR_Print.h"
#include "PSWR_CalBanks.h"
#include "PSWR_CallSign.h"
#include "PSWR_Eeprom.h"

#include <EEPROM.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

namespace
{
constexpr uint32_t WIFI_UART_BAUD = 921600UL;
constexpr uint32_t TELEMETRY_MS = 75UL;
constexpr uint32_t CREDENTIAL_RETRY_MS = 2000UL;

char rxLine[512] = {};
size_t rxLen = 0;
uint32_t lastTelemetryMs = 0;
uint32_t lastCredentialSendMs = 0;
bool credentialsAcknowledged = false;
bool connected = false;
bool modulePresent = false;
char remoteIp[24] = {};
char remoteSsid[WIFI_SSID_MAX_CHARS + 1] = {};
int remoteRssi = 0;
char remoteFirmware[12] = {};

// Clock state from XIAO/NTP. Keep these separate from WiFi status so the
// display can continue showing the last valid second through brief UART jitter.
char remoteUtc[9] = {};
char remoteLocal[9] = {};
char remoteDate[20] = {};
char remoteDateUtc[20] = {};
char remoteDateLocal[20] = {};
char remoteZone[6] = {};
bool clockValid = false;
uint32_t lastClockMs = 0;
constexpr uint32_t CLOCK_STALE_MS = 10000UL;

struct ScanResult
{
  char ssid[WIFI_SSID_MAX_CHARS + 1];
  int rssi;
  bool secure;
};

ScanResult scanResults[WIFI_SCAN_MAX_RESULTS] = {};
uint8_t scanCount = 0;
bool scanBusy = false;
bool scanReady = false;
bool scanFailed = false;
bool scanBeginSeen = false;
uint32_t scanStartMs = 0;
uint32_t lastScanRequestMs = 0;
uint8_t scanRequestAttempts = 0;
constexpr uint32_t SCAN_REQUEST_RETRY_MS = 1200UL;
constexpr uint32_t SCAN_BEGIN_TIMEOUT_MS = 6000UL;
constexpr uint32_t SCAN_ACTIVE_TIMEOUT_MS = 20000UL;

void printJsonEscaped(Stream &out, const char *text)
{
  if (!text) return;
  while (*text)
  {
    const char c = *text++;
    if (c == '"' || c == '\\') out.print('\\');
    out.print(c);
  }
}

void sendCredentials()
{
  Serial5.print(F("{\"type\":\"wifi_cfg\",\"ssid\":\""));
  printJsonEscaped(Serial5, wifi_ssid_get());
  Serial5.print(F("\",\"password\":\""));
  printJsonEscaped(Serial5, wifi_password_get());
  Serial5.println(F("\"}"));
  lastCredentialSendMs = millis();
}

bool jsonHasTrue(const char *line, const char *key)
{
  char pattern[48];
  snprintf(pattern, sizeof(pattern), "\"%s\":true", key);
  return strstr(line, pattern) != nullptr;
}

bool jsonGetInt(const char *line, const char *key, int &value)
{
  char pattern[48];
  snprintf(pattern, sizeof(pattern), "\"%s\":", key);
  const char *p = strstr(line, pattern);
  if (!p) return false;
  p += strlen(pattern);
  value = atoi(p);
  return true;
}

bool jsonGetString(const char *line, const char *key, char *out, size_t outSize)
{
  if (!out || outSize == 0) return false;
  char pattern[48];
  snprintf(pattern, sizeof(pattern), "\"%s\":\"", key);
  const char *p = strstr(line, pattern);
  if (!p) return false;
  p += strlen(pattern);
  size_t n = 0;
  bool escaped = false;
  while (*p && n + 1 < outSize)
  {
    const char c = *p++;
    if (!escaped && c == '"') break;
    if (!escaped && c == '\\') { escaped = true; continue; }
    out[n++] = c;
    escaped = false;
  }
  out[n] = '\0';
  return true;
}

void updateRemoteFirmware(const char *line)
{
  char value[24] = {};

  // W3.4+ uses the compact "fw" field on control packets.
  if (jsonGetString(line, "fw", value, sizeof(value)) && value[0])
  {
    const size_t n = strnlen(value, sizeof(remoteFirmware) - 1);
    memcpy(remoteFirmware, value, n);
    remoteFirmware[n] = '\0';
    return;
  }

  // W3.2 already includes a RELEASE string in periodic connected-status
  // packets (for example "ESPC3W3.2"). Accept that too, so the Teensy can
  // identify an older XIAO whenever it is online.
  if (jsonGetString(line, "version", value, sizeof(value)) && value[0])
  {
    const char *start = strchr(value, 'W');
    if (!start) start = value;
    const size_t n = strnlen(start, sizeof(remoteFirmware) - 1);
    memcpy(remoteFirmware, start, n);
    remoteFirmware[n] = '\0';
  }
}

void selectCouplerFromWeb()
{
  if (flag.swr_alarm || flag.config_mode) return;
  const bool newCoupler = !cpl;
  calbanks_select(newCoupler);
  cpl = newCoupler;
  digitalWrite(CouplerLed, LOW);
  digitalWrite(CouplerSelect, cpl ? LOW : HIGH);
  flag.idle_refresh = true;
}

void setBandFromWeb(uint8_t band)
{
  if (band >= CALBAND_COUNT || flag.config_mode) return;
  calbanks_select_band(band); // V3.54 changes only the active coupler's band.
  flag.idle_refresh = true;
}

void sendCalibrationData()
{
  Serial5.print(F("{\"type\":\"cal_all\",\"sets\":["));
  for (uint8_t bank = 1; bank <= CALBANK_TOTAL; ++bank)
  {
    cal_t cal[2] = {};
    if (!calbanks_get(bank, cal)) continue;
    if (bank > 1) Serial5.print(',');
    Serial5.print(F("{\"set\":")); Serial5.print(bank - 1);
    Serial5.print(F(",\"cal1_db\":")); Serial5.print((double)cal[0].db10m / 10.0, 1);
    Serial5.print(F(",\"cal1_fwd\":")); Serial5.print(cal[0].Fwd, 3);
    Serial5.print(F(",\"cal1_rev\":")); Serial5.print(cal[0].Rev, 3);
    Serial5.print(F(",\"cal2_db\":")); Serial5.print((double)cal[1].db10m / 10.0, 1);
    Serial5.print(F(",\"cal2_fwd\":")); Serial5.print(cal[1].Fwd, 3);
    Serial5.print(F(",\"cal2_rev\":")); Serial5.print(cal[1].Rev, 3);
    Serial5.print('}');
  }
  Serial5.print(F("],\"callsign\":\"")); printJsonEscaped(Serial5, callsign_get());
  Serial5.print(F("\",\"version\":\"")); Serial5.print(VERSION);
  Serial5.println(F("\"}"));
}

void handleLine(const char *line)
{
  if (!line || !*line) return;

  updateRemoteFirmware(line);

  // W1.5+ XIAO firmware sends this heartbeat continuously, regardless of
  // router/WiFi connection state. Latch hardware presence until reboot so a
  // temporary UART/WiFi disturbance never makes Setup items disappear.
  if (strcmp(line, "{\"hb\":1}") == 0)
  {
    modulePresent = true;
    return;
  }

  // Clock packet from the XIAO. The XIAO owns NTP and timezone handling;
  // the Teensy only renders the already formatted values.
  if (strstr(line, "\"type\":\"clock\"") != nullptr)
  {
    modulePresent = true;
    char utc[sizeof(remoteUtc)] = {};
    char local[sizeof(remoteLocal)] = {};
    char date[sizeof(remoteDate)] = {};
    char dateUtc[sizeof(remoteDateUtc)] = {};
    char dateLocal[sizeof(remoteDateLocal)] = {};
    char zone[sizeof(remoteZone)] = {};

    if (jsonGetString(line, "utc", utc, sizeof(utc)) &&
        jsonGetString(line, "local", local, sizeof(local)) &&
        jsonGetString(line, "date", date, sizeof(date)) &&
        jsonGetString(line, "zone", zone, sizeof(zone)))
    {
      // Newer XIAO firmware sends separate UTC/local dates. Fall back to
      // the legacy date field so mixed-version testing still works.
      if (!jsonGetString(line, "date_utc", dateUtc, sizeof(dateUtc)))
        memcpy(dateUtc, date, sizeof(dateUtc));
      if (!jsonGetString(line, "date_local", dateLocal, sizeof(dateLocal)))
        memcpy(dateLocal, date, sizeof(dateLocal));

      memcpy(remoteUtc, utc, sizeof(remoteUtc));
      memcpy(remoteLocal, local, sizeof(remoteLocal));
      memcpy(remoteDate, date, sizeof(remoteDate));
      memcpy(remoteDateUtc, dateUtc, sizeof(remoteDateUtc));
      memcpy(remoteDateLocal, dateLocal, sizeof(remoteDateLocal));
      memcpy(remoteZone, zone, sizeof(remoteZone));
      remoteUtc[sizeof(remoteUtc) - 1] = '\0';
      remoteLocal[sizeof(remoteLocal) - 1] = '\0';
      remoteDate[sizeof(remoteDate) - 1] = '\0';
      remoteDateUtc[sizeof(remoteDateUtc) - 1] = '\0';
      remoteDateLocal[sizeof(remoteDateLocal) - 1] = '\0';
      remoteZone[sizeof(remoteZone) - 1] = '\0';
      clockValid = true;
      lastClockMs = millis();
    }
    return;
  }

  // WiFi scan protocol from the XIAO. Results arrive one AP per JSON line so
  // the Teensy never needs a large temporary JSON document.
  if (strstr(line, "\"type\":\"wifi_scan_begin\"") != nullptr)
  {
    modulePresent = true;
    scanCount = 0;
    scanBusy = true;
    scanReady = false;
    scanFailed = false;
    scanBeginSeen = true;
    scanStartMs = millis();
    return;
  }

  if (strstr(line, "\"type\":\"wifi_ap\"") != nullptr)
  {
    if (scanCount < WIFI_SCAN_MAX_RESULTS)
    {
      char ssid[WIFI_SSID_MAX_CHARS + 1] = {};
      int rssi = 0;
      int secure = 0;
      if (jsonGetString(line, "ssid", ssid, sizeof(ssid)) && ssid[0])
      {
        const size_t copyLen = strnlen(ssid, WIFI_SSID_MAX_CHARS);
        memcpy(scanResults[scanCount].ssid, ssid, copyLen);
        scanResults[scanCount].ssid[copyLen] = '\0';
        if (jsonGetInt(line, "rssi", rssi)) scanResults[scanCount].rssi = rssi;
        if (jsonGetInt(line, "secure", secure)) scanResults[scanCount].secure = (secure != 0);
        ++scanCount;
      }
    }
    return;
  }

  if (strstr(line, "\"type\":\"wifi_scan_end\"") != nullptr)
  {
    scanBusy = false;
    scanReady = true;
    scanFailed = false;
    return;
  }

  if (strstr(line, "\"type\":\"wifi_scan_error\"") != nullptr)
  {
    scanCount = 0;
    scanBusy = false;
    scanReady = true;
    scanFailed = true;
    return;
  }

  if (strstr(line, "\"wifi_req\"") != nullptr)
  {
    modulePresent = true;
    // W3.4+ adds its firmware identifier to this existing request.
    // updateRemoteFirmware() above has already stored it.
    sendCredentials();
    return;
  }

  if (jsonHasTrue(line, "reqCal"))
  {
    modulePresent = true;
    sendCalibrationData();
    return;
  }

  if (strstr(line, "\"wifi_ack\":1") != nullptr)
  {
    modulePresent = true;
    credentialsAcknowledged = true;
  }

  if (strstr(line, "\"wifi\":\"connected\"") != nullptr)
  {
    modulePresent = true;
    connected = true;
    credentialsAcknowledged = true;
  }
  else if (strstr(line, "\"wifi\":\"disconnected\"") != nullptr ||
           strstr(line, "\"wifi\":\"failed\"") != nullptr)
  {
    modulePresent = true;
    connected = false;
    remoteIp[0] = '\0';
    remoteRssi = 0;
  }

  jsonGetString(line, "ssid", remoteSsid, sizeof(remoteSsid));
  jsonGetString(line, "ip", remoteIp, sizeof(remoteIp));
  int tmp = 0;
  if (jsonGetInt(line, "rssi", tmp)) remoteRssi = tmp;

  int pep = 0;
  if (jsonGetInt(line, "pepset", pep))
  {
    if (pep == 1) R.PEP_period = 1;
    else if (pep == 2) R.PEP_period = 10;
    else if (pep == 3) R.PEP_period = 20;
    EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
  }

  int band = -1;
  if (jsonGetInt(line, "band", band) && band >= 0 && band < CALBAND_COUNT)
    setBandFromWeb((uint8_t)band);

  if (jsonHasTrue(line, "cpl"))
    selectCouplerFromWeb();
}

void sendTelemetry()
{
  char fwdText[16], pepText[16], avgText[16], dbmText[16];
  char swrText[16], pkText[16], refText[16], instText[16];

  print_p_mw(fwd_power_mw); strncpy(fwdText, lcd_buf, sizeof(fwdText)); fwdText[sizeof(fwdText)-1]='\0';
  print_p_mw(power_mw_pep); strncpy(pepText, lcd_buf, sizeof(pepText)); pepText[sizeof(pepText)-1]='\0';
  print_p_mw(power_mw_avg); strncpy(avgText, lcd_buf, sizeof(avgText)); avgText[sizeof(avgText)-1]='\0';
  print_dbm(db10_from_mw(display_dbm_mw)); strncpy(dbmText, lcd_buf, sizeof(dbmText)); dbmText[sizeof(dbmText)-1]='\0';
  print_swr(); strncpy(swrText, lcd_buf, sizeof(swrText)); swrText[sizeof(swrText)-1]='\0';
  print_p_mw(power_mw_pk); strncpy(pkText, lcd_buf, sizeof(pkText)); pkText[sizeof(pkText)-1]='\0';
  print_p_mw(ref_power_mw); strncpy(refText, lcd_buf, sizeof(refText)); refText[sizeof(refText)-1]='\0';
  print_p_mw(power_mw); strncpy(instText, lcd_buf, sizeof(instText)); instText[sizeof(instText)-1]='\0';

  const uint8_t pepVal = (R.PEP_period >= 20) ? 3U : (R.PEP_period >= 10) ? 2U : 1U;

  Serial5.print(F("{\"pep_val\":")); Serial5.print(pepVal);
  Serial5.print(F(",\"cpl\":")); Serial5.print(cpl ? 2 : 1);
  Serial5.print(F(",\"btns\":")); Serial5.print(calbanks_active_band());
  Serial5.print(F(",\"band_name\":\"")); Serial5.print(calbanks_active_band_name()); Serial5.print('"');
  Serial5.print(F(",\"fwd\":\"")); Serial5.print(fwdText); Serial5.print('"');
  Serial5.print(F(",\"pep\":\"")); Serial5.print(pepText); Serial5.print('"');
  Serial5.print(F(",\"avg\":\"")); Serial5.print(avgText); Serial5.print('"');
  Serial5.print(F(",\"dbm\":\"")); Serial5.print(dbmText); Serial5.print('"');
  Serial5.print(F(",\"vswr\":\"")); Serial5.print(swrText); Serial5.print('"');
  Serial5.print(F(",\"pk\":\"")); Serial5.print(pkText); Serial5.print('"');
  Serial5.print(F(",\"ref\":\"")); Serial5.print(refText); Serial5.print('"');
  Serial5.print(F(",\"inst\":\"")); Serial5.print(instText); Serial5.print('"');
  Serial5.print(F(",\"volf\":")); Serial5.print((double)fwd * adc_ref / 4096.0, 4);
  Serial5.print(F(",\"volr\":")); Serial5.print((double)rev * adc_ref / 4096.0, 4);
  Serial5.print(F(",\"swrt\":\""));
  if (flag.swr_alarm) Serial5.print(F("Alarm"));
  else if (R.SWR_alarm_trig < 40) Serial5.print((double)R.SWR_alarm_trig / 10.0, 1);
  else Serial5.print(F("Off"));
  Serial5.print(F("\",\"callsign\":\"")); printJsonEscaped(Serial5, callsign_get());
  Serial5.println(F("\"}"));
}
}

void wifi_link_begin(void)
{
  Serial5.begin(WIFI_UART_BAUD);
  static uint8_t serial5RxBuffer[2048];
  Serial5.addMemoryForRead(serial5RxBuffer, sizeof(serial5RxBuffer));
  credentialsAcknowledged = false;
  connected = false;
  modulePresent = false;
  remoteIp[0] = '\0';
  remoteSsid[0] = '\0';
  remoteRssi = 0;
  remoteFirmware[0] = '\0';
  remoteUtc[0] = '\0';
  remoteLocal[0] = '\0';
  remoteDate[0] = '\0';
  remoteZone[0] = '\0';
  clockValid = false;
  lastClockMs = 0;
  scanCount = 0;
  scanBusy = false;
  scanReady = false;
  scanFailed = false;
  scanBeginSeen = false;
  scanRequestAttempts = 0;
  sendCredentials();
}

void wifi_link_service(void)
{
  while (Serial5.available())
  {
    const char c = (char)Serial5.read();
    if (c == '\n')
    {
      rxLine[rxLen] = '\0';
      if (rxLen) handleLine(rxLine);
      rxLen = 0;
    }
    else if (c != '\r')
    {
      if (rxLen + 1 < sizeof(rxLine)) rxLine[rxLen++] = c;
      else rxLen = 0;
    }
  }

  const uint32_t now = millis();
  if (!credentialsAcknowledged && (uint32_t)(now - lastCredentialSendMs) >= CREDENTIAL_RETRY_MS)
    sendCredentials();

  if (scanBusy)
  {
    if (!scanBeginSeen)
    {
      // The request itself is tiny, but retry it until the XIAO explicitly
      // acknowledges that the radio scan has started.
      if ((uint32_t)(now - lastScanRequestMs) >= SCAN_REQUEST_RETRY_MS &&
          scanRequestAttempts < 4U)
      {
        Serial5.println(F("{\"wifi_scan\":1}"));
        lastScanRequestMs = now;
        ++scanRequestAttempts;
      }

      if ((uint32_t)(now - scanStartMs) >= SCAN_BEGIN_TIMEOUT_MS)
      {
        scanBusy = false;
        scanReady = true;
        scanFailed = true;
        scanCount = 0;
      }
    }
    else if ((uint32_t)(now - scanStartMs) >= SCAN_ACTIVE_TIMEOUT_MS)
    {
      scanBusy = false;
      scanReady = true;
      scanFailed = true;
      scanCount = 0;
    }
  }

  // Do not flood the XIAO UART while a scan request/scan is active. The RF
  // measurement engine continues normally; only web telemetry is paused.
  if (!scanBusy && (uint32_t)(now - lastTelemetryMs) >= TELEMETRY_MS)
  {
    lastTelemetryMs = now;
    sendTelemetry();
  }
}

void wifi_link_credentials_changed(void)
{
  credentialsAcknowledged = false;
  connected = false;
  sendCredentials();
}

void wifi_link_scan_start(void)
{
  scanCount = 0;
  scanBusy = true;
  scanReady = false;
  scanFailed = false;
  scanBeginSeen = false;
  scanStartMs = millis();
  lastScanRequestMs = scanStartMs;
  scanRequestAttempts = 1;
  Serial5.println(F("{\"wifi_scan\":1}"));
}

bool wifi_link_scan_busy(void) { return scanBusy; }
bool wifi_link_scan_ready(void) { return scanReady; }
bool wifi_link_scan_failed(void) { return scanFailed; }
uint8_t wifi_link_scan_count(void) { return scanCount; }

const char *wifi_link_scan_ssid(uint8_t index)
{
  return (index < scanCount) ? scanResults[index].ssid : "";
}

int wifi_link_scan_rssi(uint8_t index)
{
  return (index < scanCount) ? scanResults[index].rssi : 0;
}

bool wifi_link_scan_secure(uint8_t index)
{
  return (index < scanCount) ? scanResults[index].secure : false;
}

const char *wifi_link_ip(void) { return remoteIp; }
const char *wifi_link_ssid(void) { return remoteSsid; }
int wifi_link_rssi(void) { return remoteRssi; }
bool wifi_link_connected(void) { return connected; }
bool wifi_link_module_present(void) { return modulePresent; }
const char *wifi_link_firmware_version(void) { return remoteFirmware; }

bool wifi_link_clock_valid(void)
{
  return clockValid && lastClockMs != 0 &&
         (uint32_t)(millis() - lastClockMs) < CLOCK_STALE_MS;
}

const char *wifi_link_clock_utc(void) { return remoteUtc; }
const char *wifi_link_clock_local(void) { return remoteLocal; }
const char *wifi_link_clock_date(void) { return remoteDate; }
const char *wifi_link_clock_date_utc(void) { return remoteDateUtc; }
const char *wifi_link_clock_date_local(void) { return remoteDateLocal; }
const char *wifi_link_clock_zone(void) { return remoteZone; }
