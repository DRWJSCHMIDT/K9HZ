/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_Display.h"
#include "PSWR_State.h"
#include "PSWR_CallSign.h"
#include "PSWR_StartupLogo.h"
#include "PSWR_Print.h"
#include "PSWR_Measurement.h"
#include "PSWR_ModScope.h"
#include "PSWR_CalBanks.h"
#include "PSWR_WiFiLink.h"
#include "PSWR_WiFiConfig.h"

#include "Profont22.h"
#include "Profont29.h"

#include <math.h>

// V3.102 display-stage diagnostic. Updated on EVERY normal Power-screen frame
// after the exact large PEP and small PK values have been formatted for the OLED.
static DisplayPepDebugSnapshot display_pep_debug_snapshot = {};

bool display_get_pep_debug_snapshot(DisplayPepDebugSnapshot &out)
{
  if (display_pep_debug_snapshot.frame_sequence == 0) return false;
  out = display_pep_debug_snapshot;
  return true;
}
#include <string.h>

namespace {

constexpr uint16_t kDisplayW = 256;
constexpr uint16_t kDisplayH = 64;

// SSD1322 is 4-bit grayscale: 0=black, 15=brightest.
constexpr uint8_t kWhite = SSD1322_WHITE;
constexpr uint8_t kBright = 0x0F;
constexpr uint8_t kNormal = 0x0A;
constexpr uint8_t kMedium = 0x09;
constexpr uint8_t kDim = 0x05;
constexpr uint8_t kLine = 0x04;  // same selected-card background used by graphical menus

// dBm-display PEP history. Independent from the Watt-screen PEP marker.
double dbmPepBlocks[PEP_BUFFER] = {0.0};
uint16_t dbmPepHead = 0;
uint16_t dbmPepValid = 0;
double dbmPepMw = 1.0e-12;

// Display-only smoothing for the FWD/REV screen.
double displayFwdMw = 0.0;
double displayRevMw = 0.0;
bool fwdRevInitialized = false;

const char *pepPeriodText()
{
  if (R.PEP_period >= 20) return "2.0s";
  if (R.PEP_period >= 10) return "1.0s";
  return "0.1s";
}

void trimLeft(char *s)
{
  if (!s) return;
  size_t n = strlen(s);
  size_t first = 0;
  while (first < n && s[first] == ' ') ++first;
  if (first > 0) memmove(s, s + first, n - first + 1);
}

// Copy the shared 82-byte formatter buffer into a smaller local display buffer.
// Do the bound explicitly instead of strncpy(): GCC can otherwise emit many
// -Wstringop-truncation warnings when these tiny formatter functions are inlined.
void copyLcdBuf(char *out, size_t outSize)
{
  if (!out || outSize == 0) return;

  size_t n = 0;
  while (n < sizeof(lcd_buf) && lcd_buf[n] != '\0') ++n;
  if (n >= outSize) n = outSize - 1;

  if (n > 0) memcpy(out, lcd_buf, n);
  out[n] = '\0';
}

void formatPower(double mw, char *out, size_t outSize)
{
  if (!out || outSize == 0) return;
  print_p_mw(mw);
  copyLcdBuf(out, outSize);
  trimLeft(out);
}

void formatDbm(double mw, char *out, size_t outSize)
{
  if (!out || outSize == 0) return;
  print_dbm(db10_from_mw(mw));
  copyLcdBuf(out, outSize);
  trimLeft(out);
}

void formatSwr(char *out, size_t outSize)
{
  if (!out || outSize == 0) return;
  print_swr_display();
  copyLcdBuf(out, outSize);
  trimLeft(out);
}

void selectFont(const GFXfont *font, uint8_t level = kWhite)
{
  lcd.setFont(font);
  lcd.setTextColor(level);
  lcd.setTextWrap(false);
}

int16_t textWidth(const char *text)
{
  if (!text) return 0;
  int16_t x1 = 0, y1 = 0;
  uint16_t w = 0, h = 0;
  lcd.getTextBounds(text, 0, 0, &x1, &y1, &w, &h);
  return (int16_t)w;
}

void printRight(int16_t rightX, int16_t baselineY, const char *text)
{
  const int16_t w = textWidth(text);
  int16_t x = rightX - w;
  if (x < 0) x = 0;
  lcd.setCursor(x, baselineY);
  lcd.print(text);
}


// Clean small-text renderer. U8g2's Helvetica fonts are substantially easier
// to read at 8..10 pixel cap height than the old Profont menu glyphs.
void selectUiFont(const uint8_t *font, uint8_t level = kWhite)
{
  u8g2.setFont(font);
  u8g2.setFontMode(1);           // transparent background
  u8g2.setFontDirection(0);
  u8g2.setForegroundColor(level);
}

int16_t uiTextWidth(const char *text)
{
  if (!text) return 0;
  return u8g2.getUTF8Width(text);
}

void uiPrintRight(int16_t rightX, int16_t baselineY, const char *text)
{
  int16_t x = rightX - uiTextWidth(text);
  if (x < 0) x = 0;
  u8g2.setCursor(x, baselineY);
  u8g2.print(text);
}

void uiPrintCentered(int16_t centerX, int16_t baselineY, const char *text)
{
  int16_t x = centerX - uiTextWidth(text) / 2;
  if (x < 0) x = 0;
  u8g2.setCursor(x, baselineY);
  u8g2.print(text);
}

void beginFrame()
{
  lcd.clearDisplay();
  lcd.setTextWrap(false);
  lcd.setTextColor(kWhite);
}

void endFrame()
{
  lcd.display();
}

// Compact status strip used by the three normal measurement screens.
// The measurement itself owns the display; mode/coupler/time are secondary.

// Large left-hand primary value.  Profont29 is intentionally used for the
// quantity that matters most when the meter is viewed from a distance.



// Power-bar autorange: upscale immediately, downscale after a short stable delay.

// V2.12 main PK/PEP screen layout:
//   - large Power reading at upper left
//   - equally large SWR reading at upper right
//   - small PEP directly underneath Power
//   - bottom power bar retained
void drawPowerSwrHero(const char *powerText,
                      const char *swrText,
                      const char *pepText)
{
  // Use exactly the same large font for Power and SWR.
  selectFont(&Profont29, kBright);

  int16_t powerW = textWidth(powerText);
  int16_t swrW   = textWidth(swrText);

  // Keep a comfortable gap between the two hero values. If an unusually long
  // formatted power value would collide with SWR, fall back both values
  // together so their visual weight remains identical.
  if ((powerW + swrW) > 236)
  {
    selectFont(&Profont22, kBright);
    powerW = textWidth(powerText);
    swrW   = textWidth(swrText);
  }

  // Power begins at the upper-left edge.
  lcd.setCursor(1, 24);
  lcd.print(powerText);

  // SWR uses the same font and is right-aligned to the upper-right edge.
  printRight(254, 24, swrText);

  // Small labels make the meaning obvious without competing with the numbers.
  selectUiFont(u8g2_font_6x12_tf, kDim);
  u8g2.setCursor(2, 36);
  u8g2.print("PK");

  char pepLine[24];
  snprintf(pepLine, sizeof(pepLine), "%s", pepText);

  // PEP value uses the same subdued brightness as the PEP label.
  // Only the main POWER and SWR values are visually highlighted.
  selectUiFont(u8g2_font_6x12_tf, kDim);
  u8g2.setCursor(26, 36);
  u8g2.print(pepLine);

  selectUiFont(u8g2_font_6x12_tf, kDim);
  uiPrintRight(254, 36, "SWR");
}


// Common SWR alarm status used on all three normal measurement screens.
// Normal state is deliberately quiet; a latched alarm uses the same
// highlighted card language as the graphical setup menus.
void drawSwrAlarmStatus(void)
{
  char swrAlarmText[24];

  if (flag.swr_alarm)
  {
    if (R.SWR_alarm_trig == 40)
      snprintf(swrAlarmText, sizeof(swrAlarmText), "SWR ALARM = OFF");
    else
      snprintf(swrAlarmText, sizeof(swrAlarmText), "SWR ALARM = %u.%u",
               (unsigned)(R.SWR_alarm_trig / 10U),
               (unsigned)(R.SWR_alarm_trig % 10U));

    selectUiFont(u8g2_font_6x12_tf, kBright);
    const int16_t textW = uiTextWidth(swrAlarmText);
    const int16_t cardW = textW + 10;
    const int16_t cardX = 128 - cardW / 2;
    constexpr int16_t cardY = 24;
    constexpr int16_t cardH = 15;

    lcd.fillRect(cardX, cardY, cardW, cardH, kLine);
    lcd.drawRect(cardX, cardY, cardW, cardH, kWhite);
    lcd.fillRect(cardX + 1, cardY + 1, cardW - 2, 2, kWhite);
    uiPrintCentered(128, 36, swrAlarmText);
  }
  else
  {
    if (R.SWR_alarm_trig == 40)
      snprintf(swrAlarmText, sizeof(swrAlarmText), "SWR ALARM OFF");
    else
      snprintf(swrAlarmText, sizeof(swrAlarmText), "SWR ALARM %u.%u",
               (unsigned)(R.SWR_alarm_trig / 10U),
               (unsigned)(R.SWR_alarm_trig % 10U));

    selectUiFont(u8g2_font_6x10_tf, kDim);
    uiPrintCentered(128, 35, swrAlarmText);
  }
}

// V2.15 FWD/REV page hero layout.  This mirrors the Power/dBm pages but
// uses REV as the subdued secondary quantity below FWD.
void drawFwdRevHero(const char *fwdText,
                    const char *swrText,
                    const char *revText)
{
  selectFont(&Profont29, kBright);

  int16_t fwdW = textWidth(fwdText);
  int16_t swrW = textWidth(swrText);

  // Keep FWD and SWR visually equal.  If an unusually long formatted value
  // would collide, step both down together.
  if ((fwdW + swrW) > 236)
  {
    selectFont(&Profont22, kBright);
    fwdW = textWidth(fwdText);
    swrW = textWidth(swrText);
  }

  lcd.setCursor(1, 24);
  lcd.print(fwdText);
  printRight(254, 24, swrText);

  // Secondary REV indication: intentionally subdued so FWD and SWR dominate.
  selectUiFont(u8g2_font_6x12_tf, kDim);
  u8g2.setCursor(2, 36);
  u8g2.print("REV");

  u8g2.setCursor(26, 36);
  u8g2.print(revText);

  uiPrintRight(254, 36, "SWR");
}

void drawFwdRevBottomStatus(double fullScale)
{
  char fsValue[16];
  char fsText[24];
  formatPower(fullScale, fsValue, sizeof(fsValue));
  snprintf(fsText, sizeof(fsText), "FS %s", fsValue);

  char couplerText[16];
  snprintf(couplerText, sizeof(couplerText), "%s CPL%u",
           calbanks_active_band_name(), cpl ? 2U : 1U);

  selectUiFont(u8g2_font_6x12_tf, kDim);
  u8g2.setCursor(2, 61);
  u8g2.print(couplerText);
  uiPrintCentered(128, 61, "LIVE");
  uiPrintRight(254, 61, fsText);
}

void drawPowerBottomStatus(double fullScale)
{
  char fsValue[16];
  char fsText[24];

  formatPower(fullScale, fsValue, sizeof(fsValue));
  snprintf(fsText, sizeof(fsText), "FS %s", fsValue);

  char couplerText[16];
  snprintf(couplerText, sizeof(couplerText), "%s CPL%u",
           calbanks_active_band_name(), cpl ? 2U : 1U);

  char pepText[16];
  snprintf(pepText, sizeof(pepText), "PEP %s", pepPeriodText());

  // Bottom strip: one clean line of secondary information.
  selectUiFont(u8g2_font_6x12_tf, kDim);
  u8g2.setCursor(2, 61);
  u8g2.print(couplerText);

  uiPrintCentered(128, 61, pepText);
  uiPrintRight(254, 61, fsText);
}

double powerBarScale(double mw)
{
  // V2.16.5.42: do not hold an old high-power sample for 30 seconds.
  // Instead, move to a larger scale immediately and return to the correct
  // lower scale only after the input has stayed there for a short time.
  static double activeScale = 0.0;
  static double downCandidateScale = 0.0;
  static uint32_t downCandidateSinceMs = 0;

  if (!isfinite(mw) || mw < 0.0) mw = 0.0;
  if (mw > 9000000.0) mw = 9000000.0;

  const uint64_t value = (uint64_t)(mw * 1000.0 + 0.5); // 1 uW resolution

  const uint8_t r1 = R.ScaleRange[0] ? R.ScaleRange[0] : SCALE_RANGE1;
  const uint8_t r2 = R.ScaleRange[1] ? R.ScaleRange[1] : SCALE_RANGE2;
  const uint8_t r3 = R.ScaleRange[2] ? R.ScaleRange[2] : SCALE_RANGE3;

  uint64_t decade = (R.low_power_floor == FLOOR_TEN_mW) ? 50000ULL : 5000ULL;
  while ((decade * r3) < value && decade < 1000000000ULL)
    decade *= 10ULL;

  uint64_t desiredRaw;
  if      (value >= decade * r2) desiredRaw = decade * r3;
  else if (value >= decade * r1) desiredRaw = decade * r2;
  else                           desiredRaw = decade * r1;

  if (desiredRaw == 0) desiredRaw = 1;
  const double desiredScale = (double)desiredRaw / 1000.0;

  if (activeScale <= 0.0)
  {
    activeScale = desiredScale;
    downCandidateScale = 0.0;
    downCandidateSinceMs = 0;
    return activeScale;
  }

  // Going up must always be immediate so the bar can never over-range.
  if (desiredScale > activeScale)
  {
    activeScale = desiredScale;
    downCandidateScale = 0.0;
    downCandidateSinceMs = 0;
    return activeScale;
  }

  if (desiredScale < activeScale)
  {
    const uint32_t now = millis();

    // Restart the delay if the correct lower target itself changes.
    if (downCandidateScale != desiredScale)
    {
      downCandidateScale = desiredScale;
      downCandidateSinceMs = now;
    }
    else if ((uint32_t)(now - downCandidateSinceMs) >= POWER_BAR_DOWNSCALE_DELAY_MS)
    {
      activeScale = desiredScale;
      downCandidateScale = 0.0;
      downCandidateSinceMs = 0;
    }
  }
  else
  {
    // Current power belongs to the active scale again: cancel a pending drop.
    downCandidateScale = 0.0;
    downCandidateSinceMs = 0;
  }

  return activeScale;
}

void drawHorizontalBar(int16_t x, int16_t y, int16_t w, int16_t h,
                       double value, double fullScale,
                       double marker = 0.0)
{
  if (w < 3 || h < 3) return;

  lcd.drawRect(x, y, w, h, kDim);

  if (!isfinite(value) || value < 0.0) value = 0.0;
  if (!isfinite(marker) || marker < 0.0) marker = 0.0;
  if (!isfinite(fullScale) || fullScale <= 0.0) fullScale = 1.0;

  double ratio = value / fullScale;
  if (ratio < 0.0) ratio = 0.0;
  if (ratio > 1.0) ratio = 1.0;

  const int16_t innerW = w - 2;
  const int16_t fillW = (int16_t)lround(ratio * innerW);
  if (fillW > 0)
    lcd.fillRect(x + 1, y + 1, fillW, h - 2, kMedium);

  if (marker > value && marker > 0.0)
  {
    double mr = marker / fullScale;
    if (mr < 0.0) mr = 0.0;
    if (mr > 1.0) mr = 1.0;
    int16_t mx = x + 1 + (int16_t)lround(mr * (innerW - 1));
    if (mx < x + 1) mx = x + 1;
    if (mx > x + w - 2) mx = x + w - 2;
    // V2.13: make the PEP marker clearly visible on the slim bar.
    // Draw a 3-pixel-wide marker, clipped to the bar's inner width.
    int16_t mx0 = mx - 1;
    int16_t mx1 = mx;
    int16_t mx2 = mx + 1;
    if (mx0 < x + 1) mx0 = x + 1;
    if (mx2 > x + w - 2) mx2 = x + w - 2;
    lcd.drawLine(mx0, y - 1, mx0, y + h, kBright);
    lcd.drawLine(mx1, y - 1, mx1, y + h, kBright);
    lcd.drawLine(mx2, y - 1, mx2, y + h, kBright);
  }
}

void drawAbsoluteMarker(int16_t x, int16_t y, int16_t w, int16_t h,
                        double marker, double fullScale)
{
  if (w < 3 || h < 3) return;
  if (!isfinite(marker) || marker <= 0.0) return;
  if (!isfinite(fullScale) || fullScale <= 0.0) return;

  double ratio = marker / fullScale;
  if (ratio < 0.0) ratio = 0.0;
  if (ratio > 1.0) ratio = 1.0;

  const int16_t innerW = w - 2;
  int16_t mx = x + 1 + (int16_t)lround(ratio * (innerW - 1));
  if (mx < x + 1) mx = x + 1;
  if (mx > x + w - 2) mx = x + w - 2;
  // V2.15: use the same clearly visible 3-pixel marker style as the PEP bar.
  int16_t mx0 = mx - 1;
  int16_t mx1 = mx;
  int16_t mx2 = mx + 1;
  if (mx0 < x + 1) mx0 = x + 1;
  if (mx2 > x + w - 2) mx2 = x + w - 2;
  lcd.drawLine(mx0, y - 1, mx0, y + h, kBright);
  lcd.drawLine(mx1, y - 1, mx1, y + h, kBright);
  lcd.drawLine(mx2, y - 1, mx2, y + h, kBright);
}

void renderScreensaver()
{
  if (flag.idle_refresh && screensaver_time.hasPassed(SCREENSAVER_SHIFT_MS))
    flag.idle_refresh = false;

  if (Menu_exit_timer != 0) return;
  if (!screensaver_time.hasPassed(SCREENSAVER_SHIFT_MS)) return;

  lcd.setContrast(DISPLAY_CONTRAST_SLEEP);
  beginFrame();
  selectUiFont(u8g2_font_helvB10_tf, kDim);

  const char *msg = R.idle_disp[0] ? R.idle_disp : "NO SIGNAL";
  const int16_t w = uiTextWidth(msg);
  const int16_t maxX = (w < (int16_t)kDisplayW) ? (int16_t)kDisplayW - w : 0;
  const int16_t x = (maxX > 0) ? (int16_t)(rand() % (maxX + 1)) : 0;
  const int16_t baseline = 14 + (int16_t)(rand() % 47); // safely inside 64 px

  u8g2.setCursor(x, baseline);
  u8g2.print(msg);
  endFrame();
  screensaver_time.start();
}

static double heldPkForDisplay(double currentMw)
{
  static double heldMw = 0.0;
  static uint32_t lastPeakMs = 0;
  static bool initialized = false;

  if (!isfinite(currentMw) || currentMw < 0.0)
    currentMw = 0.0;

  const uint32_t now = millis();

  // The qualified RF gate is based on the last COMPLETE 100 ms net-power block,
  // while power_mw_pk is a live value and can already have fallen to zero in the
  // partial block immediately after key-up ends.  Do not let the PK hold timer
  // replace the last valid small PK value with 0 mW while display_rf_active is
  // still true.  Once the qualified RF gate closes, the normal user-selected PK
  // hold timing below is allowed to expire exactly as before.
  if (display_rf_active && initialized &&
      currentMw <= DISPLAY_RF_OFF_THRESHOLD_MW)
  {
    return heldMw;
  }

  if (!initialized || currentMw >= heldMw)
  {
    heldMw = currentMw;
    lastPeakMs = now;
    initialized = true;
  }
  else if ((uint32_t)(now - lastPeakMs) >= R.PK_hold_ms)
  {
    heldMw = currentMw;
    lastPeakMs = now;
  }

  return heldMw;
}

} // namespace

bool display_begin(void)
{
  // User-proven SSD1322_for_Adafruit_GFX initialization sequence.
  const bool ok = lcd.begin();
  lcd.clearDisplay();
  lcd.display();
  lcd.setRotation(0);
  lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
  lcd.setTextWrap(false);

  // Attach the U8g2 font renderer to the existing Adafruit_GFX-compatible
  // SSD1322 object. It is used for menus and all small/status text only.
  u8g2.begin(lcd);
  u8g2.setFontMode(1);
  u8g2.setFontDirection(0);
  u8g2.setForegroundColor(kWhite);
  return ok;
}

void display_startup(void)
{
  lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
  beginFrame();

  // Balanced startup identity: the selected logo stays on the left, while
  // every text line shares one exact horizontal center in the right-hand area.
  lcd.drawRect(0, 0, 256, 64, kDim);

  // User-selectable startup emblem. The Startup Logo setup page calls the
  // same drawing function, so its preview is exactly what appears on boot.
  const uint8_t startupLogo = startup_logo_get();
  const int16_t startupLogoY = (startupLogo == 0) ? 12 : ((startupLogo == 3) ? 7 : 6); // RF Tower + Coupler startup offsets.
  startup_logo_draw(2, startupLogoY, startupLogo, kBright, kMedium, kDim);

  constexpr int16_t startupTextCenterX = 157;

  // Main product identity, centered.
  selectFont(&Profont22, kBright);
  const int16_t titleW = textWidth(STARTUPDISPLAY1);
  lcd.setCursor(startupTextCenterX - titleW / 2, 21);
  lcd.print(STARTUPDISPLAY1);

  selectUiFont(u8g2_font_helvB08_tf, kWhite);
  uiPrintCentered(startupTextCenterX, 31, STARTUPDISPLAY2);

  // Version doubles as the visual divider. Use real 2-pixel-thick bars
  // instead of dash characters, with the version centered between them.
  const char *versionText = "V3.102";
  selectUiFont(u8g2_font_6x10_tf, kMedium);
  const int16_t versionW = uiTextWidth(versionText);
  const int16_t versionLeft = startupTextCenterX - versionW / 2;
  const int16_t versionRight = versionLeft + versionW;
  constexpr int16_t dividerLeft = 63;
  constexpr int16_t dividerRight = 251;
  constexpr int16_t dividerY = 40;
  constexpr int16_t dividerGap = 5;
  if (versionLeft - dividerGap > dividerLeft)
    lcd.fillRect(dividerLeft, dividerY, versionLeft - dividerGap - dividerLeft, 2, kMedium);
  if (versionRight + dividerGap < dividerRight)
    lcd.fillRect(versionRight + dividerGap, dividerY, dividerRight - (versionRight + dividerGap), 2, kMedium);
  uiPrintCentered(startupTextCenterX, 45, versionText);

  // Stored call/name, centered. Longer user-programmed names automatically
  // use the compact font so all 30 printable characters remain visible.
  const char *startupCall = callsign_get();
  selectUiFont(u8g2_font_helvR08_tf, kMedium);
  if (uiTextWidth(startupCall) > 190)
    selectUiFont(u8g2_font_6x10_tf, kMedium);
  uiPrintCentered(startupTextCenterX, 59, startupCall);

  endFrame();
}

void display_smoothing_update(void)
{
  static bool initialized = false;

  double rfAverageMw = pswr_get_qualified_net_power_mw();
  if (!isfinite(rfAverageMw) || rfAverageMw < 0.0) rfAverageMw = 0.0;

  // dBm screen deliberately shows calibrated detector noise from startup.
  double dbmSourceMw = 1.0e-12;
  if (isfinite(ad8307_FdBm)) dbmSourceMw = pow(10.0, ad8307_FdBm / 10.0);
  if (!isfinite(dbmSourceMw) || dbmSourceMw < 1.0e-12) dbmSourceMw = 1.0e-12;
  if (dbmSourceMw > 9000000.0) dbmSourceMw = 9000000.0;

  double fwdMw = fwd_power_mw;
  double revMw = ref_power_mw;
  if (!isfinite(fwdMw) || fwdMw < 0.0) fwdMw = 0.0;
  if (!isfinite(revMw) || revMw < 0.0) revMw = 0.0;

  if (!fwdRevInitialized)
  {
    displayFwdMw = fwdMw;
    displayRevMw = revMw;
    fwdRevInitialized = true;
  }
  else
  {
    const double fastFallRatio = pow(10.0, -DISPLAY_FAST_FALL_DB / 10.0);

    if (fwdMw <= displayFwdMw * fastFallRatio)
      displayFwdMw = fwdMw;
    else
      displayFwdMw += DISPLAY_SMOOTH_ALPHA * (fwdMw - displayFwdMw);

    if (revMw <= displayRevMw * fastFallRatio)
      displayRevMw = revMw;
    else
      displayRevMw += DISPLAY_SMOOTH_ALPHA * (revMw - displayRevMw);
  }

  if (!initialized)
  {
    display_dbm_mw = dbmSourceMw;
    initialized = true;
  }
  else
  {
    const double fastFallRatio = pow(10.0, -DISPLAY_FAST_FALL_DB / 10.0);
    if (dbmSourceMw <= (display_dbm_mw * fastFallRatio))
      display_dbm_mw = dbmSourceMw;
    else
      display_dbm_mw += DISPLAY_SMOOTH_ALPHA * (dbmSourceMw - display_dbm_mw);
  }

  dbmPepBlocks[dbmPepHead] = display_dbm_mw;
  dbmPepHead++;
  if (dbmPepHead >= PEP_BUFFER) dbmPepHead = 0;
  if (dbmPepValid < PEP_BUFFER) dbmPepValid++;

  uint16_t window = R.PEP_period;
  if (window < 1) window = 1;
  if (window > PEP_BUFFER) window = PEP_BUFFER;
  if (window > dbmPepValid) window = dbmPepValid;

  double maximum = 1.0e-12;
  for (uint16_t i = 0; i < window; ++i)
  {
    const uint16_t idx = (uint16_t)((dbmPepHead + PEP_BUFFER - 1U - i) % PEP_BUFFER);
    if (dbmPepBlocks[idx] > maximum) maximum = dbmPepBlocks[idx];
  }
  dbmPepMw = maximum;

  // Watt/SWR presentation gate uses NET delivered power for both hysteresis
  // edges. A strong external station can raise both directional detectors, but
  // without net transmitter power it cannot keep the meter falsely in RF mode.
  if (display_rf_active)
  {
    if (rfAverageMw <= DISPLAY_RF_OFF_THRESHOLD_MW)
      display_rf_active = false;
  }
  else if (rfAverageMw >= DISPLAY_RF_ON_THRESHOLD_MW)
  {
    display_rf_active = true;
  }

  if (display_rf_active)
  {
    display_pep_armed = true;
  }
  else if (display_pep_armed &&
           (!isfinite(power_mw_pep) ||
            power_mw_pep <= DISPLAY_RF_OFF_THRESHOLD_MW))
  {
    // V1.19.1 fix: no stray near-zero PEP marker after genuine PEP expires.
    display_pep_armed = false;
  }

  if (!display_rf_active)
  {
    // If an SWR alarm is latched, keep the last valid SWR visible after RF
    // disappears.  The alarm message and SWR value therefore remain as the
    // operator saw them until the normal alarm acknowledge/reset clears the
    // latch.  With no active alarm, retain the normal no-RF 1.00 display.
    if (!flag.swr_alarm)
    {
      display_swr = 1.0;
      display_swr_bar = 0;
    }
  }
  else
  {
    display_swr = swr_avg;
    if (!isfinite(display_swr) || display_swr < 1.0) display_swr = 1.0;
    display_swr_bar = swr_bar;
  }
}

void lcd_display_clean(const char * /*introtext*/, const char * /*indicator*/, double power)
{
  if (display_off_active) return;
  if (screensaver_active)
  {
    renderScreensaver();
    return;
  }

  lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
  beginFrame();

  // Fetch the most recently finalized 100 ms block before choosing the small
  // PK value. During the deliberately rejected START block, PEP history is not
  // yet valid and the live peak path can contain the detector key-up overshoot.
  // Suppress that one incomplete START window on the display as well. The first
  // complete RF block then enables both HERO and PK together.
  PepDebugSnapshot md = {};
  const bool haveMeasurement = pswr_get_pep_debug_snapshot(md);
  const bool startWindowInvalid =
    haveMeasurement && md.tx_start_event && (md.pep_window == 0);

  // V3.102: the small PK field is explicitly a finalized 100 ms Peak readout.
  // Normally it comes from md.pk_mw.  One exception is the first complete block
  // that still overlaps the 100 ms key-down/detector-settling guard.  Measurement
  // already validates that block for PEP by substituting its completed average
  // (md.pep_input_mw) for the transient-contaminated peak.  Use that SAME guarded
  // value for the small PK field so the display cannot flash a 113/131 W turn-on
  // spike while HERO correctly shows about 96/100 W.  After the startup guard,
  // PK continues to use the ordinary finalized 100 ms peak.  START itself remains
  // suppressed until the first complete block is available.
  double rawPkMw = 0.0;
  if (display_rf_active && !startWindowInvalid)
  {
    if (haveMeasurement)
    {
      const bool guardedFirstCompleteBlock =
        md.startup_guard && !md.tx_start_event && (md.pep_input_mw > 0.0);
      rawPkMw = guardedFirstCompleteBlock ? md.pep_input_mw : md.pk_mw;
    }
    else
    {
      rawPkMw = power;
    }

    if (!isfinite(rawPkMw) || rawPkMw < 0.0) rawPkMw = 0.0;
  }
  const double liveMw = heldPkForDisplay(rawPkMw);
  const double pepMw = display_pep_armed ? power_mw_pep : 0.0;
  const double scale = powerBarScale((pepMw > liveMw) ? pepMw : liveMw);

  char pkText[12], pepText[12], swrText[12];
  formatPower(liveMw, pkText, sizeof(pkText));
  formatPower(pepMw, pepText, sizeof(pepText));
  formatSwr(swrText, sizeof(swrText));

  // Capture EVERY actual Power-screen frame, not merely frames that happen to
  // coincide with publication of a new 100 ms measurement block. This closes
  // the diagnostic gap that could miss a one-frame wrong hero value.

  display_pep_debug_snapshot.frame_sequence++;
  if (display_pep_debug_snapshot.frame_sequence == 0)
    display_pep_debug_snapshot.frame_sequence = 1; // reserve zero as "no frame yet"

  display_pep_debug_snapshot.frame_millis = millis();
  display_pep_debug_snapshot.measurement_sequence = haveMeasurement ? md.sequence : 0;
  display_pep_debug_snapshot.dsp_pep_mw = pepMw;
  display_pep_debug_snapshot.dsp_pk_mw = liveMw;
  display_pep_debug_snapshot.global_pep_mw = power_mw_pep;
  display_pep_debug_snapshot.global_pep_db = power_db_pep;
  display_pep_debug_snapshot.armed = display_pep_armed;
  display_pep_debug_snapshot.rf_active = display_rf_active;

  strncpy(display_pep_debug_snapshot.pep_text, pepText,
          sizeof(display_pep_debug_snapshot.pep_text));
  display_pep_debug_snapshot.pep_text[sizeof(display_pep_debug_snapshot.pep_text) - 1] = '\0';

  strncpy(display_pep_debug_snapshot.pk_text, pkText,
          sizeof(display_pep_debug_snapshot.pk_text));
  display_pep_debug_snapshot.pk_text[sizeof(display_pep_debug_snapshot.pk_text) - 1] = '\0';

  // V2.12: hero layout.
  drawPowerSwrHero(pepText, swrText, pkText);

  // Common SWR alarm indication on all normal measurement screens.
  drawSwrAlarmStatus();

  // V2.13: slimmer/narrower power bar, moved upward to free a bottom status line.
  drawHorizontalBar(12, 41, 232, 8, liveMw, scale, pepMw);

  // Bottom line now carries the remaining useful operating information.
  drawPowerBottomStatus(scale);

  endFrame();
}

void lcd_display_clean_dBm(void)
{
  if (display_off_active) return;
  if (screensaver_active)
  {
    renderScreensaver();
    return;
  }

  lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
  beginFrame();

  char liveText[16], pepText[16], swrText[12];
  formatDbm(display_dbm_mw, liveText, sizeof(liveText));
  formatDbm(dbmPepMw, pepText, sizeof(pepText));
  formatSwr(swrText, sizeof(swrText));

  // V2.14: use exactly the same hero composition as the main Power screen:
  // large LIVE dBm at upper-left, equally large SWR at upper-right,
  // subdued PEP dBm underneath, slim bar, and the standard bottom status.
  drawPowerSwrHero(liveText, swrText, pepText);
  drawSwrAlarmStatus();

  const double scale =
    powerBarScale((dbmPepMw > display_dbm_mw) ? dbmPepMw : display_dbm_mw);

  drawHorizontalBar(12, 41, 232, 8, display_dbm_mw, scale, dbmPepMw);
  drawPowerBottomStatus(scale);

  endFrame();
}

void lcd_display_fwd_rev(void)
{
  if (display_off_active) return;
  if (screensaver_active)
  {
    renderScreensaver();
    return;
  }

  lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
  beginFrame();

  const double fwdMw = display_rf_active ? displayFwdMw : 0.0;
  const double revMw = display_rf_active ? displayRevMw : 0.0;
  const double scale = powerBarScale((fwdMw > revMw) ? fwdMw : revMw);

  char fwdText[12], revText[12], swrText[12];
  formatPower(fwdMw, fwdText, sizeof(fwdText));
  formatPower(revMw, revText, sizeof(revText));
  formatSwr(swrText, sizeof(swrText));

  // V2.15: same hero composition as Power and LIVE dBm.
  drawFwdRevHero(fwdText, swrText, revText);
  drawSwrAlarmStatus();

  // Slim FWD bar with a bright 3-pixel REV marker on the same absolute scale.
  drawHorizontalBar(12, 41, 232, 8, fwdMw, scale);
  drawAbsoluteMarker(12, 41, 232, 8, revMw, scale);

  // The page is live, so the center status says LIVE rather than a PEP period.
  drawFwdRevBottomStatus(scale);

  endFrame();
}

void lcd_display_modscope(void)
{
  if (display_off_active) return;
  if (screensaver_active)
  {
    renderScreensaver();
    return;
  }

  lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
  beginFrame();

  // Header: full coupler name is clearer than the abbreviated C1/C2.
  selectUiFont(u8g2_font_6x12_tf, kDim);
  u8g2.setCursor(2, 10);
  u8g2.print("MOD SCOPE");

  char couplerText[24];
  snprintf(couplerText, sizeof(couplerText), "%s Coupler %u",
           calbanks_active_band_name(), cpl ? 2U : 1U);
  selectUiFont(u8g2_font_6x10_tf, kDim);
  uiPrintRight(254, 10, couplerText);
  lcd.drawFastHLine(0, 13, kDisplayW, kLine);

  // V3.22: keep the complete fast ModScope history, but compress it into a
  // narrower graph so the right side can carry the same large live Power value
  // used by the normal Power screen.
  constexpr int16_t graphX = 4;
  constexpr int16_t graphY = 18;
  constexpr int16_t graphW = 156;
  constexpr int16_t graphH = 37;
  constexpr int16_t centerY = graphY + graphH / 2;
  constexpr int16_t halfHeight = 16;

  // Scope frame occupies the left side. The right side intentionally remains
  // open, like the normal hero-value screens.
  lcd.drawRect(2, 17, 160, 37, kDim);
  constexpr uint8_t kModScopeCenterLine = 0x02;
  lcd.drawFastHLine(graphX, centerY, graphW, kModScopeCenterLine);

  float samples[MODSCOPE_POINTS];
  float peakAmplitude = 0.0f;
  modscope_snapshot(samples, MODSCOPE_POINTS, peakAmplitude);

  // Do not auto-zoom detector noise to full height. At low/no RF the minimum
  // scale corresponds to four times the configured noise-floor power.
  float minFullScale = 0.0f;
  if (NOISE_FLOOR_MW > 0.0f)
    minFullScale = sqrtf(NOISE_FLOOR_MW * 4.0f);

  float fullScale = peakAmplitude;
  if (fullScale < minFullScale) fullScale = minFullScale;
  if (fullScale < 1.0e-6f) fullScale = 1.0f;

  const bool rfSeen =
    (peakAmplitude > 0.0f) &&
    ((peakAmplitude * peakAmplitude) >= NOISE_FLOOR_MW);

  if (rfSeen)
  {
    // Preserve all 248 fast samples. Each visible x-column represents the
    // strongest sample in its corresponding slice of the full history.
    for (int16_t xPix = 0; xPix < graphW; ++xPix)
    {
      uint16_t first = (uint16_t)(((uint32_t)xPix * MODSCOPE_POINTS) / graphW);
      uint16_t last = (uint16_t)(((uint32_t)(xPix + 1) * MODSCOPE_POINTS) / graphW);
      if (last <= first) last = first + 1;
      if (last > MODSCOPE_POINTS) last = MODSCOPE_POINTS;

      float columnPeak = 0.0f;
      for (uint16_t i = first; i < last; ++i)
      {
        if (samples[i] > columnPeak) columnPeak = samples[i];
      }

      float n = columnPeak / fullScale;
      if (n < 0.0f) n = 0.0f;
      if (n > 1.0f) n = 1.0f;

      int16_t h = (int16_t)lroundf(n * (float)halfHeight);
      if (h < 0) h = 0;
      if (h > halfHeight) h = halfHeight;

      // Keep the ModScope trace at one consistent level. The large PEP
      // value is the only bright hero element on this screen.
      lcd.drawFastVLine(graphX + xPix, centerY - h, 2 * h + 1, kMedium);
    }
  }

  // Right-side hero Power value: show the currently selected PEP value.
  // R.PEP_period selects 0.1 s, 1.0 s or 2.0 s; the ModScope waveform itself
  // is completely independent of this display value and remains unchanged.
  const double pepMw = display_pep_armed ? power_mw_pep : 0.0;
  char powerText[12];
  formatPower(pepMw, powerText, sizeof(powerText));

  constexpr int16_t powerPanelX = 169;
  constexpr int16_t powerPanelW = 84;

  // Keep the ModScope PEP value visually consistent: always use Profont22.
  // Do not switch font according to the number of digits.
  selectFont(&Profont22, kBright);
  int16_t powerW = textWidth(powerText);

  int16_t powerX = powerPanelX + (powerPanelW - powerW) / 2;
  if (powerX < powerPanelX) powerX = powerPanelX;
  lcd.setCursor(powerX, 38);
  lcd.print(powerText);

  // Small live SWR readout replaces the old POWER label.  The large value
  // above remains the forward Power indication; this adds useful SWR context
  // without taking any extra ModScope graph space.
  char swrText[12];
  formatSwr(swrText, sizeof(swrText));

  char swrLine[18];
  snprintf(swrLine, sizeof(swrLine), "SWR %s", swrText);

  selectUiFont(u8g2_font_6x10_tf, kDim);
  uiPrintCentered(powerPanelX + powerPanelW / 2, 50, swrLine);

  // ModScope is a live view. Turning selects another live screen; a short
  // encoder-button push exits directly to the normal Power screen.
  selectUiFont(u8g2_font_6x10_tf, kDim);
  u8g2.setCursor(2, 63);
  u8g2.print("TURN = SCREEN");
  selectUiFont(u8g2_font_6x10_tf, kDim);
  uiPrintRight(254, 63, "PUSH = EXIT");

  endFrame();
}

void lcd_display_clock(void)
{
  if (display_off_active) return;

  beginFrame();

  if (!wifi_link_clock_valid())
  {
    selectUiFont(u8g2_font_helvB08_tr, kMedium);
    uiPrintCentered(128, 11, "CLOCK - WAITING FOR NTP");

    selectFont(&Profont29, kBright);
    const char *waiting = "--:--:--";
    lcd.setCursor((kDisplayW - textWidth(waiting)) / 2, 41);
    lcd.print(waiting);

    selectUiFont(u8g2_font_helvR08_tr, kDim);
    uiPrintCentered(128, 60,
                    wifi_link_connected() ? "Synchronizing time..." : "WiFi connection required");
    lcd.display();
    return;
  }

  const bool utcPrimary = (clock_primary_get() == CLOCK_PRIMARY_UTC);
  const char *primaryDate = utcPrimary ? wifi_link_clock_date_utc()
                                       : wifi_link_clock_date_local();
  const char *primaryTime = utcPrimary ? wifi_link_clock_utc()
                                       : wifi_link_clock_local();

  selectUiFont(u8g2_font_helvR08_tr, kNormal);
  u8g2.setCursor(2, 10);
  u8g2.print(primaryDate);

  const char *grid = grid_square_get();
  if (grid && *grid)
  {
    selectUiFont(u8g2_font_helvR08_tr, kDim);
    uiPrintRight(254, 10, grid);
  }

  selectFont(&Profont29, kBright);
  const int16_t primaryTimeW = textWidth(primaryTime);
  const int16_t primaryTimeX = (kDisplayW - primaryTimeW) / 2;
  lcd.setCursor(primaryTimeX, 41);
  lcd.print(primaryTime);

  // Small primary-clock identifier. Keep the large time itself perfectly
  // centered and place UTC/LOC just above/right of it.
  const char *primaryTag = utcPrimary ? "UTC" : "LOC";
  selectUiFont(u8g2_font_helvR08_tr, kNormal);
  int16_t tagX = primaryTimeX + primaryTimeW + 4;
  const int16_t tagW = uiTextWidth(primaryTag);
  if (tagX + tagW > 254) tagX = 254 - tagW;
  if (tagX < 0) tagX = 0;
  u8g2.setCursor(tagX, 30);
  u8g2.print(primaryTag);

  char bottom[40];
  if (utcPrimary)
    snprintf(bottom, sizeof(bottom), "LOCAL %s   %s",
             wifi_link_clock_local(), wifi_link_clock_zone());
  else
    snprintf(bottom, sizeof(bottom), "UTC %s", wifi_link_clock_utc());

  selectUiFont(u8g2_font_helvR08_tr, kWhite);
  uiPrintCentered(128, 61, bottom);

  lcd.display();
}

void lcd_display_debug(uint8_t page)
{
  if (display_off_active) return;
  lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
  beginFrame();

  // V2.16.5.25: three-page graphical diagnostics.
  // Page selection is read-only UI state; all measurement values and algorithms
  // remain untouched.
  if (page > 2) page = 0;

  char textBuf[28];

  // Common header.
  selectUiFont(u8g2_font_6x12_tf, kBright);
  u8g2.setCursor(2, 10);
  u8g2.print("DIAGNOSTICS");

  snprintf(textBuf, sizeof(textBuf), "%u/3 %s C%u",
           (unsigned)(page + 1U), calbanks_active_band_name(), cpl ? 2U : 1U);
  selectUiFont(u8g2_font_6x12_tf, kDim);
  uiPrintRight(254, 10, textBuf);
  lcd.drawFastHLine(0, 13, kDisplayW, kMedium);

  if (page == 0)
  {
    // -----------------------------------------------------------------------
    // PAGE 1: DETECTORS
    // Calibrated dBm is the hero value; raw ADC and detector voltage are kept
    // directly underneath for analog front-end service work.
    // -----------------------------------------------------------------------
    constexpr int16_t cardY = 17;
    constexpr int16_t cardW = 121;
    constexpr int16_t cardH = 38;
    constexpr int16_t fwdX = 4;
    constexpr int16_t revX = 131;

    const auto drawDiagnosticCard = [&](int16_t x,
                                        const char *channel,
                                        int16_t adcCode,
                                        double dbmValue)
    {
      lcd.fillRect(x, cardY, cardW, cardH, kDim);
      lcd.drawRect(x, cardY, cardW, cardH, kWhite);
      lcd.fillRect(x + 1, cardY + 1, cardW - 2, 2, kWhite);

      selectUiFont(u8g2_font_6x10_tf, kBright);
      u8g2.setCursor(x + 5, 28);
      u8g2.print(channel);

      selectUiFont(u8g2_font_6x10_tf, kDim);
      uiPrintRight(x + cardW - 5, 26, "dBm");

      snprintf(textBuf, sizeof(textBuf), "%.1f", dbmValue);
      selectFont(&Profont22, kWhite);
      int16_t heroX = x + (cardW - textWidth(textBuf)) / 2;
      if (heroX < x + 3) heroX = x + 3;
      lcd.setCursor(heroX, 43);
      lcd.print(textBuf);

      const double volts = adc_ref * (double)adcCode / 4096.0;
      snprintf(textBuf, sizeof(textBuf), "ADC %d  %.3fV", (int)adcCode, volts);
      selectUiFont(u8g2_font_6x10_tf, kDim);
      uiPrintCentered(x + cardW / 2, 52, textBuf);
    };

    drawDiagnosticCard(fwdX, "FWD", fwd, ad8307_FdBm);
    drawDiagnosticCard(revX, "REV", rev, ad8307_RdBm);
  }
  else
  {
    // Compact two-column service grid used by pages 2 and 3.
    constexpr int16_t leftX = 4;
    constexpr int16_t rightX = 131;
    constexpr int16_t cellW = 121;
    constexpr int16_t rowY[3] = { 17, 30, 43 };
    constexpr int16_t rowH = 12;

    const auto drawGridCell = [&](int16_t x, int16_t y,
                                  const char *label, const char *value)
    {
      lcd.drawRect(x, y, cellW, rowH, kMedium);

      selectUiFont(u8g2_font_6x10_tf, kDim);
      u8g2.setCursor(x + 4, y + 9);
      u8g2.print(label);

      selectUiFont(u8g2_font_6x10_tf, kBright);
      uiPrintRight(x + cellW - 4, y + 9, value);
    };

    if (page == 1)
    {
      // ---------------------------------------------------------------------
      // PAGE 2: RF VALUES
      // Useful live RF quantities in one glance without changing any of the
      // meter's established calculations or display smoothing.
      // ---------------------------------------------------------------------
      char fwdText[14], revText[14], swrText[12];
      char pkText[14], pepText[14], avgText[14];

      formatPower(fwd_power_mw, fwdText, sizeof(fwdText));
      formatPower(ref_power_mw, revText, sizeof(revText));
      formatSwr(swrText, sizeof(swrText));
      formatPower(power_mw_pk, pkText, sizeof(pkText));
      formatPower(power_mw_pep, pepText, sizeof(pepText));
      formatPower(power_mw_1savg, avgText, sizeof(avgText));

      drawGridCell(leftX,  rowY[0], "FWD",  fwdText);
      drawGridCell(rightX, rowY[0], "REV",  revText);
      drawGridCell(leftX,  rowY[1], "SWR",  swrText);
      drawGridCell(rightX, rowY[1], "PK",   pkText);
      drawGridCell(leftX,  rowY[2], "PEP",  pepText);
      drawGridCell(rightX, rowY[2], "AVG1", avgText);
    }
    else
    {
      // ---------------------------------------------------------------------
      // PAGE 3: ADC HEALTH
      // These counters already exist for USB $addebug; showing them here makes
      // the front panel far more useful for service/installation diagnostics.
      // ---------------------------------------------------------------------
      char missedText[16], errorText[16];
      char fwdAdcText[12], revAdcText[12];
      char vrefText[12], i2cText[12];

      snprintf(missedText, sizeof(missedText), "%lu",
               (unsigned long)pswr_get_missed_samples());
      snprintf(errorText, sizeof(errorText), "%lu",
               (unsigned long)pswr_get_adc_read_errors());
      snprintf(fwdAdcText, sizeof(fwdAdcText), "%d", (int)fwd);
      snprintf(revAdcText, sizeof(revAdcText), "%d", (int)rev);
      snprintf(vrefText, sizeof(vrefText), "%.3fV", adc_ref);
      snprintf(i2cText, sizeof(i2cText), "%.1fMHz",
               (double)I2C_HS_DATA_CLOCK_HZ / 1000000.0);

      drawGridCell(leftX,  rowY[0], "MISSED", missedText);
      drawGridCell(rightX, rowY[0], "ERRORS", errorText);
      drawGridCell(leftX,  rowY[1], "FWD ADC", fwdAdcText);
      drawGridCell(rightX, rowY[1], "REV ADC", revAdcText);
      drawGridCell(leftX,  rowY[2], "VREF", vrefText);
      drawGridCell(rightX, rowY[2], "HS-I2C", i2cText);
    }
  }

  // Common page navigation / exit footer.
  selectUiFont(u8g2_font_6x10_tf, kDim);
  u8g2.setCursor(2, 63);
  u8g2.print("TURN = PAGE");
  uiPrintRight(254, 63, "PUSH = EXIT");

  endFrame();
}
