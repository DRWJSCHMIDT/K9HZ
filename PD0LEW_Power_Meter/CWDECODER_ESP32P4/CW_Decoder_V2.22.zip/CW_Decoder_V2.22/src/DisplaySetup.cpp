
#include "DisplaySetup.h"
#include "DisplayColors.h"

#include <Arduino.h>
#include <lvgl.h>
#include <esp_heap_caps.h>

#include "Waveshare_HX8394_DSI.h"
#include <TAMC_GT911.h>
#include "Adafruit_GFX.h"

// -----------------------------------------------------------------------------
// Hardware configuration
// -----------------------------------------------------------------------------

namespace {

constexpr int32_t TOUCH_INT = -1;
constexpr int32_t TOUCH_RST = -1;
constexpr int32_t TOUCH_SDA = 7;
constexpr int32_t TOUCH_SCL = 8;

constexpr int32_t SCREEN_WIDTH  = 1280;
constexpr int32_t SCREEN_HEIGHT = 720;

constexpr uint8_t DISPLAY_ROTATION = 3;
constexpr uint8_t DEFAULT_BRIGHTNESS = 254;

/*
 * Number of display lines held in the partial LVGL buffer.
 *
 * 1280 pixels × 40 lines × 2 bytes = approximately 100 kB.
 */
constexpr uint32_t LVGL_BUFFER_LINES = 40;

// V1.95: keep the proven LVGL allocator. Do not attach an extra PSRAM
// pool at runtime; this target/library combination rejects lv_mem_add_pool().

constexpr uint32_t TOUCH_PRINT_INTERVAL_MS = 50;

// -----------------------------------------------------------------------------
// Hardware objects
// -----------------------------------------------------------------------------

TAMC_GT911 touchController(
  TOUCH_SDA,
  TOUCH_SCL,
  TOUCH_INT,
  TOUCH_RST,
  SCREEN_HEIGHT,
  SCREEN_WIDTH
);

Waveshare_HX8394_DSI displayDriver;

Arduino_DSI_Display *graphics = nullptr;

// -----------------------------------------------------------------------------
// LVGL objects
// -----------------------------------------------------------------------------

lv_display_t *lvglDisplay = nullptr;
lv_indev_t   *lvglTouchDevice = nullptr;
lv_color_t   *lvglBuffer = nullptr;

uint32_t previousLvglMillis = 0;

bool touchDebugEnabled = false;
uint32_t previousTouchPrintMillis = 0;
volatile bool touchActivityPending = false;

// -----------------------------------------------------------------------------
// Fatal error helper
// -----------------------------------------------------------------------------

void stopWithError(const char *message) {
  Serial.println();
  Serial.print("FATAL: ");
  Serial.println(message);

  while (true) {
    delay(1000);
  }
}

// -----------------------------------------------------------------------------
// LVGL display flush callback
// -----------------------------------------------------------------------------

void displayFlushCallback(
  lv_display_t *display,
  const lv_area_t *area,
  uint8_t *pixelMap
) {
  if (!graphics || !area || !pixelMap) {
    lv_display_flush_ready(display);
    return;
  }

  const int32_t width =
    area->x2 - area->x1 + 1;

  const int32_t height =
    area->y2 - area->y1 + 1;

  graphics->draw16bitRGBBitmap(
    area->x1,
    area->y1,
    reinterpret_cast<uint16_t *>(pixelMap),
    width,
    height
  );

  lv_display_flush_ready(display);
}

// -----------------------------------------------------------------------------
// LVGL touch callback
// -----------------------------------------------------------------------------

void touchReadCallback(
  lv_indev_t *inputDevice,
  lv_indev_data_t *data
) {
  (void)inputDevice;

  int32_t x = 0;
  int32_t y = 0;

  if (DisplaySetup::getTouch(x, y)) {
    // Keep the proven V1.6 touch behavior.  Only record activity here.
    // Never change brightness or navigate screens from the input callback.
    touchActivityPending = true;
    data->state = LV_INDEV_STATE_PRESSED;
    data->point.x = x;
    data->point.y = y;
  } else {
    data->state = LV_INDEV_STATE_RELEASED;
  }
}

}  // namespace

// =============================================================================
// Public functions
// =============================================================================

namespace DisplaySetup {

bool begin() {
  Serial.println();
  Serial.println("Initializing display, LVGL and GT911 touch");

  // ---------------------------------------------------------------------------
  // Initialize the Waveshare display
  // ---------------------------------------------------------------------------

  if (!displayDriver.begin(DISPLAY_ROTATION)) {
    Serial.println("Display initialization failed");
    return false;
  }

  graphics = displayDriver.gfx();

  if (!graphics) {
    Serial.println("Unable to obtain display graphics object");
    return false;
  }

  displayDriver.setBrightness(DEFAULT_BRIGHTNESS);

  // ---------------------------------------------------------------------------
  // Initialize touchscreen
  // ---------------------------------------------------------------------------

  touchController.begin();
  touchController.setRotation(DISPLAY_ROTATION);

  // ---------------------------------------------------------------------------
  // Initialize LVGL
  // ---------------------------------------------------------------------------

  lv_init();

  // V1.95: use the same LVGL allocator configuration as the proven SAFE2
  // releases. Setup navigation safety is handled in CWUI by deferring page
  // changes until after the LVGL event callback has returned.

  const size_t bufferSize =
    SCREEN_WIDTH *
    LVGL_BUFFER_LINES *
    sizeof(lv_color_t);

  lvglBuffer = static_cast<lv_color_t *>(
    heap_caps_malloc(
      bufferSize,
      MALLOC_CAP_SPIRAM |
      MALLOC_CAP_8BIT
    )
  );

  if (!lvglBuffer) {
    Serial.println("LVGL PSRAM buffer allocation failed");
    return false;
  }

  Serial.printf(
    "LVGL buffer allocated: %u bytes\n",
    static_cast<unsigned>(bufferSize)
  );

  // ---------------------------------------------------------------------------
  // Create LVGL display
  // ---------------------------------------------------------------------------

  lvglDisplay = lv_display_create(
    SCREEN_WIDTH,
    SCREEN_HEIGHT
  );

  if (!lvglDisplay) {
    Serial.println("LVGL display creation failed");
    return false;
  }

  lv_display_set_color_format(
    lvglDisplay,
    LV_COLOR_FORMAT_RGB565
  );

  lv_display_set_flush_cb(
    lvglDisplay,
    displayFlushCallback
  );

  lv_display_set_buffers(
    lvglDisplay,
    lvglBuffer,
    nullptr,
    bufferSize,
    LV_DISPLAY_RENDER_MODE_PARTIAL
  );

  // ---------------------------------------------------------------------------
  // Create LVGL touch input device
  // ---------------------------------------------------------------------------

  lvglTouchDevice = lv_indev_create();

  if (!lvglTouchDevice) {
    Serial.println("LVGL input-device creation failed");
    return false;
  }

  lv_indev_set_type(
    lvglTouchDevice,
    LV_INDEV_TYPE_POINTER
  );

  lv_indev_set_read_cb(
    lvglTouchDevice,
    touchReadCallback
  );

  previousLvglMillis = millis();

  Serial.println("Display setup complete");

  return true;
}

void update() {
  const uint32_t currentMillis = millis();
  const uint32_t elapsedMillis =
    currentMillis - previousLvglMillis;

  previousLvglMillis = currentMillis;

  if (elapsedMillis > 0) {
    lv_tick_inc(elapsedMillis);
  }

  lv_timer_handler();

  /*
   * Give the ESP32 scheduler a small opportunity to run other tasks.
   */
  //delay(2);
}

void setBrightness(uint8_t brightness) {
  displayDriver.setBrightness(brightness);
}

bool getTouch(int32_t &x, int32_t &y) {
  touchController.read();

  if (!touchController.isTouched) {
    return false;
  }

  x = touchController.points[0].y;
  y = SCREEN_HEIGHT - touchController.points[0].x;

  x = constrain(
    x,
    static_cast<int32_t>(0),
    SCREEN_WIDTH - 1
  );

  y = constrain(
    y,
    static_cast<int32_t>(0),
    SCREEN_HEIGHT - 1
  );

  if (touchDebugEnabled) {
    const uint32_t currentMillis = millis();

    if (
      currentMillis - previousTouchPrintMillis >=
      TOUCH_PRINT_INTERVAL_MS
    ) {
      previousTouchPrintMillis = currentMillis;

      Serial.printf(
        "Touch: X=%ld Y=%ld\n",
        static_cast<long>(x),
        static_cast<long>(y)
      );
    }
  }

  return true;
}

bool consumeTouchActivity() {
  const bool wasTouched = touchActivityPending;
  touchActivityPending = false;
  return wasTouched;
}

void applyScreenStyle(lv_obj_t *screen) {
  if (screen == nullptr) {
    return;
  }

  lv_obj_set_style_bg_color(
    screen,
    DisplayColors::Background(),
    LV_PART_MAIN
  );

  lv_obj_set_style_bg_opa(
    screen,
    LV_OPA_COVER,
    LV_PART_MAIN
  );

  lv_obj_clear_flag(
    screen,
    LV_OBJ_FLAG_SCROLLABLE
  );
}

void enableTouchDebug(bool enabled) {
  touchDebugEnabled = enabled;
}

void waitForTouchRelease() {
  if (lvglTouchDevice) lv_indev_wait_release(lvglTouchDevice);
}

}  // namespace DisplaySetup