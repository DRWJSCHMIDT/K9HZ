#pragma once

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

extern TaskHandle_t gSseTaskHandle;

// Task function
void sseTask(void* param);

// Helper to start the task
void startSseClient();