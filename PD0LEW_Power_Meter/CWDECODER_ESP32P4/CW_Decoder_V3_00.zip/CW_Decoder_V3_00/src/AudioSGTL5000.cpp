#include "AudioSGTL5000.h"
#include <math.h>

namespace {
constexpr uint16_t CHIP_ID            = 0x0000;
constexpr uint16_t CHIP_DIG_POWER     = 0x0002;
constexpr uint16_t CHIP_CLK_CTRL      = 0x0004;
constexpr uint16_t CHIP_I2S_CTRL      = 0x0006;
constexpr uint16_t CHIP_SSS_CTRL      = 0x000A;
constexpr uint16_t CHIP_ADCDAC_CTRL   = 0x000E;
constexpr uint16_t CHIP_DAC_VOL       = 0x0010;
constexpr uint16_t CHIP_ANA_ADC_CTRL  = 0x0020;
constexpr uint16_t CHIP_ANA_HP_CTRL   = 0x0022;
constexpr uint16_t CHIP_ANA_CTRL      = 0x0024;
constexpr uint16_t CHIP_LINREG_CTRL   = 0x0026;
constexpr uint16_t CHIP_REF_CTRL      = 0x0028;
constexpr uint16_t CHIP_LINE_OUT_CTRL = 0x002C;
constexpr uint16_t CHIP_LINE_OUT_VOL  = 0x002E;
constexpr uint16_t CHIP_ANA_POWER     = 0x0030;
constexpr uint16_t CHIP_SHORT_CTRL    = 0x003C;
}

AudioSGTL5000::AudioSGTL5000(TwoWire &wire, uint8_t address)
  : _wire(wire), _address(address) {}

bool AudioSGTL5000::readReg(uint16_t reg, uint16_t &value) {
  _wire.beginTransmission(_address);
  _wire.write(static_cast<uint8_t>(reg >> 8));
  _wire.write(static_cast<uint8_t>(reg & 0xFF));
  if (_wire.endTransmission(false) != 0) return false;

  if (_wire.requestFrom(static_cast<int>(_address), 2) != 2) return false;
  value = static_cast<uint16_t>(_wire.read()) << 8;
  value |= static_cast<uint16_t>(_wire.read());
  return true;
}

bool AudioSGTL5000::writeReg(uint16_t reg, uint16_t value) {
  _wire.beginTransmission(_address);
  _wire.write(static_cast<uint8_t>(reg >> 8));
  _wire.write(static_cast<uint8_t>(reg & 0xFF));
  _wire.write(static_cast<uint8_t>(value >> 8));
  _wire.write(static_cast<uint8_t>(value & 0xFF));
  return _wire.endTransmission() == 0;
}

bool AudioSGTL5000::modifyReg(uint16_t reg, uint16_t value, uint16_t mask) {
  uint16_t current = 0;
  if (!readReg(reg, current)) return false;
  return writeReg(reg, static_cast<uint16_t>((current & ~mask) | (value & mask)));
}

bool AudioSGTL5000::isPresent() {
  uint16_t id = 0;
  if (!readReg(CHIP_ID, id)) return false;
  return (id & 0xFF00U) == 0xA000U;
}

uint16_t AudioSGTL5000::chipId() {
  uint16_t id = 0;
  readReg(CHIP_ID, id);
  return id;
}

bool AudioSGTL5000::setSampleRate(uint32_t sampleRateHz) {
  if (sampleRateHz != 48000 && sampleRateHz != 96000) return false;
  const uint16_t clkCtrl = (sampleRateHz == 48000) ? 0x0008 : 0x000C;
  return writeReg(CHIP_CLK_CTRL, clkCtrl);
}

bool AudioSGTL5000::beginLineIn(uint32_t sampleRateHz) {
  // V1.90 test mode: both rates use the same proven PJRC SGTL5000 sequence.
  // Only SYS_FS and the ESP32-P4 I2S clock change:
  //   48 kHz -> 12.288 MHz MCLK, CHIP_CLK_CTRL 0x0008
  //   96 kHz -> 24.576 MHz MCLK, CHIP_CLK_CTRL 0x000C
  // ESP32-P4 is I2S master and the SGTL5000 remains I2S slave.
  if (sampleRateHz != 48000 && sampleRateHz != 96000) return false;
  if (!isPresent()) return false;

  bool ok = true;
  ok &= writeReg(CHIP_ANA_POWER, 0x4060);      // external VDDD on PJRC adapter
  ok &= writeReg(CHIP_LINREG_CTRL, 0x006C);   // 3.3 V VDDA/VDDIO arrangement
  ok &= writeReg(CHIP_REF_CTRL, 0x01F2);
  ok &= writeReg(CHIP_LINE_OUT_CTRL, 0x0F22);
  ok &= writeReg(CHIP_SHORT_CTRL, 0x4446);
  ok &= writeReg(CHIP_ANA_CTRL, 0x0137);
  if (!ok) return false;

  ok &= writeReg(CHIP_ANA_POWER, 0x40FF);      // power analog blocks
  ok &= writeReg(CHIP_DIG_POWER, 0x0073);      // ADC/DAC + I2S in/out
  if (!ok) return false;

  delay(400);                                  // allow VAG ramp

  ok &= writeReg(CHIP_LINE_OUT_VOL, 0x1D1D);
  ok &= setSampleRate(sampleRateHz);             // SYS_FS=48/96 kHz, MCLK=256*Fs
  // Use PJRC's normal SGTL5000 framing: 64 BCLKs per LRCLK.
  // Audio remains 16-bit, but each channel occupies a 32-bit I2S slot.
  // This is the long-proven format used by the Teensy Audio Library.
  ok &= writeReg(CHIP_I2S_CTRL, 0x0030);       // slave, 16-bit data, Philips I2S, 64*Fs BCLK
  ok &= writeReg(CHIP_SSS_CTRL, 0x0010);       // ADC -> I2S OUT, I2S IN -> DAC
  ok &= writeReg(CHIP_ADCDAC_CTRL, 0x0000);    // ADC HPF normal, DAC unmuted
  ok &= writeReg(CHIP_DAC_VOL, 0x3C3C);        // DAC digital gain 0 dB
  ok &= writeReg(CHIP_ANA_HP_CTRL, 0x7F7F);    // headphone minimum before enable

  _anaCtrl = 0x0036;
  ok &= writeReg(CHIP_ANA_CTRL, _anaCtrl);
  ok &= selectLineIn();
  ok &= setLineInLevel(_lineInLevel);
  ok &= setHeadphoneMute(true);                 // safe power-up default
  return ok;
}

bool AudioSGTL5000::selectLineIn() {
  // SELECT_ADC bit 2 = 1. Clear ADC mute bit 0.
  _anaCtrl = static_cast<uint16_t>((_anaCtrl | (1U << 2)) & ~(1U << 0));
  return writeReg(CHIP_ANA_CTRL, _anaCtrl);
}

bool AudioSGTL5000::selectMicIn() {
  _anaCtrl = static_cast<uint16_t>(_anaCtrl & ~(1U << 2));
  _anaCtrl = static_cast<uint16_t>(_anaCtrl & ~(1U << 0));
  return writeReg(CHIP_ANA_CTRL, _anaCtrl);
}

bool AudioSGTL5000::setLineInLevel(uint8_t left, uint8_t right) {
  if (left > 15) left = 15;
  if (right > 15) right = 15;
  _lineInLevel = left;
  return writeReg(CHIP_ANA_ADC_CTRL, static_cast<uint16_t>((left << 4) | right));
}

bool AudioSGTL5000::setLineInGainIndex(uint8_t index) {
  if (index > 19) index = 19;
  _lineInGainIndex = index;

  // SGTL5000 ADC analog gain is 0..+22.5 dB in 1.5 dB steps.
  // CHIP_ANA_ADC_CTRL bit 8 shifts the entire range down by 6 dB.
  // Map the four negative settings through the -6 dB range, then use the
  // normal range for 0..+22.5 dB. Both channels are changed together.
  bool minus6Range = index < 4;
  uint8_t code = minus6Range ? index : static_cast<uint8_t>(index - 4);
  if (code > 15) code = 15;
  _lineInLevel = code;
  const uint16_t reg = static_cast<uint16_t>((minus6Range ? 0x0100U : 0x0000U) |
                                              (static_cast<uint16_t>(code) << 4) | code);
  return writeReg(CHIP_ANA_ADC_CTRL, reg);
}

bool AudioSGTL5000::setHeadphoneVolume(float volume01) {
  volume01 = constrain(volume01, 0.0f, 1.0f);
  // Match PJRC AudioControlSGTL5000::volume() semantics.
  // 0.0 -> 0x7F (-51.5 dB), 1.0 -> 0x00 (+12 dB).
  // This is intentionally the same scale users of the Teensy Audio Library know.
  const uint8_t amount = static_cast<uint8_t>(lroundf(volume01 * 127.0f));
  const uint8_t reg = static_cast<uint8_t>(0x7F - amount);
  return writeReg(CHIP_ANA_HP_CTRL, static_cast<uint16_t>(reg | (reg << 8)));
}


bool AudioSGTL5000::setHeadphoneSourceLineIn(bool directLineIn) {
  // CHIP_ANA_CTRL bit 6 SELECT_HP:
  //   0 = DAC
  //   1 = direct stereo LINE IN -> headphone amplifier
  // Direct LINE IN bypass is ideal for receiver monitoring because it does not
  // depend on the ESP32 I2S TX path and preserves both L/R channels.
  if (directLineIn) _anaCtrl |= (1U << 6);
  else              _anaCtrl &= ~(1U << 6);
  return writeReg(CHIP_ANA_CTRL, _anaCtrl);
}

bool AudioSGTL5000::setHeadphoneMute(bool mute) {
  if (mute) _anaCtrl |= (1U << 4);
  else      _anaCtrl &= ~(1U << 4);
  return writeReg(CHIP_ANA_CTRL, _anaCtrl);
}


void AudioSGTL5000::dumpAudioRegisters(Stream &out) {
  struct RegItem { uint16_t reg; const char *name; };
  static const RegItem regs[] = {
    {CHIP_ID, "CHIP_ID"},
    {CHIP_DIG_POWER, "CHIP_DIG_POWER"},
    {CHIP_CLK_CTRL, "CHIP_CLK_CTRL"},
    {CHIP_I2S_CTRL, "CHIP_I2S_CTRL"},
    {CHIP_SSS_CTRL, "CHIP_SSS_CTRL"},
    {CHIP_ADCDAC_CTRL, "CHIP_ADCDAC_CTRL"},
    {CHIP_ANA_ADC_CTRL, "CHIP_ANA_ADC_CTRL"},
    {CHIP_ANA_HP_CTRL, "CHIP_ANA_HP_CTRL"},
    {CHIP_ANA_CTRL, "CHIP_ANA_CTRL"},
    {CHIP_ANA_POWER, "CHIP_ANA_POWER"},
  };
  out.println("Audio: SGTL5000 register readback");
  for (const auto &item : regs) {
    uint16_t value = 0;
    if (readReg(item.reg, value)) {
      out.printf("  %-18s 0x%04X\n", item.name, value);
    } else {
      out.printf("  %-18s READ FAILED\n", item.name);
    }
  }
}

bool AudioSGTL5000::setAdcHighPass(bool enabled) {
  // ADCDAC bit 0 = ADC HPF bypass.
  return modifyReg(CHIP_ADCDAC_CTRL, enabled ? 0x0000 : 0x0001, 0x0001);
}
