---
name: Humour / Jokes
about: Humourous issues are allowed, but please follow GitHub's Acceptable Use policies
labels: "Type: Humour"
---
