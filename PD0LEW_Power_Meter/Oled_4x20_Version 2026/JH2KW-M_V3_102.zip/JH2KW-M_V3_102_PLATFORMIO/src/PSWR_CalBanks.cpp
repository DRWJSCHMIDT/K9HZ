/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_CalBanks.h"
#include "PSWR_State.h"
#include "PSWR_Eeprom.h"

#include <EEPROM.h>
#include <math.h>
#include <string.h>

namespace
{
// V3.46 two-coupler store. Keep this definition/address only for seamless
// migration; current firmware never writes the old record.
constexpr int LEGACY_CALBANK_EEPROM_ADDR = 128;
constexpr uint32_t LEGACY_CALBANK_MAGIC = 0x4C4A4342UL; // "LJCB"
constexpr uint8_t LEGACY_CALBANK_VERSION = 1;

struct LegacyCouplerCalibrationStore
{
  uint32_t magic;
  uint8_t version;
  uint8_t reserved[3];
  cal_t cal[2][2];
};

// Callsign lives at 240..275 and Startup Logo at 280..287. The eight-bank
// store starts at 320 and remains in exactly the same location as V3.47+.
constexpr int BAND_CALBANK_EEPROM_ADDR = 320;
constexpr uint32_t BAND_CALBANK_MAGIC = 0x4A483842UL; // "JH8B"
constexpr uint8_t BAND_CALBANK_VERSION_V1 = 1; // V3.47..V3.53, one global band
constexpr uint8_t BAND_CALBANK_VERSION = 2;    // V3.54+, one remembered band per coupler

// Previous V3.47..V3.53 layout. Same total size as the new V2 layout so the
// calibration data can be migrated in place without moving any EEPROM block.
struct BandCalibrationStoreV1
{
  uint32_t magic;
  uint8_t version;
  uint8_t activeBand;
  uint8_t reserved[2];
  cal_t cal[CALBAND_COUNT][CALBANK_COUPLER_COUNT][2];
};

struct BandCalibrationStore
{
  uint32_t magic;
  uint8_t version;
  uint8_t bandForCoupler[CALBANK_COUPLER_COUNT]; // [0]=CPL1, [1]=CPL2
  uint8_t reserved;
  cal_t cal[CALBAND_COUNT][CALBANK_COUPLER_COUNT][2];
};

static_assert(sizeof(cal_t) == 24, "Unexpected cal_t layout");
static_assert(sizeof(LegacyCouplerCalibrationStore) == 104,
              "Unexpected legacy coupler calibration store size");
static_assert(sizeof(BandCalibrationStoreV1) == 392,
              "Unexpected V1 eight-bank calibration store size");
static_assert(sizeof(BandCalibrationStore) == 392,
              "Unexpected V2 eight-bank calibration store size");
static_assert(BAND_CALBANK_EEPROM_ADDR + (int)sizeof(BandCalibrationStore) <= 1024,
              "Eight-bank calibration store exceeds reserved EEPROM range");

BandCalibrationStore store = {};
uint8_t activeCoupler = 0; // 0=CPL1, 1=CPL2

const char * const bandNames[CALBAND_COUNT] = { "HF", "6M", "2M", "70cm" };

bool validCal(const cal_t (&cal)[2])
{
  return isfinite(cal[0].Fwd) && isfinite(cal[0].Rev) &&
         isfinite(cal[1].Fwd) && isfinite(cal[1].Rev) &&
         cal[0].Fwd >= 0.0 && cal[0].Fwd <= 5.0 &&
         cal[0].Rev >= 0.0 && cal[0].Rev <= 5.0 &&
         cal[1].Fwd >= 0.0 && cal[1].Fwd <= 5.0 &&
         cal[1].Rev >= 0.0 && cal[1].Rev <= 5.0 &&
         cal[0].db10m != cal[1].db10m &&
         fabs(cal[0].Fwd - cal[1].Fwd) > 0.001 &&
         fabs(cal[0].Rev - cal[1].Rev) > 0.001;
}

bool allCalibrationBanksValid(const cal_t (&cal)[CALBAND_COUNT][CALBANK_COUPLER_COUNT][2])
{
  for (uint8_t band = 0; band < CALBAND_COUNT; ++band)
    for (uint8_t coupler = 0; coupler < CALBANK_COUPLER_COUNT; ++coupler)
      if (!validCal(cal[band][coupler])) return false;
  return true;
}

bool storeV2Valid(const BandCalibrationStore &candidate)
{
  return candidate.magic == BAND_CALBANK_MAGIC &&
         candidate.version == BAND_CALBANK_VERSION &&
         candidate.bandForCoupler[0] < CALBAND_COUNT &&
         candidate.bandForCoupler[1] < CALBAND_COUNT &&
         allCalibrationBanksValid(candidate.cal);
}

bool storeV1Valid(const BandCalibrationStoreV1 &candidate)
{
  return candidate.magic == BAND_CALBANK_MAGIC &&
         candidate.version == BAND_CALBANK_VERSION_V1 &&
         candidate.activeBand < CALBAND_COUNT &&
         allCalibrationBanksValid(candidate.cal);
}

bool legacyStoreValid(const LegacyCouplerCalibrationStore &candidate)
{
  return candidate.magic == LEGACY_CALBANK_MAGIC &&
         candidate.version == LEGACY_CALBANK_VERSION &&
         validCal(candidate.cal[0]) && validCal(candidate.cal[1]);
}

uint8_t activeBandIndex()
{
  const uint8_t band = store.bandForCoupler[activeCoupler];
  return band < CALBAND_COUNT ? band : (uint8_t)CALBAND_HF;
}

void copyFromR(uint8_t band, uint8_t coupler)
{
  memcpy(store.cal[band][coupler], R.cal_AD, sizeof(R.cal_AD));
}

void copyToR(uint8_t band, uint8_t coupler)
{
  memcpy(R.cal_AD, store.cal[band][coupler], sizeof(R.cal_AD));
}

void seedAllFromR()
{
  for (uint8_t band = 0; band < CALBAND_COUNT; ++band)
    for (uint8_t coupler = 0; coupler < CALBANK_COUPLER_COUNT; ++coupler)
      memcpy(store.cal[band][coupler], R.cal_AD, sizeof(R.cal_AD));
}

void seedFromLegacy(const LegacyCouplerCalibrationStore &legacy)
{
  for (uint8_t band = 0; band < CALBAND_COUNT; ++band)
  {
    memcpy(store.cal[band][0], legacy.cal[0], sizeof(legacy.cal[0]));
    memcpy(store.cal[band][1], legacy.cal[1], sizeof(legacy.cal[1]));
  }
}

void persist()
{
  store.magic = BAND_CALBANK_MAGIC;
  store.version = BAND_CALBANK_VERSION;
  EEPROM_writeAnything(BAND_CALBANK_EEPROM_ADDR, store);
}
}

void calbanks_begin(bool coupler2Active, bool forceReset)
{
  BandCalibrationStore loadedV2 = {};
  EEPROM_readAnything(BAND_CALBANK_EEPROM_ADDR, loadedV2);

  if (!forceReset && storeV2Valid(loadedV2))
  {
    store = loadedV2;
  }
  else
  {
    store = {};
    store.magic = BAND_CALBANK_MAGIC;
    store.version = BAND_CALBANK_VERSION;
    store.bandForCoupler[0] = CALBAND_HF;
    store.bandForCoupler[1] = CALBAND_HF;

    bool migrated = false;

    if (!forceReset)
    {
      // First preference: migrate the V3.47..V3.53 eight-bank record. Keep all
      // eight calibration banks exactly as they are and initialize BOTH
      // couplers to the previously global active band. From this point onward
      // CPL1 and CPL2 remember their own selected band independently.
      BandCalibrationStoreV1 loadedV1 = {};
      EEPROM_readAnything(BAND_CALBANK_EEPROM_ADDR, loadedV1);
      if (storeV1Valid(loadedV1))
      {
        memcpy(store.cal, loadedV1.cal, sizeof(store.cal));
        store.bandForCoupler[0] = loadedV1.activeBand;
        store.bandForCoupler[1] = loadedV1.activeBand;
        migrated = true;
      }
    }

    if (!forceReset && !migrated)
    {
      LegacyCouplerCalibrationStore legacy = {};
      EEPROM_readAnything(LEGACY_CALBANK_EEPROM_ADDR, legacy);
      if (legacyStoreValid(legacy))
      {
        seedFromLegacy(legacy);
        migrated = true;
      }
    }

    if (!migrated)
      seedAllFromR();
  }

  activeCoupler = coupler2Active ? 1U : 0U;
  copyToR(activeBandIndex(), activeCoupler);
  persist();
}

void calbanks_select(bool coupler2Active)
{
  const uint8_t requestedCoupler = coupler2Active ? 1U : 0U;
  if (requestedCoupler == activeCoupler)
    return;

  // Save the current coupler's active band, then switch physical coupler and
  // recall THAT coupler's own remembered band. Example:
  //   CPL1 remembers HF, CPL2 remembers 2M
  //   CPL1 -> CPL2 therefore loads 2M-CPL2 automatically.
  copyFromR(activeBandIndex(), activeCoupler);
  activeCoupler = requestedCoupler;
  copyToR(activeBandIndex(), activeCoupler);
  persist();
}

bool calbanks_select_band(uint8_t bandIndex)
{
  if (bandIndex >= CALBAND_COUNT) return false;
  if (bandIndex == activeBandIndex()) return true;

  // Change the remembered band ONLY for the currently active physical coupler.
  copyFromR(activeBandIndex(), activeCoupler);
  store.bandForCoupler[activeCoupler] = bandIndex;
  copyToR(bandIndex, activeCoupler);
  persist();
  return true;
}

void calbanks_commit_active(void)
{
  copyFromR(activeBandIndex(), activeCoupler);
  persist();
}

uint8_t calbanks_active_number(void)
{
  return (uint8_t)(activeCoupler + 1U);
}

uint8_t calbanks_active_band(void)
{
  return activeBandIndex();
}

const char *calbanks_active_band_name(void)
{
  return bandNames[activeBandIndex()];
}

const char *calbanks_band_name(uint8_t bandIndex)
{
  return bandNames[bandIndex < CALBAND_COUNT ? bandIndex : 0U];
}

bool calbanks_get(uint8_t bankNumber, cal_t (&out)[2])
{
  if (bankNumber < 1U || bankNumber > CALBANK_TOTAL) return false;
  const uint8_t index = (uint8_t)(bankNumber - 1U);
  const uint8_t band = (uint8_t)(index / CALBANK_COUPLER_COUNT);
  const uint8_t coupler = (uint8_t)(index % CALBANK_COUPLER_COUNT);
  memcpy(out, store.cal[band][coupler], sizeof(cal_t) * 2U);
  return true;
}

uint8_t calbanks_bank_band(uint8_t bankNumber)
{
  if (bankNumber < 1U || bankNumber > CALBANK_TOTAL) return 0xffU;
  return (uint8_t)((bankNumber - 1U) / CALBANK_COUPLER_COUNT);
}

uint8_t calbanks_bank_coupler(uint8_t bankNumber)
{
  if (bankNumber < 1U || bankNumber > CALBANK_TOTAL) return 0U;
  return (uint8_t)(((bankNumber - 1U) % CALBANK_COUPLER_COUNT) + 1U);
}
