#include "CWDecoder.cpp"
#include <iostream>
#include <string>
#include <cstdlib>
int main(int argc,char**argv){
 float wpm=argc>1?atof(argv[1]):50;double dot=1.2/wpm;int type=argc>2?atoi(argv[2]):0;int spacing=argc>3?atoi(argv[3]):20;
 CWDecoder::setCwType(type);CWDecoder::setFarnsworthSpacing(spacing);
 CWDecoder::setInputLevelPercent(30);CWDecoder::setFilterBandwidthHz(30);
 CWDecoder::setAutoTone(true);CWDecoder::begin();
 std::string pattern;const char* text="CQ CQ DE PA0TEST HELLO WORLD 12345 ";
 for(const char* c=text;*c;c++) {
  if(*c==' '){pattern+=std::string(type==2?8*spacing/10:4,'0');continue;}
  for(const auto &m:MORSE_TABLE)if(m.value==*c){
   for(const char* a=m.code;*a;a++){pattern+=type==2?(*a=='-'?"111111":"11"):(*a=='-'?"111":"1");pattern+=type==2?"00":"0";}
   pattern+=std::string(type==2?6*spacing/10-2:2,'0');break;
  }
 }
 if(type==2)dot*=0.5;
 double keyedClock=0;int keyedUnit=0;double keyedDuration=dot;uint32_t jitterRng=1234;
 uint32_t rng=12345;unsigned sample=0;int32_t slots[960];
 for(int b=0;b<24000;b++) {
  for(int n=0;n<480;n++,sample++) {
   double t=sample/96000.0;int unit=int((t+0.42)/dot)%pattern.size();
   if(type==1) {
    keyedClock+=1.0/96000;
    if(keyedClock>=keyedDuration){keyedClock-=keyedDuration;++keyedUnit;
      jitterRng=jitterRng*1664525u+1013904223u;
      keyedDuration=dot*(0.85+0.30*double(jitterRng>>8)/16777216.0);}
    unit=keyedUnit%pattern.size();
   }
   rng=rng*1664525u+1013904223u;float noise=(float(rng>>8)/16777216.0f*2-1)*12;
   int16_t v=int16_t((pattern[unit]=='1'?310*sin(2*3.141592653589793*750*t):0)+noise);
   slots[2*n]=slots[2*n+1]=int32_t(v)*65536;
  }
  CWDecoder::processI2S32(slots,480);
 }
 std::cout<<"type="<<type<<" sent="<<wpm<<" learned="<<1200/displayDotMs<<" text="<<decodedText<<"\n";
 return strstr(decodedText,"CQ CQ DE PA0TEST HELLO WORLD 12345") ? 0 : 2;
}
