#ifndef DISPLAY_POWER_H
#define DISPLAY_POWER_H

#include <Arduino.h>

namespace DisplayPower {
void begin(uint8_t brightnessPercent, uint16_t screensaverMinutes);
void update();
void setBrightnessPercent(uint8_t percent);
uint8_t brightnessPercent();
void setScreensaverMinutes(uint16_t minutes);
uint16_t screensaverMinutes();
bool isDimmed();
}

#endif
