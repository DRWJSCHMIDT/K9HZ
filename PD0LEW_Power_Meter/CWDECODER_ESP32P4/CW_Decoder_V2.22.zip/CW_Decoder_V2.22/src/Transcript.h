#pragma once
#include <stddef.h>
#include <stdint.h>

// UI-owned, bounded RAM history. Only the live trailing word can move.
// Earlier completed pages never reflow as text arrives.
// Width is measured by the UI's actual font, avoiding character-count pages.
class Transcript {
public:
  static constexpr size_t kPages = 50;
  static constexpr size_t kLines = 9;
  static constexpr size_t kLineChars = 128;
  static constexpr size_t kPageBytes = kLines * (kLineChars + 1) + 1;
  using Width = int (*)(char);

  void clear() {
    first_ = selected_ = 0; count_ = 1; live_ = true;
    length_ = columns_ = pixels_ = 0; lines_ = 1;
    wrapBeforeWord_ = false;
    pages_[0][0] = '\0';
  }
  Transcript() { clear(); }
  void append(char c, Width width, int maxWidth) {
    if (c == '\r' || (c != '\n' && (c < 32 || c > 126))) return;
    if (c == '\n') { newLine(); return; }
    if (wrapBeforeWord_) {
      if (c == ' ') return;
      newLine();
    }
    const int advance = width(c);
    // Do not start a line/page with a separator or create an empty page because
    // a word space arrives at the right margin.
    if (c == ' ' && !columns_) return;
    if (c == ' ' && (columns_ >= kLineChars || pixels_ + advance > maxWidth)) {
      wrapBeforeWord_ = true;
      return;
    }
    if (columns_ >= kLineChars || (columns_ && pixels_ + advance > maxWidth)) {
      char *tail = pages_[(first_ + count_ - 1) % kPages];
      const size_t lineStart = length_ - columns_;
      size_t wordStart = length_;
      while (wordStart > lineStart && tail[wordStart - 1] != ' ') --wordStart;
      // Move the live word, rather than waiting for its closing space. This
      // preserves immediate character display and works at the ninth line too.
      if (wordStart > lineStart) {
        char word[kLineChars + 1];
        const size_t wordLength = length_ - wordStart;
        int wordPixels = 0;
        for (size_t i = 0; i < wordLength; ++i) {
          word[i] = tail[wordStart + i];
          wordPixels += width(word[i]);
        }
        if (wordLength < kLineChars && wordPixels + advance <= maxWidth) {
          length_ = wordStart;
          while (length_ > lineStart && tail[length_ - 1] == ' ') --length_;
          tail[length_] = '\0';
          newLine();
          tail = pages_[(first_ + count_ - 1) % kPages];
          for (size_t i = 0; i < wordLength; ++i) tail[length_++] = word[i];
          tail[length_] = '\0';
          columns_ = wordLength;
          pixels_ = wordPixels;
        } else newLine();
      } else {
        // An uninterrupted token wider than an entire line must be split to
        // keep every character visible and bound storage (e.g. noise/garbage).
        newLine();
      }
    }
    char *p = pages_[(first_ + count_ - 1) % kPages];
    p[length_++] = c; p[length_] = '\0';
    ++columns_; pixels_ += advance;
  }
  void previous() { live_ = false; if (selected_) --selected_; }
  void next() { if (selected_ + 1 < count_) ++selected_; live_ = selected_ + 1 == count_; }
  void goLive() { selected_ = count_ - 1; live_ = true; }
  bool live() const { return live_; }
  size_t selected() const { return selected_; }
  size_t count() const { return count_; }
  const char *page(size_t index) const { return pages_[(first_ + index) % kPages]; }
  const char *current() const { return page(selected_); }

private:
  void newLine() {
    wrapBeforeWord_ = false;
    columns_ = pixels_ = 0;
    if (lines_ < kLines) {
      char *p = pages_[(first_ + count_ - 1) % kPages];
      p[length_++] = '\n'; p[length_] = '\0'; ++lines_;
      return;
    }
    if (count_ < kPages) ++count_;
    else {
      first_ = (first_ + 1) % kPages;
      if (selected_) --selected_;
    }
    if (live_) selected_ = count_ - 1;
    length_ = 0; lines_ = 1;
    pages_[(first_ + count_ - 1) % kPages][0] = '\0';
  }
  char pages_[kPages][kPageBytes] = {};
  size_t first_ = 0, count_ = 1, selected_ = 0, length_ = 0, columns_ = 0, lines_ = 1;
  int pixels_ = 0;
  bool live_ = true;
  bool wrapBeforeWord_ = false;
};
