#ifndef AUDIO_SGTL5000_H
#define AUDIO_SGTL5000_H

#include <Arduino.h>
#include <Wire.h>

class AudioSGTL5000 {
public:
  static constexpr uint8_t kDefaultAddress = 0x0A;

  explicit AudioSGTL5000(TwoWire &wire = Wire, uint8_t address = kDefaultAddress);

  bool beginLineIn(uint32_t sampleRateHz);
  bool setSampleRate(uint32_t sampleRateHz);
  bool begin48kLineIn() { return beginLineIn(48000); }
  bool begin96kLineIn() { return beginLineIn(96000); }
  bool isPresent();
  uint16_t chipId();
  void dumpAudioRegisters(Stream &out);

  bool selectLineIn();
  bool selectMicIn();
  bool setLineInLevel(uint8_t left, uint8_t right);
  bool setLineInLevel(uint8_t level) { return setLineInLevel(level, level); }
  uint8_t lineInLevel() const { return _lineInLevel; }
  // 20 analog gain positions: index 0..19 = -6.0..+22.5 dB in 1.5 dB steps.
  bool setLineInGainIndex(uint8_t index);
  uint8_t lineInGainIndex() const { return _lineInGainIndex; }

  bool setHeadphoneVolume(float volume01);
  bool setHeadphoneMute(bool mute);
  bool setHeadphoneSourceLineIn(bool directLineIn);
  bool setAdcHighPass(bool enabled);

private:
  TwoWire &_wire;
  uint8_t _address;
  uint8_t _lineInLevel = 5;
  uint8_t _lineInGainIndex = 4;
  uint16_t _anaCtrl = 0x0036;

  bool writeReg(uint16_t reg, uint16_t value);
  bool readReg(uint16_t reg, uint16_t &value);
  bool modifyReg(uint16_t reg, uint16_t value, uint16_t mask);
};

#endif
