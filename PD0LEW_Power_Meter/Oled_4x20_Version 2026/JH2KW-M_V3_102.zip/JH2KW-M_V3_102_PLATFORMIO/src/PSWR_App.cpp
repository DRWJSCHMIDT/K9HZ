/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_App.h"
#include "PSWR_State.h"
#include "PSWR_Measurement.h"
#include "PSWR_Display.h"
#include "PSWR_Menu.h"
#include "PSWR_USB.h"
#include "PSWR_Eeprom.h"
#include "PSWR_AD7991_HS.h"
#include "PSWR_CalBanks.h"
#include "PSWR_CallSign.h"
#include "PSWR_StartupLogo.h"
#include "PSWR_WiFiConfig.h"
#include "PSWR_WiFiLink.h"
#include "PSWR_Encoder.h"

#include <EEPROM.h>
#include <TimerOne.h>
#include <math.h>

// SSD1322 controller power management. Keep the controller state explicit so
// waking is immediate and displayOn/displayOff are not sent repeatedly.
static void oledWake(void)
{
  if (display_off_active)
  {
    lcd.displayOn();
    display_off_active = false;
    lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
    flag.idle_refresh = true;
  }
}

static void oledPowerOff(void)
{
  if (!display_off_active)
  {
    lcd.displayOff();
    display_off_active = true;
  }
}

// Clock-only brightness protection. This is independent of the normal
// screensaver/display-off timers because Clock mode is intentionally always on.
static bool clock_dim_active = false;
static bool clock_dim_was_clock = false;
static uint32_t clock_dim_last_activity_ms = 0;

static void clockDimRestore(void)
{
  clock_dim_last_activity_ms = millis();
  if (clock_dim_active)
  {
    lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
    clock_dim_active = false;
    flag.idle_refresh = true;
  }
}

static void clockDimService(void)
{
  const bool inClock = (!flag.config_mode && mode_display == POWER_CLOCK &&
                        Menu_exit_timer == 0);

  if (!inClock)
  {
    if (clock_dim_active)
      lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
    clock_dim_active = false;
    clock_dim_was_clock = false;
    return;
  }

  if (!clock_dim_was_clock)
  {
    clock_dim_was_clock = true;
    clock_dim_last_activity_ms = millis();
    lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
    clock_dim_active = false;
  }

  const uint16_t dimMinutes = clock_dim_minutes_get();
  if (dimMinutes == 0)
  {
    if (clock_dim_active)
      lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
    clock_dim_active = false;
    return;
  }

  const uint32_t timeoutMs = (uint32_t)dimMinutes * 60000UL;
  if (!clock_dim_active && (uint32_t)(millis() - clock_dim_last_activity_ms) >= timeoutMs)
  {
    lcd.setContrast(DISPLAY_CONTRAST_CLOCK_DIM);
    clock_dim_active = true;
  }
}

//-----------------------------------------------------------------------------------------
// Validate persistent settings before use.
//-----------------------------------------------------------------------------------------
static void saveDisplayMode(void)
{
  // Remember the selected front-panel screen immediately.
  // EEPROM_writeAnything() compares every byte first, so only the changed
  // mode byte is physically written.
  if (R.mode_display != mode_display)
  {
    R.mode_display = mode_display;
    EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
  }
}

// Clock is the only hardware-dependent live page. Without a XIAO we skip
// mode 5, so the four measurement screens remain the complete live-screen list.
static uint8_t stepLiveMode(uint8_t currentMode, int16_t step)
{
  static const uint8_t modesWithWifi[] =
  {
    POWER_BARPK, POWER_CLEAN_DBM, POWER_FWD_REV, POWER_MOD_SCOPE,
    POWER_CLOCK
  };
  static const uint8_t modesWithoutWifi[] =
  {
    POWER_BARPK, POWER_CLEAN_DBM, POWER_FWD_REV, POWER_MOD_SCOPE
  };

  const bool haveWifi = wifi_link_module_present();
  const uint8_t *modes = haveWifi ? modesWithWifi : modesWithoutWifi;
  const int16_t count = haveWifi
                        ? (int16_t)(sizeof(modesWithWifi) / sizeof(modesWithWifi[0]))
                        : (int16_t)(sizeof(modesWithoutWifi) / sizeof(modesWithoutWifi[0]));

  int16_t index = 0;
  for (int16_t i = 0; i < count; ++i)
  {
    if (modes[i] == currentMode)
    {
      index = i;
      break;
    }
  }

  index += step;
  while (index < 0) index += count;
  while (index >= count) index -= count;
  return modes[index];
}

void sanitizeSettings(void)
{
  if (R.reserved_meter_cal < 10 || R.reserved_meter_cal > 250)
    R.reserved_meter_cal = LEGACY_METER_CAL_DEFAULT;

  if (R.SWR_alarm_trig < 15 || R.SWR_alarm_trig > 40)
    R.SWR_alarm_trig = SWR_ALARM;

  if (R.SWR_alarm_pwr_thresh == 0 || R.SWR_alarm_pwr_thresh > 10000)
    R.SWR_alarm_pwr_thresh = SWR_THRESHOLD;

  R.usb_report_cont = R.usb_report_cont ? 1 : 0;
  if (R.usb_report_type < REPORT_DATA || R.usb_report_type > REPORT_AD_DEBUG)
    R.usb_report_type = REPORT_DATA;

  if (R.PEP_period != 1 && R.PEP_period != 10 && R.PEP_period != 20)
    R.PEP_period = PEP_PERIOD;

  if (R.PK_hold_ms < 100 || R.PK_hold_ms > 2000 || (R.PK_hold_ms % 100) != 0)
    R.PK_hold_ms = PK_HOLD_DEFAULT_MS;

  // Recover safely from corrupt/old scale settings.
  if (R.ScaleRange[0] < 1 || R.ScaleRange[0] > 99 ||
      R.ScaleRange[1] < 1 || R.ScaleRange[2] < 1)
  {
    R.ScaleRange[0] = SCALE_RANGE1;
    R.ScaleRange[1] = SCALE_RANGE2;
    R.ScaleRange[2] = SCALE_RANGE3;
  }
  else
  {
    uint16_t r1 = R.ScaleRange[0];
    uint16_t r2 = R.ScaleRange[1];
    uint16_t r3 = R.ScaleRange[2];
    const uint16_t maxInDecade = (uint16_t)(r1 * 10U - 1U);

    if (r2 < r1) r2 = r1;
    if (r3 < r2) r3 = r2;
    if (r2 > maxInDecade) r2 = maxInDecade;
    if (r3 > maxInDecade) r3 = maxInDecade;
    if (r3 < r2) r3 = r2;

    R.ScaleRange[1] = (uint8_t)r2;
    R.ScaleRange[2] = (uint8_t)r3;
  }

  R.idle_disp[20] = '\0';
  const float t = R.idle_disp_thresh;
  const bool validIdleThreshold = isfinite(t) &&
    (t == 0.0f || t == 0.001f || t == 0.01f || t == 0.1f || t == 1.0f || t == 10.0f);
  if (!validIdleThreshold)
    R.idle_disp_thresh = SLEEPTHRESHOLD;

  // V3.3.5+ uses milliwatts only for the low-power display floor.
  // Legacy uW enum values are retained in var_t solely for EEPROM layout compatibility.
  if (R.low_power_floor != FLOOR_ONE_mW && R.low_power_floor != FLOOR_TEN_mW)
    R.low_power_floor = FLOOR_ONE_mW;

  // Current front-panel modes are Power, dBm, FWD/REV, ModScope and Clock.
  // Mode 5 is now the Clock screen and can be remembered across restart.
  if (R.mode_display < 1 || R.mode_display > MAX_MODE)
    R.mode_display = DEFAULT_MODE;

  // Screensaver timeout choices: Off, 1, 2, 5, 10, 15, 30 or 60 minutes.
  switch (R.screensaver_minutes)
  {
    case 0: case 1: case 2: case 5: case 10: case 15: case 30: case 60:
      break;
    default:
      R.screensaver_minutes = SCREENSAVER_DEFAULT_MINUTES;
      break;
  }

  // Full display-off delay choices. Old EEPROM padding may contain arbitrary
  // bytes, so normalize anything except the supported menu values to Off.
  switch (R.display_off_minutes)
  {
    case 0: case 1: case 2: case 5: case 10: case 15: case 30: case 60:
      break;
    default:
      R.display_off_minutes = DISPLAY_OFF_DEFAULT_MINUTES;
      break;
  }

  const bool badCalibration =
    !isfinite(R.cal_AD[0].Fwd) || !isfinite(R.cal_AD[0].Rev) ||
    !isfinite(R.cal_AD[1].Fwd) || !isfinite(R.cal_AD[1].Rev) ||
    R.cal_AD[0].Fwd < 0.0 || R.cal_AD[0].Fwd > 5.0 ||
    R.cal_AD[0].Rev < 0.0 || R.cal_AD[0].Rev > 5.0 ||
    R.cal_AD[1].Fwd < 0.0 || R.cal_AD[1].Fwd > 5.0 ||
    R.cal_AD[1].Rev < 0.0 || R.cal_AD[1].Rev > 5.0 ||
    R.cal_AD[0].db10m == R.cal_AD[1].db10m ||
    fabs(R.cal_AD[0].Fwd - R.cal_AD[1].Fwd) < 0.001 ||
    fabs(R.cal_AD[0].Rev - R.cal_AD[1].Rev) < 0.001;

  if (badCalibration)
  {
    R.cal_AD[0].db10m = CAL1_NOR_VALUE;
    R.cal_AD[0].Fwd   = CALFWD1_DEFAULT;
    R.cal_AD[0].Rev   = CALREV1_DEFAULT;
    R.cal_AD[1].db10m = CAL2_NOR_VALUE;
    R.cal_AD[1].Fwd   = CALFWD2_DEFAULT;
    R.cal_AD[1].Rev   = CALREV2_DEFAULT;
  }
}
            

//
//-----------------------------------------------------------------------------------------
// Forward & Reverse Voltage Measure and collect Function ( Interrupt driven )
//-----------------------------------------------------------------------------------------
//
static void powerSampler(void)
{
  // LJ-2000M acquisition model: a bounded direct-LPI2C High-Speed read runs
  // in the 50 us TimerOne ISR and queues only raw ADC codes. Heavy RF math,
  // OLED, menu and USB work remain outside the interrupt.
  ad7991_hs_capture_isr();
}

//
//-----------------------------------------------------------------------------------------
// Top level task
// runs in an endless loop
//-----------------------------------------------------------------------------------------
//

void pswrLoop()
{
  // Service the ADC as early and as often as possible.
  pswr_service_sampler();

  // The SWR alarm itself remains latched until the normal acknowledge/reset,
  // but the audible warning is intentionally limited to three seconds.
  // This timer affects only the buzzer: screen message and alarm indication
  // remain active exactly as before.
  if (swr_buzzer_active &&
      (uint32_t)(millis() - swr_buzzer_started_ms) >= SWR_BUZZER_AUTO_OFF_MS)
  {
    swrBuzzerOff();
    swr_buzzer_active = false;
    swr_buzzer_started_ms = 0;
  }

  // Coupler select button = input 6, LED is output 7.
  //
  // Normal operation now uses one physical button for two related actions:
  //   short press/release  -> change Coupler 1 / Coupler 2
  //   long hold            -> open Band Select
  //
  // The short action is deliberately performed on RELEASE. Therefore a press
  // that becomes a long hold can never switch coupler first by mistake.
  //
  // During an SWR alarm this same button remains the dedicated ACKNOWLEDGE
  // button. Alarm acknowledgement happens immediately after the normal contact
  // debounce and MUST NOT switch coupler or open Band Select, even if held.
  {
    static uint32_t couplerPressStartMs = 0;
    static bool couplerLongActionDoneThisPress = false;
    static bool suppressCouplerUntilRelease = false;

    const uint32_t now = millis();

    // Small local helper: change the physical coupler and recall that coupler's
    // own remembered band/calibration bank.
    auto selectNextCoupler = [&](bool showConfirmation)
    {
      const bool newCoupler = !cpl;
      // V3.54: each physical coupler remembers its own band. A short coupler
      // press therefore recalls the band assigned to the destination coupler.
      // Example: CPL1=HF and CPL2=2M -> switching CPL1 to CPL2 loads 2M-CPL2.
      calbanks_select(newCoupler);
      cpl = newCoupler;
      digitalWrite(CouplerLed, LOW);
      digitalWrite(CouplerSelect, cpl ? LOW : HIGH);

      if (showConfirmation)
      {
        VirtLCD.clear();
        VirtLCD.setCursor(1, 1);
        VirtLCD.print(cpl ? "Coupler 2" : "Coupler 1");
        VirtLCD.setCursor(11, 1);
        VirtLCD.print("selected");
        VirtLCD.transfer();
        Menu_exit_timer = 15;
      }
      else
      {
        // BAND SELECT is already on screen; simply redraw its C1/C2 status.
        flag.menu_lcd_upd = false;
      }
    };

    // Preserve the proven contact debounce for detecting press/release edges.
    if ((uint32_t)(now - lastTimeButtonStateChanged) > COUPLER_DEBOUNCE_MS)
    {
      const byte buttonState = (byte)digitalRead(CouplerSW);

      if (buttonState != lastButtonState)
      {
        lastTimeButtonStateChanged = now;
        lastButtonState = buttonState;

        if (buttonState == LOW)
        {
          screensaver_begin_time.start();
          screensaver_active = false;
          oledWake();

          couplerLongActionDoneThisPress = false;

          if (flag.swr_alarm)
          {
            // Alarm acknowledge is immediate. This press is consumed completely
            // and cannot later become either a coupler or band-select command.
            flag.swr_alarm = false;
            swr_alarm_acknowledged = true;
            swrBuzzerOff();
            swr_buzzer_active = false;
            swr_buzzer_started_ms = 0;
            optionalDigitalWrite(R_Led, LOW);
            digitalWrite(CouplerLed, LOW);

            suppressCouplerUntilRelease = true;
            couplerPressStartMs = 0;
          }
          else if ((!flag.config_mode && mode_display != POWER_CLOCK) ||
                   menuBandSelectActive())
          {
            // Allow the dual-purpose coupler button on normal measurement
            // screens and also allow a short C1/C2 change while BAND SELECT
            // itself is open. In Clock mode the button is intentionally inert.
            suppressCouplerUntilRelease = false;
            couplerPressStartMs = now;
          }
          else
          {
            // Other setup/calibration menus remain protected from coupler changes.
            suppressCouplerUntilRelease = true;
            couplerPressStartMs = 0;
          }
        }
        else
        {
          // Short coupler action happens only on release, and only if the press
          // did not already become the long Band Select action.
          if (!suppressCouplerUntilRelease &&
              !couplerLongActionDoneThisPress &&
              couplerPressStartMs != 0 &&
              ((!flag.config_mode && mode_display != POWER_CLOCK) ||
               menuBandSelectActive()))
          {
            const bool inBandSelect = menuBandSelectActive();
            selectNextCoupler(!inBandSelect);
          }

          // Release fully arms the next independent press.
          couplerPressStartMs = 0;
          couplerLongActionDoneThisPress = false;
          suppressCouplerUntilRelease = false;
        }
      }
    }

    // A long hold from any normal live screen opens BAND SELECT. Because the
    // coupler toggle happens only on release, this path cannot cause a coupler
    // change first. Once BAND SELECT is open, short presses can still choose C1/C2.
    if (lastButtonState == LOW &&
        !flag.swr_alarm &&
        !flag.config_mode &&
        mode_display != POWER_CLOCK &&
        !suppressCouplerUntilRelease &&
        !couplerLongActionDoneThisPress &&
        couplerPressStartMs != 0 &&
        (uint32_t)(now - couplerPressStartMs) >= COUPLER_BAND_SELECT_HOLD_MS)
    {
      couplerLongActionDoneThisPress = true;
      menuOpenBandSelect(false);
    }
  }

  // Flash the front-panel LED while the SWR alarm is latched.
  // This is presentation only: CouplerSelect and the active calibration bank
  // never change because of the flashing LED.
  {
    static uint32_t lastAlarmLedToggleMs = 0;
    static bool alarmLedState = false;

    if (flag.swr_alarm)
    {
      const uint32_t now = millis();
      if (lastAlarmLedToggleMs == 0 ||
          (now - lastAlarmLedToggleMs) >= SWR_ALARM_LED_FLASH_MS)
      {
        lastAlarmLedToggleMs = now;
        alarmLedState = !alarmLedState;
        digitalWrite(CouplerLed, alarmLedState ? HIGH : LOW);
      }
    }
    else
    {
      lastAlarmLedToggleMs = 0;
      alarmLedState = false;
      digitalWrite(CouplerLed, LOW);
    }
  }

  static uint8_t  multi_button;             // Event from Multipurpose Enact Switch
  //-------------------------------------------------------------------------------
  // Here we do routines which are to be run through as often as possible
  //-------------------------------------------------------------------------------

  //-------------------------------------------------------------------
  // Optional RF/power LED follows qualified NET power, not raw detector pickup.
  if (pswr_get_qualified_net_power_mw() > R.idle_disp_thresh) optionalDigitalWrite(G_Led, HIGH);
  else optionalDigitalWrite(G_Led, LOW);
  
  //-------------------------------------------------------------------
  // Check USB and direct XIAO ESP32 serial links.
  usb_read_serial();
  usb_pep_debug_service();
  wifi_link_service();

  // Clock exists only when the XIAO WiFi module is physically present.
  // If Clock was remembered from an earlier installation but no module is
  // detected now, fall back silently to the normal Power screen before any
  // CLOCK - WAITING FOR NTP frame can be rendered. Do not overwrite the
  // stored preference here; reinstalling the module can still restore Clock.
  if (!flag.config_mode &&
      mode_display == POWER_CLOCK &&
      !wifi_link_module_present())
  {
    mode_display = POWER_BARPK;
    flag.mode_change = true;
  }

  pswr_service_sampler();
    
  //-------------------------------------------------------------------------------
  // Here we do routines which are to be accessed once every POLL_TIMER milliseconds
  //-------------------------------------------------------------------------------
  // Poll timer.
  if (pollMetro.check())                    // check if the metro has passed its interval .
  {
      
    //-------------------------------------------------------------------
    // Prepare various types of power for print to LCD and calculate SWR
    calc_SWR_and_power();

    // Update LCD-only smoothed copies of the live instantaneous readings.
    // Measurement performance and all internal values remain untouched.
    display_smoothing_update();
    
    //----------------------------------------------
    // Two-stage OLED inactivity management.
    // Stage 1: optional dimmed NO SIGNAL screensaver.
    // Stage 2: optional true SSD1322 display OFF after an additional delay.
    // Only qualified RF or real user/menu activity resets the inactivity clock.
    if (display_rf_active || flag.config_mode || mode_display == POWER_CLOCK)
    {
      // Clock mode is intentionally an always-visible desk-clock screen. It
      // must not be replaced by NO SIGNAL or the display-off timeout.
      screensaver_begin_time.start();
      screensaver_active = false;
      oledWake();
    }
    else
    {
      const uint32_t screensaver_ms =
        (uint32_t)R.screensaver_minutes * 60000UL;

      if (R.screensaver_minutes == 0)
        screensaver_active = false;
      else if (screensaver_begin_time.hasPassed(screensaver_ms))
        screensaver_active = true;

      if (R.display_off_minutes != 0)
      {
        // If a screensaver timeout is enabled, Display Off Time is an
        // additional delay after NO SIGNAL starts. If screensaver is Off,
        // Display Off Time counts directly from the last activity.
        const uint32_t off_base_ms =
          (R.screensaver_minutes == 0) ? 0UL : screensaver_ms;
        const uint32_t display_off_ms = off_base_ms +
          (uint32_t)R.display_off_minutes * 60000UL;

        if (screensaver_begin_time.hasPassed(display_off_ms))
          oledPowerOff();
      }
      else
      {
        oledWake();
      }
    }

    // Clock mode has its own low-brightness timer. It never changes any
    // measurement/display-off settings and is restored by user activity.
    clockDimService();
             
    //-------------------------------------------------------------------
    // Menu Exit announcement Timer
    if (Menu_exit_timer == 1) VirtLCD.clear();  // Clear announcement before going live again
    if (Menu_exit_timer > 0)  Menu_exit_timer--;

    //-------------------------------------------------------------------
    // We are either entering or exiting Config Menu, need to clear up display
    // or
    // We just changed display modes, start/restart EEPROM save timer for new default display
    if (flag.mode_change)
    {
      
      flag.mode_change = false;

      if (flag.config_mode)                     // Entering Config Menu
      {
        VirtLCD.clear();
      }
    }    

    //-------------------------------------------------------------------
    // Various Menu (rotary encoder) selectable display/function modes
    //
    if (Menu_exit_timer == 0)
    {
      if (flag.config_mode)                     // Pushbutton Configuration Menu
      {
        ConfigMenu();
      }  
      else if (mode_display == POWER_BARPK)     // 100 ms Peak Power, SWR and PEP
      {
        lcd_display_clean("100ms Peak Power", "Pk  ", display_rf_active ? power_mw_pk : 0.0);
      }
      else if (mode_display == POWER_CLEAN_DBM) // Power Meter in dBm
      {
        lcd_display_clean_dBm();
      }
      else if (mode_display == POWER_FWD_REV)   // Live Forward / Reflected power
      {
        lcd_display_fwd_rev();
      }
      else if (mode_display == POWER_MOD_SCOPE) // Live modulation envelope scope
      {
        lcd_display_modscope();
      }
      else if (mode_display == POWER_CLOCK)     // NTP date + local + UTC clock
      {
        lcd_display_clock();
      }
    }
    //----------------------------------------------
    // Menus and temporary announcements still use the proven 20x4 virtual
    // text canvas. Normal meter screens render directly with Adafruit_GFX and
    // must not be overwritten by a stale virtual text frame.
    if (flag.config_mode || Menu_exit_timer > 0)
      VirtLCD.transfer();
  } 

  //-------------------------------------------------------------------------------
  // Here we do timing related routines which are to be accessed once every millisecond
  //-------------------------------------------------------------------------------
  if (pushMetro.check())
  {  
    
    //-------------------------------------------------------------------------------
    // Encoder and Pushbutton  Management
    //
    if (!flag.config_mode && mode_display == POWER_CLOCK && digitalRead(EnactSW) == LOW)
      clockDimRestore();

    multi_button = multipurpose_pushbutton();
    if (multi_button != 0)
    {
      if (!flag.config_mode && mode_display == POWER_CLOCK)
        clockDimRestore();
      screensaver_begin_time.start();
      screensaver_active = false;
      oledWake();
    }
    if (multi_button == 1)                  // One short-push event on release
    {
      flag.short_push = true;               // Used with Configuration Menu functions
    }
    else if (multi_button == 2 && !flag.config_mode) // One long-push event per press
    {
      // Clock is a display-only screen: encoder push is reserved for LOCAL/UTC
      // selection and must never open Setup. Other live screens keep the normal
      // long-push path into the Configuration Menu.
      if (mode_display != POWER_CLOCK)
      {
        flag.config_mode = true;            // Ask for Config Menu Mode
        flag.mode_change = true;            // Indicate that we need to set up for this mode
      }
    }

    //-------------------------------------------------------------------     
    // Do stuff when not in Config Menu
    if (!flag.config_mode)
    {
      if (flag.short_push)
      {
        // Live-screen short-push actions are deliberately local and harmless:
        // - ModScope exits to Power.
        // - Clock toggles the primary time directly between UTC and LOCAL.
        if (mode_display == POWER_MOD_SCOPE)
        {
          mode_display = POWER_BARPK;
          saveDisplayMode();
          flag.mode_change = true;
        }
        else if (mode_display == POWER_CLOCK)
        {
          const uint8_t currentClock = clock_primary_get();
          const uint8_t nextClock =
            (currentClock == CLOCK_PRIMARY_UTC) ? CLOCK_PRIMARY_LOCAL : CLOCK_PRIMARY_UTC;

          // Store immediately so the selected primary clock is remembered after restart.
          clock_primary_set(nextClock);

          // A push is also Clock-screen activity: restore normal brightness and
          // force the next display pass to reflect the new primary clock.
          clockDimRestore();
          flag.idle_refresh = true;
        }
        flag.short_push = false;
      }
      
      const int16_t encoderSteps = encoderTakeSteps();
      if (encoderSteps != 0)               // Encoder turned to cycle through modes
      {
        if (mode_display == POWER_CLOCK)
          clockDimRestore();
        // User activity wakes the OLED and restarts the inactivity timeout.
        screensaver_begin_time.start();
        screensaver_active = false;
        oledWake();
        // Apply exactly one logical encoder movement. Clock is skipped when
        // the XIAO is absent; the four measurement screens remain available.
        mode_display = stepLiveMode(mode_display, encoderSteps);
        saveDisplayMode();
        /* encoderTakeSteps() returns exactly one logical movement */
      }
    }    
  }  
  
  //-------------------------------------------------------------------------------
  // Here we do timing related routines which are to be accessed once every 1/10th of a second
  //-------------------------------------------------------------------------------
  if (slowMetro.check())                    // check if the metro has passed its interval .
  {
      
    usb_cont_report();                      // Report Power and SWR to USB, if in Continuous mode
    
  }

  // One final service point minimizes sample loss after LCD/menu/EEPROM work.
  pswr_service_sampler();
}


//
//-----------------------------------------------------------------------------------------
//      Setup Ports, timers, start the works and never return, unless reset
//                          by the watchdog timer
//                   then - do everything, all over again
//-----------------------------------------------------------------------------------------
//
void pswrSetup()
{
  pinMode(CouplerSW, INPUT_PULLUP);
  pinMode(CouplerSelect, OUTPUT);
  pinMode(CouplerLed, OUTPUT);
  pinMode(SwrBuzzerPin, OUTPUT);
  cpl = false;
  digitalWrite(CouplerLed, LOW);
  digitalWrite(CouplerSelect, HIGH);
  swrBuzzerOff();
  swr_buzzer_active = false;
  swr_buzzer_started_ms = 0;
  lastButtonState = (byte)digitalRead(CouplerSW);
  uint8_t coldstart;

  // Initialize optional indicator outputs only when a real pin is assigned.
  optionalPinMode(R_Led, OUTPUT);
  optionalDigitalWrite(R_Led, LOW);
  optionalPinMode(G_Led, OUTPUT);
  optionalDigitalWrite(G_Led, LOW);

  pinMode(EnactSW, INPUT_PULLUP);                // Menu/Enact pushbutton switch
 
  
  // Initialize the AD7991. Standard Wire is used only for discovery/configuration
  // at 400 kHz. Measurement reads then use the LJ-2000M Hs master-code sequence
  // with a 2 MHz LPI2C1 data phase.
  ad7991_hs_begin();

  coldstart = EEPROM.read(EEPROM_COLDSTART_ADDR);                    // Grab the coldstart byte indicator in EEPROM for
  const bool factoryDefaultsLoaded = (coldstart != COLDSTART_REF);
                                                 // comparison with the COLDSTART_REFERENCE
  //
  // Initialize all memories if first upload or if COLDSTART_REF has been modified
  // either through PSWR_Config.h or through Menu functions
  if (coldstart != COLDSTART_REF)
  { 
    EEPROM.write(EEPROM_COLDSTART_ADDR, COLDSTART_REF);               // COLDSTART_REF in first byte indicates all initialized
    EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);                   // Write default settings into EEPROM
  }
  else                                           // EEPROM contains stored data, retrieve the data
  {
    EEPROM_readAnything(EEPROM_SETTINGS_ADDR, R);                    // Read the stored data
  }

  // V3.3.4 one-time migration: earlier V3.3.x defaults used 0.001 mW (1 uW).
  // Move only that legacy default to the new 1.0 mW NOISE_FLOOR_MW setting,
  // without changing calibration or forcing a full EEPROM factory reset.
  // A marker byte after var_t makes this migration run only once; users can
  // still deliberately select 0.001 mW later if they want to.
  const int noiseFloorMigrationAddr = EEPROM_SETTINGS_ADDR + (int)sizeof(var_t);
  const uint8_t noiseFloorMigrationTag = 0x34;
  if (EEPROM.read(noiseFloorMigrationAddr) != noiseFloorMigrationTag)
  {
    if (fabs(R.idle_disp_thresh - 0.001f) < 0.0000001f)
      R.idle_disp_thresh = NOISE_FLOOR_MW;
    EEPROM.write(noiseFloorMigrationAddr, noiseFloorMigrationTag);
  }

  // V3.3.5 one-time migration: move the legacy default low-power display
  // floor from 1 uW to 1 mW. This affects formatting/display only; calibration
  // and measurement data are untouched.
  const int displayFloorMigrationAddr = noiseFloorMigrationAddr + 1;
  const uint8_t displayFloorMigrationTag = 0x35;
  if (EEPROM.read(displayFloorMigrationAddr) != displayFloorMigrationTag)
  {
    if (R.low_power_floor == FLOOR_ONE_uW)
      R.low_power_floor = FLOOR_ONE_mW;
    EEPROM.write(displayFloorMigrationAddr, displayFloorMigrationTag);
  }

  sanitizeSettings();                             // Reject corrupt/out-of-range persistent data
  // V3.47: four bands x two physical couplers = eight independent calibration
  // banks. On first upgrade the proven V3.46 C1/C2 banks are migrated into all
  // four bands, so no existing calibration is lost.
  calbanks_begin(cpl, factoryDefaultsLoaded);

  // Callsign storage is kept outside var_t and calibration-bank EEPROM space.
  // Existing V3.01 units migrate to PD0LEW on first V3.04 boot; a true factory
  // reset starts with the explicit placeholder "Your Call".
  callsign_begin(factoryDefaultsLoaded);

  // Startup-logo choice lives in its own EEPROM block and defaults to the
  // V3.24 RF-wave emblem on upgrade or factory reset.
  startup_logo_begin(factoryDefaultsLoaded);

  // WiFi credentials are owned by the Teensy and stored independently.
  // The directly-connected XIAO ESP32 receives them over Serial5.
  wifi_config_begin(factoryDefaultsLoaded);

  EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);                     // compare-before-write helper avoids unnecessary cell writes
  
  Serial.begin(115200);                            // initialize USB virtual serial serial port
  wifi_link_begin();                              // XIAO ESP32 on Serial5 @ 921600 baud

  //------------------------------------------
  // Initialize the NHD-3.12-25664UCB2 graphical SSD1322 OLED.
  // Pins and constructor match the user-proven hardware setup in PSWR_State.cpp.
  const bool oled_ok = display_begin();
  if (!oled_ok)
    Serial.println("SSD1322 OLED initialization failed");
  display_startup();
  delay(3000);

  mode_display = R.mode_display;
  flag.mode_change = false;

  lcd.clearDisplay();
  lcd.display();
  VirtLCD.init(OLED_COLUMNS, OLED_ROWS);
  VirtLCD.clear();
  screensaver_active = false;
  display_off_active = false;
  screensaver_begin_time.start();

  Timer1.initialize(SAMPLE_TIMER);               // Init the adc sample timer interrupt function
  Timer1.attachInterrupt(powerSampler);          // Start the works
  
}
