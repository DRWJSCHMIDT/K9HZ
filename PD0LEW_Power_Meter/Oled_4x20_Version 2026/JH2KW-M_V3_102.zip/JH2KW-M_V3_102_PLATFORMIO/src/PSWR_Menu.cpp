/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_Menu.h"
#include "PSWR_State.h"
#include "PSWR_Encoder.h"
#include "PSWR_Display.h"
#include "PSWR_Measurement.h"
#include "PSWR_Print.h"
#include "PSWR_Eeprom.h"
#include "PSWR_CalBanks.h"
#include "PSWR_CallSign.h"
#include "PSWR_StartupLogo.h"
#include "PSWR_WiFiConfig.h"
#include "PSWR_WiFiLink.h"
#include <math.h>
#include <string.h>

// First Level Menu Items

const uint8_t level0_menu_size = 20;
const char *level0_menu_items[] =
{ "  SWR Alarm",
  "  SWR Alarm Power",
  "  PEP Hold",
  "  PK Hold",
  "  Noise Floor",
  "  Screensaver Time",
  "  Display Off Time",
  "  Power Bar Scale",
  "  Set Your Call",
  "  Set Grid",
  "  Clock Primary",
  "  Clock Dim Time",
  "  WiFi SSID",
  "  WiFi Password",
  "  WiFi Status",
  "  Startup Logo",
  "  Calibrate",
  "  Diagnostics",
  "  Factory Reset",
  "  Exit"
};

// Stable actions are kept separate from visible menu positions. When no XIAO
// WiFi card is detected, the six WiFi/clock-related entries are removed from
// the visible list while all remaining actions keep their original behaviour.
enum SetupAction : uint8_t
{
  SETUP_SWR_ALARM = 0,
  SETUP_SWR_POWER,
  SETUP_PEP_HOLD,
  SETUP_PK_HOLD,
  SETUP_NOISE_FLOOR,
  SETUP_SCREENSAVER_TIME,
  SETUP_DISPLAY_OFF_TIME,
  SETUP_POWER_BAR_SCALE,
  SETUP_SET_CALL,
  SETUP_SET_GRID,
  SETUP_CLOCK_PRIMARY,
  SETUP_CLOCK_DIM,
  SETUP_WIFI_SSID,
  SETUP_WIFI_PASSWORD,
  SETUP_WIFI_STATUS,
  SETUP_STARTUP_LOGO,
  SETUP_CALIBRATE,
  SETUP_DIAGNOSTICS,
  SETUP_FACTORY_RESET,
  SETUP_EXIT
};

static const uint8_t level0_menu_actions[level0_menu_size] =
{
  SETUP_SWR_ALARM, SETUP_SWR_POWER, SETUP_PEP_HOLD, SETUP_PK_HOLD,
  SETUP_NOISE_FLOOR, SETUP_SCREENSAVER_TIME, SETUP_DISPLAY_OFF_TIME,
  SETUP_POWER_BAR_SCALE, SETUP_SET_CALL, SETUP_SET_GRID,
  SETUP_CLOCK_PRIMARY, SETUP_CLOCK_DIM, SETUP_WIFI_SSID,
  SETUP_WIFI_PASSWORD, SETUP_WIFI_STATUS, SETUP_STARTUP_LOGO,
  SETUP_CALIBRATE, SETUP_DIAGNOSTICS, SETUP_FACTORY_RESET, SETUP_EXIT
};

static const bool level0_menu_requires_wifi[level0_menu_size] =
{
  false, false, false, false, false, false, false, false, false,
  true, true, true, true, true, true,
  false, false, false, false, false
};

// Flags for SWR Alarm & Threshold menu
#define SWR_ALARM_THRESHOLD      1
#define	SWR_ALARM_PWR_THRESHOLD  2
// SWR Alarm Power Threshold menu Items
const uint8_t swr_alarm_pwr_thresh_menu_size = 5;
const char *swr_alarm_pwr_thresh_menu_items[] =
{ "    1mW",
  "   10mW",
  "   0.1W",
  "     1W",
  "    10W"
};

// Flag for PEP Sample Period select
#define PEP_MENU                 3
#define PK_HOLD_MENU             4
// PEP Sample Period select menu Items
const uint8_t pep_menu_size = 3;
const char *pep_menu_items[] =
{ "   0.1s",
  "   1.0s",
  "   2.0s"
};

// Flag for Encoder Resolution Change
//#define ENCODER_MENU	8


// Flag for Screensaver Threshold select menu
#define SCREENTHRESH_MENU	5
#define SCREENTIME_MENU       7
#define DISPLAYOFF_MENU      10
// Screensaver Threshold select menu Items
const uint8_t screenthresh_menu_size = 6;
const char *screenthresh_menu_items[] =
{ "     Off",
  " 0.001mW",
  "  0.01mW",
  "   0.1mW",
  "     1mW",
  "    10mW"
};

// Screensaver idle-time selection. Values are minutes; 0 disables the screensaver.
const uint8_t screentime_menu_size = 8;
const uint16_t screentime_minutes[screentime_menu_size] = { 0, 1, 2, 5, 10, 15, 30, 60 };
const char *screentime_menu_items[] =
{ "     Off",
  "  1 minute",
  "  2 minutes",
  "  5 minutes",
  " 10 minutes",
  " 15 minutes",
  " 30 minutes",
  " 60 minutes"
};

// Additional full-OLED-off delay after the dimmed screensaver.
// 0 disables the hardware display-off stage.
const uint8_t displayoff_menu_size = 8;
const uint16_t displayoff_minutes[displayoff_menu_size] = { 0, 1, 2, 5, 10, 15, 30, 60 };
const char *displayoff_menu_items[] =
{ "     Off",
  "  1 minute",
  "  2 minutes",
  "  5 minutes",
  " 10 minutes",
  " 15 minutes",
  " 30 minutes",
  " 60 minutes"
};

// Flag for Scale Range menu
#define SCALERANGE_MENU         6

// Flags for Scale Range Submenu functions

// Flag for Calibrate menu
#define CAL_MENU                8
const uint8_t calibrate_menu_size = 6;
const char *calibrate_menu_items[] =
{ "  OneLevelCal(dBm)",
  "   1st level (dBm)",
  "   2nd level (dBm)",
  "  Cal Debug",
  "  Go Back",
  "  Exit"
};

// Flags for Calibrate Submenu functions
#define CAL_SET0_MENU         800  // Single level calibration
#define CAL_SET1_MENU         801  // 1st level
#define CAL_SET2_MENU         802  // 2nd level
#define CAL_OVERVIEW_MENU     803  // Read-only calibration debug

// Flag for Debug Screen
#define DEBUG_MENU              9

// Flag for Set Your Call editor
#define YOURCALL_MENU          12
#define GRID_MENU              19
#define CLOCK_PRIMARY_MENU     20
#define CLOCK_DIM_MENU         21

// Flag for Startup Logo selector
#define STARTUP_LOGO_MENU      13
#define WIFI_SSID_MENU         15
#define WIFI_PASSWORD_MENU     16
#define WIFI_STATUS_MENU       17
#define WIFI_SSID_MANUAL_MENU  18

// Flag for four-band selector
#define BAND_MENU              14

// Flag for Factory Reset
#define FACTORY_MENU           11
// Factory Reset menu Items
const uint8_t factory_menu_size = 3;
const char *factory_menu_items[] =
{ "  No  - Go back",
  "  Yes - Reset",
  "  No  - Exit"
};

// Second, deliberate confirmation step before the destructive reset.
const uint8_t factory_confirm_menu_size = 2;
const char *factory_confirm_menu_items[] =
{ "  Cancel",
  "  Reset"
};

var_t     eeprom_R;                // Used to read and compare EEPROM R with current R

// Set Your Call editor state. The menu code owns the editable buffer and
// encoder/button actions; the graphical OLED layer only reads these values.
namespace
{
constexpr uint8_t YOURCALL_MAX_CHARS = 30;
constexpr uint8_t YOURCALL_KEY_COUNT = 43;

char yourcall_edit_text[YOURCALL_MAX_CHARS + 1] = {};
uint8_t yourcall_key_index = 10; // Start on Q.
bool yourcall_session_active = false;
bool yourcall_replace_placeholder = false;

const char yourcall_key_chars[38] =
{
  '1','2','3','4','5','6','7','8','9','0',
  'Q','W','E','R','T','Y','U','I','O','P',
  'A','S','D','F','G','H','J','K','L','-',
  'Z','X','C','V','B','N','M','/'
};
}

const char *menuYourCallEditText(void)
{
  return yourcall_edit_text;
}

uint8_t menuYourCallKeyIndex(void)
{
  return yourcall_key_index;
}

// Maidenhead grid-square editor state. This deliberately reuses the proven
// Set Your Call keyboard geometry, but limits the stored locator to 10 chars.
namespace
{
char grid_edit_text[GRID_MAX_CHARS + 1] = {};
uint8_t grid_key_index = 10; // Start on Q.
bool grid_session_active = false;
}

const char *menuGridEditText(void) { return grid_edit_text; }
uint8_t menuGridKeyIndex(void) { return grid_key_index; }
uint8_t menuGridMaxChars(void) { return (uint8_t)GRID_MAX_CHARS; }

namespace
{
uint8_t clock_primary_selection = CLOCK_PRIMARY_UTC;
bool clock_primary_session_active = false;
}

uint8_t menuClockPrimarySelection(void) { return clock_primary_selection; }

namespace
{
uint8_t clock_dim_selection = CLOCK_DIM_5_MIN;
bool clock_dim_session_active = false;
}

uint8_t menuClockDimSelection(void) { return clock_dim_selection; }

namespace
{
char wifi_edit_text[WIFI_PASSWORD_MAX_CHARS + 1] = {};
uint8_t wifi_key_index = 10; // Q
bool wifi_session_active = false;
bool wifi_password_mode = false;
bool wifi_replace_placeholder = false;

// WiFi scan/selection state. Selecting a scanned SSID is staged in RAM until
// the password is stored, so pressing ESC cannot leave EEPROM half-changed.
bool wifi_scan_session_active = false;
int16_t wifi_scan_selection = 0;
bool wifi_password_from_scan = false;
char wifi_pending_ssid[WIFI_SSID_MAX_CHARS + 1] = {};
}

const char *menuWifiEditText(void) { return wifi_edit_text; }
uint8_t menuWifiKeyIndex(void) { return wifi_key_index; }
uint8_t menuWifiMaxChars(void)
{
  return (uint8_t)(wifi_password_mode ? WIFI_PASSWORD_MAX_CHARS : WIFI_SSID_MAX_CHARS);
}

uint8_t menuWifiScanSelection(void)
{
  return (wifi_scan_selection < 0) ? 0U : (uint8_t)wifi_scan_selection;
}

namespace
{
uint8_t startup_logo_edit_index = STARTUP_LOGO_DEFAULT;
bool startup_logo_session_active = false;
}

uint8_t menuStartupLogoIndex(void)
{
  return startup_logo_edit_index;
}

namespace
{
uint8_t band_select_edit_index = CALBAND_HF;
uint8_t band_select_coupler_index = 0;
bool band_select_session_active = false;
bool band_select_return_to_setup = true;
}

uint8_t menuBandSelectIndex(void)
{
  return band_select_edit_index;
}

bool menuBandSelectActive(void)
{
  return flag.config_mode && menu_level == BAND_MENU;
}

void menuOpenBandSelect(bool returnToSetup)
{
  band_select_return_to_setup = returnToSetup;
  band_select_session_active = false;
  flag.config_mode = true;
  flag.mode_change = true;
  menu_level = BAND_MENU;
  flag.menu_lcd_upd = false;
}


//
//--------------------------------------------------------------------
// Multipurpose Pushbutton
//
// Returns 0 for no push, 1 for short push and 2 for long push
// (routine should be called once every 1 ms)
//--------------------------------------------------------------------


uint8_t multipurpose_pushbutton(void)
{
  // Fully debounced, one-event-per-press state machine.
  //
  // Important distinction:
  //   * On the normal meter screen a long press enters Configuration mode.
  //   * Once a press STARTS inside Configuration mode, it is always treated as
  //     one menu-selection press on release, even when held longer than the
  //     normal long-press time.  V3.3.8 could silently discard such menu presses.
  static bool rawPressed = false;
  static bool stablePressed = false;
  static bool longReported = false;
  static bool pressStartedInConfig = false;
  static uint32_t rawChangeMs = 0;
  static uint32_t pressStartMs = 0;

  constexpr uint32_t debounceMs = 8;

  const bool rawNow = (digitalRead(EnactSW) == LOW);
  const uint32_t now = millis();

  // Track the raw contact, but do not act until it has remained stable long
  // enough to reject mechanical bounce on both press and release.
  if (rawNow != rawPressed)
  {
    rawPressed = rawNow;
    rawChangeMs = now;
  }

  if ((uint32_t)(now - rawChangeMs) < debounceMs)
    return 0;

  // Debounced state transition.
  if (stablePressed != rawPressed)
  {
    stablePressed = rawPressed;

    if (stablePressed)
    {
      pressStartMs = now;
      longReported = false;
      pressStartedInConfig = flag.config_mode;
      return 0;
    }

    // Debounced release.
    const uint32_t heldMs = (uint32_t)(now - pressStartMs);

    if (pressStartedInConfig)
    {
      // A menu press must never disappear just because it was held >200 ms.
      longReported = false;
      return (heldMs >= BUTTON_SHORT_MIN_MS) ? 1 : 0;
    }

    // A press that started on the normal display is a short event only when
    // it never generated the long-press event used to enter Configuration.
    if (!longReported && heldMs >= BUTTON_SHORT_MIN_MS)
      return 1;

    longReported = false;
    return 0;
  }

  // Long press is meaningful only when the physical press STARTED outside the
  // Configuration menus.  This avoids swallowing ordinary menu selections.
  if (stablePressed && !pressStartedInConfig && !longReported &&
      (uint32_t)(now - pressStartMs) >= BUTTON_LONG_MS)
  {
    longReported = true;
    return 2;
  }

  return 0;
}

//----------------------------------------------------------------------
// Center a transient menu/status message on the 256x64 OLED.
// With the standard X11 6x12 font, 42 virtual columns span essentially
// the complete display width. Row 2 is the vertical center of the 5-row
// graphical menu canvas.
//----------------------------------------------------------------------
static void lcd_center_message(const char *text, uint8_t row = 2)
{
  if (!text) return;

  size_t len = strlen(text);
  uint8_t col = 0;
  if (len < OLED_COLUMNS)
    col = (uint8_t)((OLED_COLUMNS - len) / 2);

  if (row >= OLED_ROWS)
    row = OLED_ROWS / 2;

  VirtLCD.setCursor(col, row);
  VirtLCD.print(text);
}

//----------------------------------------------------------------------
// Display a Menu of choices, one line at a time
//
// **menu refers to a pointer array containing the Menu to be printed
//
// menu_size indicates how many pointers (menu items) there are in the array
//
// current_choice indicates which item is currently up for selection if
// pushbutton is pushed
//
// begin row, begin_col indicate the upper left hand corner of the one, three or
// four lines to be printed
//
// lines indicates how many lines are displayed at any one time, 1, 3 or 4.
//----------------------------------------------------------------------
static void lcd_scroll_Menu(const char * const *menu, uint8_t menu_size,
                     uint8_t current_choice, uint8_t begin_row, uint8_t begin_col, uint8_t lines)
{
  if (!menu || menu_size == 0 || lines == 0)
    return;

  // V2.08 graphical menu: use the full 42-character width and up to five rows.
  // The selected item is placed on the second visible menu row where possible,
  // with previous and following choices around it.
  if (begin_row >= OLED_ROWS)
    return;

  const uint8_t maxLines = OLED_ROWS - begin_row;
  if (lines > maxLines)
    lines = maxLines;

  // Clear all requested rows across the complete graphical text width.
  for (uint8_t row = 0; row < lines; ++row)
  {
    VirtLCD.setCursor(begin_col, begin_row + row);
    for (uint8_t col = begin_col; col < OLED_COLUMNS; ++col)
      VirtLCD.print(" ");
  }

  // One-line selectors are still used by several value-setting menus.
  if (lines == 1)
  {
    VirtLCD.setCursor(begin_col, begin_row);
    snprintf(lcd_buf, sizeof(lcd_buf), "->%s", menu[current_choice]);
    VirtLCD.print(lcd_buf);
    return;
  }

  // Row 0: previous item.
  uint8_t index = (current_choice == 0) ? (menu_size - 1) : (current_choice - 1);
  VirtLCD.setCursor(begin_col + 2, begin_row);
  snprintf(lcd_buf, sizeof(lcd_buf), "%s", menu[index]);
  VirtLCD.print(lcd_buf);

  // Row 1: selected item.
  VirtLCD.setCursor(begin_col, begin_row + 1);
  snprintf(lcd_buf, sizeof(lcd_buf), "->%s", menu[current_choice]);
  VirtLCD.print(lcd_buf);

  // Remaining rows: following items, wrapping around the menu.
  for (uint8_t row = 2; row < lines; ++row)
  {
    index = (uint8_t)((current_choice + row - 1) % menu_size);
    VirtLCD.setCursor(begin_col + 2, begin_row + row);
    snprintf(lcd_buf, sizeof(lcd_buf), "%s", menu[index]);
    VirtLCD.print(lcd_buf);
  }
}



//----------------------------------------------------------------------
// Menu functions begin:
//----------------------------------------------------------------------


//--------------------------------------------------------------------
// Diagnostics screen, exit on push
//--------------------------------------------------------------------
static void debug_menu(void)
{
  // V2.16.5.25: Diagnostics uses three read-only pages.
  // Keep this local to Diagnostics so the proven global encoder behaviour is
  // untouched: one accepted movement changes exactly one diagnostic page.
  static uint8_t diagnostic_page = 0;

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps > 0)
  {
    diagnostic_page++;
    if (diagnostic_page >= 3) diagnostic_page = 0;
  }
  else if (encoder_steps < 0)
  {
    if (diagnostic_page == 0) diagnostic_page = 2;
    else diagnostic_page--;
  }

  lcd_display_debug(diagnostic_page);

  // Exit on Button Push
  if (flag.short_push)
  {
    flag.short_push = false;            // Clear pushbutton status
    diagnostic_page = 0;                // Always reopen Diagnostics on page 1

    VirtLCD.clear();
    // The graphical 42-column menu can show this message on one line.
    lcd_center_message("Exit from diagnostics");
    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;           // Force screensaver reprint upon exit
    flag.config_mode = false;           // We're done, EXIT
    menu_level = 0;                     // We are done with this menu level
  }
}


//--------------------------------------------------------------------
// SWR Alarm Threshold Set Menu
//--------------------------------------------------------------------
static void swr_alarm_threshold_menu(void)
{
  // Selection modified by encoder.  We remember last selection, even if exit and re-entry
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int32_t next = (int32_t)R.SWR_alarm_trig + encoder_steps;
    if (next < 15) next = 15;
    if (next > 40) next = 40;
    R.SWR_alarm_trig = (uint8_t)next;
    // Reset data from Encoder
    /* encoderTakeSteps() consumed all queued detents */

    // Indicate that an LCD update is needed
    flag.menu_lcd_upd = false;          // Keep track of LCD update requirements
  }

  // If LCD update is needed
  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;           // We have serviced LCD
    VirtLCD.clear();

    VirtLCD.setCursor(0, 0);
    VirtLCD.print("SWR Alarm Threshold:");
    VirtLCD.setCursor(0, 1);
    VirtLCD.print("Adjust->   ");
    if (R.SWR_alarm_trig == 40)
      VirtLCD.print("Off");
    else
    {
      snprintf(lcd_buf, sizeof(lcd_buf), "%1u.%01u", R.SWR_alarm_trig / 10, R.SWR_alarm_trig % 10);
      VirtLCD.print(lcd_buf);
    }
    VirtLCD.setCursor(0, 2);
    VirtLCD.print("Range is 1.5 to 3.9");
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("4.0 = SWR Alarm Off");
  }
  // Enact selection by saving in EEPROM
  if (flag.short_push)
  {
    flag.short_push = false;            // Clear pushbutton status
    VirtLCD.clear();
    EEPROM_readAnything(EEPROM_SETTINGS_ADDR, eeprom_R);
    if (eeprom_R.SWR_alarm_trig != R.SWR_alarm_trig)  // New Value
    {
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    else lcd_center_message("Nothing Changed");

    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;           // Force screensaver reprint upon exit
    flag.config_mode = false;           // We're done, EXIT
    menu_level = 0;                     // We are done with this menu level
    flag.menu_lcd_upd = false;          // Make ready for next time
  }
}


//--------------------------------------------------------------------
// SWR Alarm Power Threshold Menu
//--------------------------------------------------------------------
static void swr_alarm_power_threshold_menu(void)
{
  static int current_selection;

  // Get current SWR-alarm power threshold (not the unrelated screensaver threshold).
  // 1mW=>0, 10mW=>1, 100mW=>2, 1000mW=>3, 10000mW=>4
  if      (R.SWR_alarm_pwr_thresh == 1)     current_selection = 0;
  else if (R.SWR_alarm_pwr_thresh == 10)    current_selection = 1;
  else if (R.SWR_alarm_pwr_thresh == 100)   current_selection = 2;
  else if (R.SWR_alarm_pwr_thresh == 1000)  current_selection = 3;
  else if (R.SWR_alarm_pwr_thresh == 10000) current_selection = 4;
  else                                      current_selection = 1; // safe 10mW fallback

  // Selection modified by encoder.  We remember last selection, even if exit and re-entry
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    current_selection += encoder_steps;
    // Reset data from Encoder
    /* encoderTakeSteps() consumed all queued detents */

    // Indicate that an LCD update is needed
    flag.menu_lcd_upd = false;
  }

  // If LCD update is needed
  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;           // We have serviced LCD

    // Keep Encoder Selection Within Bounds of the Menu Size
    uint8_t menu_size = swr_alarm_pwr_thresh_menu_size;
    while (current_selection >= menu_size)
      current_selection -= menu_size;
    while (current_selection < 0)
      current_selection += menu_size;

    // Update with currently selected value
    if      (current_selection == 0) R.SWR_alarm_pwr_thresh = 1;
    else if (current_selection == 1) R.SWR_alarm_pwr_thresh = 10;
    else if (current_selection == 2) R.SWR_alarm_pwr_thresh = 100;
    else if (current_selection == 3) R.SWR_alarm_pwr_thresh = 1000;
    else if (current_selection == 4) R.SWR_alarm_pwr_thresh = 10000;

    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("SWR Alarm Power:");
    VirtLCD.setCursor(0, 1);
    VirtLCD.print("Select");

    // Print the Rotary Encoder scroll Menu
    lcd_scroll_Menu(swr_alarm_pwr_thresh_menu_items, menu_size, (uint8_t)current_selection, 1, 6, 1);

    VirtLCD.setCursor(0, 2);
    VirtLCD.print("Power screen threshold");
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("1mW 10mW 0.1W 1W 10W");
  }

  // Enact selection
  if (flag.short_push)
  {
    VirtLCD.clear();

    flag.short_push = false;            // Clear pushbutton status

    // Check if selected threshold is not same as previous
    EEPROM_readAnything(EEPROM_SETTINGS_ADDR, eeprom_R);
    if (eeprom_R.SWR_alarm_pwr_thresh != R.SWR_alarm_pwr_thresh)// New Value
    {
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    else lcd_center_message("Nothing Changed");

    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;           // Force screensaver reprint upon exit
    flag.config_mode = false;           // We're done, EXIT
    menu_level = 0;                     // We are done with this menu level
    flag.menu_lcd_upd = false;          // Make ready for next time
  }
}


//--------------------------------------------------------------------
// Peak Envelope Power (PEP) period selection Menu
//--------------------------------------------------------------------
static void pep_menu(void)
{
  static int current_selection;

  // Get Current value
  if (R.PEP_period == 20) current_selection = 2;       // 2.0 seconds
  else if (R.PEP_period == 10) current_selection = 1;  // 1.0 second
  else current_selection = 0;                         // 0.1 second

  // Selection modified by encoder.  We remember last selection, even if exit and re-entry
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    current_selection += encoder_steps;
    // Reset data from Encoder
    /* encoderTakeSteps() consumed all queued detents */

    // Indicate that an LCD update is needed
    flag.menu_lcd_upd = false;
  }

  // If LCD update is needed
  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;					  // We have serviced LCD

    // Keep Encoder Selection Within Bounds of the Menu Size
    uint8_t menu_size = pep_menu_size;
    while (current_selection >= menu_size)
      current_selection -= menu_size;
    while (current_selection < 0)
      current_selection += menu_size;

    if      (current_selection == 2) R.PEP_period = 20;
    else if (current_selection == 1) R.PEP_period = 10;
    else R.PEP_period = 1;

    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("PEP hold time:");
    VirtLCD.setCursor(0, 1);
    VirtLCD.print("Select");

    // Print the Rotary Encoder scroll Menu
    lcd_scroll_Menu(pep_menu_items, menu_size, (uint8_t)current_selection, 1, 6, 1);

    VirtLCD.setCursor(0, 2);
    VirtLCD.print("Available periods");
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("0.1, 1 or 2 seconds");
  }

  // Enact selection
  if (flag.short_push)
  {
    VirtLCD.clear();

    flag.short_push = false;            // Clear pushbutton status

    // Check if selected threshold is not same as previous
    EEPROM_readAnything(EEPROM_SETTINGS_ADDR, eeprom_R);
    if (eeprom_R.PEP_period != R.PEP_period)
    {
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    else lcd_center_message("Nothing Changed");

    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;           // Force screensaver reprint upon exit
    flag.config_mode = false;           // We're done with Menu, EXIT
    menu_level = 0;                     // We are done with this menu level
    flag.menu_lcd_upd = false;          // Make ready for next time
  }
}

//--------------------------------------------------------------------
// Peak (PK) OLED hold-time selection Menu
//--------------------------------------------------------------------
static void pk_hold_menu(void)
{
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int32_t next = (int32_t)R.PK_hold_ms + (int32_t)encoder_steps * 100;
    if (next < 100) next = 100;
    if (next > 2000) next = 2000;
    R.PK_hold_ms = (uint16_t)next;
    /* encoderTakeSteps() consumed all queued detents */
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("PK display hold:");
    VirtLCD.setCursor(0, 1);
    snprintf(lcd_buf, sizeof(lcd_buf), "       %.1f seconds", R.PK_hold_ms / 1000.0);
    VirtLCD.print(lcd_buf);
    VirtLCD.setCursor(0, 2);
    VirtLCD.print("Turn to adjust");
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("Push to store");
  }

  if (flag.short_push)
  {
    flag.short_push = false;
    VirtLCD.clear();

    EEPROM_readAnything(EEPROM_SETTINGS_ADDR, eeprom_R);
    if (eeprom_R.PK_hold_ms != R.PK_hold_ms)
    {
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    else lcd_center_message("Nothing Changed");

    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;
    flag.config_mode = false;
    menu_level = 0;
    flag.menu_lcd_upd = false;
  }
}

//--------------------------------------------------------------------
// Screensaver idle-time selection Menu
//--------------------------------------------------------------------
static void screentime_menu(void)
{
  static int current_selection = 4; // default 10 minutes

  // Match the currently stored value whenever we enter/update this menu.
  for (uint8_t i = 0; i < screentime_menu_size; ++i)
  {
    if (R.screensaver_minutes == screentime_minutes[i])
    {
      current_selection = i;
      break;
    }
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    current_selection += encoder_steps;
    /* encoderTakeSteps() consumed all queued detents */
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    const uint8_t menu_size = screentime_menu_size;
    while (current_selection >= menu_size) current_selection -= menu_size;
    while (current_selection < 0) current_selection += menu_size;

    R.screensaver_minutes = screentime_minutes[current_selection];

    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Screensaver time:");
    lcd_scroll_Menu(screentime_menu_items, menu_size,
                    (uint8_t)current_selection, 1, 1, 2);
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("Push to store");
  }

  if (flag.short_push)
  {
    flag.short_push = false;
    EEPROM_readAnything(EEPROM_SETTINGS_ADDR, eeprom_R);

    VirtLCD.clear();
    VirtLCD.setCursor(3, 1);
    if (eeprom_R.screensaver_minutes != R.screensaver_minutes)
    {
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    else
    {
      lcd_center_message("Nothing Changed");
    }

    // A setting change is user activity: restart the idle countdown.
    screensaver_begin_time.start();
    screensaver_active = false;
    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;
    flag.config_mode = false;
    menu_level = 0;
    flag.menu_lcd_upd = false;
  }
}

//--------------------------------------------------------------------
// Full OLED display-off delay selection Menu
//--------------------------------------------------------------------
static void displayoff_menu(void)
{
  static int current_selection = 0; // default Off

  for (uint8_t i = 0; i < displayoff_menu_size; ++i)
  {
    if (R.display_off_minutes == displayoff_minutes[i])
    {
      current_selection = i;
      break;
    }
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    current_selection += encoder_steps;
    /* encoderTakeSteps() consumed all queued detents */
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    const uint8_t menu_size = displayoff_menu_size;
    while (current_selection >= menu_size) current_selection -= menu_size;
    while (current_selection < 0) current_selection += menu_size;

    R.display_off_minutes = displayoff_minutes[current_selection];

    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Display off time:");
    lcd_scroll_Menu(displayoff_menu_items, menu_size,
                    (uint8_t)current_selection, 1, 1, 2);
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("Push to store");
  }

  if (flag.short_push)
  {
    flag.short_push = false;
    EEPROM_readAnything(EEPROM_SETTINGS_ADDR, eeprom_R);

    VirtLCD.clear();
    VirtLCD.setCursor(3, 1);
    if (eeprom_R.display_off_minutes != R.display_off_minutes)
    {
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    else
    {
      lcd_center_message("Nothing Changed");
    }

    screensaver_begin_time.start();
    screensaver_active = false;
    display_off_active = false;
    lcd.displayOn();
    lcd.setContrast(DISPLAY_CONTRAST_ACTIVE);
    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;
    flag.config_mode = false;
    menu_level = 0;
    flag.menu_lcd_upd = false;
  }
}

//--------------------------------------------------------------------
// Screensaver Threshold Sensitivity selection Menu
//--------------------------------------------------------------------
static void screenthresh_menu(void)
{
  static int current_selection;

  // Get current screensaver threshold without relying on floating-point log rounding.
  if      (R.idle_disp_thresh == 0.0f)   current_selection = 0;
  else if (R.idle_disp_thresh == 0.001f) current_selection = 1;
  else if (R.idle_disp_thresh == 0.01f)  current_selection = 2;
  else if (R.idle_disp_thresh == 0.1f)   current_selection = 3;
  else if (R.idle_disp_thresh == 1.0f)   current_selection = 4;
  else                                   current_selection = 5; // 10mW or sanitized fallback

  // Selection modified by encoder.  We remember last selection, even if exit and re-entry
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    current_selection += encoder_steps;
    // Reset data from Encoder
    /* encoderTakeSteps() consumed all queued detents */

    // Indicate that an LCD update is needed
    flag.menu_lcd_upd = false;
  }

  // If LCD update is needed
  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;           // We have serviced LCD

    // Keep Encoder Selection Within Bounds of the Menu Size
    uint8_t menu_size = screenthresh_menu_size;
    while (current_selection >= menu_size)
      current_selection -= menu_size;
    while (current_selection < 0)
      current_selection += menu_size;

    // Update with an explicit value rather than pow(), avoiding float-rounding
    // surprises when the value is later compared with the menu choices.
    static const float thresholds[] = {0.0f, 0.001f, 0.01f, 0.1f, 1.0f, 10.0f};
    R.idle_disp_thresh = thresholds[current_selection];

    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Noise Floor (mW):");
    VirtLCD.setCursor(0, 1);
    VirtLCD.print("Select");

    // Print the Rotary Encoder scroll Menu
    lcd_scroll_Menu(screenthresh_menu_items, menu_size, (uint8_t)current_selection, 1, 6, 1);

    VirtLCD.setCursor(0, 2);
    VirtLCD.print("Available thresholds");
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("0.001-10mW, 10x step");
  }

  // Enact selection
  if (flag.short_push)
  {
    VirtLCD.clear();

    flag.short_push = false;            // Clear pushbutton status

    // Check if selected threshold is not same as previous
    EEPROM_readAnything(EEPROM_SETTINGS_ADDR, eeprom_R);
    if (eeprom_R.idle_disp_thresh != R.idle_disp_thresh)// New Value
    {
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    else lcd_center_message("Nothing Changed");

    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;           // Force screensaver reprint upon exit
    flag.config_mode = false;           // We're done, EXIT
    menu_level = 0;                     // We are done with this menu level
    flag.menu_lcd_upd = false;          // Make ready for next time
  }
}

//--------------------------------------------------------------------
// Power Bar Scale menu
//
// V2.16.5.3:
//   New Power Bar Scale UI.
//
//   SELECT screen:
//     Range 1       x6
//     Range 2      x12
//     Range 3      x24
//     Back
//
//   EDIT screen:
//     One selected range is shown as a large centered value.
//     Turn encoder = adjust value.
//     Push encoder = store value and return to SELECT screen.
//
//   The common encoder code is deliberately not modified.  This menu
//   consumes encoderTakeSteps() exactly once per call.
//--------------------------------------------------------------------
static void scalerange_menu(void)
{
  static int16_t menu_selection = 0;   // 0=Range1, 1=Range2, 2=Range3, 3=Back
  static bool    edit_mode = false;
  static uint8_t edit_range = 0;
  static int16_t edit_value = 0;

  // Consume the queued detents once, and only once, for this menu pass.
  const int16_t encoder_steps = encoderTakeSteps();

  //------------------------------------------------------------------
  // EDIT MODE
  //------------------------------------------------------------------
  if (edit_mode)
  {
    if (encoder_steps != 0)
    {
      edit_value += encoder_steps;

      //--------------------------------------------------------------
      // Apply the permitted limits for the range being edited.
      //--------------------------------------------------------------
      if (edit_range == 0)
      {
        // Range 1: 1..99.
        if (edit_value < 1)  edit_value = 1;
        if (edit_value > 99) edit_value = 99;
      }
      else
      {
        // Range 2 and Range 3:
        //   not below Range 1
        //   below 10 x Range 1
        //   absolute maximum 99
        const int16_t min_range = R.ScaleRange[0];
        int16_t max_range = (int16_t)R.ScaleRange[0] * 10 - 1;

        if (max_range > 99) max_range = 99;
        if (max_range < min_range) max_range = min_range;

        if (edit_value < min_range) edit_value = min_range;
        if (edit_value > max_range) edit_value = max_range;
      }

      //--------------------------------------------------------------
      // Put the new value in the live settings.
      //--------------------------------------------------------------
      R.ScaleRange[edit_range] = (uint8_t)edit_value;

      //--------------------------------------------------------------
      // Keep the three values in a valid order:
      //
      //   Range 1 <= Range 2 <= Range 3 < 10 x Range 1
      //--------------------------------------------------------------
      int16_t max_range = (int16_t)R.ScaleRange[0] * 10 - 1;
      if (max_range > 99) max_range = 99;
      if (max_range < R.ScaleRange[0]) max_range = R.ScaleRange[0];

      if (R.ScaleRange[1] < R.ScaleRange[0])
        R.ScaleRange[1] = R.ScaleRange[0];

      if (R.ScaleRange[2] < R.ScaleRange[0])
        R.ScaleRange[2] = R.ScaleRange[0];

      if (R.ScaleRange[1] > max_range)
        R.ScaleRange[1] = (uint8_t)max_range;

      if (R.ScaleRange[2] > max_range)
        R.ScaleRange[2] = (uint8_t)max_range;

      // Increasing Range 2 can move Range 3 upward with it.
      if ((edit_range == 1) && (R.ScaleRange[1] > R.ScaleRange[2]))
        R.ScaleRange[2] = R.ScaleRange[1];

      // Decreasing Range 3 can move Range 2 downward with it.
      if ((edit_range == 2) && (R.ScaleRange[2] < R.ScaleRange[1]))
        R.ScaleRange[1] = R.ScaleRange[2];

      // A Range 1 change may force both upper ranges into new limits.
      if (edit_range == 0)
      {
        if (R.ScaleRange[1] < R.ScaleRange[0])
          R.ScaleRange[1] = R.ScaleRange[0];

        if (R.ScaleRange[2] < R.ScaleRange[1])
          R.ScaleRange[2] = R.ScaleRange[1];

        if (R.ScaleRange[1] > max_range)
          R.ScaleRange[1] = (uint8_t)max_range;

        if (R.ScaleRange[2] > max_range)
          R.ScaleRange[2] = (uint8_t)max_range;
      }

      // The dependency checks above may have adjusted the edited value.
      edit_value = R.ScaleRange[edit_range];

      flag.menu_lcd_upd = false;
    }

    //--------------------------------------------------------------
    // Draw the new dedicated edit page.
    //
    // PSWR_vLCD recognizes "Turn to adjust" as an adjustment page and
    // renders row 1 as the large centered value.
    //--------------------------------------------------------------
    if (!flag.menu_lcd_upd)
    {
      flag.menu_lcd_upd = true;
      VirtLCD.clear();

      VirtLCD.setCursor(0, 0);
      snprintf(lcd_buf, sizeof(lcd_buf), "Power Bar Scale R%u",
               (unsigned)(edit_range + 1));
      VirtLCD.print(lcd_buf);

      VirtLCD.setCursor(0, 1);
      snprintf(lcd_buf, sizeof(lcd_buf), "x%u",
               (unsigned)R.ScaleRange[edit_range]);
      VirtLCD.print(lcd_buf);

      // Pass the current legal adjustment window to the graphical renderer.
      int16_t ui_min_range = 1;
      int16_t ui_max_range = 99;

      if (edit_range > 0)
      {
        ui_min_range = R.ScaleRange[0];
        ui_max_range = (int16_t)R.ScaleRange[0] * 10 - 1;
        if (ui_max_range > 99) ui_max_range = 99;
        if (ui_max_range < ui_min_range) ui_max_range = ui_min_range;
      }

      VirtLCD.setCursor(0, 2);
      snprintf(lcd_buf, sizeof(lcd_buf), "MIN x%d MAX x%d",
               (int)ui_min_range, (int)ui_max_range);
      VirtLCD.print(lcd_buf);

      VirtLCD.setCursor(0, 3);
      VirtLCD.print("Turn adjust Push save");
    }

    //--------------------------------------------------------------
    // Push = save and go back to the Power Bar Scale list.
    //--------------------------------------------------------------
    if (flag.short_push)
    {
      flag.short_push = false;

      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);

      VirtLCD.clear();
      lcd_center_message("Value Stored");
      Menu_exit_timer = 15;  // Common menu/status display time

      flag.idle_refresh = true;
      flag.config_mode = true;
      menu_level = SCALERANGE_MENU;
      flag.menu_lcd_upd = false;

      edit_mode = false;
    }

    return;
  }

  //------------------------------------------------------------------
  // SELECT MODE
  //------------------------------------------------------------------
  if (encoder_steps != 0)
  {
    menu_selection += encoder_steps;

    while (menu_selection >= 4) menu_selection -= 4;
    while (menu_selection < 0)  menu_selection += 4;

    flag.menu_lcd_upd = false;
  }

  //--------------------------------------------------------------
  // Draw Range 1 / Range 2 / Range 3 / Back as a normal 4-line list.
  //--------------------------------------------------------------
  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();

    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Power Bar Scale");

    VirtLCD.setCursor(0, 1);
    snprintf(lcd_buf, sizeof(lcd_buf), "%sRange 1        x%u",
             (menu_selection == 0) ? "-> " : "   ",
             (unsigned)R.ScaleRange[0]);
    VirtLCD.print(lcd_buf);

    VirtLCD.setCursor(0, 2);
    snprintf(lcd_buf, sizeof(lcd_buf), "%sRange 2        x%u",
             (menu_selection == 1) ? "-> " : "   ",
             (unsigned)R.ScaleRange[1]);
    VirtLCD.print(lcd_buf);

    VirtLCD.setCursor(0, 3);
    snprintf(lcd_buf, sizeof(lcd_buf), "%sRange 3        x%u",
             (menu_selection == 2) ? "-> " : "   ",
             (unsigned)R.ScaleRange[2]);
    VirtLCD.print(lcd_buf);

    VirtLCD.setCursor(0, 4);
    VirtLCD.print((menu_selection == 3) ? "-> Back" : "   Back");
  }

  //--------------------------------------------------------------
  // Push = edit selected range, or return to the main Setup menu.
  //--------------------------------------------------------------
  if (flag.short_push)
  {
    flag.short_push = false;

    if (menu_selection < 3)
    {
      edit_range = (uint8_t)menu_selection;
      edit_value = R.ScaleRange[edit_range];
      edit_mode = true;
      flag.menu_lcd_upd = false;
    }
    else
    {
      // Back returns one level to LJ-OLED Setup, not completely out of Setup.
      menu_level = 0;
      flag.config_mode = true;
      flag.menu_lcd_upd = false;

      menu_selection = 0;
      edit_mode = false;
    }
  }
}

//--------------------------------------------------------------------
// Calibrate Submenu functions
//--------------------------------------------------------------------
static void calibrate_menu_level2(void)
{
  static int16_t  current_selection;                     // Keep track of current LCD menu selection

  uint8_t cal_set;                                       // Determine whether CAL_SET0, CAL_SET1 or CAL_SET2

  if (menu_level == CAL_SET2_MENU) cal_set = 1;	         // CAL_SET2_MENU
  else cal_set = 0;                                      // CAL_SET0_MENU or CAL_SET1_MENU

  // These defines to aid readability of code
#define CAL_BAD	0                                      // Input signal of insufficient quality for calibration
#define CAL_FWD	1                                      // Good input signal detected, forward direction
#define CAL_REV	2                                      // Good input signal detected, reverse direction
  // Below variable can take one of the three above defined values, based on the
  // detected input "calibration" signal
  static uint8_t cal_sig_direction_quality;

  // Get current value. Calibration values are stored as dBm * 10.
  current_selection = R.cal_AD[cal_set].db10m;

  // Calibration-only encoder acceleration. Slow movement adjusts 0.1 dB per
  // detent; quicker movement 1.0 dB. Every other menu
  // continues to use plain one-detent/one-step navigation.
  static int16_t displayed_cal_step_db10 = CAL_ENCODER_FINE_DB10;
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    const int16_t cal_step_db10 = encoderCalibrationStepDb10();
    current_selection += (int32_t)encoder_steps * cal_step_db10;
    displayed_cal_step_db10 = cal_step_db10;
    flag.menu_lcd_upd = false;
  }
  else
  {
    // After a short pause the fine 0.1 dB mode is restored automatically.
    const int16_t cal_step_db10 = encoderCalibrationStepDb10();
    if (cal_step_db10 != displayed_cal_step_db10)
    {
      displayed_cal_step_db10 = cal_step_db10;
      flag.menu_lcd_upd = false;
    }
  }

  // Determine calibration direction from the FILTERED physical detector
  // voltages.  This removes single-sample ADC noise from the decision while
  // still following a direction change very quickly (~13 ms filter time constant).
  //
  // NOTE: this is a DIRECTION-SEPARATION test, not an RF-power test.  V3.3.8
  // inherited the old 12 dB separation requirement, which was unnecessarily
  // strict and could show "Poor signal quality" even with plenty of RF present.
  const double cal_fwd_v = pswr_get_cal_fwd_voltage();
  const double cal_rev_v = pswr_get_cal_rev_voltage();
  const double cal_delta_v = cal_fwd_v - cal_rev_v;

  const double cal_forward_db =  cal_delta_v * 1000.0 / LOGAMP2_SLOPE;
  const double cal_reverse_db = -cal_delta_v * 1000.0 / LOGAMP1_SLOPE;

  if ((cal_forward_db >= CAL_DIRECTION_MIN_DB)
      && (cal_sig_direction_quality != CAL_FWD))
  {
    cal_sig_direction_quality = CAL_FWD;
    flag.menu_lcd_upd = false;
  }
  else if ((cal_reverse_db >= CAL_DIRECTION_MIN_DB)
           && (cal_sig_direction_quality != CAL_REV))
  {
    cal_sig_direction_quality = CAL_REV;
    flag.menu_lcd_upd = false;
  }
  else if ((cal_forward_db < CAL_DIRECTION_MIN_DB)
           && (cal_reverse_db < CAL_DIRECTION_MIN_DB)
           && (cal_sig_direction_quality != CAL_BAD))
  {
    cal_sig_direction_quality = CAL_BAD;
    flag.menu_lcd_upd = false;
  }
  
  // If LCD update is needed
  if(!flag.menu_lcd_upd)  
  {
    flag.menu_lcd_upd = true;                            // We have serviced LCD

    // Keep Encoder Selection Within Bounds of the Menu Size
    int16_t max_value = 650;                             // Highest permissible Calibration value in dBm * 10
    int16_t min_value = -200;                            // Lowest permissible Calibration value in dBm * 10
    if(current_selection > max_value) current_selection = max_value;
    if(current_selection < min_value) current_selection = min_value;

    // Store Current value in running storage
    R.cal_AD[cal_set].db10m = current_selection;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);

    if (menu_level == CAL_SET0_MENU)                     // equals cal_set == 0
    {
      VirtLCD.print("Single Level Cal:");
    }
    else if (menu_level == CAL_SET1_MENU)                // equals cal_set == 1
    {
      VirtLCD.print("First Cal SetPoint:");
    }
    else if (menu_level == CAL_SET2_MENU)
    {
      VirtLCD.print("Second Cal SetPoint:");
    }

    // Format the current calibration value.
    const double current_dbm = current_selection / 10.0;
    snprintf(lcd_buf, sizeof(lcd_buf), "Value      %5.1f dBm", current_dbm);
    VirtLCD.setCursor(0, 1);
    VirtLCD.print(lcd_buf);

    // Make the acceleration visible so the operator always knows the current
    // resolution. After ~350 ms without a detent this returns to 0.1 dB.
    snprintf(lcd_buf, sizeof(lcd_buf), "Step        %3.1f dB",
             displayed_cal_step_db10 / 10.0);
    VirtLCD.setCursor(0, 2);
    VirtLCD.print(lcd_buf);

    VirtLCD.setCursor(0, 3);
    if (cal_sig_direction_quality == CAL_FWD)
      VirtLCD.print(">Push SET<      FWD");
    else if (cal_sig_direction_quality == CAL_REV)
      VirtLCD.print(">Push SET<      REV");
    else                                                 // cal_sig_direction_quality == CAL_BAD
      VirtLCD.print(">Push EXIT<     ---");
  }

  // Enact selection by saving in EEPROM
  if (flag.short_push)
  {
    flag.short_push = false;                             // Clear pushbutton status
    VirtLCD.clear();

    // Save modified value
    // If forward direction, then we calibrate for both, using the measured value for
    // in the forward direction only
    if (cal_sig_direction_quality == CAL_FWD)
    {
      if (menu_level == CAL_SET0_MENU)
      {
       R.cal_AD[0].Fwd = pswr_get_cal_fwd_voltage();
        R.cal_AD[0].Rev = R.cal_AD[0].Fwd;
        // Set second calibration point at 30 dB less
        R.cal_AD[1].db10m = R.cal_AD[0].db10m - 300;
        R.cal_AD[1].Fwd = R.cal_AD[0].Fwd - LOGAMP1_SLOPE * .001 * 30;
        R.cal_AD[1].Rev = R.cal_AD[0].Fwd - LOGAMP2_SLOPE * .001 * 30;
      }
      else
      {
        R.cal_AD[cal_set].Fwd = pswr_get_cal_fwd_voltage();
        R.cal_AD[cal_set].Rev = R.cal_AD[cal_set].Fwd;
      }
      calbanks_commit_active();
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    // If reverse, then we calibrate for reverse direction only
    else if (cal_sig_direction_quality == CAL_REV)
    {
      if (menu_level == CAL_SET0_MENU)
      {
        R.cal_AD[0].Rev = pswr_get_cal_rev_voltage();
        // Set second calibration point at 30 dB less
        R.cal_AD[1].Rev = R.cal_AD[0].Rev - LOGAMP2_SLOPE * .001 * 30;
      }
      else
      {
        R.cal_AD[cal_set].Rev = pswr_get_cal_rev_voltage();
      }
      calbanks_commit_active();
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      lcd_center_message("Value Stored");
    }
    else                                                 // cal_sig_direction_quality == CAL_BAD
    {
      lcd_center_message("Nothing Changed");
    }

    Menu_exit_timer = 15;  // Common menu/status display time
    flag.idle_refresh = true;                            // Force screensaver reprint upon exit
    flag.config_mode = true;                             // We're NOT done, just backing off
    menu_level = CAL_MENU;                               // We are done with this menu level
    flag.menu_lcd_upd = false;                           // Make ready for next time
  }
}




//--------------------------------------------------------------------
// Read-only calibration overview.
//
// Encoder pages: two pages per logical bank (POINTS / SLOPES), in order:
// HF-C1, HF-C2, 6M-C1, 6M-C2, 2M-C1, 2M-C2, 70cm-C1, 70cm-C2.
//
// Push returns to the Calibrate menu. The stored banks are copied for
// display only; the physical coupler selection and active calibration are
// never changed by this overview.
//--------------------------------------------------------------------
static void calibration_overview_menu(void)
{
  static int page = 0;
  constexpr int PAGE_COUNT = CALBANK_TOTAL * 2;

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    page += encoder_steps;
    while (page >= PAGE_COUNT) page -= PAGE_COUNT;
    while (page < 0) page += PAGE_COUNT;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;

    const uint8_t bank = (uint8_t)(page / 2) + 1U;
    const uint8_t subpage = (uint8_t)(page % 2);
    cal_t cal[2] = {};

    VirtLCD.clear();

    if (!calbanks_get(bank, cal))
    {
      VirtLCD.setCursor(0, 0);
      VirtLCD.print("CAL DEBUG");
      VirtLCD.setCursor(0, 1);
      VirtLCD.print("Calibration read err");
      VirtLCD.setCursor(0, 3);
      VirtLCD.print("Push to return");
    }
    else if (subpage == 0U)
    {
      // Compact stored-point overview. Both calibration points are visible at once.
      snprintf(lcd_buf, sizeof(lcd_buf),
               "CAL DEBUG B%u C%u %u/2",
               (unsigned)(calbanks_bank_band(bank) + 1U),
               (unsigned)calbanks_bank_coupler(bank),
               (unsigned)(subpage + 1U));
      VirtLCD.setCursor(0, 0);
      VirtLCD.print(lcd_buf);

      snprintf(lcd_buf, sizeof(lcd_buf),
               "P1 %4.1f P2 %4.1fdBm",
               cal[0].db10m / 10.0,
               cal[1].db10m / 10.0);
      VirtLCD.setCursor(0, 1);
      VirtLCD.print(lcd_buf);

      snprintf(lcd_buf, sizeof(lcd_buf),
               "F1 %5.3f F2 %5.3fV",
               cal[0].Fwd, cal[1].Fwd);
      VirtLCD.setCursor(0, 2);
      VirtLCD.print(lcd_buf);

      snprintf(lcd_buf, sizeof(lcd_buf),
               "R1 %5.3f R2 %5.3fV",
               cal[0].Rev, cal[1].Rev);
      VirtLCD.setCursor(0, 3);
      VirtLCD.print(lcd_buf);
    }
    else
    {
      const double span_db =
        fabs((double)cal[0].db10m - (double)cal[1].db10m) / 10.0;

      double slope_fwd = 0.0;
      double slope_rev = 0.0;
      if (span_db > 0.001)
      {
        slope_fwd = fabs(cal[0].Fwd - cal[1].Fwd) * 1000.0 / span_db;
        slope_rev = fabs(cal[0].Rev - cal[1].Rev) * 1000.0 / span_db;
      }
      const double slope_diff = fabs(slope_fwd - slope_rev);

      snprintf(lcd_buf, sizeof(lcd_buf),
               "CAL DEBUG B%u C%u %u/2",
               (unsigned)(calbanks_bank_band(bank) + 1U),
               (unsigned)calbanks_bank_coupler(bank),
               (unsigned)(subpage + 1U));
      VirtLCD.setCursor(0, 0);
      VirtLCD.print(lcd_buf);

      snprintf(lcd_buf, sizeof(lcd_buf),
               "Span       %4.1fdB",
               span_db);
      VirtLCD.setCursor(0, 1);
      VirtLCD.print(lcd_buf);

      snprintf(lcd_buf, sizeof(lcd_buf),
               "F%4.1f R%4.1f mV/dB",
               slope_fwd, slope_rev);
      VirtLCD.setCursor(0, 2);
      VirtLCD.print(lcd_buf);

      snprintf(lcd_buf, sizeof(lcd_buf),
               "F/R diff  %4.1fmV/dB",
               slope_diff);
      VirtLCD.setCursor(0, 3);
      VirtLCD.print(lcd_buf);
    }
  }

  if (flag.short_push)
  {
    flag.short_push = false;
    menu_level = CAL_MENU;
    flag.menu_lcd_upd = false;
  }
}


//--------------------------------------------------------------------
// Set Your Call menu
//--------------------------------------------------------------------
static void yourcall_menu(void)
{
  if (!yourcall_session_active)
  {
    strncpy(yourcall_edit_text, callsign_get(), YOURCALL_MAX_CHARS);
    yourcall_edit_text[YOURCALL_MAX_CHARS] = '\0';
    yourcall_key_index = 10; // Q
    yourcall_replace_placeholder = (strcmp(yourcall_edit_text, "Your Call") == 0);
    yourcall_session_active = true;
    flag.menu_lcd_upd = false;
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int16_t next = (int16_t)yourcall_key_index + encoder_steps;
    while (next >= YOURCALL_KEY_COUNT) next -= YOURCALL_KEY_COUNT;
    while (next < 0) next += YOURCALL_KEY_COUNT;
    yourcall_key_index = (uint8_t)next;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Set Your Call");

    const size_t len = strlen(yourcall_edit_text);
    const char *tail = yourcall_edit_text;
    if (len > 18) tail += len - 18;
    VirtLCD.setCursor(0, 1);
    VirtLCD.print(tail);

    char keyLine[20];
    snprintf(keyLine, sizeof(keyLine), "Key %02u Len %02u",
             (unsigned)yourcall_key_index, (unsigned)len);
    VirtLCD.setCursor(0, 2);
    VirtLCD.print(keyLine);
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("QWERTY CALL EDIT");
  }

  if (!flag.short_push)
    return;

  flag.short_push = false;
  const uint8_t key = yourcall_key_index;
  size_t len = strlen(yourcall_edit_text);

  if (key < 38)
  {
    if (yourcall_replace_placeholder)
    {
      yourcall_edit_text[0] = '\0';
      len = 0;
      yourcall_replace_placeholder = false;
    }
    if (len < YOURCALL_MAX_CHARS)
    {
      yourcall_edit_text[len] = yourcall_key_chars[key];
      yourcall_edit_text[len + 1] = '\0';
    }
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 38) // SPACE
  {
    if (yourcall_replace_placeholder)
    {
      yourcall_edit_text[0] = '\0';
      len = 0;
      yourcall_replace_placeholder = false;
    }
    if (len < YOURCALL_MAX_CHARS)
    {
      yourcall_edit_text[len] = ' ';
      yourcall_edit_text[len + 1] = '\0';
    }
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 39) // BACKSPACE
  {
    if (len > 0)
      yourcall_edit_text[len - 1] = '\0';
    yourcall_replace_placeholder = false;
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 40) // CLEAR
  {
    yourcall_edit_text[0] = '\0';
    yourcall_replace_placeholder = false;
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 41) // OK / STORE
  {
    VirtLCD.clear();
    if (callsign_set(yourcall_edit_text))
      lcd_center_message("Call Stored");
    else
      lcd_center_message("Call Empty");

    Menu_exit_timer = 15;
    flag.idle_refresh = true;
    flag.config_mode = true;
    menu_level = 0;
    yourcall_session_active = false;
    flag.menu_lcd_upd = false;
    return;
  }

  // key 42 = ESC: return to Setup without changing EEPROM.
  VirtLCD.clear();
  lcd_center_message("Nothing Changed");
  Menu_exit_timer = 15;
  flag.idle_refresh = true;
  flag.config_mode = true;
  menu_level = 0;
  yourcall_session_active = false;
  flag.menu_lcd_upd = false;
}



//--------------------------------------------------------------------
// Clock Primary selector
//--------------------------------------------------------------------
static void clock_primary_menu(void)
{
  if (!clock_primary_session_active)
  {
    clock_primary_selection = clock_primary_get();
    clock_primary_session_active = true;
    flag.menu_lcd_upd = false;
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int16_t next = (int16_t)clock_primary_selection + encoder_steps;
    while (next >= 2) next -= 2;
    while (next < 0) next += 2;
    clock_primary_selection = (uint8_t)next;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Clock Primary");
    VirtLCD.setCursor(0, 1);
    VirtLCD.print(clock_primary_selection == CLOCK_PRIMARY_UTC ? "UTC" : "Local");
    VirtLCD.setCursor(0, 2);
    VirtLCD.print("TURN = SELECT");
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("PUSH = STORE");
  }

  if (!flag.short_push) return;

  flag.short_push = false;
  clock_primary_set(clock_primary_selection);

  // Clock Primary is a live-clock setting, so after STORE return directly
  // to the Clock screen instead of stepping back through the Setup menu.
  mode_display = POWER_CLOCK;
  if (R.mode_display != mode_display)
  {
    R.mode_display = mode_display;
    EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
  }

  VirtLCD.clear();
  Menu_exit_timer = 0;
  flag.idle_refresh = true;
  flag.config_mode = false;
  menu_level = 0;
  clock_primary_session_active = false;
  flag.menu_lcd_upd = false;
}

//--------------------------------------------------------------------
// Clock Dim Time selector
//--------------------------------------------------------------------
static void clock_dim_menu(void)
{
  if (!clock_dim_session_active)
  {
    clock_dim_selection = clock_dim_mode_get();
    clock_dim_session_active = true;
    flag.menu_lcd_upd = false;
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int16_t next = (int16_t)clock_dim_selection + encoder_steps;
    while (next >= CLOCK_DIM_COUNT) next -= CLOCK_DIM_COUNT;
    while (next < 0) next += CLOCK_DIM_COUNT;
    clock_dim_selection = (uint8_t)next;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    static const char * const labels[CLOCK_DIM_COUNT] =
      { "5 Min", "10 Min", "30 Min", "Off" };

    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Clock Dim Time");
    VirtLCD.setCursor(0, 1);
    VirtLCD.print(labels[clock_dim_selection]);
    VirtLCD.setCursor(0, 2);
    VirtLCD.print("TURN = SELECT");
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("PUSH = STORE");
  }

  if (!flag.short_push) return;

  flag.short_push = false;
  clock_dim_mode_set(clock_dim_selection);

  // Like Clock Primary, this is a live-clock setting: after STORE go directly
  // back to the Clock screen so the selected timeout can be tested immediately.
  mode_display = POWER_CLOCK;
  if (R.mode_display != mode_display)
  {
    R.mode_display = mode_display;
    EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
  }

  VirtLCD.clear();
  Menu_exit_timer = 0;
  flag.idle_refresh = true;
  flag.config_mode = false;
  menu_level = 0;
  clock_dim_session_active = false;
  flag.menu_lcd_upd = false;
}

//--------------------------------------------------------------------
// Maidenhead Grid editor
//--------------------------------------------------------------------
static void grid_menu(void)
{
  if (!grid_session_active)
  {
    strncpy(grid_edit_text, grid_square_get(), GRID_MAX_CHARS);
    grid_edit_text[GRID_MAX_CHARS] = '\0';
    grid_key_index = 10; // Q
    grid_session_active = true;
    flag.menu_lcd_upd = false;
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int16_t next = (int16_t)grid_key_index + encoder_steps;
    while (next >= YOURCALL_KEY_COUNT) next -= YOURCALL_KEY_COUNT;
    while (next < 0) next += YOURCALL_KEY_COUNT;
    grid_key_index = (uint8_t)next;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Set Grid");

    const size_t len = strlen(grid_edit_text);
    const char *tail = grid_edit_text;
    if (len > 18) tail += len - 18;
    VirtLCD.setCursor(0, 1);
    if (len > 0) VirtLCD.print(tail);
    else VirtLCD.print("JO33IC / JO33IC78");

    char keyLine[20];
    snprintf(keyLine, sizeof(keyLine), "Key %02u Len %02u",
             (unsigned)grid_key_index, (unsigned)len);
    VirtLCD.setCursor(0, 2);
    VirtLCD.print(keyLine);
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("GRID SQUARE EDIT");
  }

  if (!flag.short_push)
    return;

  flag.short_push = false;
  const uint8_t key = grid_key_index;
  size_t len = strlen(grid_edit_text);

  if (key < 38)
  {
    if (len < GRID_MAX_CHARS)
    {
      char c = yourcall_key_chars[key];
      if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
      grid_edit_text[len] = c;
      grid_edit_text[len + 1] = '\0';
    }
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 38) // SPACE ignored for grid squares
  {
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 39) // BACKSPACE
  {
    if (len > 0) grid_edit_text[len - 1] = '\0';
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 40) // CLEAR
  {
    grid_edit_text[0] = '\0';
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 41) // OK / STORE
  {
    VirtLCD.clear();
    if (grid_square_set(grid_edit_text))
      lcd_center_message(grid_edit_text[0] ? "Grid Stored" : "Grid Cleared");
    else
      lcd_center_message("Grid Invalid");

    Menu_exit_timer = 15;
    flag.idle_refresh = true;
    flag.config_mode = true;
    menu_level = 0;
    grid_session_active = false;
    flag.menu_lcd_upd = false;
    return;
  }

  // ESC: return to Setup without changing EEPROM.
  VirtLCD.clear();
  lcd_center_message("Nothing Changed");
  Menu_exit_timer = 15;
  flag.idle_refresh = true;
  flag.config_mode = true;
  menu_level = 0;
  grid_session_active = false;
  flag.menu_lcd_upd = false;
}

//--------------------------------------------------------------------
// WiFi SSID / Password editor - same encoder QWERTY keyboard as Set Your Call
//--------------------------------------------------------------------
static void wifi_text_menu(bool passwordMode)
{
  const size_t maxChars = passwordMode ? WIFI_PASSWORD_MAX_CHARS : WIFI_SSID_MAX_CHARS;

  if (!wifi_session_active || wifi_password_mode != passwordMode)
  {
    const char *source = passwordMode ? wifi_password_get() : wifi_ssid_get();
    if (passwordMode && wifi_password_from_scan) source = "";
    strncpy(wifi_edit_text, source ? source : "", maxChars);
    wifi_edit_text[maxChars] = '\0';
    wifi_key_index = 10; // Q
    wifi_password_mode = passwordMode;
    wifi_replace_placeholder = (!passwordMode && strcmp(wifi_edit_text, "Your SSID") == 0);
    wifi_session_active = true;
    flag.menu_lcd_upd = false;
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int16_t next = (int16_t)wifi_key_index + encoder_steps;
    while (next >= YOURCALL_KEY_COUNT) next -= YOURCALL_KEY_COUNT;
    while (next < 0) next += YOURCALL_KEY_COUNT;
    wifi_key_index = (uint8_t)next;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print(passwordMode ? "WiFi Password" : "WiFi SSID");
    VirtLCD.setCursor(0, 1);
    if (passwordMode) VirtLCD.print("Password hidden");
    else
    {
      const size_t len = strlen(wifi_edit_text);
      const char *tail = wifi_edit_text;
      if (len > 18) tail += len - 18;
      VirtLCD.print(tail);
    }
    // Keep a changing value in the virtual LCD buffer so TextLCD::transfer()
    // detects every encoder movement and redraws the graphical keyboard.
    // The graphical WiFi renderer uses menuWifiKeyIndex() for the highlight;
    // this row is only a redraw trigger, just like Set Your Call.
    {
      char keyLine[20];
      const size_t len = strlen(wifi_edit_text);
      snprintf(keyLine, sizeof(keyLine), "Key %02u Len %02u",
               (unsigned)wifi_key_index, (unsigned)len);
      VirtLCD.setCursor(0, 2);
      VirtLCD.print(keyLine);
    }

    VirtLCD.setCursor(0, 3);
    VirtLCD.print("QWERTY WIFI EDIT");
  }

  if (!flag.short_push) return;

  flag.short_push = false;
  const uint8_t key = wifi_key_index;
  size_t len = strlen(wifi_edit_text);

  if (key < 38)
  {
    if (wifi_replace_placeholder)
    {
      wifi_edit_text[0] = '\0';
      len = 0;
      wifi_replace_placeholder = false;
    }
    if (len < maxChars)
    {
      wifi_edit_text[len] = yourcall_key_chars[key];
      wifi_edit_text[len + 1] = '\0';
    }
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 38) // SPACE
  {
    if (wifi_replace_placeholder)
    {
      wifi_edit_text[0] = '\0';
      len = 0;
      wifi_replace_placeholder = false;
    }
    if (len < maxChars)
    {
      wifi_edit_text[len] = ' ';
      wifi_edit_text[len + 1] = '\0';
    }
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 39) // BACKSPACE
  {
    if (len > 0) wifi_edit_text[len - 1] = '\0';
    wifi_replace_placeholder = false;
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 40) // CLEAR
  {
    wifi_edit_text[0] = '\0';
    wifi_replace_placeholder = false;
    flag.menu_lcd_upd = false;
    return;
  }

  if (key == 41) // OK / STORE
  {
    bool saved = false;

    if (passwordMode && wifi_password_from_scan)
    {
      // Commit the scanned SSID and its password together. Until this point
      // the selected network existed only in RAM.
      saved = wifi_ssid_set(wifi_pending_ssid) && wifi_password_set(wifi_edit_text);
    }
    else
    {
      saved = passwordMode ? wifi_password_set(wifi_edit_text)
                           : wifi_ssid_set(wifi_edit_text);
    }

    VirtLCD.clear();
    if (saved)
    {
      wifi_link_credentials_changed();
      lcd_center_message(passwordMode ? "Password Stored" : "SSID Stored");
    }
    else
      lcd_center_message(passwordMode ? "Password Invalid" : "SSID Invalid");

    wifi_password_from_scan = false;
    wifi_pending_ssid[0] = '\0';
    Menu_exit_timer = 15;
    flag.idle_refresh = true;
    flag.config_mode = true;
    menu_level = 0;
    wifi_session_active = false;
    flag.menu_lcd_upd = false;
    return;
  }

  // ESC: leave without changing stored credentials.
  VirtLCD.clear();
  lcd_center_message("Nothing Changed");
  Menu_exit_timer = 15;
  flag.idle_refresh = true;
  flag.config_mode = true;
  menu_level = 0;
  wifi_session_active = false;
  wifi_password_from_scan = false;
  wifi_pending_ssid[0] = '\0';
  flag.menu_lcd_upd = false;
}


//--------------------------------------------------------------------
// Startup Logo selector
//--------------------------------------------------------------------
static void startup_logo_menu(void)
{
  if (!startup_logo_session_active)
  {
    startup_logo_edit_index = startup_logo_get();
    startup_logo_session_active = true;
    flag.menu_lcd_upd = false;
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int16_t next = (int16_t)startup_logo_edit_index + encoder_steps;
    while (next >= STARTUP_LOGO_COUNT) next -= STARTUP_LOGO_COUNT;
    while (next < 0) next += STARTUP_LOGO_COUNT;
    startup_logo_edit_index = (uint8_t)next;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Startup Logo");

    char line[21];
    snprintf(line, sizeof(line), "Logo %u of %u",
             (unsigned)(startup_logo_edit_index + 1U),
             (unsigned)STARTUP_LOGO_COUNT);
    VirtLCD.setCursor(0, 1);
    VirtLCD.print(line);
    VirtLCD.setCursor(0, 2);
    VirtLCD.print(startup_logo_name(startup_logo_edit_index));
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("Logo Select");
  }

  if (!flag.short_push)
    return;

  flag.short_push = false;
  startup_logo_set(startup_logo_edit_index);
  VirtLCD.clear();
  lcd_center_message("Logo Stored");
  Menu_exit_timer = 15;
  flag.idle_refresh = true;
  flag.config_mode = true;
  menu_level = 0;
  startup_logo_session_active = false;
  flag.menu_lcd_upd = false;
}

//--------------------------------------------------------------------
// Band Select menu: HF / 6M / 2M / 70cm.
// The band changes only the active calibration bank. The physical coupler
// state/output is never changed here.
//--------------------------------------------------------------------
static void band_select_menu(void)
{
  if (!band_select_session_active)
  {
    band_select_edit_index = calbanks_active_band();
    band_select_coupler_index = cpl ? 1U : 0U;
    band_select_session_active = true;
    flag.menu_lcd_upd = false;
  }

  // The external coupler button remains active while BAND SELECT is open.
  // When CPL1/CPL2 changes, immediately show THAT coupler's remembered band.
  const uint8_t currentCouplerIndex = cpl ? 1U : 0U;
  if (currentCouplerIndex != band_select_coupler_index)
  {
    band_select_coupler_index = currentCouplerIndex;
    band_select_edit_index = calbanks_active_band();
    flag.menu_lcd_upd = false;
  }

  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    int16_t next = (int16_t)band_select_edit_index + encoder_steps;
    while (next >= CALBAND_COUNT) next -= CALBAND_COUNT;
    while (next < 0) next += CALBAND_COUNT;
    band_select_edit_index = (uint8_t)next;

    // V3.54: Band Select edits only the currently active physical coupler.
    // CPL1 and CPL2 remember their bands independently.
    calbanks_select_band(band_select_edit_index);

    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Band Select");
    VirtLCD.setCursor(0, 1);
    VirtLCD.print(calbanks_band_name(band_select_edit_index));
    VirtLCD.setCursor(0, 2);
    VirtLCD.print(cpl ? "Coupler 2" : "Coupler 1");
    VirtLCD.setCursor(0, 3);
    VirtLCD.print("Turn select Push save");
  }

  if (!flag.short_push)
    return;

  flag.short_push = false;
  calbanks_select_band(band_select_edit_index);

  VirtLCD.clear();
  char msg[24];
  snprintf(msg, sizeof(msg), "Band %s Selected", calbanks_active_band_name());
  lcd_center_message(msg);
  Menu_exit_timer = 15;
  flag.idle_refresh = true;

  if (band_select_return_to_setup)
  {
    flag.config_mode = true;
    menu_level = 0;
  }
  else
  {
    flag.config_mode = false;
    menu_level = 0;
  }

  band_select_session_active = false;
  flag.menu_lcd_upd = false;
}


//--------------------------------------------------------------------
// Calibrate Menu functions
//--------------------------------------------------------------------
static void calibrate_menu(void)
{
  static int current_selection;                       // Keep track of current LCD menu selection

  // Selection modified by encoder.  We remember last selection, even if exit and re-entry
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    current_selection += encoder_steps;
    // Reset data from Encoder
    /* encoderTakeSteps() consumed all queued detents */
    // Indicate that an LCD update is needed
    flag.menu_lcd_upd = false;
  }

  // If LCD update is needed
  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;                            // We have serviced LCD

    // Keep Encoder Selection Within Bounds of the Menu Size
    uint8_t menu_size = calibrate_menu_size;
    while (current_selection >= menu_size)
      current_selection -= menu_size;
    while (current_selection < 0)
      current_selection += menu_size;

    VirtLCD.clear();

    // Print the Rotary Encoder scroll Menu
    lcd_scroll_Menu(calibrate_menu_items, menu_size, (uint8_t)current_selection, 1, 0, 1);

    switch (current_selection)
    {
      case 0:
        VirtLCD.setCursor(0, 2);
        VirtLCD.print("Calibrate using one");
        VirtLCD.setCursor(6, 3);
        VirtLCD.print("accurate level");
        break;
      case 1:
        VirtLCD.setCursor(0, 2);
        VirtLCD.print("Set higher of two");
        VirtLCD.setCursor(5, 3);
        VirtLCD.print("accurate levels");
        break;
      case 2:
        VirtLCD.setCursor(0, 2);
        VirtLCD.print("Set lower of two");
        VirtLCD.setCursor(5, 3);
        VirtLCD.print("accurate levels");
        break;
      case 3:
        VirtLCD.setCursor(0, 2);
        VirtLCD.print("8 band/coupler banks");
        VirtLCD.setCursor(0, 3);
        VirtLCD.print("points + slope debug");
        break;
    }

    // Indicate Current value stored under the currently selected GainPreset
    // The "stored" value indication changes according to which GainPreset is currently selected.
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("Calibrate");
    if (current_selection <= 2)
    {
      int16_t value = 0;

      switch (current_selection)
      {
        case 0:
        case 1:
          value = R.cal_AD[0].db10m;
          break;
        case 2:
          value = R.cal_AD[1].db10m;
          break;
      }
      int16_t val_sub = value;
      int16_t val = val_sub / 10;
      val_sub = val_sub % 10;

      // Print value of currently indicated reference
      VirtLCD.setCursor(16, 0);
      if (value < 0)
      {
        val *= -1;
        val_sub *= -1;
        snprintf(lcd_buf, sizeof(lcd_buf), "-%1u.%01u", val, val_sub);
      }
      else
      {
        snprintf(lcd_buf, sizeof(lcd_buf), "%2u.%01u", val, val_sub);
      }
      VirtLCD.print(lcd_buf);
    }
    else
    {
      VirtLCD.setCursor(16, 0);
      VirtLCD.print(" --");
    }
  }

  // Enact selection
  if (flag.short_push)
  {
    flag.short_push = false;                             // Clear pushbutton status

    switch (current_selection)
    {
      case 0:
        menu_level = CAL_SET0_MENU;
        flag.menu_lcd_upd = false;                       // force LCD reprint
        break;
      case 1:
        menu_level = CAL_SET1_MENU;
        flag.menu_lcd_upd = false;                       // force LCD reprint
        break;
      case 2:
        menu_level = CAL_SET2_MENU;
        flag.menu_lcd_upd = false;                       // force LCD reprint
        break;
      case 3:
        menu_level = CAL_OVERVIEW_MENU;
        flag.menu_lcd_upd = false;
        break;
      case 4:
        VirtLCD.clear();
        VirtLCD.setCursor(4, 1);
        VirtLCD.print("Done with Calibration");
        Menu_exit_timer = 15;  // Common menu/status display time
        flag.idle_refresh = true;                        // Force screensaver reprint upon exit
        flag.config_mode = true;                         // We're NOT done, just backing off
        menu_level = 0;                                  // We are done with this menu level
        flag.menu_lcd_upd = false;                       // Make ready for next time
        break;
      default:
        VirtLCD.clear();
        VirtLCD.setCursor(4, 1);
        VirtLCD.print("Done with Calibration");
        Menu_exit_timer = 15;  // Common menu/status display time
        flag.idle_refresh = true;                        // Force screensaver reprint upon exit
        flag.config_mode = false;                        // We're done
        menu_level = 0;                                  // We are done with this menu level
        flag.menu_lcd_upd = false;                       // Make ready for next time
        break;
    }
  }
}


//--------------------------------------------------------------------
// Factory Reset with all default values
//--------------------------------------------------------------------
static void factory_menu(void)
{
  static int current_selection;
  static bool confirm_reset = false;
  static int confirm_selection = 0;  // Always enter on the safe CANCEL choice.

  // Selection modified by encoder. We remember the normal Factory Reset
  // selection between visits, but the destructive confirmation always starts
  // on CANCEL.
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    if (confirm_reset)
      confirm_selection += encoder_steps;
    else
      current_selection += encoder_steps;

    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;

    VirtLCD.clear();

    if (confirm_reset)
    {
      const uint8_t menu_size = factory_confirm_menu_size;
      while (confirm_selection >= menu_size)
        confirm_selection -= menu_size;
      while (confirm_selection < 0)
        confirm_selection += menu_size;

      VirtLCD.setCursor(0, 0);
      VirtLCD.print("ARE YOU SURE?");

      lcd_scroll_Menu(factory_confirm_menu_items, menu_size,
                      (uint8_t)confirm_selection, 1, 0, 1);

      VirtLCD.setCursor(0, 3);
      VirtLCD.print("Factory Confirm");
    }
    else
    {
      const uint8_t menu_size = factory_menu_size;
      while (current_selection >= menu_size)
        current_selection -= menu_size;
      while (current_selection < 0)
        current_selection += menu_size;

      VirtLCD.setCursor(0, 0);
      VirtLCD.print("All to Default?");

      lcd_scroll_Menu(factory_menu_items, menu_size,
                      (uint8_t)current_selection, 1, 0, 1);

      VirtLCD.setCursor(0, 3);
      VirtLCD.print("Factory Reset Menu");
    }
  }

  if (flag.short_push)
  {
    flag.short_push = false;

    if (confirm_reset)
    {
      if (confirm_selection == 0)
      {
        // CANCEL: return to the first Factory Reset page. Nothing is changed.
        confirm_reset = false;
        current_selection = 0;
        flag.menu_lcd_upd = false;
      }
      else
      {
        // Final, explicit RESET confirmation.
        EEPROM.write(EEPROM_COLDSTART_ADDR, 0xfe);
        VirtLCD.clear();
        lcd_center_message("Factory Reset", 1);
        lcd_center_message("All defaults", 2);
        Menu_exit_timer = 15;
        flag.idle_refresh = true;
        SOFT_RESET();
      }
      return;
    }

    switch (current_selection)
    {
      case 0:
        VirtLCD.clear();
        lcd_center_message("Nothing Changed");
        Menu_exit_timer = 15;
        flag.idle_refresh = true;
        flag.config_mode = true;
        menu_level = 0;
        flag.menu_lcd_upd = false;
        break;

      case 1:
        // Do NOT reset here. Enter the dedicated second confirmation page.
        confirm_reset = true;
        confirm_selection = 0;
        flag.menu_lcd_upd = false;
        break;

      default:
        VirtLCD.clear();
        lcd_center_message("Nothing Changed");
        Menu_exit_timer = 15;
        flag.idle_refresh = true;
        flag.config_mode = false;
        menu_level = 0;
        flag.menu_lcd_upd = false;
        break;
    }
  }
}


//--------------------------------------------------------------------
// WiFi network scan / selector.
//--------------------------------------------------------------------
static void wifi_scan_menu(void)
{
  static bool lastBusy = false;
  static bool lastReady = false;
  static uint8_t lastCount = 0;

  if (!wifi_scan_session_active)
  {
    wifi_scan_session_active = true;
    wifi_scan_selection = 0;
    lastBusy = true;
    lastReady = false;
    lastCount = 0;
    wifi_link_scan_start();
    flag.menu_lcd_upd = false;
  }

  const bool busy = wifi_link_scan_busy();
  const bool ready = wifi_link_scan_ready();
  const uint8_t count = wifi_link_scan_count();

  if (busy != lastBusy || ready != lastReady || count != lastCount)
  {
    lastBusy = busy;
    lastReady = ready;
    lastCount = count;
    wifi_scan_selection = 0;
    flag.menu_lcd_upd = false;
  }

  // While the XIAO is scanning, a push simply returns to Setup.
  if (busy)
  {
    encoderTakeSteps();
    if (!flag.menu_lcd_upd)
    {
      flag.menu_lcd_upd = true;
      VirtLCD.clear();
      VirtLCD.setCursor(0, 0); VirtLCD.print("WiFi Networks");
      VirtLCD.setCursor(0, 1); VirtLCD.print("Scanning...");
      VirtLCD.setCursor(0, 2); VirtLCD.print("Please wait");
      VirtLCD.setCursor(0, 3); VirtLCD.print("WIFI SCAN BUSY");
    }
    if (flag.short_push)
    {
      flag.short_push = false;
      wifi_scan_session_active = false;
      menu_level = 0;
      flag.menu_lcd_upd = false;
    }
    return;
  }

  // Network entries + RESCAN + MANUAL ENTRY + BACK.
  const int16_t choiceCount = (int16_t)count + 3;
  const int16_t encoderSteps = encoderTakeSteps();
  if (encoderSteps != 0)
  {
    wifi_scan_selection += encoderSteps;
    while (wifi_scan_selection >= choiceCount) wifi_scan_selection -= choiceCount;
    while (wifi_scan_selection < 0) wifi_scan_selection += choiceCount;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0); VirtLCD.print("WiFi Networks");
    VirtLCD.setCursor(0, 1);
    if (wifi_link_scan_failed()) VirtLCD.print("Scan failed - Rescan");
    else if (count == 0) VirtLCD.print("No networks found");
    else
    {
      const char *ssid = (wifi_scan_selection < count)
                           ? wifi_link_scan_ssid((uint8_t)wifi_scan_selection)
                           : "Options";
      VirtLCD.print(ssid);
    }
    char state[20];
    snprintf(state, sizeof(state), "Sel %02d AP %02u", (int)wifi_scan_selection,
             (unsigned)count);
    VirtLCD.setCursor(0, 2); VirtLCD.print(state);
    VirtLCD.setCursor(0, 3); VirtLCD.print("WIFI SCAN READY");
  }

  if (!flag.short_push) return;
  flag.short_push = false;

  if (wifi_scan_selection < count)
  {
    strncpy(wifi_pending_ssid,
            wifi_link_scan_ssid((uint8_t)wifi_scan_selection),
            WIFI_SSID_MAX_CHARS);
    wifi_pending_ssid[WIFI_SSID_MAX_CHARS] = '\0';
    wifi_password_from_scan = true;
    wifi_scan_session_active = false;
    wifi_session_active = false;
    menu_level = WIFI_PASSWORD_MENU;
    flag.menu_lcd_upd = false;
    return;
  }

  const int16_t special = wifi_scan_selection - count;
  if (special == 0) // RESCAN
  {
    wifi_scan_selection = 0;
    wifi_link_scan_start();
    flag.menu_lcd_upd = false;
    return;
  }

  if (special == 1) // MANUAL ENTRY
  {
    wifi_scan_session_active = false;
    wifi_password_from_scan = false;
    wifi_pending_ssid[0] = '\0';
    wifi_session_active = false;
    menu_level = WIFI_SSID_MANUAL_MENU;
    flag.menu_lcd_upd = false;
    return;
  }

  // BACK
  wifi_scan_session_active = false;
  menu_level = 0;
  flag.menu_lcd_upd = false;
}


//--------------------------------------------------------------------
// Read-only WiFi status page. Updated twice per second so RSSI remains live.
//--------------------------------------------------------------------
static void wifi_status_menu(void)
{
  static uint32_t lastRefresh = 0;
  const uint32_t now = millis();

  encoderTakeSteps();
  if ((uint32_t)(now - lastRefresh) >= 500UL)
  {
    lastRefresh = now;
    flag.menu_lcd_upd = false;
  }

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;
    VirtLCD.clear();
    VirtLCD.setCursor(0, 0); VirtLCD.print("WiFi Status");
    VirtLCD.setCursor(0, 1);
    VirtLCD.print(wifi_link_connected() ? "Connected" : "Disconnected");
    VirtLCD.setCursor(0, 2);
    VirtLCD.print(wifi_link_connected() ? wifi_link_ip() : "No IP address");
    VirtLCD.setCursor(0, 3);
    const char *wifiFw = wifi_link_firmware_version();
    snprintf(lcd_buf, sizeof(lcd_buf), "RSSI %d dBm  FW %s",
             wifi_link_rssi(), (wifiFw && wifiFw[0]) ? wifiFw : "--");
    VirtLCD.print(lcd_buf);
  }

  if (flag.short_push)
  {
    flag.short_push = false;
    menu_level = 0;
    flag.menu_lcd_upd = false;
  }
}


//
//--------------------------------------------------------------------
// Manage the first level of Menus
//--------------------------------------------------------------------
//
static void menu_level0(void)
{
  static int current_selection; // Position within the currently visible menu
  static bool last_wifi_present = false;
  static bool presence_initialized = false;

  const bool wifi_present = wifi_link_module_present();

  // If the XIAO comes alive while Setup is already open, redraw immediately so
  // the WiFi/clock entries appear without leaving and re-entering the menu.
  if (!presence_initialized || wifi_present != last_wifi_present)
  {
    last_wifi_present = wifi_present;
    presence_initialized = true;
    flag.menu_lcd_upd = false;
  }

  const char *visible_items[level0_menu_size];
  uint8_t visible_actions[level0_menu_size];
  uint8_t visible_count = 0;

  for (uint8_t i = 0; i < level0_menu_size; ++i)
  {
    if (level0_menu_requires_wifi[i] && !wifi_present)
      continue;

    visible_items[visible_count] = level0_menu_items[i];
    visible_actions[visible_count] = level0_menu_actions[i];
    ++visible_count;
  }

  if (visible_count == 0)
    return;

  // Selection modified by encoder. We remember last visible position.
  const int16_t encoder_steps = encoderTakeSteps();
  if (encoder_steps != 0)
  {
    current_selection += encoder_steps;
    flag.menu_lcd_upd = false;
  }

  while (current_selection >= visible_count)
    current_selection -= visible_count;
  while (current_selection < 0)
    current_selection += visible_count;

  if (!flag.menu_lcd_upd)
  {
    flag.menu_lcd_upd = true;

    VirtLCD.clear();
    VirtLCD.setCursor(0, 0);
    VirtLCD.print("JH2KW-M SETUP:");

    lcd_scroll_Menu(visible_items, visible_count,
                    (uint8_t)current_selection, 1, 0, 4);
  }

  if (!flag.short_push)
    return;

  flag.short_push = false;
  flag.menu_lcd_upd = false;

  const uint8_t action = visible_actions[current_selection];
  switch (action)
  {
    case SETUP_SWR_ALARM:
      menu_level = SWR_ALARM_THRESHOLD;
      break;

    case SETUP_SWR_POWER:
      menu_level = SWR_ALARM_PWR_THRESHOLD;
      break;

    case SETUP_PEP_HOLD:
      menu_level = PEP_MENU;
      break;

    case SETUP_PK_HOLD:
      menu_level = PK_HOLD_MENU;
      break;

    case SETUP_NOISE_FLOOR:
      menu_level = SCREENTHRESH_MENU;
      break;

    case SETUP_SCREENSAVER_TIME:
      menu_level = SCREENTIME_MENU;
      break;

    case SETUP_DISPLAY_OFF_TIME:
      menu_level = DISPLAYOFF_MENU;
      break;

    case SETUP_POWER_BAR_SCALE:
      menu_level = SCALERANGE_MENU;
      break;

    case SETUP_SET_CALL:
      menu_level = YOURCALL_MENU;
      yourcall_session_active = false;
      break;

    case SETUP_SET_GRID:
      menu_level = GRID_MENU;
      grid_session_active = false;
      break;

    case SETUP_CLOCK_PRIMARY:
      menu_level = CLOCK_PRIMARY_MENU;
      clock_primary_session_active = false;
      break;

    case SETUP_CLOCK_DIM:
      menu_level = CLOCK_DIM_MENU;
      clock_dim_session_active = false;
      break;

    case SETUP_WIFI_SSID:
      menu_level = WIFI_SSID_MENU;
      wifi_scan_session_active = false;
      break;

    case SETUP_WIFI_PASSWORD:
      menu_level = WIFI_PASSWORD_MENU;
      wifi_password_from_scan = false;
      wifi_pending_ssid[0] = '\0';
      wifi_session_active = false;
      break;

    case SETUP_WIFI_STATUS:
      menu_level = WIFI_STATUS_MENU;
      break;

    case SETUP_STARTUP_LOGO:
      menu_level = STARTUP_LOGO_MENU;
      startup_logo_session_active = false;
      break;

    case SETUP_CALIBRATE:
      menu_level = CAL_MENU;
      break;

    case SETUP_DIAGNOSTICS:
      menu_level = DEBUG_MENU;
      break;

    case SETUP_FACTORY_RESET:
      menu_level = FACTORY_MENU;
      break;

    case SETUP_EXIT:
    default:
      VirtLCD.clear();
      VirtLCD.setCursor(2, 1);
      Menu_exit_timer = 15;
      VirtLCD.print("Return from Menu");
      flag.config_mode = false;
      break;
  }
}


//
//--------------------------------------------------------------------
// Scan the Configuraton Menu Status and delegate tasks accordingly
//--------------------------------------------------------------------
//
void ConfigMenu(void)
{
  // Select which menu level to manage
  if (menu_level == 0) menu_level0();

  else if (menu_level == SWR_ALARM_THRESHOLD) swr_alarm_threshold_menu();
  else if (menu_level == SWR_ALARM_PWR_THRESHOLD) swr_alarm_power_threshold_menu();

  else if (menu_level == PEP_MENU) pep_menu();
  else if (menu_level == PK_HOLD_MENU) pk_hold_menu();

  else if (menu_level == SCREENTHRESH_MENU) screenthresh_menu();
  else if (menu_level == SCREENTIME_MENU) screentime_menu();
  else if (menu_level == DISPLAYOFF_MENU) displayoff_menu();

  else if (menu_level == SCALERANGE_MENU) scalerange_menu();
  else if (menu_level == CAL_MENU) calibrate_menu();
  else if (menu_level == CAL_SET0_MENU) calibrate_menu_level2();
  else if (menu_level == CAL_SET1_MENU) calibrate_menu_level2();
  else if (menu_level == CAL_SET2_MENU) calibrate_menu_level2();
  else if (menu_level == CAL_OVERVIEW_MENU) calibration_overview_menu();

  else if (menu_level == YOURCALL_MENU) yourcall_menu();
  else if (menu_level == GRID_MENU) grid_menu();
  else if (menu_level == CLOCK_PRIMARY_MENU) clock_primary_menu();
  else if (menu_level == CLOCK_DIM_MENU) clock_dim_menu();
  else if (menu_level == WIFI_SSID_MENU) wifi_scan_menu();
  else if (menu_level == WIFI_SSID_MANUAL_MENU) wifi_text_menu(false);
  else if (menu_level == WIFI_PASSWORD_MENU) wifi_text_menu(true);
  else if (menu_level == WIFI_STATUS_MENU) wifi_status_menu();
  else if (menu_level == STARTUP_LOGO_MENU) startup_logo_menu();
  else if (menu_level == BAND_MENU) band_select_menu();

  else if (menu_level == DEBUG_MENU) debug_menu();

  else if (menu_level == FACTORY_MENU) factory_menu();
}
