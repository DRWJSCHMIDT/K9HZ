#include "DisplayPower.h"
#include "DisplaySetup.h"

namespace {
constexpr uint8_t MIN_BRIGHTNESS_PERCENT = 10;
constexpr uint8_t MAX_BRIGHTNESS_PERCENT = 100;
constexpr uint8_t SCREENSAVER_DIM_PERCENT = 10;
// Stable V1.6 used 254 at full brightness. Do not use 255.
constexpr uint16_t MAX_PWM = 254;

uint8_t configuredBrightness = 100;
uint16_t configuredSaverMinutes = 0;
uint32_t lastActivityMillis = 0;
bool dimmed = false;

uint8_t percentToPwm(uint8_t percent) {
  if (percent < MIN_BRIGHTNESS_PERCENT) percent = MIN_BRIGHTNESS_PERCENT;
  if (percent > MAX_BRIGHTNESS_PERCENT) percent = MAX_BRIGHTNESS_PERCENT;
  return static_cast<uint8_t>((static_cast<uint32_t>(percent) * MAX_PWM + 50U) / 100U);
}

void applyNormalBrightness() {
  const uint8_t pwm = percentToPwm(configuredBrightness);
  DisplaySetup::setBrightness(pwm);
  Serial.printf("[DISPLAY] brightness %u%% -> PWM %u\n",
                static_cast<unsigned>(configuredBrightness), static_cast<unsigned>(pwm));
}

void applySaverBrightness() {
  const uint8_t pwm = percentToPwm(SCREENSAVER_DIM_PERCENT);
  DisplaySetup::setBrightness(pwm);
  Serial.printf("[SAVER] dim to %u%% -> PWM %u\n",
                static_cast<unsigned>(SCREENSAVER_DIM_PERCENT), static_cast<unsigned>(pwm));
}
}

namespace DisplayPower {

void begin(uint8_t brightnessPercent, uint16_t screensaverMinutes) {
  if (brightnessPercent < MIN_BRIGHTNESS_PERCENT) brightnessPercent = MIN_BRIGHTNESS_PERCENT;
  if (brightnessPercent > MAX_BRIGHTNESS_PERCENT) brightnessPercent = MAX_BRIGHTNESS_PERCENT;
  configuredBrightness = brightnessPercent;
  configuredSaverMinutes = screensaverMinutes;
  lastActivityMillis = millis();
  dimmed = false;
  applyNormalBrightness();
}

void update() {
  const uint32_t now = millis();
  // IMPORTANT: brightness is never changed inside the GT911/LVGL callback.
  if (DisplaySetup::consumeTouchActivity()) {
    lastActivityMillis = now;
    if (dimmed) {
      dimmed = false;
      applyNormalBrightness();
      Serial.println("[SAVER] wake by touch");
    }
  }

  if (!dimmed && configuredSaverMinutes > 0) {
    const uint32_t timeoutMs = static_cast<uint32_t>(configuredSaverMinutes) * 60000UL;
    if (now - lastActivityMillis >= timeoutMs) {
      dimmed = true;
      applySaverBrightness();
    }
  }
}

void setBrightnessPercent(uint8_t percent) {
  if (percent < MIN_BRIGHTNESS_PERCENT) percent = MIN_BRIGHTNESS_PERCENT;
  if (percent > MAX_BRIGHTNESS_PERCENT) percent = MAX_BRIGHTNESS_PERCENT;
  configuredBrightness = percent;
  lastActivityMillis = millis();
  if (!dimmed) applyNormalBrightness();
}

uint8_t brightnessPercent() { return configuredBrightness; }

void setScreensaverMinutes(uint16_t minutes) {
  configuredSaverMinutes = minutes;
  lastActivityMillis = millis();
  if (dimmed) {
    dimmed = false;
    applyNormalBrightness();
  }
  Serial.printf("[SAVER] timeout set to %u minute(s)\n", static_cast<unsigned>(configuredSaverMinutes));
}

uint16_t screensaverMinutes() { return configuredSaverMinutes; }
bool isDimmed() { return dimmed; }
}
