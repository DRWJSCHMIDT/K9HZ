#pragma once
#include <map>
#include <string>
struct Preferences {
 inline static std::map<std::string,double> data;
 bool begin(const char*,bool){return true;}
 size_t remove(const char*k){ return data.erase(k); }
 #define FIELD(T,N) T get##N(const char*k,T d){auto i=data.find(k);return i==data.end()?d:T(i->second);} size_t put##N(const char*k,T v){data[k]=v;return sizeof(T);}
 FIELD(uint8_t,UChar)
 FIELD(uint16_t,UShort)
 FIELD(int8_t,Char)
 FIELD(bool,Bool)
 FIELD(float,Float)
 #undef FIELD
};
