#ifndef DISPLAY_COLORS_H
#define DISPLAY_COLORS_H

#include <lvgl.h>

/*
 * Central color collection for LVGL 9.5.
 *
 * Usage:
 *
 *   lv_obj_set_style_bg_color(
 *     object,
 *     DisplayColors::DarkBlue(),
 *     LV_PART_MAIN
 *   );
 *
 *   lv_obj_set_style_text_color(
 *     label,
 *     DisplayColors::White(),
 *     LV_PART_MAIN
 *   );
 */

namespace DisplayColors {

// =============================================================================
// Basic colors
// =============================================================================

inline lv_color_t Black() {
  return lv_color_hex(0x000000);
}

inline lv_color_t White() {
  return lv_color_hex(0xFFFFFF);
}

inline lv_color_t Red() {
  return lv_color_hex(0xFF0000);
}

inline lv_color_t Green() {
  return lv_color_hex(0x00FF00);
}

inline lv_color_t Blue() {
  return lv_color_hex(0x0000FF);
}

inline lv_color_t Yellow() {
  return lv_color_hex(0xFFFF00);
}

inline lv_color_t Cyan() {
  return lv_color_hex(0x00FFFF);
}

inline lv_color_t Magenta() {
  return lv_color_hex(0xFF00FF);
}

// =============================================================================
// Gray colors
// =============================================================================

inline lv_color_t Gray10() {
  return lv_color_hex(0x1A1A1A);
}

inline lv_color_t Gray20() {
  return lv_color_hex(0x333333);
}

inline lv_color_t Gray30() {
  return lv_color_hex(0x4D4D4D);
}

inline lv_color_t Gray40() {
  return lv_color_hex(0x666666);
}

inline lv_color_t Gray50() {
  return lv_color_hex(0x808080);
}

inline lv_color_t Gray60() {
  return lv_color_hex(0x999999);
}

inline lv_color_t Gray70() {
  return lv_color_hex(0xB3B3B3);
}

inline lv_color_t Gray80() {
  return lv_color_hex(0xCCCCCC);
}

inline lv_color_t Gray90() {
  return lv_color_hex(0xE6E6E6);
}

// =============================================================================
// Red colors
// =============================================================================

inline lv_color_t DarkRed() {
  return lv_color_hex(0x800000);
}

inline lv_color_t DeepRed() {
  return lv_color_hex(0xA00000);
}

inline lv_color_t MediumRed() {
  return lv_color_hex(0xC00000);
}

inline lv_color_t BrightRed() {
  return lv_color_hex(0xFF2020);
}

inline lv_color_t LightRed() {
  return lv_color_hex(0xFF6666);
}

inline lv_color_t SoftRed() {
  return lv_color_hex(0xFF9999);
}

// =============================================================================
// Orange and brown colors
// =============================================================================

inline lv_color_t DarkOrange() {
  return lv_color_hex(0xC06000);
}

inline lv_color_t Orange() {
  return lv_color_hex(0xFF8000);
}

inline lv_color_t BrightOrange() {
  return lv_color_hex(0xFFA000);
}

inline lv_color_t LightOrange() {
  return lv_color_hex(0xFFC060);
}

inline lv_color_t Brown() {
  return lv_color_hex(0x804000);
}

inline lv_color_t LightBrown() {
  return lv_color_hex(0xB07030);
}

// =============================================================================
// Yellow and gold colors
// =============================================================================

inline lv_color_t DarkYellow() {
  return lv_color_hex(0xB0B000);
}

inline lv_color_t BrightYellow() {
  return lv_color_hex(0xFFFF20);
}

inline lv_color_t LightYellow() {
  return lv_color_hex(0xFFFF80);
}

inline lv_color_t Gold() {
  return lv_color_hex(0xFFD700);
}

inline lv_color_t DarkGold() {
  return lv_color_hex(0xB89600);
}

// =============================================================================
// Green colors
// =============================================================================

inline lv_color_t DarkGreen() {
  return lv_color_hex(0x006000);
}

inline lv_color_t DeepGreen() {
  return lv_color_hex(0x008000);
}

inline lv_color_t MediumGreen() {
  return lv_color_hex(0x00A000);
}

inline lv_color_t ButtonGreen() {
  return lv_color_hex(0x00A800);
}

inline lv_color_t BrightGreen() {
  return lv_color_hex(0x00D000);
}

inline lv_color_t LightGreen() {
  return lv_color_hex(0x70E070);
}

inline lv_color_t Lime() {
  return lv_color_hex(0x80FF00);
}

inline lv_color_t Olive() {
  return lv_color_hex(0x808000);
}

// =============================================================================
// Cyan and turquoise colors
// =============================================================================

inline lv_color_t DarkCyan() {
  return lv_color_hex(0x006060);
}

inline lv_color_t MediumCyan() {
  return lv_color_hex(0x00A0A0);
}

inline lv_color_t BrightCyan() {
  return lv_color_hex(0x00E0E0);
}

inline lv_color_t Turquoise() {
  return lv_color_hex(0x20C0A0);
}

inline lv_color_t LightCyan() {
  return lv_color_hex(0x80FFFF);
}

// =============================================================================
// Blue colors
// =============================================================================

inline lv_color_t Navy() {
  return lv_color_hex(0x000080);
}

inline lv_color_t DarkBlue() {
  return lv_color_hex(0x001860);
}

inline lv_color_t DeepBlue() {
  return lv_color_hex(0x002080);
}

inline lv_color_t MediumBlue() {
  return lv_color_hex(0x0040C0);
}

inline lv_color_t BrightBlue() {
  return lv_color_hex(0x0080FF);
}

inline lv_color_t SkyBlue() {
  return lv_color_hex(0x40B0FF);
}

inline lv_color_t LightBlue() {
  return lv_color_hex(0x80C8FF);
}

// =============================================================================
// Purple and pink colors
// =============================================================================

inline lv_color_t DarkPurple() {
  return lv_color_hex(0x400060);
}

inline lv_color_t Purple() {
  return lv_color_hex(0x8000C0);
}

inline lv_color_t Violet() {
  return lv_color_hex(0xA040FF);
}

inline lv_color_t LightPurple() {
  return lv_color_hex(0xC080FF);
}

inline lv_color_t Pink() {
  return lv_color_hex(0xFF4080);
}

inline lv_color_t LightPink() {
  return lv_color_hex(0xFF90B0);
}

// =============================================================================
// Application and status colors
// =============================================================================

inline lv_color_t Background() {
  // Flat dark receiver background. Avoid full-screen LVGL gradients on the
  // 1280x720 display: they are unnecessarily expensive on this target.
  return lv_color_hex(0x09151F);
}

inline lv_color_t PanelBackground() {
  return lv_color_hex(0x0D1B26);
}

inline lv_color_t PanelBorder() {
  return lv_color_hex(0x2A4A5E);
}

inline lv_color_t ButtonNormal() {
  return lv_color_hex(0x142634);
}

inline lv_color_t ButtonPressed() {
  return lv_color_hex(0x1A3345);
}

inline lv_color_t ButtonSelected() {
  return lv_color_hex(0x0F4A68);
}

inline lv_color_t TextPrimary() {
  return lv_color_hex(0xFFFFFF);
}

inline lv_color_t TextSecondary() {
  return lv_color_hex(0xB0C0D0);
}

inline lv_color_t TextDisabled() {
  return lv_color_hex(0x606870);
}

inline lv_color_t StatusOk() {
  return lv_color_hex(0x00C000);
}

inline lv_color_t StatusWarning() {
  return lv_color_hex(0xFFA000);
}

inline lv_color_t StatusError() {
  return lv_color_hex(0xE02020);
}

inline lv_color_t StatusInformation() {
  return lv_color_hex(0x0080E0);
}

inline lv_color_t MeterLow() {
  return lv_color_hex(0x00C000);
}

inline lv_color_t MeterMedium() {
  return lv_color_hex(0xFFD000);
}

inline lv_color_t MeterHigh() {
  return lv_color_hex(0xFF8000);
}

inline lv_color_t MeterCritical() {
  return lv_color_hex(0xE00000);
}

}  // namespace DisplayColors

#endif

