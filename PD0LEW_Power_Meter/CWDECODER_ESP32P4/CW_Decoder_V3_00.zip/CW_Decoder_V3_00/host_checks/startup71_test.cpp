#include "CWDecoder.cpp"
#include <cassert>
#include <iostream>
int main() {
 CWDecoder::begin();
 // Silence cannot request recovery.
 acquisitionSamples=60ULL*12000;serviceStartupRecovery();assert(automaticRelocks==0);
 // A recent stable tone but no edges/text gets the same text-preserving reset.
 for(unsigned attempt=1;attempt<=3;attempt++) {
  acquisitionSamples+=6*12000;acquisitionLastTone=acquisitionSamples;
  acquisitionToneHits=10;noiseEnvelope=900;decodedText[0]='X';decodedText[1]=0;
  serviceStartupRecovery();assert(automaticRelocks==attempt);
  assert(noiseEnvelope==20 && decodedText[0]=='X');
 }
 acquisitionSamples+=10*12000;acquisitionLastTone=acquisitionSamples;acquisitionToneHits=10;
 serviceStartupRecovery();assert(automaticRelocks==3);
 CWDecoder::begin();acquisitionSamples=10*12000;acquisitionLastTone=acquisitionSamples;acquisitionToneHits=10;
 acquisitionLastEdge=acquisitionSamples-12000;serviceStartupRecovery();assert(automaticRelocks==0);
 acquisitionLastEdge=0;appendDecoded('S');serviceStartupRecovery();assert(automaticRelocks==0);
 std::cout<<"PASS: startup recovery, transcript retention, silence/active-keying guards, three-attempt limit, stops on valid text\n";
}
