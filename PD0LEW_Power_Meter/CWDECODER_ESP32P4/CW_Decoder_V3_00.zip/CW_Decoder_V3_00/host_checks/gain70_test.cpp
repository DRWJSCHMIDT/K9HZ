#include "CWDecoder.cpp"
#include <cassert>
#include <cmath>
#include <iostream>
int main(){
 CWDecoder::setInputLevelPercent(100);CWDecoder::begin();
 noiseEnvelope=100;signalEnvelope=1000;iLp1=400;qLp1=200;iLp2=300;qLp2=100;
 previousInput=100;hpState=50;for(float &s:spectrumRing)s=42;
 dotMs=82;symbolLength=1;symbolBuffer[0]='.';symbolBuffer[1]=0;appendDecoded('A');
 CWDecoder::setInputLevelPercent(7);int32_t frame[2]={};CWDecoder::processI2S32(frame,1);
 assert(fabs(noiseEnvelope-7)<0.001 && fabs(signalEnvelope-70)<0.001);
 assert(fabs(iLp1-28)<0.001 && fabs(spectrumRing[0]-2.94)<0.001);
 assert(dotMs==82 && symbolLength==1 && decodedText[0]=='A');
 CWDecoder::setInputLevelPercent(14);CWDecoder::processI2S32(frame,1);
 assert(fabs(noiseEnvelope-14)<0.001 && fabs(signalEnvelope-140)<0.001);
 std::cout<<"PASS: gain history scales both directions; timing, symbol and text retained\n";
}
