/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_STATE_H
#define PSWR_STATE_H

#include "PSWR_Config.h"
#include "PSWR_vLCD.h"

#include <Arduino.h>
#include <Encoder.h>
#include <Metro.h>
#include <Chrono.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <SSD1322_for_Adafruit_GFX.h>
#include <U8g2_for_Adafruit_GFX.h>

extern Adafruit_SSD1322 lcd;
extern U8G2_FOR_ADAFRUIT_GFX u8g2;
extern TextLCD VirtLCD;
extern Encoder Enc;
extern Metro pollMetro;
extern Metro pushMetro;
extern Metro slowMetro;
extern Chrono screensaver_time;
extern Chrono screensaver_begin_time;

extern unsigned long lastTimeButtonStateChanged;

extern double adc_ref;
extern int16_t fwd;
extern int16_t rev;
extern double f_inst;
extern double r_inst;
extern double ad8307_FdBm;
extern double ad8307_RdBm;
extern double fwd_power_mw;
extern double ref_power_mw;
extern double power_mw;
extern double power_mw_pk;
extern double power_mw_pep;
extern double power_mw_lng;
extern double power_mw_avg;
extern double power_mw_1savg;
extern double power_db;
extern double power_db_pk;
extern double power_db_pep;
extern double power_db_lng;


extern double display_dbm_mw;
extern double display_swr;
extern uint16_t display_swr_bar;
extern bool display_rf_active;
extern bool display_pep_armed;
extern bool screensaver_active;
extern bool display_off_active;
extern double swr;
extern double swr_avg;
extern uint16_t swr_bar;

extern uint16_t menu_level;
extern char lcd_buf[82];
extern uint16_t Menu_exit_timer;
extern uint8_t mode_display;
extern flags flag;
extern bool Reverse;
extern byte lastButtonState;
extern bool cpl;
extern bool swr_alarm_acknowledged;
extern bool swr_buzzer_active;
extern uint32_t swr_buzzer_started_ms;
extern var_t R;

#endif // PSWR_STATE_H
