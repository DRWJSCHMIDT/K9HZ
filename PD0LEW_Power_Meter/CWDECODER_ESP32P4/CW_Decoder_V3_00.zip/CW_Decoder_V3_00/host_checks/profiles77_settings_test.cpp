// Updated V2.29 NVS compatibility: existing presets remain readable, but
// only STANDARD and HAND-SENT can be selected or persisted going forward.
#include "AppSettings.cpp"
#include <cassert>
#include <iostream>
int main(){
 Preferences::data.clear();ready=false;
 AppSettings::begin();assert(AppSettings::cwType()==0&&AppSettings::fadingAssist());
 AppSettings::setCwType(1);AppSettings::setFadingAssist(true);
 ready=false;cwTypeValue=0;fadingAssistValue=false;
 AppSettings::begin();assert(AppSettings::cwType()==1&&AppSettings::fadingAssist());
 // Migrate a legacy FARNSWORTH mode to STANDARD and persist the migration.
 Preferences::data["cwtype"]=2;ready=false;AppSettings::begin();
 assert(AppSettings::cwType()==0&&Preferences::data["cwtype"]==0);
 Preferences::data["cwtype"]=99;ready=false;AppSettings::begin();
 assert(AppSettings::cwType()==0&&Preferences::data["cwtype"]==0);
 AppSettings::setCwType(4);assert(AppSettings::cwType()==0);
 puts("PASS: V2.29 two-mode CW TYPE persistence and legacy migration");
}
