#pragma once
#include <lvgl.h>
namespace StartupScreen {
// Temporary boot artwork; destroy before allocating the decoder UI.
lv_obj_t* create();
void show();
}
