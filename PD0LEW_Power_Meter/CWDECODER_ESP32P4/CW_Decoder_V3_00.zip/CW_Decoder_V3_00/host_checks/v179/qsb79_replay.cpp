#include "CWDecoder.cpp"
#include <fstream>
#include <iostream>
#include <cstdlib>
int main(int argc,char**argv){
 if(argc<2)return 2;
 CWDecoder::setFilterBandwidthHz(argc>2?atoi(argv[2]):40);
 CWDecoder::setFadingAssist(argc>3?atoi(argv[3]):0);
 CWDecoder::setManualTone(495);
 CWDecoder::setAutoTone(argc>4?atoi(argv[4]):1);
 CWDecoder::setInputLevelPercent(argc>5?atoi(argv[5]):30);
 CWDecoder::begin();
 std::ifstream f(argv[1],std::ios::binary);int16_t pcm[480];int32_t slots[960];unsigned block=0,lastLevelBlock=0;
 while(f.read((char*)pcm,sizeof(pcm)) || f.gcount()){
  int n=f.gcount()/2;
  for(int i=0;i<n;i++)slots[2*i]=slots[2*i+1]=int32_t(pcm[i])*65536;
  CWDecoder::processI2S32(slots,n);
  ++block;
  if(argc>6 && atoi(argv[6]) && block%20==0) {
   auto c=CWDecoder::getState();float peak=0;for(int i=0;i<n;i++)peak=fmaxf(peak,fabsf(pcm[i]));
   if(c.measuredToneValid && c.spectralSnrDb>=8 && toDbfs(peak)>-75 && block-lastLevelBlock>=200){
    lastLevelBlock=block;
    int step=c.signalDbfs>-38?-3:(c.signalDbfs>-42?-1:(c.signalDbfs<-56?3:(c.signalDbfs<-50?1:0)));
    CWDecoder::setInputLevelPercent(constrain(int(CWDecoder::inputLevelPercent())+step,1,30));
   }
  }
  if(block%200==0 && argc>7)std::cerr<<block/200<<","<<detectorToneHz<<","<<1200/dotMs<<","<<envelope<<","<<noiseEnvelope<<","<<signalEnvelope<<","<<keyDown<<"\n";
 }
 std::cout<<"tone="<<detectorToneHz<<" wpm="<<1200/displayDotMs<<" relocks="<<automaticRelocks<<"\n"<<decodedText<<"\n";
}
