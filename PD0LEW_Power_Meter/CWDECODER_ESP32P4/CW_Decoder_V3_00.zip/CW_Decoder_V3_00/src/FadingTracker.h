#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>

// Normal-mode fading assistance, owned by the audio task. Noise is measured
// beside the wanted tone, independently of the mark/gap decisions. In a narrow
// filter at high WPM, inter-element tails are NOT a reliable noise reference.
// Fixed storage only; no heap, UI calls or changes to the audio output path.
class FadingTracker {
 public:
  float peak = 30.0f;
  float noisePower = 0.0f;
  void reset() {
    count = write = ticks = 0;
    phase = noisePower = 0.0f;
    peak = 30.0f;
    for (float &v : refI) v = 0;
    for (float &v : refQ) v = 0;
  }
  bool ready() const { return count >= 20; }
  void scale(float ratio) {
    peak *= ratio;
    noisePower *= ratio * ratio;
    for (float &v : refI) v *= ratio;
    for (float &v : refQ) v *= ratio;
    for (float &v : history) v *= ratio;
  }
  void process(float mixI, float mixQ, float envelope, float alpha, float bandwidth) {
    // 1.28 s mark-level history, sampled every 10 ms. A high percentile avoids
    // using a single noise spike as the reference level.
    if (++ticks >= 120) {
      ticks = 0;
      history[write] = envelope;
      write = (write + 1) % kHistory;
      if (count < kHistory) ++count;
      float sorted[kHistory];
      std::copy(history, history + count, sorted);
      std::sort(sorted, sorted + count);
      peak = sorted[count * 85 / 100];
    }
    constexpr float pi2 = 6.283185307179586f;
    // Keep reference channels outside the selected detector passband.
    phase += pi2 * std::fmax(100.0f, 2.0f * bandwidth) / 12000.0f;
    if (phase >= pi2) phase -= pi2;
    const float c = std::cos(phase), s = std::sin(phase);
    const float ri[2] = {mixI*c - mixQ*s, mixI*c + mixQ*s};
    const float rq[2] = {mixQ*c + mixI*s, mixQ*c - mixI*s};
    for (size_t b = 0; b < 2; ++b) {
      const size_t j = 2*b;
      refI[j] += alpha * (ri[b] - refI[j]);
      refQ[j] += alpha * (rq[b] - refQ[j]);
      refI[j+1] += alpha * (refI[j] - refI[j+1]);
      refQ[j+1] += alpha * (refQ[j] - refQ[j+1]);
    }
    const float power = 2*(refI[1]*refI[1] + refQ[1]*refQ[1] +
                          refI[3]*refI[3] + refQ[3]*refQ[3]);
    noisePower += 0.00041658f * (power - noisePower); // ~200 ms
  }
 private:
  static constexpr size_t kHistory = 128;
  float refI[4] = {}, refQ[4] = {}, phase = 0;
  float history[kHistory] = {};
  size_t count = 0, write = 0, ticks = 0;
};
