#ifndef SAFE_SERIAL_H
#define SAFE_SERIAL_H

#include <Arduino.h>
#include <HardwareSerial.h>

class SafeSerial {
private:
    HardwareSerial* serial;
    SemaphoreHandle_t mutex;

public:
    SafeSerial(HardwareSerial* ser) : serial(ser), mutex(NULL) {}

    void begin(unsigned long baud) {
        serial->begin(baud);
        if (mutex == NULL) {
            mutex = xSemaphoreCreateMutex();
        }
    }

    void begin(unsigned long baud, uint32_t config, int8_t rxPin, int8_t txPin) {
        serial->begin(baud, config, rxPin, txPin);
        if (mutex == NULL) {
            mutex = xSemaphoreCreateMutex();
        }
    }

    // Non-blocking lock for ISR
    bool tryLock() {
        return xSemaphoreTakeFromISR(mutex, NULL) == pdTRUE;
    }

    void unlockFromISR() {
        xSemaphoreGiveFromISR(mutex, NULL);
    }

    // Blocking lock for normal code
    bool lock(TickType_t timeout = portMAX_DELAY) {
        return xSemaphoreTake(mutex, timeout) == pdTRUE;
    }

    void unlock() {
        xSemaphoreGive(mutex);
    }

    // Pass-through for input methods (no mutex needed)
    int available() {
        return serial->available();
    }

    int read() {
        return serial->read();
    }

    // Direct hardware methods (no mutex)
    bool setRxBufferSize(size_t size) {
        return serial->setRxBufferSize(size);
    }

    // Print functions with automatic mutex
    size_t print(const char* str) {
        if (!lock()) return 0;
        size_t result = serial->print(str);
        unlock();
        return result;
    }

    size_t print(const String& s) {
        if (!lock()) return 0;
        size_t result = serial->print(s);
        unlock();
        return result;
    }

    size_t println(const char* str) {
        if (!lock()) return 0;
        size_t result = serial->println(str);
        unlock();
        return result;
    }

    size_t println(const String& s) {
        if (!lock()) return 0;
        size_t result = serial->println(s);
        unlock();
        return result;
    }

    // Write function (for raw bytes)
    size_t write(const uint8_t* buffer, size_t size) {
        if (!lock()) return 0;
        size_t result = serial->write(buffer, size);
        unlock();
        return result;
    }

    // Direct write from ISR (non-blocking)
    size_t writeFromISR(const uint8_t* buffer, size_t size) {
        if (!tryLock()) return 0;
        size_t result = serial->write(buffer, size);
        unlockFromISR();
        return result;
    }
};

#endif
