[![SparkFun Teensy Ethernet Adapter](./docs/assets/img/Ethernet_Adapter-GH_Banner.png)](https://www.sparkfun.com/sparkfun-ethernet-adapter-for-teensy.html)

[*SparkFun Teensy Ethernet Adapter (PRT-29920)*](https://www.sparkfun.com/sparkfun-ethernet-adapter-for-teensy.html)

<Basic description of the part.>

Repository Contents
-------------------

* **/docs** - Tutorial content files
* **/Documentation** - Data sheets, additional product information
* **/Hardware** - Eagle design files (.brd, .sch)
* **/Production** - Production panel files (.brd)

Documentation
--------------
* **[Quick Start Guide](Learn.SparkFun URL)** - A quick guide to get started with the SparkFun Teensy Ethernet Adapter.

Product Versions
----------------
* [PRT-29920](https://www.sparkfun.com/sparkfun-ethernet-adapter-for-teensy.html) - Initial release of SparkFun Teensy Ethernet Adapter


License Information
-------------------

This product is _**open source**_! 

Please review the LICENSE.md file for license information. 

If you have any questions or concerns on licensing, please contact technical support on our [SparkFun forums](https://forum.sparkfun.com/viewforum.php?f=152).

Distributed as-is; no warranty is given.

- Your friends at SparkFun.