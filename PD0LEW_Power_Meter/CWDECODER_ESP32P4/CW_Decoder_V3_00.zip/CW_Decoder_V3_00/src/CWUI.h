#ifndef CW_UI_H
#define CW_UI_H

namespace CWUI {
void create();
void update();
}

#endif
