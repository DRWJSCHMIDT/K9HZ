/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_vLCD.h"
#include "PSWR_State.h"
#include "PSWR_Menu.h"
#include "PSWR_StartupLogo.h"
#include "PSWR_CalBanks.h"
#include "PSWR_WiFiLink.h"
#include "PSWR_WiFiConfig.h"
#include "Profont22.h"
#include "Profont17.h"

#include <string.h>
#include <ctype.h>
#include <stdlib.h>

namespace {

constexpr uint8_t kWhite   = 0x0F;
constexpr uint8_t kBright  = 0x0D;
constexpr uint8_t kNormal  = 0x0A;
constexpr uint8_t kDim     = 0x07;
constexpr uint8_t kLine    = 0x04;

constexpr int16_t kW = 256;

// Menu baselines: title + four items.
constexpr int16_t kTitleY = 10;
constexpr int16_t kListY[4] = {24, 37, 50, 63};

void copyBounded(char *dst, size_t dstSize, const char *src)
{
  if (!dst || dstSize == 0) return;
  if (!src) {
    dst[0] = '\0';
    return;
  }

  size_t n = 0;
  while (n + 1 < dstSize && src[n] != '\0') {
    dst[n] = src[n];
    ++n;
  }
  dst[n] = '\0';
}

void trimRight(char *s)
{
  if (!s) return;
  size_t n = strlen(s);
  while (n > 0 && s[n - 1] == ' ')
    s[--n] = '\0';
}

char *trimLeft(char *s)
{
  if (!s) return s;
  while (*s == ' ') ++s;
  return s;
}

void setMenuFont(uint8_t color)
{
  u8g2.setFont(u8g2_font_6x12_tf);
  u8g2.setFontMode(1);
  u8g2.setFontDirection(0);
  u8g2.setForegroundColor(color);
}

int16_t menuTextWidth(const char *text)
{
  setMenuFont(kWhite);
  return text ? (int16_t)u8g2.getUTF8Width(text) : 0;
}

bool startsSelection(const char *line)
{
  if (!line) return false;
  while (*line == ' ') ++line;
  return line[0] == '-' && line[1] == '>';
}

char *stripSelection(char *line)
{
  char *p = trimLeft(line);
  if (p && p[0] == '-' && p[1] == '>')
    p += 2;
  return trimLeft(p);
}

bool containsAny(const char *s, const char *a, const char *b = nullptr,
                 const char *c = nullptr, const char *d = nullptr)
{
  if (!s) return false;
  if (a && strstr(s, a)) return true;
  if (b && strstr(s, b)) return true;
  if (c && strstr(s, c)) return true;
  if (d && strstr(s, d)) return true;
  return false;
}

// Return true when this is a value-adjustment page rather than a list.
// This works with the existing menu text without changing menu logic.
bool isAdjustmentScreen(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // Common selectors such as "Adjust-> 2.5" and "Select -> 1.0s".
  char *arrow = strstr(lines[1], "->");
  if (arrow) {
    char *left = trimLeft(lines[1]);
    if (arrow != left)
      return true;
  }

  // Direct-value adjustment screens.
  if (containsAny(lines[2], "Turn to adjust", "Push to store"))
    return true;

  // Calibration value editor.
  char tmp[OLED_COLUMNS + 1];
  copyBounded(tmp, sizeof(tmp), lines[1]);
  char *l1 = trimLeft(tmp);
  if (strncmp(l1, "Value", 5) == 0)
    return true;

  return false;
}

// Extract the main adjustable value from row 1.
void extractAdjustmentValue(char lines[OLED_ROWS][OLED_COLUMNS + 1],
                            char *value, size_t valueSize)
{
  if (!value || valueSize == 0) return;
  value[0] = '\0';

  char line[OLED_COLUMNS + 1];
  copyBounded(line, sizeof(line), lines[1]);
  trimRight(line);

  // Case 1: "Adjust-> 2.5" / "Select -> 1.0s"
  char *arrow = strstr(line, "->");
  if (arrow) {
    char *p = trimLeft(arrow + 2);
    copyBounded(value, valueSize, p);
    trimRight(value);
    return;
  }

  char *p = trimLeft(line);

  // Case 2: "Value      50.2 dBm"
  if (strncmp(p, "Value", 5) == 0) {
    p += 5;
    p = trimLeft(p);
    copyBounded(value, valueSize, p);
    trimRight(value);
    return;
  }

  // Case 3: row 1 contains only the value, with leading spaces.
  copyBounded(value, valueSize, p);
  trimRight(value);
}

// For an adjustment screen, remove redundant helper words and keep only useful
// footer information.
void cleanFooter(char *line)
{
  if (!line) return;
  trimRight(line);
  char *p = trimLeft(line);

  if (p != line)
    memmove(line, p, strlen(p) + 1);

  // The large centered value already communicates "adjust".
  if (strcmp(line, "Turn to adjust") == 0)
    line[0] = '\0';

  if (strcmp(line, "Push to store") == 0)
    copyBounded(line, OLED_COLUMNS + 1, "Push to store");
}

void drawTitle(const char *title)
{
  setMenuFont(kBright);
  u8g2.setCursor(2, kTitleY);
  if (title && *title)
    u8g2.print(title);

  // One subtle rule only; no box/frame.
  lcd.drawFastHLine(0, 13, kW, kLine);
}

void drawList(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  drawTitle(trimLeft(lines[0]));

  for (uint8_t row = 1; row < OLED_ROWS && row <= 4; ++row)
  {
    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    trimRight(work);

    char *clean = trimLeft(work);
    if (!clean || !*clean)
      continue;

    const bool selected = startsSelection(work);
    if (selected)
      clean = stripSelection(work);

    const int16_t y = kListY[row - 1];

    if (selected)
    {
      // Minimal cursor, no highlight rectangle.
      setMenuFont(kWhite);
      u8g2.setCursor(2, y);
      u8g2.print(">");

      u8g2.setCursor(14, y);
      u8g2.print(clean);
    }
    else
    {
      setMenuFont(kDim);
      u8g2.setCursor(14, y);
      u8g2.print(clean);
    }
  }
}

void drawBigGfxValue(const char *value)
{
  if (!value || !*value) return;

  lcd.setFont(&Profont22);
  lcd.setTextColor(kWhite);
  lcd.setTextWrap(false);

  int16_t x1 = 0, y1 = 0;
  uint16_t w = 0, h = 0;
  lcd.getTextBounds(value, 0, 0, &x1, &y1, &w, &h);

  // If a very long text value does not fit, use the standard menu font instead.
  if (w > 244)
  {
    setMenuFont(kWhite);
    int16_t tw = menuTextWidth(value);
    int16_t x = (kW - tw) / 2;
    if (x < 2) x = 2;
    u8g2.setCursor(x, 38);
    u8g2.print(value);
    return;
  }

  int16_t x = (kW - (int16_t)w) / 2;
  if (x < 2) x = 2;

  // Profont22 baseline tuned for the 64-pixel OLED.
  lcd.setCursor(x, 40);
  lcd.print(value);
}

void drawAdjustment(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  drawTitle(trimLeft(lines[0]));

  char value[OLED_COLUMNS + 1];
  extractAdjustmentValue(lines, value, sizeof(value));
  drawBigGfxValue(value);

  // Footer information at bottom. Calibration uses these for Step and FWD/REV.
  char footer1[OLED_COLUMNS + 1];
  char footer2[OLED_COLUMNS + 1];
  copyBounded(footer1, sizeof(footer1), lines[2]);
  copyBounded(footer2, sizeof(footer2), lines[3]);
  cleanFooter(footer1);
  cleanFooter(footer2);

  setMenuFont(kDim);

  if (footer1[0] && footer2[0])
  {
    // Two useful footer lines.
    u8g2.setCursor(2, 53);
    u8g2.print(footer1);

    // Put the last instruction/status line at the bottom.
    setMenuFont(kNormal);
    u8g2.setCursor(2, 63);
    u8g2.print(footer2);
  }
  else if (footer1[0] || footer2[0])
  {
    const char *footer = footer1[0] ? footer1 : footer2;
    const int16_t tw = menuTextWidth(footer);
    int16_t x = (kW - tw) / 2;
    if (x < 2) x = 2;

    setMenuFont(kDim);
    u8g2.setCursor(x, 62);
    u8g2.print(footer);
  }
}


// ---------------------------------------------------------------------------
// V2.16.5.14: fine graphical position adjustment.
// Large selected/adjusted values moved another 3 px down.
// Secondary range/trip text moved another 1 px down.
// Cards/bars and footer command strips remain unchanged from V2.16.5.13.

// Dedicated graphical Power Bar Scale renderer (V2.16.5.4)
// ---------------------------------------------------------------------------
// The rest of the menu system intentionally keeps using the virtual 42x5 LCD
// interface.  Only the Power Bar Scale pages get a native graphical layout.
// This keeps menu/encoder behaviour isolated from presentation.

bool isPowerBarScaleSelect(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Power Bar Scale") == 0;
}

bool isPowerBarScaleEdit(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strncmp(t, "Power Bar Scale R", 17) == 0;
}

int16_t parseXValue(const char *line, int16_t fallback = 0)
{
  if (!line) return fallback;
  const char *x = strrchr(line, 'x');
  if (!x || !x[1]) return fallback;
  return (int16_t)atoi(x + 1);
}

uint8_t selectedPowerBarTile(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  for (uint8_t row = 1; row <= 4 && row < OLED_ROWS; ++row)
    if (startsSelection(lines[row]))
      return (uint8_t)(row - 1);
  return 0;
}

void drawSmallCenteredIn(int16_t x, int16_t w, int16_t baselineY,
                         const char *text, uint8_t level)
{
  int16_t tw = menuTextWidth(text);
  int16_t tx = x + (w - tw) / 2;
  if (tx < x + 1) tx = x + 1;
  setMenuFont(level);
  u8g2.setCursor(tx, baselineY);
  u8g2.print(text);
}

void drawGfxCenteredIn(int16_t x, int16_t w, int16_t baselineY,
                       const char *text, uint8_t level)
{
  lcd.setFont(&Profont22);
  lcd.setTextColor(level);
  lcd.setTextWrap(false);

  int16_t x1 = 0, y1 = 0;
  uint16_t tw = 0, th = 0;
  lcd.getTextBounds(text, 0, 0, &x1, &y1, &tw, &th);
  int16_t tx = x + (w - (int16_t)tw) / 2;
  if (tx < x + 1) tx = x + 1;
  lcd.setCursor(tx, baselineY);
  lcd.print(text);
}

void drawPowerBarScaleSelect(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // Header: clean instrument-style title with a subtle rule.
  drawTitle("Power Bar Scale");

  const uint8_t selected = selectedPowerBarTile(lines);
  const int16_t values[3] = {
    parseXValue(lines[1], 1),
    parseXValue(lines[2], 1),
    parseXValue(lines[3], 1)
  };

  // Four equal tiles: R1, R2, R3, BACK.
  constexpr int16_t tileX[4] = { 2, 66, 130, 194 };
  constexpr int16_t tileW = 60;
  constexpr int16_t tileY = 20;
  constexpr int16_t tileH = 31;

  for (uint8_t i = 0; i < 4; ++i)
  {
    const bool active = (i == selected);

    // Selected tile gets a restrained grayscale fill and a bright edge.
    if (active)
      lcd.fillRect(tileX[i], tileY, tileW, tileH, kLine);

    lcd.drawRect(tileX[i], tileY, tileW, tileH,
                 active ? kWhite : kDim);

    // Small bright marker at the top edge makes the active card obvious
    // without turning the whole screen into a reverse-video block.
    if (active)
      lcd.fillRect(tileX[i] + 1, tileY + 1, tileW - 2, 2, kWhite);

    if (i < 3)
    {
      // V2.16.5.21: keep the small range label on the left side of the
      // tile so it no longer competes vertically with the large x-value.
      char label[4];
      snprintf(label, sizeof(label), "R%u", (unsigned)(i + 1));
      setMenuFont(active ? kWhite : kNormal);
      // V2.16.5.41: range label stays in the upper-left corner, 1 px higher.
      u8g2.setCursor(tileX[i] + 4, 33);
      u8g2.print(label);

      // Reserve the right-hand side of the tile for the large scale value.
      char value[8];
      snprintf(value, sizeof(value), "x%d", values[i]);
      drawGfxCenteredIn(tileX[i] + 18, tileW - 20, 48, value,
                        active ? kWhite : kBright);
    }
    else
    {
      // BACK follows the same left-label / right-symbol layout.
      setMenuFont(active ? kWhite : kNormal);
      u8g2.setCursor(tileX[i] + 4, 33);
      u8g2.print("BACK");
      drawGfxCenteredIn(tileX[i] + 34, tileW - 36, 48, "<",
                        active ? kWhite : kBright);
    }
  }

  // Quiet command strip; wording changes when BACK is selected.
  setMenuFont(kDim);
  u8g2.setCursor(2, 62);
  u8g2.print("TURN");

  const char *action = (selected == 3) ? "PUSH = RETURN" : "PUSH = EDIT";
  const int16_t aw = menuTextWidth(action);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - aw - 2, 62);
  u8g2.print(action);
}

void drawPowerBarScaleEdit(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // Parse range number from title: "Power Bar Scale R1".
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);

  uint8_t range = 1;
  const char *rp = strrchr(t, 'R');
  if (rp && rp[1] >= '1' && rp[1] <= '3')
    range = (uint8_t)(rp[1] - '0');

  const int16_t value = parseXValue(lines[1], 1);

  // Row 2 is intentionally formatted by PSWR_Menu.cpp as:
  //   "MIN xN MAX xN"
  int16_t minValue = 1;
  int16_t maxValue = 99;
  const char *minp = strstr(lines[2], "MIN x");
  const char *maxp = strstr(lines[2], "MAX x");
  if (minp) minValue = (int16_t)atoi(minp + 5);
  if (maxp) maxValue = (int16_t)atoi(maxp + 5);
  if (maxValue < minValue) maxValue = minValue;

  // Header and small range badge.
  drawTitle("Power Bar Scale");
  char badge[5];
  snprintf(badge, sizeof(badge), "R%u", (unsigned)range);
  setMenuFont(kWhite);
  const int16_t bw = menuTextWidth(badge);
  u8g2.setCursor(kW - bw - 2, kTitleY);
  u8g2.print(badge);

  // Hero value.
  char valueText[10];
  snprintf(valueText, sizeof(valueText), "x%d", value);
  drawGfxCenteredIn(0, kW, 41, valueText, kWhite);

  // Slider track: actual position between the permitted min/max values.
  constexpr int16_t trackX = 10;
  constexpr int16_t trackY = 44;
  constexpr int16_t trackW = 236;
  constexpr int16_t trackH = 6;

  lcd.drawRect(trackX, trackY, trackW, trackH, kDim);

  int16_t fillW = 1;
  if (maxValue > minValue)
  {
    long numerator = (long)(value - minValue) * (trackW - 2);
    long denominator = (long)(maxValue - minValue);
    fillW = (int16_t)(numerator / denominator);
    if (fillW < 1) fillW = 1;
    if (fillW > trackW - 2) fillW = trackW - 2;
  }
  else
  {
    fillW = trackW - 2;
  }
  lcd.fillRect(trackX + 1, trackY + 1, fillW, trackH - 2, kBright);

  // Min / action / max footer makes the adjustment limits explicit.
  char minText[12];
  char maxText[12];
  snprintf(minText, sizeof(minText), "MIN x%d", minValue);
  snprintf(maxText, sizeof(maxText), "MAX x%d", maxValue);

  setMenuFont(kDim);
  u8g2.setCursor(2, 62);
  u8g2.print(minText);

  const char *saveText = "PUSH = SAVE";
  int16_t sw = menuTextWidth(saveText);
  setMenuFont(kNormal);
  u8g2.setCursor((kW - sw) / 2, 62);
  u8g2.print(saveText);

  int16_t mw = menuTextWidth(maxText);
  setMenuFont(kDim);
  u8g2.setCursor(kW - mw - 2, 62);
  u8g2.print(maxText);
}


// ---------------------------------------------------------------------------
// Dedicated graphical Display Off Time renderer (V2.16.5.5)
// ---------------------------------------------------------------------------
// The menu logic still owns the setting, encoder and EEPROM handling.  This
// renderer only replaces the old scrolling text presentation with a compact
// instrument-style selector.

bool isDisplayOffTimePage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Display off time:") == 0 ||
         strcmp(t, "Display Off Time") == 0;
}

uint8_t selectedDisplayOffIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // Values are fixed by PSWR_Menu.cpp and deliberately duplicated here only
  // for presentation.  The actual setting is still written by the menu code.
  const uint16_t minutes[8] = { 0, 1, 2, 5, 10, 15, 30, 60 };

  for (uint8_t row = 1; row < OLED_ROWS; ++row)
  {
    if (!startsSelection(lines[row]))
      continue;

    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    char *item = stripSelection(work);
    trimRight(item);

    if (containsAny(item, "Off", "OFF"))
      return 0;

    const int value = atoi(item);
    for (uint8_t i = 1; i < 8; ++i)
      if (value == minutes[i])
        return i;
  }

  return 0;
}

void drawDisplayOffTime(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  static const uint16_t minutes[8] = { 0, 1, 2, 5, 10, 15, 30, 60 };
  static const char * const labels[8] = {
    "OFF", "1", "2", "5", "10", "15", "30", "60"
  };

  const uint8_t selected = selectedDisplayOffIndex(lines);

  drawTitle("Display Off Time");

  // Large selected timeout.  OFF is intentionally as prominent as a numeric
  // value because it is a real operating mode, not merely zero minutes.
  char hero[16];
  if (selected == 0)
    snprintf(hero, sizeof(hero), "OFF");
  else
    snprintf(hero, sizeof(hero), "%u MIN", (unsigned)minutes[selected]);

  drawGfxCenteredIn(0, kW, 39, hero, kWhite);

  // Eight compact selector tiles.  This gives the same card/highlight language
  // as Power Bar Scale while fitting every timeout on one screen.
  constexpr int16_t tileX0 = 2;
  constexpr int16_t tileStep = 31;
  constexpr int16_t tileW = 29;
  constexpr int16_t tileY = 40;
  constexpr int16_t tileH = 14;

  for (uint8_t i = 0; i < 8; ++i)
  {
    const int16_t x = tileX0 + (int16_t)i * tileStep;
    const bool active = (i == selected);

    if (active)
      lcd.fillRect(x, tileY, tileW, tileH, kLine);

    lcd.drawRect(x, tileY, tileW, tileH, active ? kWhite : kDim);

    if (active)
      lcd.fillRect(x + 1, tileY + 1, tileW - 2, 2, kWhite);

    drawSmallCenteredIn(x, tileW, 51, labels[i],
                        active ? kWhite : kNormal);
  }

  // Quiet command strip, matching the Power Bar Scale interaction language.
  const char *left = "TURN = SELECT";
  const char *right = "PUSH = SAVE";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical Screensaver Time renderer (V2.16.5.6)
// ---------------------------------------------------------------------------
// Presentation only. The existing screentime_menu() still owns encoder
// handling, EEPROM storage and the actual screensaver timeout behavior.

bool isScreensaverTimePage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Screensaver time:") == 0 ||
         strcmp(t, "Screensaver Time") == 0;
}

uint8_t selectedScreensaverTimeIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  const uint16_t minutes[8] = { 0, 1, 2, 5, 10, 15, 30, 60 };

  for (uint8_t row = 1; row < OLED_ROWS; ++row)
  {
    if (!startsSelection(lines[row]))
      continue;

    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    char *item = stripSelection(work);
    trimRight(item);

    if (containsAny(item, "Off", "OFF"))
      return 0;

    const int value = atoi(item);
    for (uint8_t i = 1; i < 8; ++i)
      if (value == minutes[i])
        return i;
  }

  return 0;
}

void drawScreensaverTime(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  static const uint16_t minutes[8] = { 0, 1, 2, 5, 10, 15, 30, 60 };
  static const char * const labels[8] = {
    "OFF", "1", "2", "5", "10", "15", "30", "60"
  };

  const uint8_t selected = selectedScreensaverTimeIndex(lines);

  drawTitle("Screensaver Time");

  // Large selected timeout, matching the Display Off Time visual language.
  char hero[16];
  if (selected == 0)
    snprintf(hero, sizeof(hero), "OFF");
  else
    snprintf(hero, sizeof(hero), "%u MIN", (unsigned)minutes[selected]);

  drawGfxCenteredIn(0, kW, 39, hero, kWhite);

  // Eight compact graphical choices; the active timeout is filled/highlighted.
  constexpr int16_t tileX0 = 2;
  constexpr int16_t tileStep = 31;
  constexpr int16_t tileW = 29;
  constexpr int16_t tileY = 40;
  constexpr int16_t tileH = 14;

  for (uint8_t i = 0; i < 8; ++i)
  {
    const int16_t x = tileX0 + (int16_t)i * tileStep;
    const bool active = (i == selected);

    if (active)
      lcd.fillRect(x, tileY, tileW, tileH, kLine);

    lcd.drawRect(x, tileY, tileW, tileH, active ? kWhite : kDim);

    if (active)
      lcd.fillRect(x + 1, tileY + 1, tileW - 2, 2, kWhite);

    drawSmallCenteredIn(x, tileW, 51, labels[i],
                        active ? kWhite : kNormal);
  }

  const char *left = "TURN = SELECT";
  const char *right = "PUSH = SAVE";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical Noise Floor renderer (V2.16.5.7)
// ---------------------------------------------------------------------------
// Presentation only. The existing screenthresh_menu() still owns encoder
// handling, EEPROM storage and the actual noise-floor threshold value.

bool isNoiseFloorPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Noise Floor (mW):") == 0 ||
         strcmp(t, "Noise Floor") == 0;
}

uint8_t selectedNoiseFloorIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // screenthresh_menu() uses a one-line selector beginning after the word
  // "Select", so locate the arrow anywhere in the virtual row.
  for (uint8_t row = 1; row < OLED_ROWS; ++row)
  {
    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    trimRight(work);

    char *arrow = strstr(work, "->");
    if (!arrow)
      continue;

    char *item = trimLeft(arrow + 2);

    if (containsAny(item, "Off", "OFF")) return 0;
    if (strstr(item, "0.001"))            return 1;
    if (strstr(item, "0.01"))             return 2;
    if (strstr(item, "0.1"))              return 3;
    if (strstr(item, "10mW"))             return 5;
    if (strstr(item, "1mW"))              return 4;
  }

  return 0;
}

void drawNoiseFloor(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  static const char * const hero[6] = {
    "OFF", "0.001 mW", "0.01 mW", "0.1 mW", "1 mW", "10 mW"
  };
  static const char * const labels[6] = {
    "OFF", ".001", ".01", ".1", "1", "10"
  };

  const uint8_t selected = selectedNoiseFloorIndex(lines);

  drawTitle("Noise Floor");

  // Large selected threshold.  The unit is included in the hero value so the
  // setting remains unambiguous while the tiles can stay compact.
  drawGfxCenteredIn(0, kW, 39, hero[selected], kWhite);

  // Six equally spaced logarithmic choices. The progression from .001 to 10
  // mW is visually obvious and the active threshold uses the same restrained
  // highlight language as the other modern settings pages.
  constexpr int16_t tileX0 = 3;
  constexpr int16_t tileStep = 42;
  constexpr int16_t tileW = 39;
  constexpr int16_t tileY = 40;
  constexpr int16_t tileH = 14;

  for (uint8_t i = 0; i < 6; ++i)
  {
    const int16_t x = tileX0 + (int16_t)i * tileStep;
    const bool active = (i == selected);

    if (active)
      lcd.fillRect(x, tileY, tileW, tileH, kLine);

    lcd.drawRect(x, tileY, tileW, tileH, active ? kWhite : kDim);

    if (active)
      lcd.fillRect(x + 1, tileY + 1, tileW - 2, 2, kWhite);

    drawSmallCenteredIn(x, tileW, 51, labels[i],
                        active ? kWhite : kNormal);
  }

  const char *left = "TURN = SELECT";
  const char *right = "PUSH = SAVE";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical Calibration renderers (V2.16.5.29)
// ---------------------------------------------------------------------------
// Presentation only. calibrate_menu(), calibrate_menu_level2() and
// calibration_overview_menu() continue to own encoder handling, calibration
// math, direction qualification, EEPROM writes and menu navigation.

bool isCalibrateMenuPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);

  if (strncmp(t, "Calibrate", 9) != 0)
    return false;

  char row1[OLED_COLUMNS + 1];
  copyBounded(row1, sizeof(row1), lines[1]);
  return strstr(row1, "->") != nullptr;
}

uint8_t selectedCalibrateMenuIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char row1[OLED_COLUMNS + 1];
  copyBounded(row1, sizeof(row1), lines[1]);
  trimRight(row1);

  char *arrow = strstr(row1, "->");
  if (!arrow)
    return 0;

  char *item = trimLeft(arrow + 2);

  if (strstr(item, "OneLevelCal")) return 0;
  if (strstr(item, "1st level"))   return 1;
  if (strstr(item, "2nd level"))   return 2;
  if (strstr(item, "Cal Debug"))   return 3;
  if (strstr(item, "Go Back"))     return 4;
  if (strstr(item, "Exit"))        return 5;
  return 0;
}

bool extractCalibrateStoredValue(char lines[OLED_ROWS][OLED_COLUMNS + 1],
                                 char *value, size_t valueSize)
{
  if (!value || valueSize == 0)
    return false;

  value[0] = '\0';

  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  trimRight(title);

  char *p = strstr(title, "Calibrate");
  if (!p)
    return false;

  p += 9;
  p = trimLeft(p);
  if (!*p || !strpbrk(p, "0123456789"))
    return false;

  copyBounded(value, valueSize, p);
  trimRight(value);
  return value[0] != '\0';
}

void drawCalibrateMenu(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  static const char * const hero[6] = {
    "ONE LEVEL",
    "HIGH POINT",
    "LOW POINT",
    "CAL DATA",
    "BACK",
    "EXIT"
  };

  const uint8_t selected = selectedCalibrateMenuIndex(lines);

  char calTitle[28];
  snprintf(calTitle, sizeof(calTitle), "CALIBRATION %s C%u",
           calbanks_active_band_name(), (unsigned)calbanks_active_number());
  drawTitle(calTitle);

  // For the three editable references show the currently stored dBm point in
  // the header. The six-segment strip below the card already communicates
  // menu position, so the header can be used for useful calibration data.
  if (selected <= 2)
  {
    char stored[18];
    if (extractCalibrateStoredValue(lines, stored, sizeof(stored)))
    {
      char ref[28];
      snprintf(ref, sizeof(ref), "REF %s dBm", stored);
      const int16_t rw = menuTextWidth(ref);
      setMenuFont(kDim);
      u8g2.setCursor(kW - rw - 2, kTitleY);
      u8g2.print(ref);
    }
  }
  else
  {
    char counter[8];
    snprintf(counter, sizeof(counter), "%u/6", (unsigned)(selected + 1));
    const int16_t cw = menuTextWidth(counter);
    setMenuFont(kDim);
    u8g2.setCursor(kW - cw - 2, kTitleY);
    u8g2.print(counter);
  }

  constexpr int16_t cardX = 4;
  constexpr int16_t cardY = 18;
  constexpr int16_t cardW = 248;
  constexpr int16_t cardH = 26;

  lcd.fillRect(cardX, cardY, cardW, cardH, kLine);
  lcd.drawRect(cardX, cardY, cardW, cardH, kWhite);
  lcd.fillRect(cardX + 1, cardY + 1, cardW - 2, 2, kWhite);
  drawGfxCenteredIn(cardX, cardW, 40, hero[selected], kWhite);

  // Six large position segments: fewer, wider segments than the 12-item Setup
  // menu, but deliberately the same visual language.
  constexpr int16_t segX = 5;
  constexpr int16_t segY = 47;
  constexpr int16_t segW = 37;
  constexpr int16_t segH = 5;
  constexpr int16_t segGap = 5;

  for (uint8_t i = 0; i < 6; ++i)
  {
    const int16_t x = segX + (int16_t)i * (segW + segGap);
    if (i == selected)
      lcd.fillRect(x, segY, segW, segH, kWhite);
    else
      lcd.drawRect(x, segY, segW, segH, kDim);
  }

  const char *left = "TURN = SELECT";
  const char *right =
    (selected == 4) ? "PUSH = BACK" :
    (selected == 5) ? "PUSH = EXIT" :
                      "PUSH = OPEN";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}

bool isCalibrationEditPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);

  return strcmp(t, "Single Level Cal:") == 0 ||
         strcmp(t, "First Cal SetPoint:") == 0 ||
         strcmp(t, "Second Cal SetPoint:") == 0;
}

const char *calibrationEditTitle(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);

  if (strncmp(t, "Single Level", 12) == 0) return "CAL ONE LEVEL";
  if (strncmp(t, "First Cal", 9) == 0)     return "CAL HIGH POINT";
  return "CAL LOW POINT";
}

void drawCalibrationEdit(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char editTitle[32];
  snprintf(editTitle, sizeof(editTitle), "%s %s C%u",
           calibrationEditTitle(lines), calbanks_active_band_name(),
           (unsigned)calbanks_active_number());
  drawTitle(editTitle);

  char value[OLED_COLUMNS + 1];
  extractAdjustmentValue(lines, value, sizeof(value));

  char stepLine[OLED_COLUMNS + 1];
  copyBounded(stepLine, sizeof(stepLine), lines[2]);
  trimRight(stepLine);
  char *step = trimLeft(stepLine);
  if (strncmp(step, "Step", 4) == 0)
    step = trimLeft(step + 4);

  char stateLine[OLED_COLUMNS + 1];
  copyBounded(stateLine, sizeof(stateLine), lines[3]);
  trimRight(stateLine);

  const bool fwd = strstr(stateLine, "FWD") != nullptr;
  const bool rev = strstr(stateLine, "REV") != nullptr;
  const bool ready = fwd || rev;
  const char *direction = fwd ? "FWD" : rev ? "REV" : "NO RF";
  const char *state = ready ? "READY" : "WAIT";

  // Main reference value: large and immediately readable.
  constexpr int16_t valueX = 4;
  constexpr int16_t valueW = 168;
  constexpr int16_t valueY = 18;
  constexpr int16_t valueH = 28;

  lcd.fillRect(valueX, valueY, valueW, valueH, kLine);
  lcd.drawRect(valueX, valueY, valueW, valueH, kWhite);
  lcd.fillRect(valueX + 1, valueY + 1, valueW - 2, 2, kWhite);
  drawGfxCenteredIn(valueX, valueW, 40, value, kWhite);

  // Separate live signal card. This is deliberately independent from the dBm
  // reference so the operator can see signal validity at a glance.
  constexpr int16_t stateX = 178;
  constexpr int16_t stateW = 74;
  constexpr int16_t stateY = 18;
  constexpr int16_t stateH = 28;

  if (ready)
    lcd.fillRect(stateX, stateY, stateW, stateH, kLine);

  lcd.drawRect(stateX, stateY, stateW, stateH, ready ? kWhite : kDim);
  drawSmallCenteredIn(stateX, stateW, 29, direction,
                      ready ? kWhite : kNormal);
  drawSmallCenteredIn(stateX, stateW, 41, state,
                      ready ? kBright : kDim);

  // Current acceleration/fine-resolution step lives in the header, keeping the
  // lower area completely clear for the command footer.
  char stepText[28];
  snprintf(stepText, sizeof(stepText), "STEP %s", step && *step ? step : "0.1 dB");
  const int16_t sw = menuTextWidth(stepText);
  setMenuFont(kDim);
  u8g2.setCursor(kW - sw - 2, kTitleY);
  u8g2.print(stepText);

  const char *left = "TURN = ADJUST";
  const char *right = ready ? "PUSH = STORE" : "PUSH = EXIT";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(ready ? kNormal : kDim);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}

bool isCalibrationOverviewPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strncmp(t, "CAL DEBUG", 9) == 0;
}

void drawCalibrationOverview(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  trimRight(title);

  unsigned bandNumber = 0, couplerNumber = 0, subpage = 0;
  if (sscanf(title, "CAL DEBUG B%u C%u %u/2",
             &bandNumber, &couplerNumber, &subpage) != 3 ||
      bandNumber < 1U || bandNumber > CALBAND_COUNT ||
      couplerNumber < 1U || couplerNumber > 2U)
  {
    drawTitle("CAL DATA");
    drawGfxCenteredIn(0, kW, 39, "READ ERROR", kWhite);
    drawSmallCenteredIn(0, kW, 63, "PUSH = BACK", kDim);
    return;
  }

  char head[24];
  snprintf(head, sizeof(head), "CAL DATA %s C%u",
           calbanks_band_name((uint8_t)(bandNumber - 1U)), couplerNumber);
  drawTitle(head);

  const char *mode = (subpage == 1) ? "POINTS" : "SLOPES";
  const int16_t mw = menuTextWidth(mode);
  setMenuFont(kDim);
  u8g2.setCursor(kW - mw - 2, kTitleY);
  u8g2.print(mode);

  if (subpage == 1)
  {
    double p1 = 0.0, p2 = 0.0, f1 = 0.0, f2 = 0.0, r1 = 0.0, r2 = 0.0;
    const bool ok =
      sscanf(lines[1], "P1 %lf P2 %lf", &p1, &p2) == 2 &&
      sscanf(lines[2], "F1 %lf F2 %lf", &f1, &f2) == 2 &&
      sscanf(lines[3], "R1 %lf R2 %lf", &r1, &r2) == 2;

    if (!ok)
    {
      drawGfxCenteredIn(0, kW, 39, "READ ERROR", kWhite);
    }
    else
    {
      constexpr int16_t cardX[2] = {4, 130};
      constexpr int16_t cardW = 122;
      constexpr int16_t cardY = 17;
      constexpr int16_t cardH = 32;
      const double p[2] = {p1, p2};
      const double f[2] = {f1, f2};
      const double r[2] = {r1, r2};

      for (uint8_t i = 0; i < 2; ++i)
      {
        lcd.drawRect(cardX[i], cardY, cardW, cardH, kDim);

        char label[5];
        snprintf(label, sizeof(label), "P%u", (unsigned)(i + 1));
        setMenuFont(kDim);
        u8g2.setCursor(cardX[i] + 4, 26);
        u8g2.print(label);

        char dbm[16];
        snprintf(dbm, sizeof(dbm), "%4.1f dBm", p[i]);
        lcd.setFont(&Profont17);
        lcd.setTextColor(kWhite);
        lcd.setTextWrap(false);
        int16_t x1 = 0, y1 = 0;
        uint16_t tw = 0, th = 0;
        lcd.getTextBounds(dbm, 0, 0, &x1, &y1, &tw, &th);
        lcd.setCursor(cardX[i] + (cardW - (int16_t)tw) / 2, 36);
        lcd.print(dbm);

        char volts[26];
        snprintf(volts, sizeof(volts), "F%.3f  R%.3f", f[i], r[i]);
        drawSmallCenteredIn(cardX[i], cardW, 45, volts, kDim);
      }
    }
  }
  else
  {
    double span = 0.0, sf = 0.0, sr = 0.0, diff = 0.0;
    const bool ok =
      sscanf(lines[1], "Span %lf", &span) == 1 &&
      sscanf(lines[2], "F%lf R%lf", &sf, &sr) == 2 &&
      sscanf(lines[3], "F/R diff %lf", &diff) == 1;

    if (!ok)
    {
      drawGfxCenteredIn(0, kW, 39, "READ ERROR", kWhite);
    }
    else
    {
      char spanText[24];
      snprintf(spanText, sizeof(spanText), "SPAN %.1f dB", span);
      drawGfxCenteredIn(0, kW, 36, spanText, kWhite);

      char fText[18], rText[18], dText[18];
      snprintf(fText, sizeof(fText), "F %.1f", sf);
      snprintf(rText, sizeof(rText), "R %.1f", sr);
      snprintf(dText, sizeof(dText), "D %.1f", diff);
      drawSmallCenteredIn(2, 82, 49, fText, kBright);
      drawSmallCenteredIn(87, 82, 49, rText, kBright);
      drawSmallCenteredIn(172, 82, 49, dText, kBright);
    }
  }

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print("TURN = PAGE");

  const char *right = "PUSH = BACK";
  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical Set Your Call QWERTY editor
// ---------------------------------------------------------------------------
bool isSetYourCallPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Set Your Call") == 0;
}

void setKeyboardFont(uint8_t color)
{
  u8g2.setFont(u8g2_font_6x10_tf);
  u8g2.setFontMode(1);
  u8g2.setFontDirection(0);
  u8g2.setForegroundColor(color);
}

void drawKeyboardKey(int16_t x, int16_t y, int16_t w, const char *label,
                     bool active)
{
  constexpr int16_t h = 9;
  if (active)
    lcd.fillRect(x, y, w, h, kLine);

  lcd.drawRect(x, y, w, h, active ? kWhite : kDim);

  setKeyboardFont(active ? kWhite : kNormal);
  const int16_t tw = label ? (int16_t)u8g2.getUTF8Width(label) : 0;
  u8g2.setCursor(x + (w - tw) / 2, y + 8);
  u8g2.print(label ? label : "");
}

void drawKeyboardEditor(const char *title, const char *text, uint8_t selected,
                        uint8_t maxChars, bool masked, const char *placeholder)
{
  const size_t len = text ? strlen(text) : 0;

  setKeyboardFont(kBright);
  u8g2.setCursor(2, 9);
  u8g2.print(title ? title : "TEXT EDIT");

  char counter[16];
  const unsigned displayLen = (len > maxChars) ? maxChars : (unsigned)len;
  snprintf(counter, sizeof(counter), "%02u/%02u", displayLen, (unsigned)maxChars);
  setKeyboardFont(kDim);
  const int16_t cw = (int16_t)u8g2.getUTF8Width(counter);
  u8g2.setCursor(kW - cw - 2, 9);
  u8g2.print(counter);

  constexpr int16_t fieldX = 3;
  constexpr int16_t fieldY = 11;
  constexpr int16_t fieldW = 250;
  constexpr int16_t fieldH = 13;
  lcd.fillRect(fieldX, fieldY, fieldW, fieldH, kLine);
  lcd.drawRect(fieldX, fieldY, fieldW, fieldH, kWhite);
  lcd.fillRect(fieldX + 1, fieldY + 1, fieldW - 2, 2, kWhite);
  setKeyboardFont(kWhite);
  u8g2.setCursor(fieldX + 4, 22);

  if (masked && len > 0)
  {
    char mask[31];
    size_t shown = len > 30 ? 30 : len;
    memset(mask, '*', shown);
    mask[shown] = '\0';
    u8g2.print(mask);
  }
  else if (text && *text)
  {
    const char *tail = text;
    if (len > 30) tail += len - 30;
    u8g2.print(tail);
  }
  else
    u8g2.print(placeholder ? placeholder : "");

  static const char * const row1[10] =
    { "1","2","3","4","5","6","7","8","9","0" };
  static const char * const row2[10] =
    { "Q","W","E","R","T","Y","U","I","O","P" };
  static const char * const row3[10] =
    { "A","S","D","F","G","H","J","K","L","-" };
  static const char * const row4[13] =
    { "Z","X","C","V","B","N","M","/","_","<","CLR","OK","ESC" };

  constexpr int16_t keyW = 18;
  constexpr int16_t leftX = 2;
  constexpr int16_t rightX = kW - 1 - keyW;
  const int16_t rowY[4] = {25, 35, 45, 55};

  const auto keyX = [=](uint8_t index, uint8_t count) -> int16_t
  {
    if (count <= 1) return leftX;
    const int32_t span = (int32_t)rightX - leftX;
    return (int16_t)(leftX +
      (span * index + (count - 1) / 2) / (count - 1));
  };

  for (uint8_t i = 0; i < 10; ++i)
    drawKeyboardKey(keyX(i, 10), rowY[0], keyW, row1[i], selected == i);
  for (uint8_t i = 0; i < 10; ++i)
    drawKeyboardKey(keyX(i, 10), rowY[1], keyW, row2[i], selected == (uint8_t)(10 + i));
  for (uint8_t i = 0; i < 10; ++i)
    drawKeyboardKey(keyX(i, 10), rowY[2], keyW, row3[i], selected == (uint8_t)(20 + i));
  for (uint8_t i = 0; i < 13; ++i)
    drawKeyboardKey(keyX(i, 13), rowY[3], keyW, row4[i], selected == (uint8_t)(30 + i));
}

void drawSetYourCall(void)
{
  drawKeyboardEditor("SET YOUR CALL", menuYourCallEditText(), menuYourCallKeyIndex(),
                     30, false, "Your Call");
}

bool isSetGridPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Set Grid") == 0;
}

void drawSetGrid(void)
{
  drawKeyboardEditor("SET GRID", menuGridEditText(), menuGridKeyIndex(),
                     menuGridMaxChars(), false, "JO33IC");
}

bool isClockPrimaryPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Clock Primary") == 0;
}

void drawClockPrimaryPage(void)
{
  drawTitle("CLOCK PRIMARY");
  const uint8_t selected = menuClockPrimarySelection();

  constexpr int16_t cardY = 20;
  constexpr int16_t cardH = 28;
  constexpr int16_t cardW = 116;
  constexpr int16_t cardX[2] = { 7, 133 };
  const char *label[2] = { "UTC", "LOCAL" };

  for (uint8_t i = 0; i < 2; ++i)
  {
    const bool active = (selected == i);
    if (active) lcd.fillRect(cardX[i], cardY, cardW, cardH, kLine);
    lcd.drawRect(cardX[i], cardY, cardW, cardH, active ? kWhite : kDim);
    if (active) lcd.fillRect(cardX[i] + 1, cardY + 1, cardW - 2, 2, kWhite);
    drawGfxCenteredIn(cardX[i], cardW, 43, label[i], active ? kWhite : kNormal);
  }

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print("TURN = SELECT");
  const char *right = "PUSH = STORE";
  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}

bool isClockDimPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Clock Dim Time") == 0;
}

void drawClockDimPage(void)
{
  drawTitle("CLOCK DIM TIME");
  const uint8_t selected = menuClockDimSelection();

  static const char * const labels[CLOCK_DIM_COUNT] =
    { "5 MIN", "10 MIN", "30 MIN", "OFF" };
  constexpr int16_t cardX[CLOCK_DIM_COUNT] = { 3, 66, 129, 192 };
  constexpr int16_t cardY = 20;
  constexpr int16_t cardW = 61;
  constexpr int16_t cardH = 31;

  for (uint8_t i = 0; i < CLOCK_DIM_COUNT; ++i)
  {
    const bool active = (selected == i);
    if (active) lcd.fillRect(cardX[i], cardY, cardW, cardH, kLine);
    lcd.drawRect(cardX[i], cardY, cardW, cardH, active ? kWhite : kDim);
    if (active) lcd.fillRect(cardX[i] + 1, cardY + 1, cardW - 2, 2, kWhite);
    drawSmallCenteredIn(cardX[i], cardW, 41, labels[i], active ? kWhite : kNormal);
  }

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print("TURN = SELECT");
  const char *right = "PUSH = STORE";
  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}

bool isWifiNetworksPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title); trimRight(t);
  return strcmp(t, "WiFi Networks") == 0;
}

void drawWifiNetworks(void)
{
  drawTitle("WIFI NETWORKS");

  if (wifi_link_scan_busy())
  {
    drawGfxCenteredIn(0, kW, 38, "SCANNING...", kWhite);
    setMenuFont(kDim);
    const char *footer = "PUSH = BACK";
    const int16_t fw = menuTextWidth(footer);
    u8g2.setCursor((kW - fw) / 2, 63);
    u8g2.print(footer);
    return;
  }

  const uint8_t count = wifi_link_scan_count();
  const uint8_t selected = menuWifiScanSelection();
  const uint8_t total = (uint8_t)(count + 3U); // RESCAN, MANUAL ENTRY, BACK

  char countText[10];
  snprintf(countText, sizeof(countText), "%u AP", (unsigned)count);
  setMenuFont(kDim);
  const int16_t cw = menuTextWidth(countText);
  u8g2.setCursor(kW - cw - 2, kTitleY);
  u8g2.print(countText);

  int16_t first = 0;
  if (total > 3)
  {
    first = (int16_t)selected - 1;
    if (first < 0) first = 0;
    if (first > (int16_t)total - 3) first = (int16_t)total - 3;
  }

  constexpr int16_t rowBase[3] = { 25, 39, 53 };
  for (uint8_t row = 0; row < 3 && (uint8_t)(first + row) < total; ++row)
  {
    const uint8_t idx = (uint8_t)(first + row);
    const bool active = (idx == selected);
    const int16_t y = rowBase[row];

    if (active)
    {
      lcd.fillRect(2, y - 11, 252, 13, kLine);
      lcd.drawRect(2, y - 11, 252, 13, kWhite);
    }

    char label[29] = {};
    char right[12] = {};

    if (idx < count)
    {
      const char *ssid = wifi_link_scan_ssid(idx);
      const bool current = wifi_link_connected() &&
                           strcmp(ssid, wifi_link_ssid()) == 0;
      const bool secure = wifi_link_scan_secure(idx);

      // 24 display characters leaves room for RSSI on the right.
      snprintf(label, sizeof(label), "%c%c%-24.24s",
               current ? 'C' : ' ', secure ? '*' : ' ', ssid);
      snprintf(right, sizeof(right), "%d", wifi_link_scan_rssi(idx));
    }
    else
    {
      const uint8_t special = idx - count;
      if (special == 0) strncpy(label, "  RESCAN", sizeof(label) - 1);
      else if (special == 1) strncpy(label, "  MANUAL ENTRY", sizeof(label) - 1);
      else strncpy(label, "  BACK", sizeof(label) - 1);
    }

    setMenuFont(active ? kWhite : kNormal);
    u8g2.setCursor(5, y);
    u8g2.print(label);

    if (idx < count)
    {
      const int16_t rw = menuTextWidth(right);
      setMenuFont(active ? kWhite : kDim);
      u8g2.setCursor(kW - rw - 5, y);
      u8g2.print(right);
    }
  }

  // C=current network, *=secured. RSSI values are dBm.
  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print("C=current *=lock");
  const char *action = "PUSH=SELECT";
  const int16_t aw = menuTextWidth(action);
  u8g2.setCursor(kW - aw - 2, 63);
  u8g2.print(action);
}

bool isWifiStatusPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title); trimRight(t);
  return strcmp(t, "WiFi Status") == 0;
}

void drawWifiStatus(void)
{
  const bool online = wifi_link_connected();
  drawTitle("WIFI STATUS");

  const char *state = online ? "ONLINE" : "OFFLINE";
  setMenuFont(online ? kWhite : kDim);
  const int16_t sw = menuTextWidth(state);
  u8g2.setCursor(kW - sw - 2, kTitleY);
  u8g2.print(state);

  char ssid[34] = {};
  if (online && wifi_link_ssid()[0])
    strncpy(ssid, wifi_link_ssid(), sizeof(ssid) - 1);
  else
    strncpy(ssid, "Not connected", sizeof(ssid) - 1);

  setMenuFont(kNormal);
  u8g2.setCursor(3, 24);
  u8g2.print("SSID");
  setMenuFont(kWhite);
  u8g2.setCursor(38, 24);
  // Keep the SSID on one clean line.
  char ssidShort[33] = {};
  const size_t ssidLen = strnlen(ssid, sizeof(ssidShort) - 1);
  memcpy(ssidShort, ssid, ssidLen);
  ssidShort[ssidLen] = '\0';
  u8g2.print(ssidShort);

  const char *ip = (online && wifi_link_ip()[0]) ? wifi_link_ip() : "---.---.---.---";
  lcd.setFont(&Profont17);
  lcd.setTextSize(1);
  lcd.setTextColor(kWhite);
  int16_t x1, y1; uint16_t w, h;
  lcd.getTextBounds(ip, 0, 0, &x1, &y1, &w, &h);
  lcd.setCursor((kW - (int16_t)w) / 2, 45);
  lcd.print(ip);
  lcd.setFont(nullptr);

  char rssiText[24];
  snprintf(rssiText, sizeof(rssiText), "RSSI %d dBm", online ? wifi_link_rssi() : 0);
  setMenuFont(kNormal);
  u8g2.setCursor(3, 62);
  u8g2.print(rssiText);

  const char *wifiFw = wifi_link_firmware_version();
  char fwText[20];
  snprintf(fwText, sizeof(fwText), "FW %s",
           (wifiFw && wifiFw[0]) ? wifiFw : "--");
  const int16_t fwW = menuTextWidth(fwText);
  u8g2.setCursor((kW - fwW) / 2, 62);
  u8g2.print(fwText);

  const char *footer = "PUSH=BACK";
  const int16_t footerW = menuTextWidth(footer);
  setMenuFont(kDim);
  u8g2.setCursor(kW - footerW - 2, 62);
  u8g2.print(footer);
}


bool isWifiSsidPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title); trimRight(t);
  return strcmp(t, "WiFi SSID") == 0;
}

bool isWifiPasswordPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title); trimRight(t);
  return strcmp(t, "WiFi Password") == 0;
}

void drawWifiEditor(bool passwordMode)
{
  drawKeyboardEditor(passwordMode ? "WIFI PASSWORD" : "WIFI SSID",
                     menuWifiEditText(), menuWifiKeyIndex(), menuWifiMaxChars(),
                     passwordMode, passwordMode ? "Password" : "Your SSID");
}


// ---------------------------------------------------------------------------
// Dedicated graphical Startup Logo selector
// ---------------------------------------------------------------------------
// The menu and real splash screen call the same startup_logo_draw() function.
// This guarantees that the selected preview is the exact stored boot emblem.

bool isStartupLogoPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Startup Logo") == 0;
}

void drawStartupLogoPage()
{
  uint8_t selected = menuStartupLogoIndex();
  if (selected >= STARTUP_LOGO_COUNT) selected = STARTUP_LOGO_DEFAULT;

  drawTitle("STARTUP LOGO");

  char counter[8];
  snprintf(counter, sizeof(counter), "%u/9", (unsigned)(selected + 1U));
  const int16_t cw = menuTextWidth(counter);
  setMenuFont(kDim);
  u8g2.setCursor(kW - cw - 2, kTitleY);
  u8g2.print(counter);

  // Exact startup-size preview at the left. Tall logo shapes get a small
  // selector-only vertical offset so their upper RF arcs clear the title.
  int16_t previewY = 16;
  if (selected == 0)      previewY = 22; // RF Tower
  else if (selected == 2) previewY = 14; // SWR Meter
  else if (selected == 3) previewY = 16; // Coupler
  startup_logo_draw(2, previewY, selected, kWhite, kBright, kDim);

  // Selected-logo name in the familiar highlighted menu card.
  constexpr int16_t cardX = 62;
  constexpr int16_t cardY = 20;
  constexpr int16_t cardW = 190;
  constexpr int16_t cardH = 25;
  lcd.fillRect(cardX, cardY, cardW, cardH, kLine);
  lcd.drawRect(cardX, cardY, cardW, cardH, kWhite);
  lcd.fillRect(cardX + 1, cardY + 1, cardW - 2, 2, kWhite);
  drawGfxCenteredIn(cardX, cardW, 42, startup_logo_name(selected), kWhite);

  setMenuFont(kDim);
  u8g2.setCursor(62, 63);
  u8g2.print("TURN = SELECT");

  const char *right = "PUSH = SAVE";
  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical four-band selector
// ---------------------------------------------------------------------------
bool isBandSelectPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "Band Select") == 0;
}

void drawBandSelectPage()
{
  uint8_t selected = menuBandSelectIndex();
  if (selected >= CALBAND_COUNT) selected = CALBAND_HF;

  drawTitle("BAND SELECT");

  char coupler[16];
  snprintf(coupler, sizeof(coupler), "Coupler %u", cpl ? 2U : 1U);
  const int16_t cw = menuTextWidth(coupler);
  setMenuFont(kDim);
  u8g2.setCursor(kW - cw - 2, kTitleY);
  u8g2.print(coupler);

  static const char * const labels[CALBAND_COUNT] = { "HF", "6M", "2M", "70cm" };
  constexpr int16_t cardX[CALBAND_COUNT] = { 3, 66, 129, 192 };
  constexpr int16_t cardY = 20;
  constexpr int16_t cardW = 61;
  constexpr int16_t cardH = 31;

  for (uint8_t i = 0; i < CALBAND_COUNT; ++i)
  {
    if (i == selected)
      lcd.fillRect(cardX[i], cardY, cardW, cardH, kLine);

    lcd.drawRect(cardX[i], cardY, cardW, cardH, i == selected ? kWhite : kDim);
    if (i == selected)
      lcd.fillRect(cardX[i] + 1, cardY + 1, cardW - 2, 2, kWhite);

    lcd.setFont(&Profont17);
    lcd.setTextColor(i == selected ? kWhite : kNormal);
    lcd.setTextWrap(false);
    int16_t x1 = 0, y1 = 0;
    uint16_t tw = 0, th = 0;
    lcd.getTextBounds(labels[i], 0, 0, &x1, &y1, &tw, &th);
    lcd.setCursor(cardX[i] + (cardW - (int16_t)tw) / 2, 43);
    lcd.print(labels[i]);
  }

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print("TURN = SELECT");

  const char *right = "PUSH = SAVE";
  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical top-level Setup menu renderer (V2.16.5.22)
// ---------------------------------------------------------------------------
// Presentation only. menu_level0() continues to own the encoder selection and
// all navigation/actions. The graphical renderer only interprets the virtual
// LCD text that the proven menu code already produces.

bool isSetupMenuPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "JH2KW-M SETUP:") == 0;
}

static constexpr uint8_t kSetupFullCount = 20;

static const char * const kSetupItems[kSetupFullCount] = {
  "SWR Alarm",
  "SWR Alarm Power",
  "PEP Hold",
  "PK Hold",
  "Noise Floor",
  "Screensaver Time",
  "Display Off Time",
  "Power Bar Scale",
  "Set Your Call",
  "Set Grid",
  "Clock Primary",
  "Clock Dim Time",
  "WiFi SSID",
  "WiFi Password",
  "WiFi Status",
  "Startup Logo",
  "Calibrate",
  "Diagnostics",
  "Factory Reset",
  "Exit"
};

static const bool kSetupRequiresWifi[kSetupFullCount] = {
  false, false, false, false, false, false, false, false, false,
  true, true, true, true, true, true,
  false, false, false, false, false
};

uint8_t buildVisibleSetupItems(const char **outItems)
{
  const bool wifiPresent = wifi_link_module_present();
  uint8_t count = 0;
  for (uint8_t i = 0; i < kSetupFullCount; ++i)
  {
    if (kSetupRequiresWifi[i] && !wifiPresent)
      continue;
    outItems[count++] = kSetupItems[i];
  }
  return count;
}

uint8_t selectedSetupMenuIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1],
                               const char * const *items, uint8_t itemCount)
{
  for (uint8_t row = 1; row < OLED_ROWS; ++row)
  {
    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    trimRight(work);

    char *arrow = strstr(work, "->");
    if (!arrow)
      continue;

    char *item = trimLeft(arrow + 2);
    trimRight(item);

    for (uint8_t i = 0; i < itemCount; ++i)
      if (strcmp(item, items[i]) == 0)
        return i;
  }

  return 0;
}

void drawSetupMenu(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  const char *items[kSetupFullCount] = {};
  const uint8_t itemCount = buildVisibleSetupItems(items);
  if (itemCount == 0)
    return;

  const uint8_t selected = selectedSetupMenuIndex(lines, items, itemCount);

  drawTitle("JH2KW-M SETUP");

  // Counter and position markers follow the actual visible menu size. With no
  // XIAO installed this becomes a compact 14-item Setup menu; with the card
  // detected all 20 items are shown.
  char counter[10];
  snprintf(counter, sizeof(counter), "%02u/%02u",
           (unsigned)(selected + 1U), (unsigned)itemCount);
  const int16_t cw = menuTextWidth(counter);
  setMenuFont(kDim);
  u8g2.setCursor(kW - cw - 2, kTitleY);
  u8g2.print(counter);

  constexpr int16_t cardX = 4;
  constexpr int16_t cardY = 18;
  constexpr int16_t cardW = 248;
  constexpr int16_t cardH = 26;

  lcd.fillRect(cardX, cardY, cardW, cardH, kLine);
  lcd.drawRect(cardX, cardY, cardW, cardH, kWhite);
  lcd.fillRect(cardX + 1, cardY + 1, cardW - 2, 2, kWhite);

  drawGfxCenteredIn(cardX, cardW, 41, items[selected], kWhite);

  const int16_t segGap = 1;
  const int16_t segW = (itemCount >= 19U) ? 11 : 13;
  const int16_t segTotalW = (int16_t)itemCount * segW +
                            (int16_t)(itemCount - 1U) * segGap;
  const int16_t segX = (kW - segTotalW) / 2;
  constexpr int16_t segY = 47;
  constexpr int16_t segH = 5;

  for (uint8_t i = 0; i < itemCount; ++i)
  {
    const int16_t x = segX + (int16_t)i * (segW + segGap);
    if (i == selected)
      lcd.fillRect(x, segY, segW, segH, kWhite);
    else
      lcd.drawRect(x, segY, segW, segH, kDim);
  }

  const char *left = "TURN = SELECT";
  const char *right = (selected == (uint8_t)(itemCount - 1U))
                        ? "PUSH = EXIT" : "PUSH = OPEN";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}

// ---------------------------------------------------------------------------
// Dedicated graphical Factory Reset renderer (V2.16.5.18)
// ---------------------------------------------------------------------------
// Presentation only. factory_menu() continues to own encoder selection,
// EEPROM cold-start invalidation, menu navigation and the actual MCU reset.

bool isFactoryResetPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);

  if (strcmp(t, "All to Default?") != 0)
    return false;

  // The legacy factory menu always writes this identifying footer on row 3.
  // Checking it as well avoids accidentally intercepting another confirmation
  // page that happens to use the same question.
  char footer[OLED_COLUMNS + 1];
  copyBounded(footer, sizeof(footer), lines[3]);
  char *f = trimLeft(footer);
  trimRight(f);

  return strcmp(f, "Factory Reset Menu") == 0;
}

uint8_t selectedFactoryResetIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // factory_menu() uses the established one-line scroll selector. Locate its
  // arrow and convert the legacy labels into the three graphical choices.
  for (uint8_t row = 1; row < OLED_ROWS; ++row)
  {
    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    trimRight(work);

    char *arrow = strstr(work, "->");
    if (!arrow)
      continue;

    char *item = trimLeft(arrow + 2);

    if (strstr(item, "Yes - Reset")) return 1;
    if (strstr(item, "No  - Exit"))  return 2;
    if (strstr(item, "No - Exit"))   return 2;
    return 0;  // "No  - Go back"
  }

  return 0;
}

void drawFactoryReset(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  const uint8_t selected = selectedFactoryResetIndex(lines);

  drawTitle("Factory Reset");

  // One explicit warning line.  Factory reset is destructive, so the page
  // should communicate what RESET means before the user confirms it.
  const char *warning = "RESTORE ALL SETTINGS TO DEFAULTS";
  const int16_t warningW = menuTextWidth(warning);
  setMenuFont(kDim);
  u8g2.setCursor((kW - warningW) / 2, 25);
  u8g2.print(warning);

  // Three large action cards. RESET remains the middle choice exactly as in
  // the proven legacy menu. Only presentation changes here.
  static const char * const labels[3] = {
    "BACK", "RESET", "EXIT"
  };

  constexpr int16_t tileX[3] = { 4, 88, 172 };
  constexpr int16_t tileW = 80;
  constexpr int16_t tileY = 29;
  constexpr int16_t tileH = 23;

  for (uint8_t i = 0; i < 3; ++i)
  {
    const bool active = (i == selected);

    if (active)
      lcd.fillRect(tileX[i], tileY, tileW, tileH, kLine);

    lcd.drawRect(tileX[i], tileY, tileW, tileH,
                 active ? kWhite : kDim);

    if (active)
      lcd.fillRect(tileX[i] + 1, tileY + 1, tileW - 2, 2, kWhite);

    // Give the destructive RESET choice one additional inner edge when it is
    // selected. This makes confirmation deliberate without adding new logic.
    if (active && i == 1)
      lcd.drawRect(tileX[i] + 2, tileY + 2, tileW - 4, tileH - 4, kBright);

    drawGfxCenteredIn(tileX[i], tileW, 50, labels[i],
                      active ? kWhite : kBright);
  }

  const char *left = "TURN = SELECT";
  const char *right =
    (selected == 0) ? "PUSH = GO BACK" :
    (selected == 1) ? "PUSH = RESET" :
                      "PUSH = EXIT";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont((selected == 1) ? kWhite : kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical Factory Reset final confirmation
// ---------------------------------------------------------------------------
// The first Factory Reset page only enters this page. The actual EEPROM reset
// is performed only after RESET is explicitly selected here.

bool isFactoryConfirmPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);

  char footer[OLED_COLUMNS + 1];
  copyBounded(footer, sizeof(footer), lines[3]);
  char *f = trimLeft(footer);
  trimRight(f);

  return strcmp(t, "ARE YOU SURE?") == 0 &&
         strcmp(f, "Factory Confirm") == 0;
}

uint8_t selectedFactoryConfirmIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  for (uint8_t row = 1; row < OLED_ROWS; ++row)
  {
    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    trimRight(work);

    char *arrow = strstr(work, "->");
    if (!arrow)
      continue;

    char *item = trimLeft(arrow + 2);
    if (strstr(item, "Reset")) return 1;
    return 0;
  }
  return 0;
}

void drawFactoryConfirm(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  const uint8_t selected = selectedFactoryConfirmIndex(lines);

  drawTitle("ARE YOU SURE?");

  setMenuFont(kDim);
  const char *warning = "THIS CANNOT BE UNDONE";
  const int16_t warningW = menuTextWidth(warning);
  u8g2.setCursor((kW - warningW) / 2, 25);
  u8g2.print(warning);

  static const char * const labels[2] = { "CANCEL", "RESET" };
  constexpr int16_t tileX[2] = { 16, 132 };
  constexpr int16_t tileW = 108;
  constexpr int16_t tileY = 30;
  constexpr int16_t tileH = 24;

  for (uint8_t i = 0; i < 2; ++i)
  {
    const bool active = (i == selected);

    if (active)
      lcd.fillRect(tileX[i], tileY, tileW, tileH, kLine);

    lcd.drawRect(tileX[i], tileY, tileW, tileH,
                 active ? kWhite : kDim);

    if (active)
      lcd.fillRect(tileX[i] + 1, tileY + 1, tileW - 2, 2, kWhite);

    if (active && i == 1)
      lcd.drawRect(tileX[i] + 2, tileY + 2, tileW - 4, tileH - 4, kBright);

    drawGfxCenteredIn(tileX[i], tileW, 50, labels[i],
                      active ? kWhite : kBright);
  }

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print("TURN = SELECT");

  const char *right = (selected == 0) ? "PUSH = CANCEL" : "PUSH = RESET";
  const int16_t rw = menuTextWidth(right);
  setMenuFont((selected == 1) ? kWhite : kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical external-coupler confirmation
// ---------------------------------------------------------------------------
// The physical coupler switch remains the only way to change coupler. This is
// merely the short graphical confirmation shown after a short coupler-button press.

int8_t couplerSelectionStatus(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  for (uint8_t row = 0; row < OLED_ROWS; ++row)
  {
    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    trimRight(work);
    char *t = trimLeft(work);

    if (strstr(t, "Coupler 1") && strstr(t, "selected")) return 1;
    if (strstr(t, "Coupler 2") && strstr(t, "selected")) return 2;
  }
  return 0;
}

void drawCouplerSelectionStatus(uint8_t coupler)
{
  drawTitle("COUPLER SELECT");

  constexpr int16_t cardX = 18;
  constexpr int16_t cardY = 21;
  constexpr int16_t cardW = 220;
  constexpr int16_t cardH = 28;

  lcd.fillRect(cardX, cardY, cardW, cardH, kLine);
  lcd.drawRect(cardX, cardY, cardW, cardH, kWhite);
  lcd.fillRect(cardX + 1, cardY + 1, cardW - 2, 2, kWhite);

  char label[16];
  snprintf(label, sizeof(label), "COUPLER %u", (unsigned)coupler);
  drawGfxCenteredIn(cardX, cardW, 45, label, kWhite);

  setMenuFont(kDim);
  const char *selected = "SELECTED";
  const int16_t sw = menuTextWidth(selected);
  u8g2.setCursor((kW - sw) / 2, 63);
  u8g2.print(selected);
}


// ---------------------------------------------------------------------------
// Dedicated graphical SWR Alarm renderer (V2.16.5.12)
// ---------------------------------------------------------------------------
// Presentation only. The existing swr_alarm_threshold_menu() continues to
// own encoder handling, EEPROM storage and the actual SWR trip threshold.

bool isSwrAlarmPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "SWR Alarm Threshold:") == 0 ||
         strcmp(t, "SWR Alarm") == 0;
}

uint8_t selectedSwrAlarmIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // swr_alarm_threshold_menu() prints row 1 as either:
  //     Adjust->   2.0
  // or:
  //     Adjust->   Off
  // Convert that text back to 0..24 for 1.5..3.9, with 25 representing OFF.
  char work[OLED_COLUMNS + 1];
  copyBounded(work, sizeof(work), lines[1]);
  trimRight(work);

  char *arrow = strstr(work, "->");
  char *item = arrow ? trimLeft(arrow + 2) : trimLeft(work);

  if (containsAny(item, "Off", "OFF"))
    return 25;

  const double swr = atof(item);
  int16_t tenths = (int16_t)(swr * 10.0 + 0.5);
  if (tenths < 15) tenths = 15;
  if (tenths > 39) tenths = 39;
  return (uint8_t)(tenths - 15);
}

void drawSwrAlarm(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  const uint8_t selected = selectedSwrAlarmIndex(lines);
  const bool alarmOff = (selected == 25);

  drawTitle("SWR Alarm");

  const char *rangeText = "TRIP LEVEL 1.5 - 3.9 : 1";
  const int16_t rangeW = menuTextWidth(rangeText);
  setMenuFont(kDim);
  u8g2.setCursor((kW - rangeW) / 2, 23);
  u8g2.print(rangeText);

  char hero[16];
  if (alarmOff)
  {
    snprintf(hero, sizeof(hero), "OFF");
  }
  else
  {
    const uint8_t tenths = (uint8_t)(15 + selected);
    snprintf(hero, sizeof(hero), "%u.%u : 1",
             tenths / 10, tenths % 10);
  }
  drawGfxCenteredIn(0, kW, 43, hero, kWhite);

  // 25 fine threshold segments represent 1.5..3.9 in exact 0.1 steps.
  // A separate OFF card makes the disabled state explicit instead of treating
  // it as just another numeric value on the bar.
  constexpr int16_t segX0 = 4;
  constexpr int16_t segStep = 7;
  constexpr int16_t segW = 6;
  constexpr int16_t segY = 45;
  constexpr int16_t segH = 8;

  for (uint8_t i = 0; i < 25; ++i)
  {
    const int16_t x = segX0 + (int16_t)i * segStep;

    if (!alarmOff && i < selected)
    {
      lcd.fillRect(x, segY, segW, segH, kLine);
      lcd.drawRect(x, segY, segW, segH, kDim);
    }
    else if (!alarmOff && i == selected)
    {
      lcd.fillRect(x, segY, segW, segH, kBright);
      lcd.drawRect(x, segY, segW, segH, kWhite);
      lcd.fillRect(x + 1, segY, segW - 2, 2, kWhite);
    }
    else
    {
      lcd.drawRect(x, segY, segW, segH, kDim);
    }
  }

  // OFF card on the right.
  constexpr int16_t offX = 184;
  constexpr int16_t offY = 43;
  constexpr int16_t offW = 68;
  constexpr int16_t offH = 12;

  if (alarmOff)
    lcd.fillRect(offX, offY, offW, offH, kLine);

  lcd.drawRect(offX, offY, offW, offH, alarmOff ? kWhite : kDim);

  if (alarmOff)
    lcd.fillRect(offX + 1, offY + 1, offW - 2, 2, kWhite);

  drawSmallCenteredIn(offX, offW, 52, "OFF",
                      alarmOff ? kWhite : kNormal);

  const char *left = "TURN = ADJUST";
  const char *right = "PUSH = SAVE";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical SWR Alarm Power renderer (V2.16.5.11)
// ---------------------------------------------------------------------------
// Presentation only. The existing swr_alarm_power_threshold_menu() continues
// to own encoder handling, EEPROM storage and the actual alarm threshold.

bool isSwrAlarmPowerPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "SWR Alarm Power:") == 0 ||
         strcmp(t, "SWR Alarm Power") == 0;
}

uint8_t selectedSwrAlarmPowerIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // swr_alarm_power_threshold_menu() places the scrolling selector after the
  // word "Select", so locate the selection arrow anywhere in the row.
  for (uint8_t row = 1; row < OLED_ROWS; ++row)
  {
    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    trimRight(work);

    char *arrow = strstr(work, "->");
    if (!arrow)
      continue;

    char *item = trimLeft(arrow + 2);

    // Match the most specific strings first so 10mW cannot be mistaken for
    // 1mW and 10W cannot be mistaken for 1W.
    if (strstr(item, "10mW")) return 1;
    if (strstr(item, "1mW"))  return 0;
    if (strstr(item, "0.1W")) return 2;
    if (strstr(item, "10W"))  return 4;
    if (strstr(item, "1W"))   return 3;
  }

  return 1; // same safe 10 mW fallback used by the menu logic
}

void drawSwrAlarmPower(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  static const char * const hero[5] = {
    "1 mW", "10 mW", "0.1 W", "1 W", "10 W"
  };
  static const char * const labels[5] = {
    "1mW", "10mW", ".1W", "1W", "10W"
  };

  const uint8_t selected = selectedSwrAlarmPowerIndex(lines);

  drawTitle("SWR Alarm Power");

  // Large selected alarm threshold.  The units follow the natural transition
  // from milliwatts to watts instead of forcing every value into one unit.
  drawGfxCenteredIn(0, kW, 39, hero[selected], kWhite);

  // Five logarithmic power cards: 1 mW -> 10 mW -> 0.1 W -> 1 W -> 10 W.
  // The active card uses the same restrained filled highlight as the other
  // modern settings pages.
  constexpr int16_t tileX0 = 4;
  constexpr int16_t tileStep = 50;
  constexpr int16_t tileW = 47;
  constexpr int16_t tileY = 40;
  constexpr int16_t tileH = 14;

  for (uint8_t i = 0; i < 5; ++i)
  {
    const int16_t x = tileX0 + (int16_t)i * tileStep;
    const bool active = (i == selected);

    if (active)
      lcd.fillRect(x, tileY, tileW, tileH, kLine);

    lcd.drawRect(x, tileY, tileW, tileH, active ? kWhite : kDim);

    if (active)
      lcd.fillRect(x + 1, tileY + 1, tileW - 2, 2, kWhite);

    drawSmallCenteredIn(x, tileW, 51, labels[i],
                        active ? kWhite : kNormal);
  }

  const char *left = "TURN = SELECT";
  const char *right = "PUSH = SAVE";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical PEP Hold Time renderer (V2.16.5.9)
// ---------------------------------------------------------------------------
// Presentation only. The existing pep_menu() still owns the encoder, the
// 0.1 / 1.0 / 2.0 second choices, EEPROM storage and the actual PEP timing.

bool isPepHoldTimePage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "PEP hold time:") == 0 ||
         strcmp(t, "PEP Hold Time") == 0;
}

uint8_t selectedPepHoldIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // pep_menu() prints "Select" at column 0 and its one-line selector starts
  // at column 6.  The virtual row therefore looks like:
  //
  //     Select->   0.1s
  //
  // Do not require the selection arrow to be at the beginning of the row.
  // Find it anywhere in the row, exactly as the graphical Noise Floor page
  // does for its one-line selector.
  for (uint8_t row = 1; row < OLED_ROWS; ++row)
  {
    char work[OLED_COLUMNS + 1];
    copyBounded(work, sizeof(work), lines[row]);
    trimRight(work);

    char *arrow = strstr(work, "->");
    if (!arrow)
      continue;

    char *item = trimLeft(arrow + 2);

    if (strstr(item, "0.1")) return 0;
    if (strstr(item, "1.0")) return 1;
    if (strstr(item, "2.0")) return 2;
  }

  return 0;
}

void drawPepHoldTime(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  static const char * const hero[3] = {
    "0.1 s", "1.0 s", "2.0 s"
  };
  static const char * const labels[3] = {
    "0.1 SEC", "1.0 SEC", "2.0 SEC"
  };

  const uint8_t selected = selectedPepHoldIndex(lines);

  drawTitle("PEP Hold Time");

  // Large current timing value, matching the visual hierarchy used by the
  // graphical PK Hold and other modern settings pages.
  drawGfxCenteredIn(0, kW, 40, hero[selected], kWhite);

  // Three wide timing cards.  There are only three valid PEP periods, so this
  // communicates the discrete choices much more clearly than a fake continuous
  // scale while retaining the same instrument-style highlight language.
  constexpr int16_t tileX0 = 8;
  constexpr int16_t tileStep = 82;
  constexpr int16_t tileW = 76;
  constexpr int16_t tileY = 41;
  constexpr int16_t tileH = 14;

  for (uint8_t i = 0; i < 3; ++i)
  {
    const int16_t x = tileX0 + (int16_t)i * tileStep;
    const bool active = (i == selected);

    if (active)
      lcd.fillRect(x, tileY, tileW, tileH, kLine);

    lcd.drawRect(x, tileY, tileW, tileH, active ? kWhite : kDim);

    if (active)
      lcd.fillRect(x + 1, tileY + 1, tileW - 2, 2, kWhite);

    drawSmallCenteredIn(x, tileW, 52, labels[i],
                        active ? kWhite : kNormal);
  }

  const char *left = "TURN = SELECT";
  const char *right = "PUSH = SAVE";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}


// ---------------------------------------------------------------------------
// Dedicated graphical PK Display Hold renderer (V2.16.5.8)
// ---------------------------------------------------------------------------
// Presentation only. The existing pk_hold_menu() still owns the encoder,
// 0.1 s adjustment steps, EEPROM storage and the actual OLED peak-hold timing.

bool isPkDisplayHoldPage(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  char title[OLED_COLUMNS + 1];
  copyBounded(title, sizeof(title), lines[0]);
  char *t = trimLeft(title);
  trimRight(t);
  return strcmp(t, "PK display hold:") == 0 ||
         strcmp(t, "PK Display Hold") == 0;
}

uint8_t selectedPkHoldIndex(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  // pk_hold_menu() formats row 1 as "0.1 seconds" .. "2.0 seconds".
  // Convert that presentation text back to one of the 20 graphical steps.
  char work[OLED_COLUMNS + 1];
  copyBounded(work, sizeof(work), lines[1]);
  char *v = trimLeft(work);

  const double seconds = atof(v);
  int16_t step = (int16_t)(seconds * 10.0 + 0.5) - 1;
  if (step < 0) step = 0;
  if (step > 19) step = 19;
  return (uint8_t)step;
}

void drawPkDisplayHold(char lines[OLED_ROWS][OLED_COLUMNS + 1])
{
  const uint8_t selected = selectedPkHoldIndex(lines);
  const uint16_t holdMs = (uint16_t)(selected + 1) * 100U;

  drawTitle("PK Display Hold");

  // Quiet range context under the title.  The setting has twenty 0.1 s steps,
  // so a segmented scale communicates its precision much better than 20 labels.
  const char *rangeText = "RANGE 0.1 - 2.0 s";
  const int16_t rangeW = menuTextWidth(rangeText);
  setMenuFont(kDim);
  u8g2.setCursor((kW - rangeW) / 2, 23);
  u8g2.print(rangeText);

  // Large current hold value.
  char hero[12];
  snprintf(hero, sizeof(hero), "%.1f s", holdMs / 1000.0);
  drawGfxCenteredIn(0, kW, 43, hero, kWhite);

  // Twenty graphical 0.1 s segments.  Earlier steps form a restrained filled
  // trail; the currently selected step is bright, making direction and amount
  // immediately visible without cluttering the OLED with twenty numbers.
  constexpr int16_t segX0 = 9;
  constexpr int16_t segStep = 12;
  constexpr int16_t segW = 10;
  constexpr int16_t segY = 44;
  constexpr int16_t segH = 8;

  for (uint8_t i = 0; i < 20; ++i)
  {
    const int16_t x = segX0 + (int16_t)i * segStep;

    if (i < selected)
    {
      lcd.fillRect(x, segY, segW, segH, kLine);
      lcd.drawRect(x, segY, segW, segH, kDim);
    }
    else if (i == selected)
    {
      lcd.fillRect(x, segY, segW, segH, kBright);
      lcd.drawRect(x, segY, segW, segH, kWhite);
      // Small top marker, consistent with the graphical selector cards.
      lcd.fillRect(x + 1, segY, segW - 2, 2, kWhite);
    }
    else
    {
      lcd.drawRect(x, segY, segW, segH, kDim);
    }
  }

  const char *left = "TURN = ADJUST";
  const char *right = "PUSH = SAVE";

  setMenuFont(kDim);
  u8g2.setCursor(2, 63);
  u8g2.print(left);

  const int16_t rw = menuTextWidth(right);
  setMenuFont(kNormal);
  u8g2.setCursor(kW - rw - 2, 63);
  u8g2.print(right);
}

void drawCenteredStatus(char lines[OLED_ROWS][OLED_COLUMNS + 1],
                        uint8_t firstRow, uint8_t lastRow)
{
  uint8_t count = 0;
  for (uint8_t row = firstRow; row <= lastRow && row < OLED_ROWS; ++row)
  {
    char temp[OLED_COLUMNS + 1];
    copyBounded(temp, sizeof(temp), lines[row]);
    trimRight(temp);
    if (*trimLeft(temp))
      ++count;
  }

  if (count == 0) return;

  // V2.16.5.23: transient confirmations now use the same strong graphical
  // font family as the modern Setup menu instead of the old 6x12 text.
  // Most messages fit in Profont22. Long messages automatically use
  // Profont17 so they remain large without being clipped.
  int16_t y;
  int16_t step;

  if (count == 1)
  {
    y = 40;
    step = 0;
  }
  else if (count == 2)
  {
    y = 28;
    step = 23;
  }
  else
  {
    // Rare three/four-line status: keep it readable without overlap.
    y = 18;
    step = 15;
  }

  for (uint8_t row = firstRow; row <= lastRow && row < OLED_ROWS; ++row)
  {
    char temp[OLED_COLUMNS + 1];
    copyBounded(temp, sizeof(temp), lines[row]);
    trimRight(temp);
    char *clean = trimLeft(temp);
    if (!clean || !*clean) continue;

    // Start with the same Profont22 used by the graphical Setup card.
    lcd.setFont(&Profont22);
    lcd.setTextColor(kWhite);
    lcd.setTextWrap(false);

    int16_t x1 = 0, y1 = 0;
    uint16_t tw = 0, th = 0;
    lcd.getTextBounds(clean, 0, 0, &x1, &y1, &tw, &th);

    // A message such as "Exit from diagnostics" is too wide in Profont22.
    // Profont17 is still substantially larger than the old menu/status font.
    if (tw > 248 || count > 2)
    {
      lcd.setFont(&Profont17);
      lcd.getTextBounds(clean, 0, 0, &x1, &y1, &tw, &th);
    }

    // Final safety fallback for an unexpectedly long future message.
    if (tw > 252)
    {
      setMenuFont(kWhite);
      const int16_t smallW = menuTextWidth(clean);
      int16_t x = (kW - smallW) / 2;
      if (x < 2) x = 2;
      u8g2.setCursor(x, y);
      u8g2.print(clean);
    }
    else
    {
      // Account for the GFX glyph left bearing so the visible text is centered.
      int16_t x = (kW - (int16_t)tw) / 2 - x1;
      if (x < 1) x = 1;
      lcd.setCursor(x, y);
      lcd.print(clean);
    }

    y += step;
  }
}

} // namespace

TextLCD::TextLCD()
  : Col(OLED_COLUMNS), Row(OLED_ROWS), virt_x(0), virt_y(0)
{
  memset(text_lcd, 0xff, sizeof(text_lcd));
  memset(virt_lcd, ' ', sizeof(virt_lcd));
  text_lcd[LCD_TEXTSIZE] = '\0';
  virt_lcd[LCD_TEXTSIZE] = '\0';
}

uint16_t TextLCD::activeSize(void) const
{
  uint16_t size = (uint16_t)Col * (uint16_t)Row;
  if (size > LCD_TEXTSIZE) size = LCD_TEXTSIZE;
  return size;
}

void TextLCD::init(uint8_t columns, uint8_t rows)
{
  if (columns == 0) columns = 1;
  if (rows == 0) rows = 1;

  if (columns > LCD_TEXTSIZE) columns = LCD_TEXTSIZE;
  if ((uint16_t)columns * rows > LCD_TEXTSIZE)
  {
    rows = LCD_TEXTSIZE / columns;
    if (rows == 0) rows = 1;
  }

  Col = columns;
  Row = rows;
  virt_x = 0;
  virt_y = 0;

  memcpy(text_lcd, virt_lcd, activeSize());
}

void TextLCD::transfer(void)
{
  const uint16_t count = activeSize();
  if (count == 0) return;

  if (memcmp(virt_lcd, text_lcd, count) == 0)
    return;

  memcpy(text_lcd, virt_lcd, count);

  char lines[OLED_ROWS][OLED_COLUMNS + 1];
  uint8_t nonEmpty = 0;
  uint8_t firstNonEmpty = OLED_ROWS;
  uint8_t lastNonEmpty = 0;
  bool hasSelection = false;

  for (uint8_t row = 0; row < OLED_ROWS; ++row)
  {
    const uint8_t width = (Col < OLED_COLUMNS) ? Col : OLED_COLUMNS;
    memcpy(lines[row], &text_lcd[(uint16_t)row * Col], width);
    lines[row][width] = '\0';
    trimRight(lines[row]);

    char test[OLED_COLUMNS + 1];
    copyBounded(test, sizeof(test), lines[row]);
    char *clean = trimLeft(test);

    if (clean && *clean)
    {
      ++nonEmpty;
      if (firstNonEmpty == OLED_ROWS) firstNonEmpty = row;
      lastNonEmpty = row;
    }

    if (startsSelection(lines[row]))
      hasSelection = true;
  }

  lcd.clearDisplay();
  lcd.setTextWrap(false);

  // Dedicated graphical Calibration pages. Presentation only; the proven
  // calibration math, EEPROM writes and encoder behaviour remain unchanged.
  if (isCalibrateMenuPage(lines))
  {
    drawCalibrateMenu(lines);
    lcd.display();
    return;
  }

  if (isCalibrationEditPage(lines))
  {
    drawCalibrationEdit(lines);
    lcd.display();
    return;
  }

  if (isCalibrationOverviewPage(lines))
  {
    drawCalibrationOverview(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical four-band selector.
  if (isBandSelectPage(lines))
  {
    drawBandSelectPage();
    lcd.display();
    return;
  }

  // Dedicated graphical Startup Logo selector.
  if (isStartupLogoPage(lines))
  {
    drawStartupLogoPage();
    lcd.display();
    return;
  }

  if (isClockPrimaryPage(lines))
  {
    drawClockPrimaryPage();
    lcd.display();
    return;
  }

  if (isClockDimPage(lines))
  {
    drawClockDimPage();
    lcd.display();
    return;
  }

  // Nearby WiFi network selector. The XIAO performs the RF scan; the Teensy
  // owns the encoder selection and credential storage.
  if (isWifiNetworksPage(lines))
  {
    drawWifiNetworks();
    lcd.display();
    return;
  }

  // Read-only WiFi connection information including the assigned IP and RSSI.
  if (isWifiStatusPage(lines))
  {
    drawWifiStatus();
    lcd.display();
    return;
  }

  if (isSetGridPage(lines))
  {
    drawSetGrid();
    lcd.display();
    return;
  }

  // WiFi SSID/password use the exact same full-screen QWERTY geometry as
  // Set Your Call. Password characters are masked in the entry field.
  if (isWifiSsidPage(lines))
  {
    drawWifiEditor(false);
    lcd.display();
    return;
  }

  if (isWifiPasswordPage(lines))
  {
    drawWifiEditor(true);
    lcd.display();
    return;
  }

  // Dedicated graphical Set Your Call editor. Menu code owns the editable
  // buffer and EEPROM action; this renderer only draws the QWERTY keyboard.
  if (isSetYourCallPage(lines))
  {
    drawSetYourCall();
    lcd.display();
    return;
  }

  // Dedicated graphical top-level Setup menu. Presentation only; the proven
  // menu selection, encoder queue and navigation logic remain unchanged.
  if (isSetupMenuPage(lines))
  {
    drawSetupMenu(lines);
    lcd.display();
    return;
  }

  // Dedicated second confirmation page before the destructive Factory Reset.
  if (isFactoryConfirmPage(lines))
  {
    drawFactoryConfirm(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical Factory Reset page.
  if (isFactoryResetPage(lines))
  {
    drawFactoryReset(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical SWR Alarm page. Presentation only; the proven
  // menu/encoder/EEPROM/alarm logic remains unchanged.
  if (isSwrAlarmPage(lines))
  {
    drawSwrAlarm(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical SWR Alarm Power page. Presentation only; the proven
  // menu/encoder/EEPROM/alarm logic remains unchanged.
  if (isSwrAlarmPowerPage(lines))
  {
    drawSwrAlarmPower(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical PEP Hold Time page. Presentation only; the proven
  // menu/encoder/EEPROM/timing logic remains unchanged.
  if (isPepHoldTimePage(lines))
  {
    drawPepHoldTime(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical PK Display Hold page. Presentation only; the proven
  // menu/encoder/EEPROM/timing logic remains unchanged.
  if (isPkDisplayHoldPage(lines))
  {
    drawPkDisplayHold(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical Noise Floor page. Presentation only; the proven
  // menu/encoder/EEPROM logic remains unchanged.
  if (isNoiseFloorPage(lines))
  {
    drawNoiseFloor(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical Screensaver Time page. Presentation only; the proven
  // menu/encoder/EEPROM logic remains unchanged.
  if (isScreensaverTimePage(lines))
  {
    drawScreensaverTime(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical Display Off Time page.  Presentation only; the proven
  // menu/encoder/EEPROM logic remains unchanged.
  if (isDisplayOffTimePage(lines))
  {
    drawDisplayOffTime(lines);
    lcd.display();
    return;
  }

  // Dedicated graphical Power Bar Scale pages.  These are intercepted before
  // the generic list/adjustment renderer; menu and encoder logic remain intact.
  if (isPowerBarScaleEdit(lines))
  {
    drawPowerBarScaleEdit(lines);
    lcd.display();
    return;
  }

  if (isPowerBarScaleSelect(lines))
  {
    drawPowerBarScaleSelect(lines);
    lcd.display();
    return;
  }

  // Graphical confirmation after the external coupler switch has actually
  // changed Coupler 1/2. Alarm acknowledgement never reaches this renderer.
  const int8_t selectedCoupler = couplerSelectionStatus(lines);
  if (selectedCoupler > 0)
  {
    drawCouplerSelectionStatus((uint8_t)selectedCoupler);
    lcd.display();
    return;
  }

  // Transient messages such as Value Stored / Nothing Changed / Factory Reset.
  // If there is no title in row 0 and no menu selection, center the content.
  if (!hasSelection && firstNonEmpty > 0)
  {
    drawCenteredStatus(lines, firstNonEmpty, lastNonEmpty);
    lcd.display();
    return;
  }

  // Adjustment page gets the large central value.
  if (!hasSelection && isAdjustmentScreen(lines))
  {
    drawAdjustment(lines);
    lcd.display();
    return;
  }

  // Standard list / information page.
  drawList(lines);
  lcd.display();
}

void TextLCD::write(char ch)
{
  const uint16_t count = activeSize();
  if (count == 0) return;

  uint16_t pos =
    (uint16_t)((uint16_t)virt_y * (uint16_t)Col + (uint16_t)virt_x);

  if (pos >= count) pos = 0;

  virt_lcd[pos] = ch;
  pos++;

  if (pos >= count) pos = 0;

  virt_y = (uint8_t)(pos / Col);
  virt_x = (uint8_t)(pos % Col);
}

void TextLCD::print(const char *text)
{
  if (!text) return;
  while (*text) write(*text++);
}

void TextLCD::setCursor(uint8_t x, uint8_t y)
{
  if (x >= Col) x = (Col > 0) ? (Col - 1) : 0;
  if (y >= Row) y = (Row > 0) ? (Row - 1) : 0;

  virt_x = x;
  virt_y = y;
}

void TextLCD::clear(void)
{
  const uint16_t count = activeSize();

  for (uint16_t i = 0; i < count; ++i)
    virt_lcd[i] = ' ';

  virt_x = 0;
  virt_y = 0;
}
