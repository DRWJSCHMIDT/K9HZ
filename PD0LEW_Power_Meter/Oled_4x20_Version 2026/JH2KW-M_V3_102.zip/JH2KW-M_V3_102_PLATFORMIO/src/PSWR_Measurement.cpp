/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_Measurement.h"
#include "PSWR_State.h"
#include "PSWR_AD7991_HS.h"
#include "PSWR_ModScope.h"
#include <math.h>

// AD7991 acquisition is owned by PSWR_AD7991_HS.cpp.  The 50 us TimerOne ISR
// performs only the bounded Hs-mode four-byte read and queues raw samples.  All
// detector calibration, power, PEP and SWR calculations remain in normal context.
static uint32_t measurement_capture_tick = 0;

// Calibration capture is deliberately filtered. At the deterministic 20 kHz
// capture rate a 1/256 IIR is about a 12.8 ms time constant, matching the stable
// calibration response of the previous OLED version without using one raw sample.
static double cal_fwd_adc_filtered = 0.0;
static double cal_rev_adc_filtered = 0.0;
static bool   cal_adc_filter_valid = false;

// SWR is intentionally based on complete 100 ms averages of linear forward
// and reflected power, not on whichever single ADC sample happens to be newest
// when the 100 ms UI poll runs. This greatly reduces detector/noise jitter and
// makes the alarm decision use the same stable directional-power interval.
static double detector_fwd_channel_mw = 0.0;
static double detector_rev_channel_mw = 0.0;
static double swr_fwd_avg_mw = 0.0;
static double swr_ref_avg_mw = 0.0;
static double swr_net_avg_mw = 0.0;
static bool   swr_block_valid = false;
static uint32_t swr_block_sequence = 0;

// V3.102 PEP/display diagnostic snapshot. Updated only after a completed 100 ms block.
// USB output is intentionally deferred to PSWR_USB.cpp so Serial printing can
// never stall the 20 kHz sample processing path.
static PepDebugSnapshot pep_debug_snapshot = {};
static uint32_t pep_debug_sequence = 0;

static inline void adc_update_cal_filter(int16_t fwd_code, int16_t rev_code)
{
  if (!cal_adc_filter_valid)
  {
    cal_fwd_adc_filtered = (double)fwd_code;
    cal_rev_adc_filtered = (double)rev_code;
    cal_adc_filter_valid = true;
    return;
  }

  constexpr double alpha = 1.0 / 256.0;
  cal_fwd_adc_filtered += ((double)fwd_code - cal_fwd_adc_filtered) * alpha;
  cal_rev_adc_filtered += ((double)rev_code - cal_rev_adc_filtered) * alpha;
}

double pswr_get_cal_fwd_voltage(void)
{
  const double code = cal_adc_filter_valid ? cal_fwd_adc_filtered : (double)fwd;
  return adc_ref * code / 4096.0;
}

double pswr_get_cal_rev_voltage(void)
{
  const double code = cal_adc_filter_valid ? cal_rev_adc_filtered : (double)rev;
  return adc_ref * code / 4096.0;
}

uint32_t pswr_get_missed_samples(void)
{
  return ad7991_hs_overruns();
}

uint32_t pswr_get_adc_read_errors(void)
{
  return ad7991_hs_read_errors();
}

uint16_t pswr_get_sample_queue_depth(void)
{
  return ad7991_hs_queue_depth();
}

uint16_t pswr_get_sample_queue_high_water(void)
{
  return ad7991_hs_queue_high_water();
}

double pswr_get_qualified_net_power_mw(void)
{
  return swr_block_valid ? swr_net_avg_mw : 0.0;
}

bool pswr_get_pep_debug_snapshot(PepDebugSnapshot &out)
{
  if (pep_debug_snapshot.sequence == 0) return false;
  out = pep_debug_snapshot;
  return true;
}

// Drain all raw samples captured by the Hs-mode ISR and run the proven OLED
// measurement engine in normal loop context.
void pswr_service_sampler(void)
{
  Ad7991CapturedSample sample;
  while (ad7991_hs_pop(sample))
  {
    fwd = (int16_t)sample.fwd;
    rev = (int16_t)sample.rev;
    measurement_capture_tick = sample.tick;
    adc_update_cal_filter(fwd, rev);
    determine_power_pep_pk();
  }
}

//-----------------------------------------------------------------------------------------
// Prepare power values and calculate SWR.
// Called at POLL_TIMER rate.
//-----------------------------------------------------------------------------------------
void calc_SWR_and_power(void)
{
  static uint8_t high_swr_count = 0;
  static uint32_t last_swr_block_sequence = 0;

  power_mw_pk  = pow(10.0, power_db_pk  / 10.0);
  power_mw_pep = pow(10.0, power_db_pep / 10.0);
  power_mw_lng = pow(10.0, power_db_lng / 10.0);

  if (!isfinite(power_mw_pk))  power_mw_pk = 0.0;
  if (!isfinite(power_mw_pep)) power_mw_pep = 0.0;
  if (!isfinite(power_mw_lng)) power_mw_lng = 0.0;

  // Process each completed 100 ms directional-power block exactly once. This
  // prevents a delayed/repeated UI poll from counting the same high-SWR block
  // twice toward the two-block alarm qualification.
  const bool new_swr_block =
    swr_block_valid && (swr_block_sequence != last_swr_block_sequence);

  if (new_swr_block)
  {
    last_swr_block_sequence = swr_block_sequence;

    // New SWR values are accepted only from a complete directional-power block
    // that also contains real net transmitted power. Common-mode broadcast
    // pickup may raise both detectors, but without net forward energy it cannot
    // create an SWR reading or alarm.
    const bool swr_tx_power_present =
      isfinite(swr_fwd_avg_mw) &&
      isfinite(swr_ref_avg_mw) &&
      isfinite(swr_net_avg_mw) &&
      (swr_net_avg_mw >= SWR_TX_NET_MIN_MW) &&
      (swr_fwd_avg_mw > MIN_PWR_FOR_SWR_CALC);

    if (swr_tx_power_present)
    {
      // Reflection coefficient magnitude from averaged linear powers:
      //   |Gamma| = sqrt(Pref / Pfwd)
      //   SWR     = (1 + |Gamma|) / (1 - |Gamma|)
      double power_ratio = swr_ref_avg_mw / swr_fwd_avg_mw;
      if (!isfinite(power_ratio) || power_ratio < 0.0)
        power_ratio = 0.0;
      if (power_ratio > 1.0)
        power_ratio = 1.0;

      const double rho = sqrt(power_ratio);

      if (!isfinite(rho) || rho >= 0.9998)
        swr = 9999.0;
      else
        swr = (1.0 + rho) / (1.0 - rho);

      if (!isfinite(swr) || swr < 1.0)
        swr = 1.0;

      // Evaluate the alarm from the uncapped SWR. The 10:1 display/output limit
      // is applied only after the alarm decision.
      const bool alarm_condition =
        (R.SWR_alarm_trig != 40) &&
        ((swr * 10.0) >= R.SWR_alarm_trig) &&
        (swr_fwd_avg_mw > (double)R.SWR_alarm_pwr_thresh);

      if (alarm_condition)
      {
        // Require two DISTINCT consecutive 100 ms high-SWR blocks. Once
        // acknowledged, do not re-trigger until the condition becomes safe.
        if (!flag.swr_alarm && !swr_alarm_acknowledged)
        {
          if (high_swr_count < 2) ++high_swr_count;
          if (high_swr_count >= 2)
          {
            flag.swr_alarm = true;
            swr_alarm_acknowledged = false;
            optionalDigitalWrite(R_Led, HIGH);
            swrBuzzerOn();
            swr_buzzer_active = true;
            swr_buzzer_started_ms = millis();
          }
        }
      }
      else
      {
        high_swr_count = 0;
        swr_alarm_acknowledged = false;
      }

      if (swr > SWR_MAX_VALUE)
        swr = SWR_MAX_VALUE;
    }
    else
    {
      // No valid transmitter power: external pickup must never create or update
      // an SWR reading or alarm. If an alarm is already latched, preserve the
      // last valid alarm SWR until acknowledge/reset.
      if (!flag.swr_alarm)
      {
        high_swr_count = 0;
        swr_alarm_acknowledged = false;
        swr = 1.0;
      }
    }
  }

  // Publish the newest valid 100 ms SWR directly; no extra long display average.
  swr_avg = swr;
  if (!isfinite(swr_avg) || swr_avg < 1.0) swr_avg = 1.0;

  if (swr_avg < 10.0)
  {
    double bar = 1000.0 * log10(swr_avg);
    if (bar < 0.0) bar = 0.0;
    if (bar > 1000.0) bar = 1000.0;
    swr_bar = (uint16_t)bar;
  }
  else
  {
    swr_bar = 1000;
  }
}

//-----------------------------------------------------------------------------------------
// Convert AD8307 detector voltages to dBm.
//-----------------------------------------------------------------------------------------
void pswr_determine_dBm(void)
{
  const double delta_db =
    (double)(R.cal_AD[1].db10m - R.cal_AD[0].db10m) / 10.0;

  const double delta_F = R.cal_AD[1].Fwd - R.cal_AD[0].Fwd;
  const double delta_R = R.cal_AD[1].Rev - R.cal_AD[0].Rev;

  // Protect against corrupt/identical calibration points.
  const double delta_Fdb =
    (fabs(delta_F) > 1.0e-6) ? (delta_db / delta_F) : (1000.0 / LOGAMP1_SLOPE);
  const double delta_Rdb =
    (fabs(delta_R) > 1.0e-6) ? (delta_db / delta_R) : (1000.0 / LOGAMP2_SLOPE);

  const double fwd_v = adc_ref * ((double)fwd / 4096.0);
  const double rev_v = adc_ref * ((double)rev / 4096.0);

  double raw_fwd_dbm =
    (fwd_v - R.cal_AD[0].Fwd) * delta_Fdb + R.cal_AD[0].db10m / 10.0;
  double raw_rev_dbm =
    (rev_v - R.cal_AD[0].Rev) * delta_Rdb + R.cal_AD[0].db10m / 10.0;

  if (!isfinite(raw_fwd_dbm)) raw_fwd_dbm = -120.0;
  if (!isfinite(raw_rev_dbm)) raw_rev_dbm = -120.0;

  // Preserve the two PHYSICAL calibrated detector channels before the legacy
  // bidirectional swap. SWR qualification averages these channels separately
  // for 100 ms, eliminating the positive bias that sample-by-sample max/min
  // selection can create in strong common-mode broadcast pickup.
  detector_fwd_channel_mw = pow(10.0, raw_fwd_dbm / 10.0);
  detector_rev_channel_mw = pow(10.0, raw_rev_dbm / 10.0);
  if (!isfinite(detector_fwd_channel_mw) || detector_fwd_channel_mw < 0.0)
    detector_fwd_channel_mw = 0.0;
  if (!isfinite(detector_rev_channel_mw) || detector_rev_channel_mw < 0.0)
    detector_rev_channel_mw = 0.0;
  if (detector_fwd_channel_mw > 9000000.0) detector_fwd_channel_mw = 9000000.0;
  if (detector_rev_channel_mw > 9000000.0) detector_rev_channel_mw = 9000000.0;

  // Existing bidirectional meter behaviour: the larger instantaneous detector
  // remains the published Forward value, with Reverse marking opposite flow.
  if (raw_fwd_dbm >= raw_rev_dbm)
  {
    ad8307_FdBm = raw_fwd_dbm;
    ad8307_RdBm = raw_rev_dbm;
    Reverse = false;
  }
  else
  {
    ad8307_FdBm = raw_rev_dbm;
    ad8307_RdBm = raw_fwd_dbm;
    Reverse = true;
  }
}


//-----------------------------------------------------------------------------------------
// Remove the statistical upward bias of the peak detector on an unmodulated carrier.
// The 100 ms average is the reference because it uses all samples and has proven stable.
// Real envelope peaks that rise more than PEAK_CARRIER_NOISE_DB above the average pass
// through unchanged. This is not a power calibration factor.
//-----------------------------------------------------------------------------------------
static double stabilize_carrier_peak_db(double peak_db, double average_mw)
{
  if (!isfinite(peak_db) || !isfinite(average_mw) || average_mw <= 1.0e-12)
    return peak_db;

  const double average_db = 10.0 * log10(average_mw);
  const double excess_db = peak_db - average_db;

  if (excess_db >= 0.0 && excess_db <= PEAK_CARRIER_NOISE_DB)
    return average_db;

  return peak_db;
}

//-----------------------------------------------------------------------------------------
// Robust prefilter for the PK/PEP path.
//
// A single corrupt ADC/I2C sample can map to several kilowatts after log-detector
// calibration. Even the existing 64-sample (3.2 ms) moving average can then be
// pulled far above a steady 100 W carrier. A 5-sample median rejects up to two
// isolated adjacent spikes before they enter that moving average.
//
// This is intentionally used ONLY for PK/PEP/long-peak. The ordinary 100 ms and
// 1 s averages, SWR block averages, calibration and ModScope keep their existing
// measurement paths. At 20 kHz the median span is only 250 us, far shorter than
// the existing 3.2 ms peak filter.
//-----------------------------------------------------------------------------------------
static_assert(PEAK_MEDIAN_SAMPLES == 5, "median5 requires PEAK_MEDIAN_SAMPLES == 5");

static double median5(const double *v)
{
  double a[PEAK_MEDIAN_SAMPLES];
  for (uint8_t i = 0; i < PEAK_MEDIAN_SAMPLES; ++i) a[i] = v[i];

  // Insertion sort of five values; fixed tiny cost and no dynamic allocation.
  for (uint8_t i = 1; i < PEAK_MEDIAN_SAMPLES; ++i)
  {
    const double x = a[i];
    uint8_t j = i;
    while (j > 0 && a[j - 1] > x)
    {
      a[j] = a[j - 1];
      --j;
    }
    a[j] = x;
  }
  return a[PEAK_MEDIAN_SAMPLES / 2];
}

//-----------------------------------------------------------------------------------------
// Determine instantaneous power and maintain:
//   - 100 ms peak
//   - 100 ms average
//   - 1 s average
//   - selectable 0.1 / 1.0 / 2.0 s PEP
//   - 30 s maximum
//
// Statistics are based on the deterministic 50 us capture tick, not loop timing.
//-----------------------------------------------------------------------------------------
void determine_power_pep_pk(void)
{
  static uint32_t block_start_tick = 0;
  static double block_power_sum = 0.0;
  static double block_fwd_channel_sum = 0.0;
  static double block_rev_channel_sum = 0.0;
  static uint32_t block_sample_count = 0;
  static double block_peak_db = -120.0;
  // Consecutive no-RF samples at the END of the current 100 ms block.
  // This lets PK/PEP recognize a block cut short by key-up without changing
  // the ordinary block average, SWR, calibration, or sample path.
  static uint32_t block_tail_no_rf_samples = 0;

  // PK/PEP must not be the maximum of one raw ADC sample. A 100 ms block
  // contains many detector samples, so a tiny positive ADC spike can otherwise
  // become the displayed peak. We therefore take the maximum of a short
  // moving average in the LINEAR power domain.
  // This rejects isolated noise while remaining fast enough for real RF envelope
  // peaks.  The ordinary 100 ms and 1 s averages below still use every raw sample.
  static double peak_median_buf[PEAK_MEDIAN_SAMPLES] = {0.0};
  static uint8_t peak_median_head = 0;
  static uint8_t peak_median_valid = 0;

  static double peak_filter_buf[PEAK_FILTER_SAMPLES] = {0.0};
  static double peak_filter_sum = 0.0;
  static uint16_t peak_filter_head = 0;
  static uint16_t peak_filter_valid = 0;

  static double pep_blocks[PEP_BUFFER] = {0.0};
  static uint16_t pep_head = 0;
  static uint16_t pep_valid = 0;

  // PEP is a rolling hold of the SAME completed 100 ms peak used by PK.
  // At the beginning of a new transmission, detector/log-amp settling can create
  // a short false peak that PK may be too brief to notice on screen but PEP would
  // hold for up to 2 seconds. The fixed 100 ms block containing RF START is also
  // only a partial RF window, so V3.99 excludes that START block from PEP history.
  // A following block that still touches the first 100 ms guard uses its completed
  // average rather than its peak. After the guard, PEP and PK use exactly the same
  // completed block peak value.
  constexpr uint32_t PEP_STARTUP_GUARD_TICKS = 100000UL / SAMPLE_TIMER;
  static_assert(PEP_STARTUP_GUARD_TICKS > PEAK_FILTER_SAMPLES,
                "PEP startup guard must exceed the peak filter span");
  static bool pep_tx_active = false;
  static bool pep_new_tx_this_block = false;
  static uint32_t pep_tx_start_tick = 0;
  static bool pep_guard_touched_this_block = false;

  static double long_blocks[LONG_BUFFER] = {0.0};
  static uint16_t long_head = 0;
  static uint16_t long_valid = 0;

  static double avg1s_sum_blocks[10] = {0.0};
  static uint32_t avg1s_count_blocks[10] = {0};
  static uint8_t avg1s_head = 0;
  static double avg1s_total_sum = 0.0;
  static uint32_t avg1s_total_count = 0;

  pswr_determine_dBm();

  f_inst = pow(10.0, ad8307_FdBm / 20.0);
  r_inst = pow(10.0, ad8307_RdBm / 20.0);

  // ModScope is display-only and stores every processed calibrated forward-RF
  // amplitude sample for the fastest possible sweep. It does not feed back into
  // measurement, PK/PEP, SWR, calibration or alarm calculations.
  modscope_capture(f_inst);

  fwd_power_mw = f_inst * f_inst;
  ref_power_mw = r_inst * r_inst;

  // Keep absurd/corrupt values from propagating into the display and statistics.
  if (!isfinite(fwd_power_mw) || fwd_power_mw < 0.0) fwd_power_mw = 0.0;
  if (!isfinite(ref_power_mw) || ref_power_mw < 0.0) ref_power_mw = 0.0;
  if (fwd_power_mw > 9000000.0) fwd_power_mw = 9000000.0;
  if (ref_power_mw > 9000000.0) ref_power_mw = 9000000.0;

  power_mw = fwd_power_mw - ref_power_mw;
  if (power_mw < 0.0) power_mw = 0.0;


  // Avoid log10(0). -120 dBm is only an internal floor for calculations.
  power_db = (power_mw > 1.0e-12) ? (10.0 * log10(power_mw)) : -120.0;
  if (!isfinite(power_db)) power_db = -120.0;

  const bool pep_sample_has_rf =
    isfinite(power_mw) && (power_mw >= ((double)NOISE_FLOOR_MW * 2.0));

  // Track only the consecutive quiet samples at the block tail. A transmission
  // that ends inside a 100 ms block leaves a continuous no-RF tail; normal
  // carrier/modulation followed by more RF resets this counter immediately.
  if (pep_sample_has_rf)
    block_tail_no_rf_samples = 0;
  else if (block_tail_no_rf_samples < 0xFFFFFFFFUL)
    ++block_tail_no_rf_samples;

  if (block_start_tick == 0)
    block_start_tick = measurement_capture_tick;

  block_power_sum += power_mw;
  block_fwd_channel_sum += detector_fwd_channel_mw;
  block_rev_channel_sum += detector_rev_channel_mw;
  block_sample_count++;

  // Reject isolated extreme samples before they can contaminate the short
  // PK/PEP envelope average. Once the five-sample history is primed, a one-
  // or two-sample ADC/RF glitch cannot become a visible power peak.
  peak_median_buf[peak_median_head] = power_mw;
  peak_median_head++;
  if (peak_median_head >= PEAK_MEDIAN_SAMPLES) peak_median_head = 0;
  if (peak_median_valid < PEAK_MEDIAN_SAMPLES) peak_median_valid++;

  const double peak_input_mw =
    (peak_median_valid == PEAK_MEDIAN_SAMPLES) ? median5(peak_median_buf) : power_mw;

  // Short linear-power envelope filter used ONLY by PK/PEP/long-peak.
  peak_filter_sum -= peak_filter_buf[peak_filter_head];
  peak_filter_buf[peak_filter_head] = peak_input_mw;
  peak_filter_sum += peak_input_mw;

  peak_filter_head++;
  if (peak_filter_head >= PEAK_FILTER_SAMPLES) peak_filter_head = 0;
  if (peak_filter_valid < PEAK_FILTER_SAMPLES) peak_filter_valid++;

  const double peak_filtered_mw =
    (peak_filter_valid > 0) ? (peak_filter_sum / (double)peak_filter_valid) : 0.0;
  const double peak_candidate_db =
    (peak_filtered_mw > 1.0e-12) ? (10.0 * log10(peak_filtered_mw)) : -120.0;

  if (block_sample_count == 1 || peak_candidate_db > block_peak_db)
    block_peak_db = peak_candidate_db;

  // Detect the beginning of a new transmission from NET delivered power.
  // Mark every statistics block that overlaps the first 100 ms. Such a block
  // may contain key-up settling and is never allowed to contribute a peak to
  // PEP hold. PK itself remains completely untouched and live.
  if (!pep_tx_active && pep_sample_has_rf)
  {
    pep_tx_active = true;
    pep_new_tx_this_block = true;
    pep_tx_start_tick = measurement_capture_tick;
  }

  if (pep_tx_active &&
      (uint32_t)(measurement_capture_tick - pep_tx_start_tick) < PEP_STARTUP_GUARD_TICKS)
  {
    pep_guard_touched_this_block = true;
  }

  // Give displays sane values immediately, even before the first complete 100 ms block.
  // For a steady carrier, suppress only the small max-of-noise excess above the
  // block average. Genuine envelope peaks remain untouched.
  if (block_sample_count > 0)
  {
    power_mw_avg = block_power_sum / (double)block_sample_count;
    if (avg1s_total_count == 0)
      power_mw_1savg = power_mw_avg;
  }

  const double live_peak_db = stabilize_carrier_peak_db(block_peak_db, power_mw_avg);
  power_db_pk = live_peak_db;

  // PEP and long-term peak are histories of COMPLETED 100 ms blocks.
  // Do not publish the unfinished current-block peak into those histories.
  // A key-up/detector transient can briefly be much higher than the final
  // validated block and would otherwise be held as a false PEP value.
  // PK remains live and responsive; PEP/LONG update only below after the
  // complete block has been carrier/noise stabilized.

  constexpr uint32_t BLOCK_TICKS = 100000UL / SAMPLE_TIMER;
  const uint32_t now_tick = measurement_capture_tick;
  if ((uint32_t)(now_tick - block_start_tick) < BLOCK_TICKS)
    return;

  // Finalize one 100 ms statistics block.
  const double block_avg =
    (block_sample_count > 0) ? (block_power_sum / (double)block_sample_count) : 0.0;

  // Preserve the pre-stabilization peak for the V3.95 diagnostic trace.
  // This lets us see whether a suspicious PEP value entered from the actual
  // block peak detector or was created later by PEP history/hold bookkeeping.
  const double raw_block_peak_db = block_peak_db;

  // Final carrier/noise discrimination for the completed 100 ms block.
  // Example: 10.7 W Peak versus 10.0 W Average is only +0.30 dB, so for an
  // unmodulated carrier the block Peak becomes the accurate 10.0 W average.
  //
  // V3.99 key-up edge protection: if at least 1 ms of consecutive no-RF samples
  // closes the block, its average is artificially low simply because RF ended
  // before the fixed 100 ms window did. In that one case keep the already
  // filtered RAW peak instead of collapsing PK/PEP to the shortened average.
  // This changes only PK/PEP presentation at the trailing edge.
  constexpr uint32_t PEP_TAIL_SILENCE_SAMPLES = 1000UL / SAMPLE_TIMER;
  static_assert(PEP_TAIL_SILENCE_SAMPLES > 0,
                "PEP tail silence threshold must be at least one sample");
  const bool block_has_meaningful_rf =
    isfinite(block_avg) && (block_avg >= ((double)NOISE_FLOOR_MW * 2.0));
  const bool block_ends_with_no_rf =
    block_has_meaningful_rf &&
    (block_tail_no_rf_samples >= PEP_TAIL_SILENCE_SAMPLES);

  if (!block_ends_with_no_rf)
    block_peak_db = stabilize_carrier_peak_db(block_peak_db, block_avg);

  power_db_pk = block_peak_db;
  power_mw_avg = block_avg;

  // Publish the complete directional-power block for SWR. Averaging power first
  // and then taking sqrt(Pref/Pfwd) is stable for carrier, CW and modulated RF.
  if (block_sample_count > 0)
  {
    double channel_fwd_avg = block_fwd_channel_sum / (double)block_sample_count;
    double channel_rev_avg = block_rev_channel_sum / (double)block_sample_count;
    if (!isfinite(channel_fwd_avg) || channel_fwd_avg < 0.0) channel_fwd_avg = 0.0;
    if (!isfinite(channel_rev_avg) || channel_rev_avg < 0.0) channel_rev_avg = 0.0;

    // Decide direction only AFTER averaging the physical channels. This keeps
    // bidirectional operation while avoiding max/min rectification of noise.
    if (channel_fwd_avg >= channel_rev_avg)
    {
      swr_fwd_avg_mw = channel_fwd_avg;
      swr_ref_avg_mw = channel_rev_avg;
    }
    else
    {
      swr_fwd_avg_mw = channel_rev_avg;
      swr_ref_avg_mw = channel_fwd_avg;
    }

    swr_net_avg_mw = swr_fwd_avg_mw - swr_ref_avg_mw;
    if (!isfinite(swr_net_avg_mw) || swr_net_avg_mw < 0.0) swr_net_avg_mw = 0.0;
    swr_block_valid = true;
    ++swr_block_sequence;
  }

  // 1-second average: ten 100 ms blocks, weighted by their actual sample counts.
  avg1s_total_sum -= avg1s_sum_blocks[avg1s_head];
  avg1s_total_count -= avg1s_count_blocks[avg1s_head];

  avg1s_sum_blocks[avg1s_head] = block_power_sum;
  avg1s_count_blocks[avg1s_head] = block_sample_count;

  avg1s_total_sum += block_power_sum;
  avg1s_total_count += block_sample_count;

  avg1s_head++;
  if (avg1s_head >= 10) avg1s_head = 0;

  power_mw_1savg =
    (avg1s_total_count > 0) ? (avg1s_total_sum / (double)avg1s_total_count) : 0.0;

  // PEP history. Only completed blocks enter the rolling hold. On a new
  // transmission, discard the previous transmission's PEP history so an old
  // held maximum can never flash at the beginning of the next transmission.
  const bool pep_block_has_rf =
    isfinite(block_avg) && (block_avg >= ((double)NOISE_FLOOR_MW * 2.0));

  // Preserve event state for the diagnostic snapshot before the normal PEP
  // state machine consumes/clears it below.
  const bool pep_tx_start_event = pep_new_tx_this_block;
  const bool pep_tx_end_event = pep_tx_active && !pep_block_has_rf;

  if (pep_new_tx_this_block)
  {
    pep_head = 0;
    pep_valid = 0;
    power_db_pep = -120.0;
    pep_new_tx_this_block = false;
  }

  // PEP normally stores exactly the completed PK block peak. During startup,
  // however, the fixed 100 ms statistics block that CONTAINS RF START is only a
  // partial RF window: part of that block may still be no-RF.  Never seed PEP
  // from that incomplete START block.  The following block is the first complete
  // 100 ms statistics window after key-up and is allowed to enter PEP history.
  // If that following block still overlaps the 100 ms detector-settling guard,
  // use its completed average rather than its peak, preserving the existing
  // false-key-up-peak protection.
  bool pep_accept_block = !pep_tx_start_event;
  double pep_block_db = block_peak_db;
  if (pep_guard_touched_this_block)
  {
    pep_block_db =
      (block_avg > 1.0e-12) ? (10.0 * log10(block_avg)) : -120.0;
  }

  if (!pep_block_has_rf)
  {
    // Keep writing no-RF blocks so the selected 0.1/1/2 s hold still expires
    // naturally after RF stops. A later transmission starts a fresh history.
    pep_block_db = -120.0;
    pep_accept_block = true;
    pep_tx_active = false;
    pep_tx_start_tick = 0;
  }

  if (pep_accept_block)
  {
    pep_blocks[pep_head] = pep_block_db;
    pep_head++;
    if (pep_head >= PEP_BUFFER) pep_head = 0;
    if (pep_valid < PEP_BUFFER) pep_valid++;
  }
  else
  {
    // Diagnostic IN=0/HOLD=0 on START now explicitly means: this partial block
    // was observed but intentionally excluded from the PEP rolling history.
    pep_block_db = -120.0;
  }

  uint16_t pep_window = R.PEP_period;
  if (pep_window < 1) pep_window = 1;
  if (pep_window > PEP_BUFFER) pep_window = PEP_BUFFER;
  if (pep_window > pep_valid) pep_window = pep_valid;

  double pep_max = -120.0;
  for (uint16_t i = 0; i < pep_window; ++i)
  {
    const uint16_t idx = (uint16_t)((pep_head + PEP_BUFFER - 1U - i) % PEP_BUFFER);
    if (pep_blocks[idx] > pep_max) pep_max = pep_blocks[idx];
  }
  power_db_pep = pep_max;

  // Publish one compact diagnostic snapshot per completed 100 ms block.
  // Conversions are done here from the exact dB values used by PK/PEP so the
  // serial trace can distinguish: raw peak -> stabilized PK -> PEP input ->
  // rolling PEP hold. Values below the internal floor are reported as zero.
  auto debug_mw_from_db = [](double db) -> double
  {
    if (!isfinite(db) || db <= -119.0) return 0.0;
    const double mw = pow(10.0, db / 10.0);
    return (isfinite(mw) && mw > 0.0) ? mw : 0.0;
  };

  pep_debug_snapshot.sequence = ++pep_debug_sequence;
  pep_debug_snapshot.capture_tick = now_tick;
  pep_debug_snapshot.sample_count = block_sample_count;
  pep_debug_snapshot.tx_start_event = pep_tx_start_event;
  pep_debug_snapshot.tx_end_event = pep_tx_end_event;
  pep_debug_snapshot.tx_active = pep_tx_active;
  pep_debug_snapshot.startup_guard = pep_guard_touched_this_block;
  pep_debug_snapshot.trailing_silence = block_ends_with_no_rf;
  pep_debug_snapshot.block_has_rf = pep_block_has_rf;
  pep_debug_snapshot.pep_window = pep_window;
  pep_debug_snapshot.block_avg_mw = block_avg;
  pep_debug_snapshot.raw_peak_mw = debug_mw_from_db(raw_block_peak_db);
  pep_debug_snapshot.pk_mw = debug_mw_from_db(block_peak_db);
  pep_debug_snapshot.pep_input_mw = debug_mw_from_db(pep_block_db);
  pep_debug_snapshot.pep_hold_mw = debug_mw_from_db(power_db_pep);
  pep_debug_snapshot.fwd_avg_mw = swr_fwd_avg_mw;
  pep_debug_snapshot.ref_avg_mw = swr_ref_avg_mw;
  pep_debug_snapshot.net_avg_mw = swr_net_avg_mw;

  // 30-second maximum history.
  long_blocks[long_head] = block_peak_db;
  long_head++;
  if (long_head >= LONG_BUFFER) long_head = 0;
  if (long_valid < LONG_BUFFER) long_valid++;

  double long_max = -120.0;
  for (uint16_t i = 0; i < long_valid; ++i)
  {
    if (long_blocks[i] > long_max) long_max = long_blocks[i];
  }
  power_db_lng = long_max;

  // Start the next true 100 ms block from the TimerOne capture time base.
  // Missing/invalid ADC reads do not stretch the PEP/average time windows.
  block_start_tick = now_tick;
  block_power_sum = 0.0;
  block_fwd_channel_sum = 0.0;
  block_rev_channel_sum = 0.0;
  block_sample_count = 0;
  block_peak_db = -120.0;
  block_tail_no_rf_samples = 0;
  pep_guard_touched_this_block = false;
}
