/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_USB.h"
#include "PSWR_State.h"
#include "PSWR_Measurement.h"
#include "PSWR_Display.h"
#include "PSWR_Print.h"
#include "PSWR_Eeprom.h"
#include "PSWR_CalBanks.h"
#include "PSWR_WiFiConfig.h"
#include "PSWR_WiFiLink.h"
#include "PSWR_CallSign.h"
#include <math.h>

// V3.102 temporary diagnostic mode. Enabled by default only in this trace
// release. Printing is one line per completed 100 ms block, never per sample.
static bool pep_debug_enabled = (PEP_DEBUG_TRACE_DEFAULT_ON != 0);

void usb_pep_debug_service(void)
{
  if (!pep_debug_enabled) return;

  // V3.102: trace every actual Power-screen frame independently from the 100 ms
  // measurement-block trace. usb_pep_debug_service() runs continuously in the
  // normal loop, while the OLED frame is updated only at the poll rate, so this
  // snapshot is consumed before the next Power frame can overwrite it.
  static uint32_t last_display_frame_sequence = 0;
  DisplayPepDebugSnapshot dsp = {};
  if (display_get_pep_debug_snapshot(dsp) &&
      dsp.frame_sequence != last_display_frame_sequence)
  {
    last_display_frame_sequence = dsp.frame_sequence;

    // Keep OFF/idle frames quiet. An armed PEP hold after RF disappears is
    // still useful and therefore remains visible in this trace.
    if (dsp.rf_active || dsp.armed)
    {
      char dline[300];
      snprintf(dline, sizeof(dline),
               "[DSPDBG] F#%lu T=%lums M#%lu RF=%u ARM=%u "
               "HERO=%.3fW TXT=%s PK=%.3fW PKTXT=%s "
               "PEPVAR=%.3fW PEPDB=%.3fdB\r\n",
               (unsigned long)dsp.frame_sequence,
               (unsigned long)dsp.frame_millis,
               (unsigned long)dsp.measurement_sequence,
               dsp.rf_active ? 1U : 0U,
               dsp.armed ? 1U : 0U,
               dsp.dsp_pep_mw / 1000.0,
               dsp.pep_text,
               dsp.dsp_pk_mw / 1000.0,
               dsp.pk_text,
               dsp.global_pep_mw / 1000.0,
               dsp.global_pep_db);
      Serial.print(dline);
    }
  }

  // Existing one-line-per-completed-100-ms-block measurement trace.
  static uint32_t last_sequence = 0;
  PepDebugSnapshot d = {};
  if (!pswr_get_pep_debug_snapshot(d) || d.sequence == last_sequence) return;
  last_sequence = d.sequence;

  // Keep the serial log focused: print RF blocks plus the single END block,
  // but do not stream endless OFF lines while the transmitter is idle.
  if (!d.block_has_rf && !d.tx_end_event && !d.tx_start_event) return;

  const char *event = d.tx_start_event ? "START" :
                      d.tx_end_event   ? "END"   :
                      d.block_has_rf   ? "RF"    : "OFF";

  const uint32_t capture_ms =
    (uint32_t)(((uint64_t)d.capture_tick * (uint64_t)SAMPLE_TIMER) / 1000ULL);

  // Human-friendly watts keep a 100 W carrier easy to inspect. RAW is the
  // pre-stabilization 100 ms peak, PK is the finalized 100 ms peak, IN is the
  // value inserted into PEP history, and HOLD is the rolling PEP maximum.
  char line[320];
  snprintf(line, sizeof(line),
           "[PEPDBG] #%lu T=%lums EV=%s G=%u TAIL=%u N=%lu "
           "AVG=%.3fW RAW=%.3fW PK=%.3fW IN=%.3fW HOLD=%.3fW "
           "F=%.3fW R=%.3fW NET=%.3fW WIN=%u OVR=%lu ERR=%lu Q=%u QMAX=%u\r\n",
           (unsigned long)d.sequence,
           (unsigned long)capture_ms,
           event,
           d.startup_guard ? 1U : 0U,
           d.trailing_silence ? 1U : 0U,
           (unsigned long)d.sample_count,
           d.block_avg_mw / 1000.0,
           d.raw_peak_mw / 1000.0,
           d.pk_mw / 1000.0,
           d.pep_input_mw / 1000.0,
           d.pep_hold_mw / 1000.0,
           d.fwd_avg_mw / 1000.0,
           d.ref_avg_mw / 1000.0,
           d.net_avg_mw / 1000.0,
           (unsigned)d.pep_window,
           (unsigned long)pswr_get_missed_samples(),
           (unsigned long)pswr_get_adc_read_errors(),
           (unsigned)pswr_get_sample_queue_depth(),
           (unsigned)pswr_get_sample_queue_high_water());
  Serial.print(line);
}

//
//-----------------------------------------------------------------------------------------
//                      Send power and SWR measurement data to the Computer
//
//                      Format of transmitted data is:
//                      Incident (real transmitted) power, VSWR
//-----------------------------------------------------------------------------------------
//
//------------------------------------------
// Instantaneous Power (unformatted) and SWR
static void usb_poll_data(void)
{
  //------------------------------------------
  // Power indication, incident power
  if (Reverse)   Serial.print("-");
  Serial.print(power_mw/1000,8);
  Serial.print(F(", "));
  Serial.println(swr,2);
}

//------------------------------------------
// Instantaneous Power (formatted, mW - kW)
static void usb_poll_inst(void)
{
  print_p_mw(power_mw);
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}

//------------------------------------------
// Peak (100ms) Power (formatted, mW - kW)
static void usb_poll_pk(void)
{
  print_p_mw(power_mw_pk);
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}

//------------------------------------------
// PEP (1s) Power (formatted, mW - kW)
static void usb_poll_pep(void)
{
  print_p_mw(power_mw_pep);
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}

//------------------------------------------
// AVG (100ms) Power (formatted, mW - kW)
static void usb_poll_avg(void)
{
  //------------------------------------------
  // Power indication, 100ms average power, formatted, pW-kW
  print_p_mw(power_mw_avg);
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}

//------------------------------------------
// AVG (1s) Power (formatted, mW - kW)
static void usb_poll_1savg(void)
{
  //------------------------------------------
  // Power indication, 1s average power, formatted, pW-kW
  print_p_mw(power_mw_1savg);
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}

static void usb_poll_instdb(void)
{
  //------------------------------------------
  // Power indication, instantaneous power, formatted, dB
  print_dbm(db10_from_mw(power_mw));
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}

static void usb_poll_pkdb(void)
{
  //------------------------------------------
  // Power indication, 100ms peak power, formatted, dB
  print_dbm(db10_from_mw(power_mw_pk));
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}

static void usb_poll_pepdb(void)
{
  //------------------------------------------
  // Power indication, PEP power, formatted, dB
  print_dbm(db10_from_mw(power_mw_pep));
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}

static void usb_poll_avgdb(void)
{
  //------------------------------------------
  // Power indication, 100ms average power, formatted, dB
  print_dbm(db10_from_mw(power_mw_avg));
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}
static void usb_poll_1savgdb(void)
{
  //------------------------------------------
  // Power indication, 1s average power, formatted, dB
  print_dbm(db10_from_mw(power_mw_1savg));
  Serial.print(lcd_buf);
  //------------------------------------------
  // SWR indication
  Serial.print(F(", VSWR"));
  print_swr();
  Serial.println(lcd_buf);
}
//
//-----------------------------------------------------------------------------------------
//                      Send Power and SWR measurement data to the Computer
//
//                      Long and Human Readable Format
//-----------------------------------------------------------------------------------------
//
static void usb_poll_long(void)
{
  
  
// forward power  
    print_p_mw(fwd_power_mw);
    Serial.print(lcd_buf);                   // array 0 in Pascal
    Serial.print(F(","));
  
// reflected power 
    print_p_mw(ref_power_mw);
    Serial.print(lcd_buf);                   // array 1 in Pascal
    Serial.print(F(","));
    

// pep power 
    print_p_mw(power_mw_pep);
    Serial.print(lcd_buf);                    // array 2 in Pascal
    Serial.print(F(","));
 
    print_p_mw(power_mw_avg);                 // array 3 in Pascal
    Serial.print(lcd_buf);
    Serial.print(F(","));
    
    print_dbm(db10_from_mw(power_mw));
    Serial.print(lcd_buf);                    // array 4 in Pascal
    Serial.print(F(","));
   
    print_swr();
    Serial.print(lcd_buf);                    // array 5 in Pascal
    Serial.print(F(","));

    // 100 ms peak power          
    print_p_mw(power_mw_pk);
    Serial.print(lcd_buf);                    // array 6 in Pascal
    Serial.print(F(","));
    
// 100 ms peak power                  
     Serial.print(F(","));

// get swr alarm trigger   
    if (R.SWR_alarm_trig < 40){
      Serial.print(R.SWR_alarm_trig/10.0,1);  // array 8 in Pascal
      Serial.print(F(","));
   }                                                
    if (R.SWR_alarm_trig == 40){
      Serial.print("Off");                    // array 8 in Pascal
      Serial.print(F(","));
    }

// SWR alarm trigger
   if (flag.swr_alarm == true){
     Serial.print( "SWR Alarm triggered");    // array 9 in Pascal
     Serial.print(F(","));
   }
   if (flag.swr_alarm == false){
      Serial.print(F(","));
   }
    Serial.print(F(","));                    // array 10 in Pascal
   
   if (!cpl){
    Serial.print("COUPLER 1");
     Serial.print(F(","));
   }                                         // array 11 in Pascal
    if (cpl){
    Serial.print("COUPLER 2");
     Serial.print(F(","));
   }

     Serial.print(F(","));                   // array 12 in Pascal       
    
     
     // instantaneous power   
    print_p_mw(power_mw);
    Serial.print(lcd_buf);                
    Serial.print(F(","));                     // Instantaneous Power  13 in Pascal
     
     
     double  output_voltage;
     output_voltage = fwd * adc_ref / 4096;
     Serial.print(output_voltage,4);
     Serial.print(F(","));                  // voltage array 14 in Pascal
     
     
     
     

// calibration setting
   
    Serial.println();
   
}

//------------------------------------------
// AD debug report - prints out raw AD values
static void usb_poll_ad_debug(void)
{
  Serial.print(F("AD values: "));
  Serial.print(fwd);
  Serial.print(F(", "));
  Serial.print(rev);
  Serial.print(F(" | missed="));
  Serial.print(pswr_get_missed_samples());
  Serial.print(F(" | read_errors="));
  Serial.println(pswr_get_adc_read_errors());
}
//------------------------------------------
// Prints the selected PSWR report type on a continuous basis, once every 100 milliseconds
void usb_cont_report(void)
{
  // Keep V3.102 diagnostic logs unambiguous. Existing continuous reporting is
  // merely paused while PEP trace is enabled and resumes if trace is disabled.
  if (pep_debug_enabled) return;

  if (R.usb_report_cont)
  {
    if (R.usb_report_type == REPORT_DATA) usb_poll_data();

    else if (R.usb_report_type == REPORT_INST) usb_poll_inst();
    else if (R.usb_report_type == REPORT_PK) usb_poll_pk();
    else if (R.usb_report_type == REPORT_PEP) usb_poll_pep();
    else if (R.usb_report_type == REPORT_AVG) usb_poll_avg();
    else if (R.usb_report_type == REPORT_1SAVG) usb_poll_1savg();

    else if (R.usb_report_type == REPORT_INSTDB) usb_poll_instdb();
    else if (R.usb_report_type == REPORT_PKDB) usb_poll_pkdb();
    else if (R.usb_report_type == REPORT_PEPDB) usb_poll_pepdb();
    else if (R.usb_report_type == REPORT_AVGDB) usb_poll_avgdb();
    else if (R.usb_report_type == REPORT_1SAVGDB) usb_poll_1savgdb();

    else if (R.usb_report_type == REPORT_LONG) usb_poll_long();
    else if (R.usb_report_type == REPORT_AD_DEBUG) usb_poll_ad_debug();
  }
}

//
//-----------------------------------------------------------------------------------------
//      Print a complete list of USB commands upon request
//-----------------------------------------------------------------------------------------
//
static void usb_print_help(void)
{
  Serial.print(F(
    "Available USB commands:\r\n"
    "\r\n"
    "$ppoll             Poll for one single USB serial report, inst power (unformatted).\r\n"
    "$pinst             Poll for one single USB serial report, inst power (human readable).\r\n"
    "$ppk               Poll for one single USB serial report, 100ms peak power (human readable).\r\n"
    "$ppep              Poll for one single USB serial report, pep power (human readable).\r\n"
    "$pavg              Poll for one single USB serial report, 100ms avg power (human readable).\r\n"
    "$p1savg            Poll for one single USB serial report, 1s avg power (human readable).\r\n"
    "$pinstdb           Poll for one single USB serial report, inst power in dB (human readable).\r\n"
    "$ppkdb             Poll for one single USB serial report, 100ms peak power in dB (human readable).\r\n"
    "$ppepdb            Poll for one single USB serial report, pep power in dB (human readable).\r\n"
    "$pavgdb            Poll for one single USB serial report, 100ms avg power in dB (human readable).\r\n"
    "$p1savgdb          Poll for one single USB serial report, 1s avg power in dB (human readable).\r\n"
    "$plong             Poll for one single USB serial report, actual power (inst, pep and avg)\r\n"
    "                   as well as fwd power, reflected power and SWR (long form).\r\n"
    "\r\n"
    "$pcont             USB serial reporting in a continuous mode, 10 times per second.\r\n"
    "                   Enter a report command after $pcont to switch back to single-shot mode.\r\n"
    "\r\n"
    "$sleepmsg=abcdefg  Screensaver text, up to 20 characters.\r\n"));

  Serial.print(F(
    "$sleeppwrset x     Power above this level turns the display into meter mode.\r\n"
    "                   x = 0, 0.001, 0.01, 0.1, 1 or 10 mW.\r\n"
    "$sleeppwrget       Return current value.\r\n"));

  Serial.print(F(
    "\r\n"
    "$alarmset x        x = 1.5 to 3.9; 4 disables the SWR alarm.\r\n"
    "$alarmget          Return current value.\r\n"
    "$alarmreset        Clear an active alarm.\r\n"
    "$alarmpowerset x   x = 1, 10, 100, 1000 or 10000 mW.\r\n"
    "$alarmpowerget     Return current value.\r\n"
    "\r\n"
    "$pepperiodset x    x = 0.1, 1 or 2 seconds.\r\n"
    "$pepperiodget      Return current value.\r\n"
    "\r\n"));

  Serial.print(F(
    "$calset cal1 AD1-1 AD2-1 cal2 AD1-2 AD2-2\r\n"
    "                   Store two AD8307 calibration points.\r\n"
    "$calget            Retrieve calibration values for active band/coupler.\r\n"
    "                   cal1/cal2 are dBm x10; AD values are detector volts.\r\n"
    "$bandget           Return active band (HF, 6M, 2M or 70cm).\r\n"
    "$bandset BAND      Set band for the active coupler only.\r\n"
    "\r\n"
    "$yourcall [CALL]    Set or retrieve startup callsign/name (1..30 chars).\r\n"
    "                   Example: $yourcall PD0LEW\r\n"
    "$wifissid [SSID]    Set or retrieve WiFi SSID (1..32 chars).\r\n"
    "$wifipass [PASS]    Set WiFi password (0..63 printable chars).\r\n"
    "$wifipass           Reports only whether a password is stored.\r\n"));

  Serial.print(F(
    "\r\n"
    "$scaleget          Retrieve user-definable scale ranges.\r\n"
    "$scaleset a b c    Store three scale ranges. Range 1 is 1..99; ranges 2/3\r\n"
    "                   remain within the same decade and are ordered automatically.\r\n"
    "\r\n"
    "$addebug           Raw ADC values plus missed-sample/read-error diagnostics.\r\n"
    "$pepdebugon        Enable V3.102 PEP + per-frame display trace (default in this test build).\r\n"
    "$pepdebugoff       Disable V3.102 PEP/display trace.\r\n"
    "$pepdebug          Report PEP trace ON/OFF state.\r\n"
    "$version           Report firmware version and date.\r\n"
    "$help              Display this help.\r\n"
    "\r\n"));
}

//
//-----------------------------------------------------------------------------------------
//      Parse and act upon an incoming USB command; USB port enumerates as a COM port
//-----------------------------------------------------------------------------------------
//
char incoming_command_string[50];                             // Input from USB Serial
static void usb_parse_incoming(void)
{
  char *pEnd;
  double inp_double;

  if (!strcasecmp("ppoll",incoming_command_string))           // Poll, if Continuous mode, then switch into Polled Mode
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_DATA)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_DATA;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);      
    }
    usb_poll_data();                                          // Send data over USB
  }
  else if (!strcasecmp("pinst",incoming_command_string))      // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed 
    if ((R.usb_report_type != REPORT_INST)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_INST;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);        
    }
    usb_poll_inst();
  }
  else if (!strcasecmp("ppk",incoming_command_string))        // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_PK)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_PK;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);    
    }
    usb_poll_pk();
  }
  else if (!strcasecmp("ppep",incoming_command_string))       // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_PEP)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_PEP;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R); 
    }
    usb_poll_pep();
  }
  else if (!strcasecmp("pavg",incoming_command_string))       // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_AVG)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_AVG;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R); 
    }
    usb_poll_avg();
  }
  else if (!strcasecmp("p1savg",incoming_command_string))     // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_1SAVG)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_1SAVG;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R); 
    }
    usb_poll_1savg();
  }
  else if (!strcasecmp("pinstdb",incoming_command_string))    // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_INSTDB)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_INSTDB;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
    usb_poll_instdb();
  }
  else if (!strcasecmp("ppkdb",incoming_command_string))      // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_PKDB)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_PKDB;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
    usb_poll_pkdb();
  }
  else if (!strcasecmp("ppepdb",incoming_command_string))     // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_PEPDB)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_PEPDB;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
    usb_poll_pepdb();
  }
  else if (!strcasecmp("pavgdb",incoming_command_string))     // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_AVGDB)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_AVGDB;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
    usb_poll_avgdb();
  }
  else if (!strcasecmp("p1savgdb",incoming_command_string))   // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_1SAVGDB)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_1SAVGDB;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
    usb_poll_1savgdb();
  }
  else if (!strcasecmp("plong",incoming_command_string))      // Poll for one single Human Readable report
  {
    // Disable continuous USB report mode ($pcont) if previously set
    // and Write report mode to EEPROM, if changed
    if ((R.usb_report_type != REPORT_LONG)||(R.usb_report_cont))
    {
      R.usb_report_type = REPORT_LONG;
      R.usb_report_cont = false;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
    usb_poll_long();
  }
  else if (!strcasecmp("addebug",incoming_command_string))    // Poll for one single Human Readable report
  {
     // Disable continuous USB report mode ($pcont) if previously set
     if (R.usb_report_cont)
    {
      R.usb_report_cont = false;
    }
    R.usb_report_type = REPORT_AD_DEBUG;
    usb_poll_ad_debug();
  }
  else if (!strcasecmp("pepdebugon",incoming_command_string))
  {
    pep_debug_enabled = true;
    Serial.println(F("PEP debug trace ON"));
  }
  else if (!strcasecmp("pepdebugoff",incoming_command_string))
  {
    pep_debug_enabled = false;
    Serial.println(F("PEP debug trace OFF"));
  }
  else if (!strcasecmp("pepdebug",incoming_command_string))
  {
    Serial.print(F("PEP debug trace: "));
    Serial.println(pep_debug_enabled ? F("ON") : F("OFF"));
  }
  else if (!strcasecmp("pcont",incoming_command_string))      // Switch into Continuous Mode
  {
    // Enable continuous USB report mode ($pcont), and write to EEPROM, if previously disabled
    if (!R.usb_report_cont)
    {
      R.usb_report_cont = true;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
  }

  else if (!strcasecmp("calget",incoming_command_string))     // Retrieve calibration values
  {
    Serial.print(F("AD8307 Cal "));
    Serial.print(calbanks_active_band_name());
    Serial.print(F(" C"));
    Serial.print(calbanks_active_number());
    Serial.print(F(": "));
    snprintf(lcd_buf, sizeof(lcd_buf),"%4d  %01.03f  %01.03f  %4d  %01.03f  %01.03f", 
        R.cal_AD[0].db10m,R.cal_AD[0].Fwd,R.cal_AD[0].Rev,
        R.cal_AD[1].db10m,R.cal_AD[1].Fwd,R.cal_AD[1].Rev);
    Serial.println(lcd_buf);
  }
  else if (!strncasecmp("calset",incoming_command_string,6))  // Write new calibration values
  {
    const long db0_raw = strtol(incoming_command_string + 6, &pEnd, 10);
    const double f0 = strtod(pEnd, &pEnd);
    const double r0 = strtod(pEnd, &pEnd);
    const long db1_raw = strtol(pEnd, &pEnd, 10);
    const double f1 = strtod(pEnd, &pEnd);
    const double r1 = strtod(pEnd, &pEnd);

    const bool valid =
      (db0_raw >= INT16_MIN && db0_raw <= INT16_MAX) &&
      (db1_raw >= INT16_MIN && db1_raw <= INT16_MAX) &&
      (db0_raw != db1_raw) &&
      isfinite(f0) && isfinite(r0) && isfinite(f1) && isfinite(r1) &&
      (f0 >= 0.0 && f0 <= 5.0) && (r0 >= 0.0 && r0 <= 5.0) &&
      (f1 >= 0.0 && f1 <= 5.0) && (r1 >= 0.0 && r1 <= 5.0) &&
      (fabs(f1 - f0) > 0.001) && (fabs(r1 - r0) > 0.001);

    if (valid)
    {
      R.cal_AD[0].db10m = (int16_t)db0_raw;
      R.cal_AD[0].Fwd = f0;
      R.cal_AD[0].Rev = r0;
      R.cal_AD[1].db10m = (int16_t)db1_raw;
      R.cal_AD[1].Fwd = f1;
      R.cal_AD[1].Rev = r1;
      calbanks_commit_active();
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      Serial.print(F("Calibration stored for "));
      Serial.print(calbanks_active_band_name());
      Serial.print(F(" C"));
      Serial.println(calbanks_active_number());
    }
    else
    {
      Serial.println(F("Invalid calibration values"));
    }
  }

  else if (!strcasecmp("bandget", incoming_command_string))
  {
    Serial.print(F("Band: "));
    Serial.print(calbanks_active_band_name());
    Serial.print(F("  Coupler: C"));
    Serial.println(calbanks_active_number());
  }
  else if (!strncasecmp("bandset", incoming_command_string, 7))
  {
    const char *arg = incoming_command_string + 7;
    while (*arg == ' ' || *arg == '\t') ++arg;

    size_t bandLen = strlen(arg);
    while (bandLen > 0 && (arg[bandLen - 1] == ' ' || arg[bandLen - 1] == '\t'))
      --bandLen;

    int band = -1;
    if (bandLen == 2 && !strncasecmp(arg, "HF", 2)) band = CALBAND_HF;
    else if (bandLen == 2 && !strncasecmp(arg, "6M", 2)) band = CALBAND_6M;
    else if (bandLen == 2 && !strncasecmp(arg, "2M", 2)) band = CALBAND_2M;
    else if (bandLen == 4 && !strncasecmp(arg, "70CM", 4)) band = CALBAND_70CM;

    if (band >= 0 && calbanks_select_band((uint8_t)band))
    {
      Serial.print(F("Band selected: "));
      Serial.print(calbanks_active_band_name());
      Serial.print(F(" C"));
      Serial.println(calbanks_active_number());
    }
    else
    {
      Serial.println(F("Invalid band. Use: $bandset HF|6M|2M|70cm"));
    }
  }

  else if (!strncasecmp("wifissid", incoming_command_string, 8))
  {
    char *arg = incoming_command_string + 8;
    while (*arg == ' ' || *arg == '\t') ++arg;
    if (*arg == '\0')
    {
      Serial.print(F("WiFi SSID: "));
      Serial.println(wifi_ssid_get());
    }
    else if (wifi_ssid_set(arg))
    {
      wifi_link_credentials_changed();
      Serial.println(F("WiFi SSID stored"));
    }
    else Serial.println(F("Invalid SSID. Use 1..32 printable characters."));
  }
  else if (!strncasecmp("wifipass", incoming_command_string, 8))
  {
    char *arg = incoming_command_string + 8;
    while (*arg == ' ' || *arg == '\t') ++arg;
    if (*arg == '\0')
    {
      Serial.println(strlen(wifi_password_get()) ? F("WiFi password: STORED")
                                                : F("WiFi password: EMPTY"));
    }
    else if (wifi_password_set(arg))
    {
      wifi_link_credentials_changed();
      Serial.println(F("WiFi password stored"));
    }
    else Serial.println(F("Invalid password. Use 0..63 printable characters."));
  }
  else if (!strncasecmp("yourcall",incoming_command_string,8))
  {
    const char *newCall = incoming_command_string + 8;
    while (*newCall == ' ' || *newCall == '\t') ++newCall;

    // With no argument, simply report the currently stored callsign.
    if (*newCall == '\0')
    {
      Serial.print(F("Your Call: "));
      Serial.println(callsign_get());
    }
    else if (callsign_set(newCall))
    {
      Serial.print(F("Your Call stored: "));
      Serial.println(callsign_get());
    }
    else
    {
      Serial.println(F("Invalid call. Use: $yourcall CALL  (1..30 printable characters)"));
    }
  }

  else if (!strcasecmp("scaleget",incoming_command_string))   // Retrieve scale limits
  {
    Serial.print(F("Scale: "));
    snprintf(lcd_buf, sizeof(lcd_buf),"%4u,%4u,%4u",
        R.ScaleRange[0],R.ScaleRange[1],R.ScaleRange[2]);
    Serial.println(lcd_buf);
  }
  else if (!strncasecmp("scaleset",incoming_command_string,8))// Write new scale limits
  {
    long v1 = strtol(incoming_command_string + 8, &pEnd, 10);
    long v2 = strtol(pEnd, &pEnd, 10);
    long v3 = strtol(pEnd, &pEnd, 10);

    if (v1 >= 1 && v1 <= 99 && v2 >= 1 && v2 <= 255 && v3 >= 1 && v3 <= 255)
    {
      uint16_t r1 = (uint16_t)v1;
      uint16_t r2 = (uint16_t)v2;
      uint16_t r3 = (uint16_t)v3;

      if (r2 >= r1 * 10U) r2 = (uint16_t)(r1 * 10U - 1U);
      if (r3 >= r1 * 10U) r3 = (uint16_t)(r1 * 10U - 1U);
      if (r2 < r1) r2 = r1;
      if (r3 < r1) r3 = r1;
      if (r2 > r3) r3 = r2;

      R.ScaleRange[0] = (uint8_t)r1;
      R.ScaleRange[1] = (uint8_t)r2;
      R.ScaleRange[2] = (uint8_t)r3;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      Serial.println(F("Scale ranges stored"));
    }
    else
    {
      Serial.println(F("Invalid scale ranges"));
    }
  }

  else if (!strncasecmp("sleepmsg=",incoming_command_string,9))// A new "sleep message" string was received
  {
    // Copy up to 20 characters and always terminate the stored string.
    strncpy(R.idle_disp, incoming_command_string + 9, 20);
    R.idle_disp[20] = '\0';
    // and store in EEPROM
    EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
  }
  //
  // The below are a bit redundant, as they are fully manageable by the rotary encoder:
  //
  //    $sleeppwrset x    Power below the level defined here will put display into screensaver mode.
  //                      x = 0.001, 0.01, 0.1, 1 or 10 mW (milliwatts)
  //    $sleeppwrget      Return current value  
  else if (!strncasecmp("sleeppwrset",incoming_command_string,11))
  {
    // Write value if valid
    inp_double = strtod(incoming_command_string+11,&pEnd);
    if ((inp_double==0)||(inp_double==0.001)||(inp_double==0.01)||(inp_double==0.1)||(inp_double==1)||(inp_double==10))
    {
      R.idle_disp_thresh = (float) inp_double;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
  }
  else if (!strcasecmp("sleeppwrget",incoming_command_string))
  {
    Serial.print(F("IdleDisplayThreshold (mW): "));
    Serial.println(R.idle_disp_thresh,3);
  }

  //    $alarmset x       x = 1.5 to 3.9. 4 will inactivate SWR Alarm function
  //    $alarmget         Return current value
  else if (!strncasecmp("alarmset",incoming_command_string,8))
  {
    // Write value if valid
    inp_double = strtod(incoming_command_string+8,&pEnd);
    if (isfinite(inp_double))
    {
      const long alarm_tenths = lround(inp_double * 10.0);
      if (alarm_tenths > 14 && alarm_tenths <= 40)
      {
        R.SWR_alarm_trig = (uint8_t)alarm_tenths;
        EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      }
    }
  }
  else if (!strcasecmp("alarmget",incoming_command_string))
  {
    Serial.print(F("SWR_Alarm_Trigger: "));
    Serial.println(R.SWR_alarm_trig/10.0,1);
  }
  else if (!strcasecmp("alarmreset",incoming_command_string))
  {
    optionalDigitalWrite(R_Led, LOW);                         // Clear optional SWR Alarm LED
    flag.swr_alarm = false;                                   // Clear SWR Alarm Flag
    swr_alarm_acknowledged = true;                            // Do not re-trigger until condition clears
    swrBuzzerOff();
    swr_buzzer_active = false;
    swr_buzzer_started_ms = 0;
    digitalWrite(CouplerLed, LOW);               // LED is alarm-only in normal operation
    Serial.println(F("SWR_Alarm_Reset"));
  }

  //    $alarmpowerset x    x = 1, 10, 100, 1000 or 10000 mW (milliwatts)
  //    $alarmpowerget      Return current value
  else if (!strncasecmp("alarmpowerset",incoming_command_string,13))
  {
    // Parse into a wide signed type first, then narrow only after validation.
    const long alarm_power = strtol(incoming_command_string+13,&pEnd,10);
    if ((alarm_power==1)||(alarm_power==10)||(alarm_power==100)||(alarm_power==1000)||(alarm_power==10000))
    {
      R.SWR_alarm_pwr_thresh = (uint16_t)alarm_power;
      EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
    }
  }
  else if (!strcasecmp("alarmpowerget",incoming_command_string))
  {
    Serial.print(F("SWR_Alarm_Power_Threshold (mW): "));
    Serial.println(R.SWR_alarm_pwr_thresh);
  }

  //    $pepperiodset x    x = 0.1, 1 or 2 seconds.  PEP sampling period
  //    $pepperiodget      Return current value
  else if (!strncasecmp("pepperiodset",incoming_command_string,12))
  {
    // Write value if valid
    inp_double = strtod(incoming_command_string+12,&pEnd);
    if (isfinite(inp_double))
    {
      const long pep_blocks = lround(inp_double * 10.0);
      if (pep_blocks == 1 || pep_blocks == 10 || pep_blocks == 20)
      {
        R.PEP_period = (uint16_t)pep_blocks;
        EEPROM_writeAnything(EEPROM_SETTINGS_ADDR, R);
      }
    }
  }
  else if (!strcasecmp("pepperiodget",incoming_command_string))
  {
    Serial.print(F("PEP_period (seconds): "));
    Serial.println(R.PEP_period / 10.0, 1);
  }

  else if (!strcasecmp("version",incoming_command_string))    // Poll for one single Human Readable report
  {
    Serial.println(F("JH2KW-M - Power and SWR Meter"));
    Serial.println(F("Copyright (c) 2016-2026 J.G. Holstein, PD0LEW"));
    Serial.println(F("Original Power/SWR Meter project: Loftur E. Jonasson, TF3LJ / VE2AO"));
    Serial.println(F("Additional project credit: Paul Davis, K9MR"));
    Serial.println(F("License: GNU GPL v3 or later"));
    Serial.print(F("Version "));
    Serial.print(VERSION);
    Serial.print(F(" "));
    Serial.println(DATE);
    Serial.println();
  }

  else if (!strcasecmp("memorywipe",incoming_command_string)) // Full reset of Memory
  {
    Serial.println(F("$memorywipe"));
    // Force a full EEPROM update upon reboot by storing 0xff in the first address
    EEPROM.write(EEPROM_COLDSTART_ADDR, 0xff);
    SOFT_RESET();
  }
  else if (!strcasecmp("softreset",incoming_command_string))  // Reset Microcontroller
  {
    Serial.println(F("$softreset"));                          // Probably not very useful
    SOFT_RESET();
  }
  
  else if (!strcasecmp("help",incoming_command_string))       // Print out USB command help
  {
    usb_print_help();
  }
} 
  

//
//-----------------------------------------------------------------------------------------
//      Monitor USB Serial port for an incoming USB command
//-----------------------------------------------------------------------------------------
//
void usb_read_serial(void)
{
  static uint8_t length = 0;
  static bool incoming = false;

  // Bound serial work per loop so ADC service remains responsive during bursts.
  uint8_t budget = 32;
  while (Serial.available() > 0 && budget--)
  {
    const int received = Serial.read();
    if (received < 0) return;

    const char ch = (char)received;

    // '$' always starts/restarts a command, which also recovers cleanly after bad input.
    if (ch == '$')
    {
      incoming = true;
      length = 0;
      continue;
    }

    if (!incoming)
      continue;

    if (ch == '\r' || ch == '\n' || ch == ';')
    {
      incoming_command_string[length] = '\0';
      if (length > 0)
        usb_parse_incoming();

      incoming = false;
      length = 0;
      continue;
    }

    if (length >= sizeof(incoming_command_string) - 1)
    {
      // Discard an overlong command safely and wait for the next '$'.
      incoming = false;
      length = 0;
      continue;
    }

    incoming_command_string[length++] = ch;
  }
}
