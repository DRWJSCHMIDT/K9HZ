#include "AppSettings.cpp"
#include <cassert>
#include <cmath>
#include <cstdio>
int main(){
  Preferences::data.clear();
  ready=false;
  AppSettings::begin();
  assert(AppSettings::adaptiveLearning());
  assert(AppSettings::learnedProfileQuality()==0);
  AppSettings::setLearnedProfile(1.93f,2.07f,78);
  AppSettings::setAdaptiveLearning(false);
  ready=false; adaptiveLearningValue=true; learnedMarkRatioValue=learnedGapRatioValue=0; learnedQualityValue=0;
  AppSettings::begin();
  assert(!AppSettings::adaptiveLearning());
  assert(std::fabs(AppSettings::learnedMarkThresholdRatio()-1.93f)<0.001f);
  assert(std::fabs(AppSettings::learnedLetterGapRatio()-2.07f)<0.001f);
  assert(AppSettings::learnedProfileQuality()==78);
  AppSettings::clearLearnedProfile();
  assert(AppSettings::learnedProfileQuality()==0);
  std::puts("PASS adaptive Preferences persistence/reset");
}
