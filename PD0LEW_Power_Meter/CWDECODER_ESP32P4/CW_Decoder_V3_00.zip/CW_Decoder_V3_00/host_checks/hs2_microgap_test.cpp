#include "CWDecoder.cpp"
#include <cassert>
#include <cstring>
#include <cstdio>

static void train(float dot) {
  weakActive = false;
  activeCwType = 1;
  fadeAssistActive = true;
  cycleTimingReady = true;
  dotMs = dot;
  displayDotMs = dot;
  guentherTiming.reset(dot);
  for (int i = 0; i < 60; ++i)
    assert(guentherTiming.observeMark((i & 1) ? 3.0f * dot : dot, 95.0f));
}
static void load(const float *marks, const float *gaps, size_t n) {
  symbolLength = guentherMarkCount = n;
  for (size_t i = 0; i < n; ++i) {
    guentherMarks[i] = marks[i];
    guentherGaps[i] = gaps[i];
    guentherMarkConfidence[i] = 100.0f;
    symbolBuffer[i] = guentherTiming.classifyDashForDecode(marks[i]) ? '-' : '.';
  }
  symbolBuffer[n] = 0;
}
int main() {
  train(24.0f);
  // Real 50 WPM W from Benchmark V1: dot followed by a dash fractured at
  // 7.42 ms, then its final dash. All segments were high confidence.
  const float splitWMarks[] = {25.0f, 33.5f, 32.75f, 75.67f};
  const float splitWGaps[] = {24.67f, 7.41667f, 24.08f, 0.0f};
  load(splitWMarks, splitWGaps, 4);
  assert(std::strcmp(symbolBuffer, "...-") == 0);
  char chosen[16] = {};
  assert(chooseGuentherHypothesis(chosen, sizeof(chosen)));
  assert(std::strcmp(chosen, ".--") == 0);

  // Intentionally keyed dots, even when one normal gap is somewhat short,
  // must retain V; this is the original V2.28 receiver failure protection.
  train(24.0f);
  const float trueVMarks[] = {24,24,24,72};
  const float trueVGaps[] = {10,24,24,0};
  load(trueVMarks, trueVGaps, 4);
  assert(!chooseGuentherHypothesis(chosen, sizeof(chosen)));
  assert(std::strcmp(chosen,"...-")==0);
  std::puts("PASS: HS2 split W restored, clean V preserved");
}
