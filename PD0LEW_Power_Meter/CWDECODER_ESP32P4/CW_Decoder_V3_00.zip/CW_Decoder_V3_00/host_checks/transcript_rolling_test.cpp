#include <cassert>
#include <cstring>
#include <iostream>
#include "../src/Transcript.h"

static int widthOne(char) { return 1; }

static void appendText(Transcript &t, const char *s) {
  while (*s) t.append(*s++, widthOne, 1208);
}

int main() {
  Transcript t;

  appendText(t, "L1");
  assert(std::strcmp(t.current(), "\n\n\n\n\n\n\n\nL1") == 0);

  for (int i = 2; i <= 9; ++i) {
    t.append('\n', widthOne, 1208);
    char line[8];
    std::snprintf(line, sizeof(line), "L%d", i);
    appendText(t, line);
  }
  assert(std::strcmp(t.current(), "L1\nL2\nL3\nL4\nL5\nL6\nL7\nL8\nL9") == 0);

  t.append('\n', widthOne, 1208);
  appendText(t, "L10");
  assert(std::strcmp(t.current(), "L2\nL3\nL4\nL5\nL6\nL7\nL8\nL9\nL10") == 0);

  t.append('\n', widthOne, 1208); appendText(t, "L11");
  t.append('\n', widthOne, 1208); appendText(t, "L12");
  assert(std::strcmp(t.current(), "L4\nL5\nL6\nL7\nL8\nL9\nL10\nL11\nL12") == 0);

  t.previous();
  assert(!t.live());
  assert(std::strcmp(t.current(), "L1\nL2\nL3\nL4\nL5\nL6\nL7\nL8\nL9") == 0);

  t.goLive();
  assert(t.live());
  assert(std::strcmp(t.current(), "L4\nL5\nL6\nL7\nL8\nL9\nL10\nL11\nL12") == 0);

  std::cout << "PASS: bottom-up rolling transcript\n";
  return 0;
}
