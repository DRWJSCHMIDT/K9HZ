#include "AppSettings.cpp"
#include <cassert>
#include <cstdio>

int main() {
  Preferences::data.clear();
  ready = false;
  autoToneResponseMsValue = 500;
  AppSettings::begin();
  assert(AppSettings::autoToneResponseMs() == 500);

  AppSettings::setAutoToneResponseMs(1000);
  assert(AppSettings::autoToneResponseMs() == 1000);
  assert(Preferences::data["atrespm"] == 1000);

  ready = false;
  autoToneResponseMsValue = 500;
  AppSettings::begin();
  assert(AppSettings::autoToneResponseMs() == 1000);

  AppSettings::setAutoToneResponseMs(2000);
  assert(AppSettings::autoToneResponseMs() == 2000);

  AppSettings::setAutoToneResponseMs(150);
  assert(AppSettings::autoToneResponseMs() == 150);

  // Invalid values safely fall back to the V1.93 normal default.
  AppSettings::setAutoToneResponseMs(777);
  assert(AppSettings::autoToneResponseMs() == 500);

  std::puts("PASS: AUTO TONE response default/cycle persistence");
}
