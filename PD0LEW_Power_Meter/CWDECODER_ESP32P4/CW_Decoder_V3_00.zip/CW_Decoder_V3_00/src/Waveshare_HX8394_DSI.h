// Copyright J.G. Holstein 2026
// ESP32-P4-WiFi6-Touch-LCD-5
#pragma once
#include <Arduino.h>
#include <Arduino_GFX_Library.h> // GFX Library for Arduino 1.6.5 

#include <Wire.h>

class Waveshare_HX8394_DSI
{
public:
    bool begin(uint8_t rotation = 3);
    void setBrightness(uint8_t value);
    Arduino_DSI_Display *gfx();

private:
    Arduino_ESP32DSIPanel *_dsipanel = nullptr;
    Arduino_DSI_Display *_gfx = nullptr;
};
