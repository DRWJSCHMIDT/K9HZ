/*
 * JH2KW-M V3.102 - PlatformIO entry point
 *
 * Functional equivalent of JH2KW-M_V3_102.ino.
 * The application logic remains in PSWR_App.cpp/.h.
 */
#include <Arduino.h>
#include "PSWR_App.h"

void setup()
{
  pswrSetup();
}

void loop()
{
  pswrLoop();
}
