/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_AD7991_HS_H
#define PSWR_AD7991_HS_H

#include <Arduino.h>

struct Ad7991CapturedSample
{
  uint16_t fwd;
  uint16_t rev;
  uint32_t tick;
};

// Discover/configure the AD7991 using Wire at normal speed, then configure
// Teensy 4.x LPI2C1 for the LJ-2000M High-Speed master-code read sequence.
// Return 2 for address 0x29, 1 for address 0x28, 0 if not found.
uint8_t ad7991_hs_begin(void);

// Called directly from the 50 us TimerOne ISR. Performs only the bounded 4-byte
// AD7991 Hs-mode read and stores the sample in the ISR capture ring buffer.
void ad7991_hs_capture_isr(void);

// Pop one captured sample in normal loop context.
bool ad7991_hs_pop(Ad7991CapturedSample &sample);

uint32_t ad7991_hs_read_errors(void);
uint32_t ad7991_hs_overruns(void);
uint16_t ad7991_hs_queue_depth(void);
uint16_t ad7991_hs_queue_high_water(void);

#endif
