

#pragma once

// Returns true if connected to stored WiFi credentials within 15 s.
bool wifiConnect();

// Starts captive-portal AP and blocks until credentials are saved (then reboots).
// Safe to call at any time — suspends the SSE task before launching the portal.
void startCaptivePortal();
