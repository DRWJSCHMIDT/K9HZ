#include <Arduino.h>
#include "SerialOutput.h"
#include <lvgl.h>
#include "lv_conf.h"
#include "DisplaySetup.h"
#include "DisplayPower.h"
#include "AudioEngine.h"
#include "CWUI.h"
#include "CWDecoder.h"
#include "AppSettings.h"
#include "StartupScreen.h"
#include "FirmwareVersion.h"

void setup() {
  Serial.begin(115200);
  delay(500);

  CW_DIAG_PRINTLN();
  CW_DIAG_PRINTLN("CW Decoder ESP32-P4 + PJRC Audio RevB " CW_FIRMWARE_VERSION " STARTUP");
  CW_DIAG_PRINTLN("Audio baseline: LIVE selectable 48 / 96 kHz, no reboot (96 kHz default)");
  CW_DIAG_PRINTLN("V2.10+: setup hard-crash protection - target-specific LVGL heap + touch release guard");
  CW_DIAG_PRINTLN("V2.26: LVGL 9.6 + clean serial decoded-text output + robust hand-sent decoder");
  CW_DIAG_PRINTLN("Display baseline: confirmed working PlatformIO V2.1");
#if defined(P4_CHIP_PRE_V3)
  CW_DIAG_PRINTLN("ESP32-P4 profile: BEFORE v3.00 / 360 MHz");
#elif defined(P4_CHIP_POST_V3)
  CW_DIAG_PRINTLN("ESP32-P4 profile: v3.00 OR NEWER / 400 MHz");
#else
  CW_DIAG_PRINTLN("ESP32-P4 profile: UNKNOWN");
#endif

  // Keep the proven DSI/LVGL/touch startup fully ahead of audio/DSP.
  if (!DisplaySetup::begin()) {
    CW_DIAG_PRINTLN("Display initialization failed");
    while (true) delay(1000);
  }

  DisplaySetup::enableTouchDebug(false);

  // Load only the new SAFE SETUP settings. The underlying V1.6 UI/touch
  // architecture remains unchanged.
  AppSettings::begin();
  // IMPORTANT: brightness/screensaver are managed outside the GT911/LVGL callback.
  // The touch callback remains the proven V1.6 behavior.
  DisplayPower::begin(AppSettings::brightnessPercent(), AppSettings::screensaverMinutes());
  CWDecoder::setFilterBandwidthHz(AppSettings::filterBandwidthHz());

  CWDecoder::setFadingAssist(true); // V2.29: FADING ASSIST always ON.
  CWDecoder::setCwType(AppSettings::cwType());
  CWDecoder::setFarnsworthSpacing(AppSettings::farnsworthSpacing());
  CWDecoder::setWeakSignal(AppSettings::weakSignal());
  CWDecoder::setAdaptiveLearning(AppSettings::adaptiveLearning());
  CWDecoder::setAdaptiveLearningProfile(AppSettings::learnedMarkThresholdRatio(),
                                        AppSettings::learnedLetterGapRatio(),
                                        AppSettings::learnedProfileQuality());
  CWDecoder::setManualTone(AppSettings::manualToneHz());
  CWDecoder::setAutoToneResponseMs(AppSettings::autoToneResponseMs());
  if (AppSettings::autoTone()) CWDecoder::setAutoTone(true);
  CWDecoder::setInputLevelPercent(AppSettings::decoderInputLevelPercent());
  AudioEngine::setMonitorFiltered(AppSettings::monitorFiltered());
  StartupScreen::show();
  CWUI::create();

  // Audio and CW DSP are started only after the display is operational.
  if (!AudioEngine::begin(AppSettings::audioSampleRateHz())) {
    CW_DIAG_PRINTLN("Audio did not start. CW UI remains active for diagnosis.");
  } else {
    AudioEngine::setHeadphoneVolumePercent(AppSettings::headphoneVolumePercent());
    // Maximum SGTL5000 ADC headroom: -6 dB analog range.
    AudioEngine::setInputGainIndex(0);
  }
  CWDecoder::setFilterBandwidthHz(AppSettings::filterBandwidthHz());
  CWDecoder::setInputLevelPercent(AppSettings::decoderInputLevelPercent());

  CW_DIAG_PRINTF("Settings: brightness=%u%% saver=%u min filter=%u Hz textcolor=%u hpvol=%u%% decoderInput=%u%% ADCgain=-6.0dB sampleRate=%luHz learning=%s profileQ=%u autoToneResponse=%ums\n",
                static_cast<unsigned>(AppSettings::brightnessPercent()),
                static_cast<unsigned>(AppSettings::screensaverMinutes()),
                static_cast<unsigned>(AppSettings::filterBandwidthHz()),
                static_cast<unsigned>(AppSettings::textColorIndex()),
                static_cast<unsigned>(AppSettings::headphoneVolumePercent()),
                static_cast<unsigned>(AppSettings::decoderInputLevelPercent()),
                static_cast<unsigned long>(AppSettings::audioSampleRateHz()),
                AppSettings::adaptiveLearning() ? "ACTIVE" : "FROZEN",
                static_cast<unsigned>(AppSettings::learnedProfileQuality()),
                static_cast<unsigned>(AppSettings::autoToneResponseMs()));
  CW_DIAG_PRINTLN("CW Decoder application ready");
}

void loop() {
  DisplaySetup::update();
  DisplayPower::update();
  CWUI::update();
}
