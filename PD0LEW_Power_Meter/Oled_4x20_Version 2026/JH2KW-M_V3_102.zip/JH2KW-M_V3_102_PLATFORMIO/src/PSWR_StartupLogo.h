/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_STARTUP_LOGO_H
#define PSWR_STARTUP_LOGO_H

#include <Arduino.h>

constexpr uint8_t STARTUP_LOGO_COUNT = 9;
constexpr uint8_t STARTUP_LOGO_DEFAULT = 5; // Logo 6: RF waveform, zero based.

void startup_logo_begin(bool forceReset);
bool startup_logo_set(uint8_t index);
uint8_t startup_logo_get(void);
const char *startup_logo_name(uint8_t index);

// Draw one of the nine startup emblems in the same 52 x 44 visual area used by
// the real splash screen. The selector and splash call this same function, so
// the preview is exactly the stored startup symbol.
void startup_logo_draw(int16_t x, int16_t y, uint8_t index,
                       uint8_t bright, uint8_t medium, uint8_t dim);

#endif // PSWR_STARTUP_LOGO_H
