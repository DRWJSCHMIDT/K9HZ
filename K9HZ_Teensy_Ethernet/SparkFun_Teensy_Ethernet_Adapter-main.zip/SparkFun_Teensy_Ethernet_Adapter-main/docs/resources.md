For more information about the SparkFun Teensy Ethernet Adapter, check out the following resources:

* [Schematic](./assets/board_files/Teensy_Ethernet.pdf)
* [KiCad Files](./assets/board_files/Teensy_Ethernet.zip)
* [Board Dimensions](./assets/board_files/Teensy_Ethernet-Dimensions.jpg)
* [TeensyDuino Documentation](https://www.pjrc.com/teensy/teensyduino.html)
* [GitHub Repository](https://github.com/sparkfun/SparkFun_Teensy_Ethernet_Adapter)