import sys, math
import numpy as np
from scipy.io import wavfile
from scipy.signal import resample_poly
rate, x = wavfile.read(sys.argv[1])
if x.ndim != 1:
    raise ValueError("Expected mono WAV")
if x.dtype == np.uint8:
    x = (x.astype(np.float64) - 128) / 128
elif np.issubdtype(x.dtype, np.integer):
    x = x.astype(np.float64) / (np.iinfo(x.dtype).max + 1)
else:
    x = x.astype(np.float64)
g = math.gcd(rate, 96000)
y = resample_poly(x, 96000 // g, rate // g) * 0.5
np.clip(np.rint(y * 32767), -32768, 32767).astype('<i2').tofile(sys.argv[2])
