#pragma once
#include <math.h>
#include <stddef.h>
#include <algorithm>

// Causal third-order Butterworth I/Q filter. All storage is fixed-size and
// owned exclusively by the audio task; no allocations or LVGL calls here.
class WeakDetector {
public:
  struct Channel { float one=0, previous=0, z1=0, z2=0; } i, q, upperI, upperQ, lowerI, lowerQ;
  float envelope=0, noise=1, signal=1, on=3, off=2.5f;
  void reset() {
    i = {}; q = {}; upperI={};upperQ={};lowerI={};lowerQ={};
    noisePower=0; offsetPhase=0; envelope=0; noise=signal=1; on=3; off=2.5f;
    count=write=ticks=0;
  }
  void setCutoff(float hz) {
    const float k=tanf(3.14159265358979323846f*hz/12000.0f);
    b1=k/(1+k); a1=(k-1)/(k+1);
    const float norm=1/(1+k+k*k); // Q=1 for the second-order Butterworth section
    b0=k*k*norm; b2=b0; bmid=2*b0;
    a2=2*(k*k-1)*norm; a3=(1-k+k*k)*norm;
  }
  void process(float mixI,float mixQ) {
    const float fi=filter(i,mixI), fq=filter(q,mixQ);
    envelope=2*sqrtf(fi*fi+fq*fq);
    // Two off-tone reference channels estimate noise independently of Morse
    // mark/gap decisions. This avoids teaching a noise burst to be a signal.
    offsetPhase += 6.283185307179586f*80.0f/12000.0f;
    if(offsetPhase>=6.283185307179586f)offsetPhase-=6.283185307179586f;
    const float co=cosf(offsetPhase), si=sinf(offsetPhase);
    const float ui=filter(upperI,mixI*co-mixQ*si);
    const float uq=filter(upperQ,mixQ*co+mixI*si);
    const float li=filter(lowerI,mixI*co+mixQ*si);
    const float lq=filter(lowerQ,mixQ*co-mixI*si);
    const float power=2*(ui*ui+uq*uq+li*li+lq*lq);
    noisePower += 0.00041658f*(power-noisePower); // about 200 ms

    if(++ticks < 60) return; // 5 ms envelope history
    ticks=0;
    history[write]=envelope; write=(write+1)%kHistory;
    if(count<kHistory)++count;
    // Refresh thresholds at 20 ms intervals, not per audio sample.
    if(write%4 || count<20)return;
    float *sorted=scratch;
    for(size_t n=0;n<count;++n)sorted[n]=history[n];
    std::sort(sorted,sorted+count);
    noise=fmaxf(1.0f,sqrtf(noisePower));
    signal=fmaxf(noise,sorted[(count*9)/10]);
    on=fmaxf(noise*3.0f,noise+0.40f*(signal-noise));
    off=on*0.85f;
  }
  bool ready() const {return count>=100;}
private:
  float filter(Channel &c,float x) {
    float first=b1*(x+c.previous)-a1*c.one;
    c.previous=x;c.one=first;
    float y=b0*first+c.z1;
    c.z1=bmid*first-a2*y+c.z2;
    c.z2=b2*first-a3*y;
    return y;
  }
  static constexpr size_t kHistory=300; // 1.5 seconds
  float noisePower=0,offsetPhase=0;
  float history[kHistory]={};
  float scratch[kHistory]={};
  size_t count=0,write=0,ticks=0;
  float b1=0,a1=0,b0=0,bmid=0,b2=0,a2=0,a3=0;
};
