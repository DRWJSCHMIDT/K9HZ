/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_WIFI_LINK_H
#define PSWR_WIFI_LINK_H

#include <Arduino.h>

void wifi_link_begin(void);
void wifi_link_service(void);
void wifi_link_credentials_changed(void);

// Nearby-network scan is performed by the XIAO ESP32 and returned over Serial5.
constexpr uint8_t WIFI_SCAN_MAX_RESULTS = 12;
void wifi_link_scan_start(void);
bool wifi_link_scan_busy(void);
bool wifi_link_scan_ready(void);
bool wifi_link_scan_failed(void);
uint8_t wifi_link_scan_count(void);
const char *wifi_link_scan_ssid(uint8_t index);
int wifi_link_scan_rssi(uint8_t index);
bool wifi_link_scan_secure(uint8_t index);

const char *wifi_link_ip(void);
const char *wifi_link_ssid(void);
int wifi_link_rssi(void);
bool wifi_link_connected(void);
// True once the Teensy has positively detected the XIAO ESP32 heartbeat.
// This indicates that the WiFi card hardware is present, independent of
// whether it is associated with an access point.
bool wifi_link_module_present(void);
// XIAO firmware identifier, e.g. "W3.4". Empty when connected firmware
// predates version reporting.
const char *wifi_link_firmware_version(void);

// NTP clock data supplied by the XIAO ESP32. Local time is Europe/Amsterdam
// with automatic CET/CEST daylight-saving changes.
bool wifi_link_clock_valid(void);
const char *wifi_link_clock_utc(void);
const char *wifi_link_clock_local(void);
const char *wifi_link_clock_date(void);
const char *wifi_link_clock_date_utc(void);
const char *wifi_link_clock_date_local(void);
const char *wifi_link_clock_zone(void);

#endif
