#pragma once
#define CW_FIRMWARE_VERSION "V2.22"
