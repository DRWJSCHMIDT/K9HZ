#include "CWDecoder.cpp"
#include <cassert>
#include <cstring>
#include <iostream>

static void readyGuenther() {
  weakActive = false;
  activeCwType = 1;
  cycleTimingReady = true;
  dotMs = 60.0f;
  displayDotMs = 60.0f;
  guentherTiming.reset(60.0f);
  for (int i=0; i<50; ++i) {
    const float m = (i & 1) ? (180.0f + (i%5-2)*2.0f) : (60.0f + (i%5-2)*1.0f);
    guentherTiming.observeMark(m, 90.0f);
  }
  assert(guentherTiming.fullyAcquired());
  decodedText[0] = '\0';
  decodedCharacters = 0;
  learningMarkCount = 0;
  weakMarkCount = 0;
}

static void loadRaw(const float *marks, size_t count, const float *gaps = nullptr) {
  symbolLength = count;
  guentherMarkCount = count;
  for (size_t i=0; i<count; ++i) {
    guentherMarks[i] = marks[i];
    guentherGaps[i] = gaps ? gaps[i] : 60.0f;
    symbolBuffer[i] = guentherTiming.classifyDash(marks[i]) ? '-' : '.';
  }
  symbolBuffer[count] = '\0';
}

int main() {
  readyGuenther();

  // Intended Q (--.-) with one very short false pulse inserted.
  const float noisyQ[] = {180,180,10,60,180};
  loadRaw(noisyQ, 5);
  assert(decodeMorse(symbolBuffer) == '?');
  finishCharacter();
  assert(std::strcmp(decodedText, "Q") == 0);

  // Run-on C + Q with a missed character boundary but a long internal gap.
  decodedText[0] = '\0';
  decodedCharacters = 0;
  const float runOn[] = {180,60,180,60, 180,180,60,180};
  float gaps[] = {60,60,60,180, 60,60,60,0};
  loadRaw(runOn, 8, gaps);
  assert(decodeMorse(symbolBuffer) == '?');
  finishCharacter();
  assert(std::strcmp(decodedText, "CQ") == 0);

  // QSB hole inside one dash: two dot-like fragments with a very short gap
  // would normally decode as I (..). The timing hypothesis may merge them to T.
  decodedText[0] = '\0';
  decodedCharacters = 0;
  const float splitDash[] = {70,70};
  float splitGap[] = {20,0};
  loadRaw(splitDash, 2, splitGap);
  assert(std::strcmp(symbolBuffer, "..") == 0);
  finishCharacter();
  assert(std::strcmp(decodedText, "T") == 0);

  std::cout << "PASS: Guenther short-pulse/run-on recovery and QSB timing hypothesis\n";
  return 0;
}
