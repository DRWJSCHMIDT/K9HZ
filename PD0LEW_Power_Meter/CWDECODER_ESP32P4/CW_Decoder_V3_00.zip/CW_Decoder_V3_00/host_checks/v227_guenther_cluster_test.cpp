#include <cassert>
#include <cstdio>
#include "../src/GuentherTiming.h"

int main() {
  GuentherTiming g;
  g.reset(50.0f);
  // Build narrow dot and moderately variable dash clusters.
  for (int i = 0; i < 60; ++i) {
    const float d = 50.0f + float((i % 5) - 2);
    const float a = 150.0f + float((i % 7) - 3) * 4.0f;
    assert(g.observeMark((i & 1) ? a : d, 95.0f));
  }
  assert(g.ready());
  // A shortened hand-sent dash near the moving boundary should be recognized
  // by cluster fit, while a normal dot remains a dot.
  assert(g.classifyDashForDecode(86.0f));
  assert(!g.classifyDashForDecode(55.0f));
  std::puts("PASS: V2.27 Guenther borderline cluster classifier");
  return 0;
}
