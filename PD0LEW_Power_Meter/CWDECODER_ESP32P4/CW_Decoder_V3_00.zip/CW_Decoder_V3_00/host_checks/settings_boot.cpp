#include "CWDecoder.h"
#include <cassert>
int main(){
 CWDecoder::setWeakSignal(true);CWDecoder::setManualTone(351);
 CWDecoder::begin();int32_t z[1920]={};CWDecoder::processI2S32(z,960);
 auto c=CWDecoder::getState();assert(c.weakSignal && !c.autoTone && c.toneHz==351);
 assert(CWDecoder::manualToneSettingHz()==351);
}
