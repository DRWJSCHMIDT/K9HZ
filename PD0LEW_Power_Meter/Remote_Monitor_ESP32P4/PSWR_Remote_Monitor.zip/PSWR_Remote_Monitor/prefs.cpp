#include "prefs.h"

AppPrefs gPrefs;

void prefsLoad() {
    Preferences p;
    p.begin("cyd-pm", true);

    if (p.isKey("host")) p.getString("host", gPrefs.meterHost, sizeof(gPrefs.meterHost));
    if (p.isKey("ssid")) p.getString("ssid", gPrefs.ssid, sizeof(gPrefs.ssid));
    if (p.isKey("pass")) p.getString("pass", gPrefs.password, sizeof(gPrefs.password));

    gPrefs.darkTheme = p.getBool("dark", true);
    gPrefs.peakHold = p.getBool("peak", true);
    //gPrefs.backlightPct = p.getUChar("backlight", 100);

    p.end();
}

void prefsSave() {
    Preferences p;
    p.begin("cyd-pm", false);

    p.putString("host", gPrefs.meterHost);
    p.putString("ssid", gPrefs.ssid);
    p.putString("pass", gPrefs.password);

   p.putBool("dark", gPrefs.darkTheme);
   p.putBool("peak", gPrefs.peakHold);
   //p.putUChar("backlight", gPrefs.backlightPct);


    p.end();
}