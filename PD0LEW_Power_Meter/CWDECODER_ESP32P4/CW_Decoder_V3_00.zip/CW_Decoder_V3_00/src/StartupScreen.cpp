#include "StartupScreen.h"
#include "FirmwareVersion.h"
#include "DisplaySetup.h"
#include <Arduino.h>
#include <initializer_list>

namespace {
constexpr uint32_t cyan=0x39C6DD, white=0xE8EEF2, muted=0x8DABB9;
lv_obj_t* shape(int x,int y,int w,int h,uint32_t color,int radius=0,
                uint32_t border=0,int bw=0) {
  auto* o=lv_obj_create(lv_screen_active());
  lv_obj_remove_style_all(o);
  lv_obj_set_pos(o,x,y);lv_obj_set_size(o,w,h);
  lv_obj_set_style_bg_color(o,lv_color_hex(color),0);
  lv_obj_set_style_bg_opa(o,LV_OPA_COVER,0);
  lv_obj_set_style_radius(o,radius,0);
  lv_obj_set_style_border_color(o,lv_color_hex(border),0);
  lv_obj_set_style_border_width(o,bw,0);
  lv_obj_set_scrollable(o, false); lv_obj_set_clickable(o, false);
  return o;
}
void label(const char* text,int x,int y,const lv_font_t* font,uint32_t color) {
  auto* o=lv_label_create(lv_screen_active());
  lv_label_set_text(o,text);lv_obj_set_pos(o,x,y);
  lv_obj_set_style_text_font(o,font,0);
  lv_obj_set_style_text_color(o,lv_color_hex(color),0);
}
}

lv_obj_t* StartupScreen::create() {
  auto* s=lv_screen_active();lv_obj_clean(s);
  lv_obj_set_style_bg_color(s,lv_color_hex(0x0B1722),0);
  lv_obj_set_style_bg_opa(s,LV_OPA_COVER,0);
  lv_obj_set_style_pad_all(s,0,0);lv_obj_set_style_border_width(s,0,0);
  lv_obj_set_scrollable(s, false);
  shape(0,0,1280,8,cyan);
  label("CW DECODER",64,112,&lv_font_montserrat_36,white);
  label("ESP32-P4 / PJRC AUDIO",64,176,&lv_font_montserrat_26,cyan);
  shape(64,226,470,2,0x28404F);
  label("Designed by",64,266,&lv_font_montserrat_26,muted);
  label("J.G. Holstein",64,306,&lv_font_montserrat_32,0xD9B66F);
  shape(64,410,310,1,0x28404F);
  label("FIRMWARE  " CW_FIRMWARE_VERSION,64,434,&lv_font_montserrat_28,white);

  // Restrained steel / brass straight-key illustration, drawn with native
  // objects and existing fonts. No bitmap, canvas, shadow cache or extra buffer.
  shape(666,489,508,20,0x07111A,10);
  shape(650,428,530,65,0x394954,14,0x788A93,3);
  shape(670,440,490,32,0x50616B,8,0x687D87,2);
  shape(684,487,62,14,0x19252F,4);
  shape(1090,487,62,14,0x19252F,4);
  // Rear binding posts and wiring terminals.
  for(int x: {702,760}) {
    shape(x,390,28,47,0xA98547,6,0xD8B876,2);
    shape(x-9,380,46,18,0xC7A568,5,0xE2C88B,2);
    shape(x+3,386,22,3,0x655234);
  }
  // Pedestal, pivot axle, and lever.
  shape(820,318,68,116,0x9C804B,8,0xD4B877,3);
  shape(800,418,110,18,0xBA9A5E,5,0xDEC18C,2);
  shape(722,306,365,25,0xADBBC2,8,0xDFE5E8,2);
  shape(734,330,342,9,0x50636E,3);
  shape(830,298,48,48,0x586D78,LV_RADIUS_CIRCLE,0xC3CFD3,3);
  shape(842,310,24,24,0xC6A96B,LV_RADIUS_CIRCLE,0xEDD4A0,2);
  shape(846,320,16,3,0x635335);
  // Tension screw and return spring.
  shape(760,271,18,38,0xA9B6BD,4,0xD5DFE3,2);
  shape(746,264,46,12,0xC4CDD1,4);
  for(int y=346;y<403;y+=10) shape(766,y,33,5,0xB7A071,2);
  shape(768,403,29,29,0x7E6946,4);
  // Front contact and black operating knob.
  shape(1034,382,34,48,0xB89A60,5,0xE0C68D,2);
  shape(1024,374,54,12,0xCFB47C,4);
  shape(1043,338,16,28,0xD1B67D,3);
  shape(1040,289,23,22,0x93A4AD,4);
  shape(997,253,109,42,0x101D28,20,0x728894,3);
  shape(1010,260,83,8,0x3F5563,4);
  // Mounting screws.
  for(int x: {677,1140}) {
    shape(x,451,15,15,0xB0BDC3,LV_RADIUS_CIRCLE);
    shape(x+3,457,9,2,0x394954);
  }
  // Morse CQ: -.-.  --.- (decorative identification, not live activity).
  const int widths[]={36,12,36,12,0,36,36,12,36};
  int x=742;
  for(int w:widths) {if(!w){x+=24;continue;}shape(x,194,w,8,cyan,4);x+=w+12;}
  label("MORSE CODE",805,547,&lv_font_montserrat_26,muted);
  label("STARTING DECODER",64,550,&lv_font_montserrat_26,muted);
  auto* bar=lv_bar_create(s);lv_obj_set_pos(bar,64,598);lv_obj_set_size(bar,470,12);
  lv_bar_set_range(bar,0,100);lv_bar_set_value(bar,0,LV_ANIM_OFF);
  lv_obj_set_style_bg_color(bar,lv_color_hex(0x162A38),LV_PART_MAIN);
  lv_obj_set_style_bg_color(bar,lv_color_hex(cyan),LV_PART_INDICATOR);
  lv_obj_set_style_radius(bar,6,LV_PART_MAIN);
  lv_obj_set_style_radius(bar,6,LV_PART_INDICATOR);
  return bar;
}

void StartupScreen::show() {
  auto* bar=create();
  constexpr uint32_t duration=2300;
  const uint32_t start=millis();
  while(uint32_t(millis()-start)<duration) {
    lv_bar_set_value(bar,int(uint32_t(millis()-start)*100/duration),LV_ANIM_OFF);
    DisplaySetup::update();delay(5);
  }
  lv_bar_set_value(bar,100,LV_ANIM_OFF);DisplaySetup::update();
  lv_obj_clean(lv_screen_active());
}
