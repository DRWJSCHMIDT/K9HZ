import numpy as np
from scipy import signal
from pathlib import Path
import re
src=(Path(__file__).resolve().parents[1]/'src/CWDecoder.cpp').read_text()
codes={v:k for k,v in re.findall(r'\{"([.\-]+)", \'([^\'])\'\}',src)}
rng=np.random.default_rng(402)
def save(name,x):
 y=signal.resample_poly(np.clip(x,-1,1),48,1)*.5
 np.clip(np.rint(y*32767),-32768,32767).astype('<i2').tofile('/tmp/'+name+'.raw')
for wpm in [10,15,20,25]:
 dot=1.2/wpm; env=[np.zeros(2000)]
 for char in 'CQ TEST 123':
  if char==' ':env.append(np.zeros(round(4*dot*2000)));continue
  for m in codes[char]:env.extend([np.ones(round(dot*(3 if m=='-' else 1)*2000)),np.zeros(round(dot*2000))])
  env.append(np.zeros(round(2*dot*2000)))
 env.append(np.zeros(2000));e=np.concatenate(env);t=np.arange(len(e))/2000
 for f in ([350,700,900] if wpm==15 else [700]):
  x=.55*e*np.sin(2*np.pi*f*t)+rng.normal(0,.3,len(e))
  save('synth_'+str(wpm)+'_'+str(f),x)
save('noise_only',rng.normal(0,.4,40000))
save('silence',np.zeros(10000))
