#include "CWDecoder.cpp"
#include <iostream>
#include <string>
#include <cstdlib>
int main(int argc,char**argv){
 float wpm=argc>1?atof(argv[1]):50;double dot=1.2/wpm;
 float amplitude=argc>2?atof(argv[2]):310;double offset=argc>3?atof(argv[3]):0.42;
 CWDecoder::setFadingAssist(argc>4 && atoi(argv[4]));
 CWDecoder::setInputLevelPercent(30);CWDecoder::setFilterBandwidthHz(30);
 CWDecoder::setAutoTone(true);CWDecoder::begin();
 std::string pattern;const char* text="CQ CQ DE PA0TEST HELLO WORLD 12345 ";
 for(const char* c=text;*c;c++) {
  if(*c==' '){pattern+="0000";continue;}
  for(const auto &m:MORSE_TABLE)if(m.value==*c){
   for(const char* a=m.code;*a;a++){pattern+=*a=='-'?"111":"1";pattern+='0';}
   pattern+="00";break;
  }
 }
 uint32_t rng=12345;unsigned sample=0;int32_t slots[960];unsigned beforeFade=0;
 for(int b=0;b<6000;b++) {
  for(int n=0;n<480;n++,sample++) {
   double t=sample/96000.0;int unit=int((t+offset)/dot)%pattern.size();
   rng=rng*1664525u+1013904223u;float noise=(float(rng>>8)/16777216.0f*2-1)*12;
   int16_t v=int16_t((pattern[unit]=='1'?(t<10?amplitude:40.0f)*sin(2*3.141592653589793*750*t):0)+noise);
   slots[2*n]=slots[2*n+1]=int32_t(v)*65536;
  }
  CWDecoder::processI2S32(slots,480);
  if(b==1999)beforeFade=decodedCharacters;
 }
 std::cout<<"assist="<<(argc>4?argv[4]:"0")<<" amp="<<amplitude<<" phase="<<offset<<" sent="<<wpm<<" learned="<<1200/displayDotMs<<" text="<<decodedText<<"\n";
 std::cout<<"characters after fade="<<decodedCharacters-beforeFade<<"\n";
 if(argc>4 && atoi(argv[4]))return decodedCharacters-beforeFade>60?0:1;
 return decodedCharacters-beforeFade<5?0:1;
}
