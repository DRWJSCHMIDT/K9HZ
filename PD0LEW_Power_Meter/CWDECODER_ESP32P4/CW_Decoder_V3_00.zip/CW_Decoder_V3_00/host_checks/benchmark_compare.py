#!/usr/bin/env python3
import json, re, subprocess, sys
from pathlib import Path

def normalize(s):
    s = s.upper().replace('\r',' ').replace('\n',' ')
    s = re.sub(r'\s+', ' ', s).strip()
    return s

def lev(a, b):
    prev = list(range(len(b)+1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(cur[-1]+1, prev[j]+1, prev[j-1]+(ca != cb)))
        prev = cur
    return prev[-1]

def main():
    if len(sys.argv) < 4:
        print('usage: benchmark_compare.py <wav_benchmark-exe> <audio.wav> <reference.txt> [trace.csv]')
        return 2
    exe, wav, ref = sys.argv[1:4]
    cmd = [exe, wav]
    if len(sys.argv) > 4: cmd.append(sys.argv[4])
    raw = subprocess.check_output(cmd, text=True).strip().splitlines()[-1]
    result = json.loads(raw)
    expected = normalize(Path(ref).read_text(errors='replace'))
    got = normalize(result.get('text',''))
    cd = lev(expected, got)
    cer = 100.0 * cd / max(1, len(expected))
    ew, gw = expected.split(), got.split()
    wd = lev(ew, gw)
    wer = 100.0 * wd / max(1, len(ew))
    print(f"CER={cer:.2f}% ({cd}/{len(expected)})  WER={wer:.2f}% ({wd}/{len(ew)})")
    print(f"WPM={result.get('wpm',0):.1f}  tone={result.get('tone_hz',0):.1f} Hz  style={result.get('hand_style','?')}")
    print(f"Guenther samples={result.get('hand_samples',0)}  outliers={result.get('outliers_rejected',0)}  low-conf={result.get('low_confidence_rejected',0)}")
    print(f"recoveries={result.get('error_corrections',0)}  hypotheses={result.get('hypothesis_corrections',0)}")
    print('DECODED:')
    print(got)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
