/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_WiFiConfig.h"
#include "PSWR_Eeprom.h"
#include <EEPROM.h>
#include <string.h>

namespace
{
// V3.54 eight-bank calibration occupies 320..711. Keep WiFi credentials in a
// separate independent block so existing settings/calibration never move.
constexpr int WIFI_EEPROM_ADDR = 720;
constexpr uint32_t WIFI_MAGIC = 0x4A485746UL; // "JHWF"
constexpr uint8_t WIFI_VERSION = 2;
constexpr uint8_t WIFI_VERSION_LEGACY = 1;
constexpr char WIFI_DEFAULT_SSID[] = "Your SSID";
constexpr char GRID_DEFAULT[] = "";

struct WiFiConfigStoreLegacy
{
  uint32_t magic;
  uint8_t version;
  char ssid[WIFI_SSID_MAX_CHARS + 1];
  char password[WIFI_PASSWORD_MAX_CHARS + 1];
  uint8_t reserved[2];
};

struct WiFiConfigStore
{
  uint32_t magic;
  uint8_t version;
  char ssid[WIFI_SSID_MAX_CHARS + 1];
  char password[WIFI_PASSWORD_MAX_CHARS + 1];
  char grid[GRID_MAX_CHARS + 1];
  uint8_t reserved[7];
};

static_assert(sizeof(WiFiConfigStoreLegacy) == 104, "Unexpected legacy WiFi EEPROM layout");
static_assert(sizeof(WiFiConfigStore) == 120, "Unexpected WiFi EEPROM layout");
static_assert(WIFI_EEPROM_ADDR + (int)sizeof(WiFiConfigStore) <= 1024,
              "WiFi EEPROM block exceeds reserved 1KB range");

WiFiConfigStore store = {};

bool printableText(const char *text, size_t maxLen, bool allowEmpty)
{
  if (!text) return false;
  const size_t len = strnlen(text, maxLen + 1);
  if (len > maxLen || (!allowEmpty && len == 0)) return false;
  for (size_t i = 0; i < len; ++i)
  {
    const uint8_t c = (uint8_t)text[i];
    if (c < 32 || c > 126) return false;
  }
  return true;
}

bool normalizeGrid(const char *text, char *out, size_t outSize)
{
  if (!text || !out || outSize == 0) return false;

  size_t write = 0;
  for (size_t i = 0; text[i] != '\0'; ++i)
  {
    const char c = text[i];
    if (c == ' ') continue;
    if (write >= GRID_MAX_CHARS) return false;

    if (c >= 'a' && c <= 'z') out[write++] = (char)(c - 'a' + 'A');
    else if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) out[write++] = c;
    else return false;
  }

  out[write] = '\0';
  return (write == 0) || (write == 4) || (write == 6) || (write == 8) || (write == 10);
}

bool validGrid(const char *text)
{
  char normalized[GRID_MAX_CHARS + 1] = {};
  return normalizeGrid(text, normalized, sizeof(normalized));
}

bool validStore(const WiFiConfigStore &candidate)
{
  return candidate.magic == WIFI_MAGIC &&
         candidate.version == WIFI_VERSION &&
         candidate.ssid[WIFI_SSID_MAX_CHARS] == '\0' &&
         candidate.password[WIFI_PASSWORD_MAX_CHARS] == '\0' &&
         candidate.grid[GRID_MAX_CHARS] == '\0' &&
         printableText(candidate.ssid, WIFI_SSID_MAX_CHARS, false) &&
         printableText(candidate.password, WIFI_PASSWORD_MAX_CHARS, true) &&
         validGrid(candidate.grid);
}

void persist()
{
  store.magic = WIFI_MAGIC;
  store.version = WIFI_VERSION;
  EEPROM_writeAnything(WIFI_EEPROM_ADDR, store);
}

void defaults()
{
  memset(&store, 0, sizeof(store));
  store.magic = WIFI_MAGIC;
  store.version = WIFI_VERSION;
  strncpy(store.ssid, WIFI_DEFAULT_SSID, WIFI_SSID_MAX_CHARS);
  store.ssid[WIFI_SSID_MAX_CHARS] = '\0';
  store.password[0] = '\0';
  strncpy(store.grid, GRID_DEFAULT, GRID_MAX_CHARS);
  store.grid[GRID_MAX_CHARS] = '\0';
  store.reserved[0] = CLOCK_PRIMARY_UTC;
  store.reserved[1] = CLOCK_DIM_5_MIN;
  persist();
}
}

void wifi_config_begin(bool forceReset)
{
  if (forceReset)
  {
    defaults();
    return;
  }

  WiFiConfigStore loaded = {};
  EEPROM_readAnything(WIFI_EEPROM_ADDR, loaded);
  if (validStore(loaded))
  {
    store = loaded;
  }
  else
  {
    WiFiConfigStoreLegacy legacy = {};
    EEPROM_readAnything(WIFI_EEPROM_ADDR, legacy);
    if (legacy.magic == WIFI_MAGIC &&
        legacy.version == WIFI_VERSION_LEGACY &&
        legacy.ssid[WIFI_SSID_MAX_CHARS] == '\0' &&
        legacy.password[WIFI_PASSWORD_MAX_CHARS] == '\0' &&
        printableText(legacy.ssid, WIFI_SSID_MAX_CHARS, false) &&
        printableText(legacy.password, WIFI_PASSWORD_MAX_CHARS, true))
    {
      memset(&store, 0, sizeof(store));
      store.magic = WIFI_MAGIC;
      store.version = WIFI_VERSION;
      const size_t ssidLen = strnlen(legacy.ssid, WIFI_SSID_MAX_CHARS);
      memcpy(store.ssid, legacy.ssid, ssidLen);
      store.ssid[ssidLen] = '\0';

      const size_t passwordLen = strnlen(legacy.password, WIFI_PASSWORD_MAX_CHARS);
      memcpy(store.password, legacy.password, passwordLen);
      store.password[passwordLen] = '\0';
      store.grid[0] = '\0';
      store.reserved[0] = CLOCK_PRIMARY_UTC;
      store.reserved[1] = CLOCK_DIM_5_MIN;
      persist();
    }
    else
      defaults();
  }
}

bool wifi_ssid_set(const char *text)
{
  if (!printableText(text, WIFI_SSID_MAX_CHARS, false)) return false;
  strncpy(store.ssid, text, WIFI_SSID_MAX_CHARS);
  store.ssid[WIFI_SSID_MAX_CHARS] = '\0';
  persist();
  return true;
}

bool wifi_password_set(const char *text)
{
  if (!printableText(text, WIFI_PASSWORD_MAX_CHARS, true)) return false;
  strncpy(store.password, text, WIFI_PASSWORD_MAX_CHARS);
  store.password[WIFI_PASSWORD_MAX_CHARS] = '\0';
  persist();
  return true;
}

const char *wifi_ssid_get(void) { return store.ssid; }
const char *wifi_password_get(void) { return store.password; }

bool grid_square_set(const char *text)
{
  char normalized[GRID_MAX_CHARS + 1] = {};
  if (!normalizeGrid(text, normalized, sizeof(normalized))) return false;
  strncpy(store.grid, normalized, GRID_MAX_CHARS);
  store.grid[GRID_MAX_CHARS] = '\0';
  persist();
  return true;
}

const char *grid_square_get(void) { return store.grid; }

uint8_t clock_primary_get(void)
{
  return (store.reserved[0] == CLOCK_PRIMARY_LOCAL) ? CLOCK_PRIMARY_LOCAL : CLOCK_PRIMARY_UTC;
}

bool clock_primary_set(uint8_t mode)
{
  if (mode != CLOCK_PRIMARY_UTC && mode != CLOCK_PRIMARY_LOCAL) return false;
  store.reserved[0] = mode;
  persist();
  return true;
}

uint8_t clock_dim_mode_get(void)
{
  const uint8_t mode = store.reserved[1];
  return (mode < CLOCK_DIM_COUNT) ? mode : CLOCK_DIM_5_MIN;
}

bool clock_dim_mode_set(uint8_t mode)
{
  if (mode >= CLOCK_DIM_COUNT) return false;
  store.reserved[1] = mode;
  persist();
  return true;
}

uint16_t clock_dim_minutes_get(void)
{
  switch (clock_dim_mode_get())
  {
    case CLOCK_DIM_10_MIN: return 10;
    case CLOCK_DIM_30_MIN: return 30;
    case CLOCK_DIM_OFF:    return 0;
    case CLOCK_DIM_5_MIN:
    default:               return 5;
  }
}

