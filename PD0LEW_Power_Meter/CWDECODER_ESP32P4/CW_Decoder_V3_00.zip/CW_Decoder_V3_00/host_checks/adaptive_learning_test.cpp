#include "../src/AdaptiveLearner.h"
#include <cassert>
#include <cmath>
#include <cstdio>

int main() {
  AdaptiveLearner l;
  const float dot = 60.0f;
  // Feed clean machine-sent timing with small realistic spread.
  for (int n=0; n<30; ++n) {
    float jitter = (n%5 - 2) * 0.8f;
    l.observeMark(dot + jitter, dot, 90.0f);
    l.observeMark(3.0f*dot - jitter, dot, 90.0f);
    l.observeGap(dot + 0.5f*jitter, dot, 90.0f);
    if ((n%2)==0) l.observeGap(3.0f*dot - jitter, dot, 90.0f);
  }
  std::printf("Q=%u mark=%.3f gap=%.3f samples=%u\n", l.quality(), l.markThresholdRatio(), l.letterGapRatio(), l.acceptedSamples());
  assert(l.markReady());
  assert(l.gapReady());
  assert(l.markThresholdRatio() > 1.8f && l.markThresholdRatio() < 2.2f);
  assert(l.letterGapRatio() > 1.7f && l.letterGapRatio() < 2.4f);
  const float oldMark=l.markThresholdRatio(), oldGap=l.letterGapRatio();
  // Low-confidence garbage must not move the profile.
  for (int n=0;n<100;++n) {
    l.observeMark(1.8f*dot,dot,20.0f);
    l.observeGap(2.8f*dot,dot,20.0f);
  }
  assert(std::fabs(l.markThresholdRatio()-oldMark) < 1e-6f);
  assert(std::fabs(l.letterGapRatio()-oldGap) < 1e-6f);
  // Persistence seed must restore the normalized profile.
  AdaptiveLearner seeded;
  seeded.seed(l.markThresholdRatio(), l.letterGapRatio(), l.quality());
  assert(seeded.markReady());
  assert(seeded.gapReady());
  assert(std::fabs(seeded.markThresholdRatio()-l.markThresholdRatio()) < 1e-6f);
  std::puts("PASS adaptive learning");
  return 0;
}
