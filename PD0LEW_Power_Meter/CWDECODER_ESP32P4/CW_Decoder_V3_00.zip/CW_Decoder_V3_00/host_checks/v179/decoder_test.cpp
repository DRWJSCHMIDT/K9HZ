#include "CWDecoder.cpp"
#include <cassert>
#include <string>
#include <iostream>
int main() {
 CWDecoder::begin();
 char out[4096];bool overflow=false;
 appendDecoded('A');appendDecoded(' ');appendDecoded(' ');appendDecoded('B');
 size_t n=CWDecoder::readText(out,sizeof(out),overflow);
 assert(std::string(out,n)=="A B" && !overflow);
 int32_t silence[1920]={};
 CWDecoder::relock();CWDecoder::processI2S32(silence,960);
 assert(std::string(CWDecoder::getState().decodedText)=="A B");
 assert(timingHistoryCount==0 && symbolLength==0);
 appendDecoded('C');CWDecoder::clearText();appendDecoded('D');
 assert(CWDecoder::readText(out,sizeof(out),overflow)==0);
 CWDecoder::processI2S32(silence,960);
 assert(!*CWDecoder::getState().decodedText);
 appendDecoded('E');n=CWDecoder::readText(out,sizeof(out),overflow);
 assert(std::string(out,n)=="E");
 for(int i=0;i<3000;++i)appendDecoded('X');
 n=CWDecoder::readText(out,sizeof(out),overflow);assert(n==2047 && overflow);
 n=CWDecoder::readText(out,sizeof(out),overflow);assert(n==0 && !overflow);
 std::cout<<"PASS: stream spacing, relock preservation, asynchronous clear, overflow reporting\n";
}
