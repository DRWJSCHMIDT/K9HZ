#ifndef APP_SETTINGS_H
#define APP_SETTINGS_H

#include <Arduino.h>

namespace AppSettings {

void begin();
bool monitorFiltered();
void setMonitorFiltered(bool value);
bool fadingAssist();
void setFadingAssist(bool value);
uint8_t cwType();
void setCwType(uint8_t value);
uint8_t farnsworthSpacing();
void setFarnsworthSpacing(uint8_t value);
bool autoTone();
void setAutoTone(bool value);
uint16_t autoToneResponseMs();
void setAutoToneResponseMs(uint16_t ms);
bool autoLevel();
void setAutoLevel(bool value);
bool weakSignal();
void setWeakSignal(bool value);
float manualToneHz();
void setManualToneHz(float value);
uint8_t scopeZoomIndex();
void setScopeZoomIndex(uint8_t value);
uint8_t scopeTimeIndex();
void setScopeTimeIndex(uint8_t value);


uint8_t brightnessPercent();
void setBrightnessPercent(uint8_t percent);

uint16_t screensaverMinutes();
void setScreensaverMinutes(uint16_t minutes);

uint16_t filterBandwidthHz();
void setFilterBandwidthHz(uint16_t hz);

uint8_t textColorIndex();
void setTextColorIndex(uint8_t index);

uint8_t headphoneVolumePercent();
void setHeadphoneVolumePercent(uint8_t percent);

uint32_t audioSampleRateHz();
void setAudioSampleRateHz(uint32_t hz);

// V1.91 persistent normalized timing profile. Learning OFF freezes the profile.
bool adaptiveLearning();
void setAdaptiveLearning(bool enabled);
float learnedMarkThresholdRatio();
float learnedLetterGapRatio();
uint8_t learnedProfileQuality();
void setLearnedProfile(float markThresholdRatio, float letterGapRatio, uint8_t quality);
void clearLearnedProfile();

// V1.23 decoder-only input level. 1..100 percent; does not change headphone loudness.
uint8_t decoderInputLevelPercent();
void setDecoderInputLevelPercent(uint8_t percent);

// Legacy settings retained for source compatibility; V1.23 UI does not use them.
uint8_t inputGainIndex();
void setInputGainIndex(uint8_t index);

int8_t decoderInputTrimDb();
void setDecoderInputTrimDb(int8_t db);

}  // namespace AppSettings

#endif
