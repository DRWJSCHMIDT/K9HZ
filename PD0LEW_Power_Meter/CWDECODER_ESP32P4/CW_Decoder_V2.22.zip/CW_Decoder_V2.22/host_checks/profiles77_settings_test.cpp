#include "AppSettings.cpp"
#include <cassert>
#include <iostream>
int main(){
 AppSettings::begin();assert(AppSettings::cwType()==0&&!AppSettings::fadingAssist());
 AppSettings::setCwType(2);AppSettings::setFarnsworthSpacing(30);AppSettings::setFadingAssist(true);
 ready=false;cwTypeValue=0;farnsworthSpacingValue=20;fadingAssistValue=false;
 AppSettings::begin();assert(AppSettings::cwType()==2&&AppSettings::farnsworthSpacing()==30&&AppSettings::fadingAssist());
 Preferences::data["cwtype"]=99;Preferences::data["fwspace"]=99;ready=false;AppSettings::begin();
 assert(AppSettings::cwType()==0&&AppSettings::farnsworthSpacing()==20);
 puts("PASS: defaults, persistence, corrupt-value fallback");
}
