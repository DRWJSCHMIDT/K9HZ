/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_Config.h"
#include "PSWR_ModScope.h"

#include <math.h>

namespace
{
float scopeBuffer[MODSCOPE_POINTS] = {0.0f};
uint16_t scopeHead = 0;
uint16_t scopeValid = 0;
}

void modscope_capture(double forwardAmplitude)
{
  if (!isfinite(forwardAmplitude) || forwardAmplitude < 0.0)
    forwardAmplitude = 0.0;

  scopeBuffer[scopeHead] = (float)forwardAmplitude;

  scopeHead++;
  if (scopeHead >= MODSCOPE_POINTS) scopeHead = 0;
  if (scopeValid < MODSCOPE_POINTS) scopeValid++;
}

void modscope_snapshot(float *samples, uint16_t count, float &peakAmplitude)
{
  peakAmplitude = 0.0f;
  if (!samples || count == 0) return;

  for (uint16_t i = 0; i < count; ++i)
    samples[i] = 0.0f;

  const uint16_t n = (scopeValid < count) ? scopeValid : count;
  const uint16_t dstOffset = count - n;
  const uint16_t oldest =
    (scopeHead + MODSCOPE_POINTS - scopeValid) % MODSCOPE_POINTS;
  const uint16_t srcOffset = scopeValid - n;

  for (uint16_t i = 0; i < n; ++i)
  {
    const uint16_t src = (oldest + srcOffset + i) % MODSCOPE_POINTS;
    const float v = scopeBuffer[src];
    samples[dstOffset + i] = v;
    if (v > peakAmplitude) peakAmplitude = v;
  }
}
