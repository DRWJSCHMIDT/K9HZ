#pragma once

// V2.26 serial policy:
//   0 = normal receiver/benchmark mode: ONLY decoded CW text is sent to Serial.
//   1 = developer diagnostics: re-enable firmware diagnostic messages.
// Keep this at 0 for clean benchmark captures.
#ifndef CW_SERIAL_DIAGNOSTICS
#define CW_SERIAL_DIAGNOSTICS 0
#endif

#if CW_SERIAL_DIAGNOSTICS
  #define CW_DIAG_PRINT(...)   do { Serial.print(__VA_ARGS__); } while (0)
  #define CW_DIAG_PRINTLN(...) do { Serial.println(__VA_ARGS__); } while (0)
  #define CW_DIAG_PRINTF(...)  do { Serial.printf(__VA_ARGS__); } while (0)
#else
  #define CW_DIAG_PRINT(...)   do { } while (0)
  #define CW_DIAG_PRINTLN(...) do { } while (0)
  #define CW_DIAG_PRINTF(...)  do { } while (0)
#endif
