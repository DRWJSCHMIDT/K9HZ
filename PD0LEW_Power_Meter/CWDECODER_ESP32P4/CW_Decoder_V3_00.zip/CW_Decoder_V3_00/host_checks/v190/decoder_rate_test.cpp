#include "CWDecoder.cpp"
#include <cassert>
#include <cstdio>
int main(){
  CWDecoder::begin(48000);
  assert(inputRate==48000u && decimation==4u);
  CWDecoder::begin(96000);
  assert(inputRate==96000u && decimation==8u);
  std::puts("PASS: decoder keeps 12 kHz DSP: /4 at 48 kHz, /8 at 96 kHz");
}
