/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_MENU_H
#define PSWR_MENU_H
#include <Arduino.h>
uint8_t multipurpose_pushbutton(void);
void ConfigMenu(void);
const char *menuYourCallEditText(void);
uint8_t menuYourCallKeyIndex(void);
const char *menuGridEditText(void);
uint8_t menuGridKeyIndex(void);
uint8_t menuGridMaxChars(void);
uint8_t menuClockPrimarySelection(void);
uint8_t menuClockDimSelection(void);
const char *menuWifiEditText(void);
uint8_t menuWifiKeyIndex(void);
uint8_t menuWifiMaxChars(void);
uint8_t menuWifiScanSelection(void);
uint8_t menuStartupLogoIndex(void);
uint8_t menuBandSelectIndex(void);
bool menuBandSelectActive(void);
void menuOpenBandSelect(bool returnToSetup);
#endif
