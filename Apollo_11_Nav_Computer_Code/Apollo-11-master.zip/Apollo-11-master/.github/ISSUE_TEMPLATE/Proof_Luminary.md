---
name: Proof Luminary099
about: Template for Luminary099 Proof issues 
title: "Proof "
---
Proof read transcribed code of [](//github.com/chrislgarry/Apollo-11/blob/master/Luminary099/.agc) against scans

**Multiple PRs for a few pages at a time are recommended!**

Lines: 
Page: — ()

Reduced quality scans can be found [here][1]

[1]://ibiblio.org/apollo/ScansForConversion/Luminary099
