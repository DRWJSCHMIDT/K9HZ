/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_CALBANKS_H
#define PSWR_CALBANKS_H

#include <Arduino.h>
#include "PSWR_Config.h"

// Four RF bands x two physical couplers = eight independent calibration banks.
constexpr uint8_t CALBAND_COUNT = 4;
constexpr uint8_t CALBANK_COUPLER_COUNT = 2;
constexpr uint8_t CALBANK_TOTAL = CALBAND_COUNT * CALBANK_COUPLER_COUNT;

enum CalBand : uint8_t
{
  CALBAND_HF = 0,
  CALBAND_6M,
  CALBAND_2M,
  CALBAND_70CM
};

// Initialize the persistent eight-bank calibration store. Existing V3.46
// Coupler-1/Coupler-2 calibration and V3.47+ eight-bank calibration are migrated
// automatically. From V3.54 onward each physical coupler remembers its own band.
void calbanks_begin(bool coupler2Active, bool forceReset);

// Switch physical coupler and recall that coupler's OWN remembered band.
void calbanks_select(bool coupler2Active);

// Change the remembered band only for the currently active physical coupler.
bool calbanks_select_band(uint8_t bandIndex);

// Save current R.cal_AD into the active band/coupler bank.
void calbanks_commit_active(void);

// Current physical coupler number (1 or 2), kept for existing callers.
uint8_t calbanks_active_number(void);

// Current band and human-readable band name.
uint8_t calbanks_active_band(void);
const char *calbanks_active_band_name(void);
const char *calbanks_band_name(uint8_t bandIndex);

// Copy one stored logical calibration bank without changing the active band
// or coupler. bankNumber is 1..8. Returns false for invalid bank number.
bool calbanks_get(uint8_t bankNumber, cal_t (&out)[2]);

uint8_t calbanks_bank_band(uint8_t bankNumber);       // 0..3, or 0xff invalid
uint8_t calbanks_bank_coupler(uint8_t bankNumber);    // 1..2, or 0 invalid

#endif
