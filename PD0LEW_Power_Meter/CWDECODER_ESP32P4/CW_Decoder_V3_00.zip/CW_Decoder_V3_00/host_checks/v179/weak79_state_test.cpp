#include "CWDecoder.cpp"
#include <cassert>
#include <iostream>
void tick(){int32_t zero[1920]={};CWDecoder::processI2S32(zero,960);}
int main(){
 CWDecoder::begin();appendDecoded('K');publishState();
 assert(!CWDecoder::getState().weakSignal);
 CWDecoder::setWeakSignal(true);CWDecoder::setManualTone(351);tick();
 auto c=CWDecoder::getState();assert(c.weakSignal && c.spectrumMinHz==300 && c.spectrumMaxHz==1000 && c.toneHz==351 && c.filterBandwidthHz==24);
 assert(std::string(c.decodedText)=="K");
 CWDecoder::relock();tick();assert(std::string(CWDecoder::getState().decodedText)=="K");
 CWDecoder::setWeakSignal(false);tick();c=CWDecoder::getState();
 assert(!c.weakSignal && c.spectrumMinHz==300 && c.spectrumMaxHz==1000 && c.filterBandwidthHz==40);
 assert(std::string(c.decodedText)=="K");
 CWDecoder::setManualTone(495);tick();assert(CWDecoder::getState().toneHz==495);
 CWDecoder::clearText();tick();assert(!*CWDecoder::getState().decodedText);
 std::cout<<"PASS: mode switching, tone bounds, filter reporting, transcript preservation, relock, clear\n";
}
