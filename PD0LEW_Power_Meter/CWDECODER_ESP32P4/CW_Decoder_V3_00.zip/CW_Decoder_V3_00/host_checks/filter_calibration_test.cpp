#include "FilterCalibration.h"
#include "MonitorFilter.h"
#include <cassert>
#include <cmath>
#include <cstdio>
#include <complex>

static constexpr double PI=3.14159265358979323846;
static double cascadeDb(double alpha, double offsetHz, double fs) {
  // Exactly the two one-pole recursions in the firmware I/Q path.
  const double a=1.0-alpha;
  const double w=2.0*PI*offsetHz/fs;
  const double den=alpha*alpha+2.0*a*(1.0-std::cos(w));
  return 20.0*std::log10(alpha*alpha/den);
}

// Time-domain check of the actual headphone-filter class (only NORMAL mode).
// Correlation projects the output back to the test frequency, bypassing
// transient energy and avoiding assumptions about the phase shift.
static double monitorGainDb(unsigned bw,unsigned sampleRate,double offset) {
  MonitorFilter filter;
  const double carrierHz=750.0;
  const double signalHz=carrierHz+offset;
  constexpr double amplitude=12000.0;
  double ci=0,co=0,si=0,so=0;
  const int n=int(sampleRate*2.0);
  const int skip=int(sampleRate*0.60);
  const double omega=2.0*PI*signalHz/sampleRate;
  for (int i=0;i<n;++i) {
    filter.configure(float(carrierHz),bw,false,true,sampleRate);
    int16_t input=int16_t(std::lround(amplitude*std::sin(omega*i)));
    int16_t output=filter.process(input);
    if (i<skip) continue;
    double c=std::cos(omega*i),s=std::sin(omega*i);
    ci+=input*c; si+=input*s;
    co+=output*c; so+=output*s;
  }
  return 20*std::log10(std::hypot(co,so)/std::hypot(ci,si));
}
int main() {
  const unsigned bws[]={30,40,60,80,120};
  for (unsigned fs:{12000u,48000u,96000u}) {
    for (unsigned bw:bws) {
      const float alpha=CWFilterCalibration::twoPoleAlphaForFullBandwidth(float(bw),float(fs));
      assert(alpha>0 && alpha<1);
      const double db=cascadeDb(alpha,double(bw)/2.0,fs);
      std::printf("response fs=%u selected=%u Hz +/-%.1f Hz = %+.5f dB\n",fs,bw,bw/2.0,db);
      assert(std::fabs(db+3.01029995664)<0.0003);
      if (fs==48000 || fs==96000) {
        const double atCenter=monitorGainDb(bw,fs,0);
        const double atBoundary=monitorGainDb(bw,fs,bw/2.0);
        std::printf("monitor  fs=%u selected=%u Hz center=%+.3f dB edge=%+.3f dB\n",fs,bw,atCenter,atBoundary);
        assert(std::fabs(atBoundary-atCenter+3.0103)<0.20);
      }
    }
  }
  std::puts("PASS: 30/40/60/80/120 Hz are calibrated full -3dB bandwidths at 12/48/96 kHz");
}
