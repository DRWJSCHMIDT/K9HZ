#include "CWDecoder.cpp"
#include <cassert>
#include <cstring>
#include <iostream>
void tick(){int32_t zero[2]={};CWDecoder::processI2S32(zero,1);}
int main(){
 CWDecoder::setAutoTone(true);CWDecoder::begin();
 appendDecoded('E'); // Early garbage is legal Morse: old guard disabled recovery.
 acquisitionSamples=3*12000-1;noiseEnvelope=777;tick();
 assert(!startupRelockDone && noiseEnvelope==777);
 acquisitionSamples=3*12000;acquisitionLastEdge=acquisitionSamples;
 acquisitionToneHits=0;noiseEnvelope=777;tick();
 assert(startupRelockDone && noiseEnvelope==20 && !acquisitionComplete);
 assert(!strcmp(decodedText,"E") && !CWDecoder::relockPending());
 noiseEnvelope=333;acquisitionSamples+=12000;tick();assert(noiseEnvelope==333);
 // A button reset before the deadline consumes the pending startup reset.
 CWDecoder::begin();CWDecoder::relock();tick();assert(startupRelockDone);
 noiseEnvelope=222;acquisitionSamples=3*12000;tick();assert(noiseEnvelope==222);
 // Manual tuning is not interrupted, nor is AUTO enabled later interrupted.
 CWDecoder::setAutoTone(false);CWDecoder::begin();
 acquisitionSamples=3*12000;noiseEnvelope=111;tick();
 assert(startupRelockDone && noiseEnvelope==111);
 CWDecoder::setAutoTone(true);tick();assert(noiseEnvelope==111);
 std::cout<<"PASS: one-shot settling RELOCK despite early false text/noisy edges, transcript retained, manual button cancels, manual mode unaffected\n";
}
