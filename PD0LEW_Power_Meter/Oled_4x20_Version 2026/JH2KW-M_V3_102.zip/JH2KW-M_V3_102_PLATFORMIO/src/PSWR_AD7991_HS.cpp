/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_AD7991_HS.h"
#include "PSWR_Config.h"

#include <Wire.h>

#if defined(__IMXRT1062__)
#include <imxrt.h>
#endif

namespace
{
constexpr uint8_t AD7991_0 = 0x28;
constexpr uint8_t AD7991_1 = 0x29;
constexpr uint16_t CAPTURE_SIZE = 2048;
constexpr uint16_t CAPTURE_MASK = CAPTURE_SIZE - 1U;
static_assert((CAPTURE_SIZE & CAPTURE_MASK) == 0,
              "capture ring size must be a power of two");

struct CaptureSlot
{
  uint16_t fwd;
  uint16_t rev;
  uint32_t tick;
};

volatile CaptureSlot captureBuffer[CAPTURE_SIZE];
volatile uint16_t captureHead = 0;
volatile uint16_t captureTail = 0;
volatile uint32_t captureTick = 0;
volatile uint32_t captureErrors = 0;
volatile uint32_t captureOverruns = 0;
volatile uint16_t captureHighWater = 0;
uint8_t adcAddress = 0;

static inline void saturatingIncrement(volatile uint32_t &value)
{
  if (value != UINT32_MAX) ++value;
}

#if defined(__IMXRT1062__)
constexpr uint8_t HS_MASTER_CODE = 0x08;
static_assert(I2C_HS_PREAMBLE_CLOCK_HZ == 1000000UL,
              "LPI2C Hs preamble register setup expects 1 MHz");
static_assert(I2C_HS_DATA_CLOCK_HZ == 3000000UL,
              "LPI2C Hs data register setup expects 3 MHz");

static void configureLpi2cHsMode()
{
  IMXRT_LPI2C_t *port = &IMXRT_LPI2C1;

  // Wire.begin() has already selected the correct pins/peripheral. Disable only
  // the master while changing the timing registers.
  port->MCR = 0;

  // Teensy 4.x LPI2C peripheral clock is 24 MHz in this configuration.
  // MCCR0: 24 MHz / (10 + 12 + 2) = 1.0 MHz preamble/master-code phase.
  port->MCCR0 = LPI2C_MCCR0_CLKHI(10) | LPI2C_MCCR0_CLKLO(12) |
                LPI2C_MCCR0_DATAVD(5) | LPI2C_MCCR0_SETHOLD(8);

  // MCCR1: 24 MHz / (3 + 3 + 2) = exactly 3.0 MHz High-Speed data phase.
  // This is copied from the user's 5-inch TFT firmware, which uses the same
  // AD7991 Hs master-code / HS_START transaction without key-down overshoot.
  port->MCCR1 = LPI2C_MCCR0_CLKHI(3) | LPI2C_MCCR0_CLKLO(3) |
                LPI2C_MCCR0_DATAVD(1) | LPI2C_MCCR0_SETHOLD(2);

  port->MCFGR1 = LPI2C_MCFGR1_PRESCALE(0);
  port->MCFGR2 = LPI2C_MCFGR2_FILTSDA(0) | LPI2C_MCFGR2_FILTSCL(0) |
                 LPI2C_MCFGR2_BUSIDLE(2400);
  port->MCFGR3 = LPI2C_MCFGR3_PINLOW(15000 * 24 / 256 + 1);
  port->MCFGR0 = 0;
  port->MFCR = LPI2C_MFCR_RXWATER(1) | LPI2C_MFCR_TXWATER(1);
  port->MCR = LPI2C_MCR_MEN;
}

static uint8_t read4Hs(uint8_t addr, uint8_t *buf)
{
  IMXRT_LPI2C_t *port = &IMXRT_LPI2C1;

  uint32_t timeout = 1000;
  while ((port->MSR & LPI2C_MSR_BBF) && !(port->MSR & LPI2C_MSR_MBF))
  {
    if (--timeout == 0) return 0;
  }

  port->MSR = 0x00007F00;

  // LJ-2000M Hs-mode transaction:
  // 1. START_NACK + Hs master code 00001xxx
  // 2. HS_START + AD7991 read address (switches hardware to MCCR1)
  // 3. RECEIVE four bytes
  // 4. STOP (returns to MCCR0 timing)
  port->MTDR = LPI2C_MTDR_CMD_START_NACK | HS_MASTER_CODE;
  port->MTDR = LPI2C_MTDR_CMD_HS_START | ((addr << 1) | 1U);
  port->MTDR = LPI2C_MTDR_CMD_RECEIVE | 3U;
  port->MTDR = LPI2C_MTDR_CMD_STOP;

  uint8_t count = 0;
  timeout = 5000;

  while (count < 4)
  {
    const uint32_t status = port->MSR;
    if (status & (LPI2C_MSR_NDF | LPI2C_MSR_ALF | LPI2C_MSR_PLTF))
    {
      port->MCR |= LPI2C_MCR_RTF | LPI2C_MCR_RRF;
      port->MTDR = LPI2C_MTDR_CMD_STOP;
      return 0;
    }

    if (((port->MFSR >> 16) & 0x07U) != 0U)
      buf[count++] = (uint8_t)(port->MRDR & 0xFFU);

    if (--timeout == 0)
    {
      port->MCR |= LPI2C_MCR_RTF | LPI2C_MCR_RRF;
      port->MTDR = LPI2C_MTDR_CMD_STOP;
      return 0;
    }
  }

  return count;
}
#else
// Host/static-test fallback. Real Teensy 4.x firmware always uses read4Hs() above.
static void configureLpi2cHsMode() {}
static uint8_t read4Hs(uint8_t addr, uint8_t *buf)
{
  const uint8_t received = Wire.requestFrom(addr, (uint8_t)4);
  if (received != 4) return 0;
  uint8_t count = 0;
  while (count < 4 && Wire.available()) buf[count++] = (uint8_t)Wire.read();
  return count;
}
#endif

static bool decodePair(const uint8_t *bytes, uint16_t &fwd, uint16_t &rev)
{
  uint16_t adc[4] = {0, 0, 0, 0};
  bool got[4] = {false, false, false, false};

  const uint8_t ch0 = (uint8_t)((bytes[0] >> 4) & 0x03U);
  const uint8_t ch1 = (uint8_t)((bytes[2] >> 4) & 0x03U);

  adc[ch0] = (uint16_t)(((uint16_t)(bytes[0] & 0x0FU) << 8) | bytes[1]);
  adc[ch1] = (uint16_t)(((uint16_t)(bytes[2] & 0x0FU) << 8) | bytes[3]);
  got[ch0] = true;
  got[ch1] = true;

  if (!got[0] || !got[1]) return false;

  fwd = adc[0];
  rev = adc[1];
  return true;
}
}

uint8_t ad7991_hs_begin(void)
{
  Wire.begin();
  Wire.setClock(I2C_CONFIG_CLOCK_HZ);

  adcAddress = AD7991_1;
  uint8_t found = 2;
  Wire.beginTransmission(adcAddress);
  if (Wire.endTransmission() != 0)
  {
    adcAddress = AD7991_0;
    found = 1;
    Wire.beginTransmission(adcAddress);
    if (Wire.endTransmission() != 0)
    {
      adcAddress = 0;
      return 0;
    }
  }

  // Configure VIN0 + VIN1 consecutive conversions and external reference.
  Wire.beginTransmission(adcAddress);
  Wire.write(0x38);
  if (Wire.endTransmission() != 0)
  {
    adcAddress = 0;
    return 0;
  }

  configureLpi2cHsMode();

  noInterrupts();
  captureHead = 0;
  captureTail = 0;
  captureTick = 0;
  captureErrors = 0;
  captureOverruns = 0;
  captureHighWater = 0;
  interrupts();

  return found;
}

void ad7991_hs_capture_isr(void)
{
  const uint32_t tick = ++captureTick;
  if (adcAddress == 0) return;

  uint8_t bytes[4];
  if (read4Hs(adcAddress, bytes) != 4)
  {
    saturatingIncrement(captureErrors);
    return;
  }

  uint16_t fwd = 0;
  uint16_t rev = 0;
  if (!decodePair(bytes, fwd, rev))
  {
    saturatingIncrement(captureErrors);
    return;
  }

  const uint16_t next = (uint16_t)((captureHead + 1U) & CAPTURE_MASK);
  if (next == captureTail)
  {
    saturatingIncrement(captureOverruns);
    return; // preserve existing queued samples; drop newest sample
  }

  captureBuffer[captureHead].fwd = fwd;
  captureBuffer[captureHead].rev = rev;
  captureBuffer[captureHead].tick = tick;
  captureHead = next;

  // Track the deepest queue occupancy reached since startup. This makes it
  // possible to prove whether LCD/menu work is merely creating a temporary
  // backlog or actually overflowing the capture ring.
  const uint16_t depth = (uint16_t)((captureHead - captureTail) & CAPTURE_MASK);
  if (depth > captureHighWater) captureHighWater = depth;
}

bool ad7991_hs_pop(Ad7991CapturedSample &sample)
{
  noInterrupts();
  if (captureTail == captureHead)
  {
    interrupts();
    return false;
  }

  const uint16_t index = captureTail;
  sample.fwd = captureBuffer[index].fwd;
  sample.rev = captureBuffer[index].rev;
  sample.tick = captureBuffer[index].tick;
  captureTail = (uint16_t)((captureTail + 1U) & CAPTURE_MASK);
  interrupts();
  return true;
}

uint32_t ad7991_hs_read_errors(void)
{
  noInterrupts();
  const uint32_t value = captureErrors;
  interrupts();
  return value;
}

uint32_t ad7991_hs_overruns(void)
{
  noInterrupts();
  const uint32_t value = captureOverruns;
  interrupts();
  return value;
}


uint16_t ad7991_hs_queue_depth(void)
{
  noInterrupts();
  const uint16_t value = (uint16_t)((captureHead - captureTail) & CAPTURE_MASK);
  interrupts();
  return value;
}

uint16_t ad7991_hs_queue_high_water(void)
{
  noInterrupts();
  const uint16_t value = captureHighWater;
  interrupts();
  return value;
}
