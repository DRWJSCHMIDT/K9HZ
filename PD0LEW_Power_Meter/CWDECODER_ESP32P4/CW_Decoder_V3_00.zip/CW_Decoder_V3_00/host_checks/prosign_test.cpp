#include "CWDecoder.cpp"
#include <cassert>
#include <cstring>
#include <iostream>

static void expectProsign(const char *code, const char *expected) {
  const char *p = decodeProsign(code);
  assert(p != nullptr);
  assert(std::strcmp(p, expected) == 0);
}

int main() {
  expectProsign(".-.-.", "<AR>");
  expectProsign(".-...", "<AS>");
  expectProsign("...-.-", "<SK>");
  expectProsign("-...-.-", "<BK>");
  expectProsign("-...-", "<BT>");
  expectProsign("-.--.", "<KN>");
  expectProsign("-.-..-..", "<CL>");
  expectProsign("........", "<HH>");
  expectProsign("...---...", "<SOS>");
  assert(decodeProsign(".-") == nullptr);
  assert(decodeMorse(".-") == 'A');

  CWDecoder::begin();
  appendDecodedText("<AR>");
  char out[32] = {};
  bool overflow = false;
  const size_t n = CWDecoder::readText(out, sizeof(out), overflow);
  assert(!overflow);
  assert(std::string(out, n) == "<AR>");
  std::cout << "PASS: prosign lookup and transcript output\n";
  return 0;
}
