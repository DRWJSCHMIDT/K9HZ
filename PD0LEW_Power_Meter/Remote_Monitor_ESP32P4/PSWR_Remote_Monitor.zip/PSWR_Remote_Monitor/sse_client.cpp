#include "sse_client.h"
#include "prefs.h"
#include "app_state.h"
#include "api_client.h"
#include <WiFi.h>
#include <WiFiClient.h>
#include <ArduinoJson.h>

TaskHandle_t gSseTaskHandle = nullptr;
static bool   sseIntervalConfigured = false;

static void applyJson(const char* json) {
    
    //Serial.println(json); // Check data Johan
    while (*json == ' ' || *json == '\t') json++;
    if (*json != '{') {
        return;
    }

    DynamicJsonDocument doc(32768);
    static uint32_t eventCount = 0;
    if (deserializeJson(doc, json) != DeserializationError::Ok) {
        return;
    }

    eventCount++;

    if (xSemaphoreTake(gStateMutex, pdMS_TO_TICKS(50)) != pdTRUE) return;

    if (!doc["pep"].isNull())     strlcpy(gState.pep,      doc["pep"],      sizeof(gState.pep));
    
    if (!doc["vswr"].isNull()) {
    gState.vswr = atof(doc["vswr"].as<const char*>());

}
    
    if (!doc["pk"].isNull())      strlcpy(gState.pk,       doc["pk"],       sizeof(gState.pk));
    if (!doc["avg"].isNull())     strlcpy(gState.avg_p,    doc["avg"],      sizeof(gState.avg_p));
    if (!doc["ref"].isNull())     strlcpy(gState.ref_p,    doc["ref"],      sizeof(gState.ref_p));
    if (!doc["dbm"].isNull())     strlcpy(gState.dbm,      doc["dbm"],      sizeof(gState.dbm));
    if (!doc["utc"].isNull())     strlcpy(gState.utc,      doc["utc"],      sizeof(gState.utc));
    if (!doc["call"].isNull()) {
        strlcpy(gState.callsign, doc["call"], sizeof(gState.callsign));
    } else if (!doc["callsign"].isNull()) {
        strlcpy(gState.callsign, doc["callsign"], sizeof(gState.callsign));
    } else if (!doc["callSign"].isNull()) {
        strlcpy(gState.callsign, doc["callSign"], sizeof(gState.callsign));
    }
    if (!doc["swrt"].isNull())    strlcpy(gState.swrt,     doc["swrt"],     sizeof(gState.swrt));
    if (!doc["rssi"].isNull())    gState.rssi    = doc["rssi"].as<int>();
    if (!doc["cpl"].isNull())     gState.cpl     = doc["cpl"].as<int>();
    if (!doc["btns"].isNull())    gState.band    = doc["btns"].as<int>();
    if (!doc["pep_val"].isNull()) gState.pep_val = doc["pep_val"].as<int>();

    gState.dirty = true;
    xSemaphoreGive(gStateMutex);

    if (!sseIntervalConfigured) {
        sseIntervalConfigured = true;
        sendCommand("{\"sseInterval\":100}");
    }
}
void startSseClient() {
    xTaskCreatePinnedToCore(
        sseTask,
        "sseTask",
        8192,
        nullptr,
        1,
        &gSseTaskHandle,
        0
    );
}


void sseTask(void* /*param*/) {
    WiFiClient client;
    static char lineBuf[640];

    while (true) {
        while (WiFi.status() != WL_CONNECTED) vTaskDelay(pdMS_TO_TICKS(500));

        client.stop();

        if (!client.connect(gPrefs.meterHost, 80)) {
            if (xSemaphoreTake(gStateMutex, portMAX_DELAY) == pdTRUE) {
                gState.sseConnected = false;
                gState.dirty = true;
                xSemaphoreGive(gStateMutex);
            }
            vTaskDelay(pdMS_TO_TICKS(500)); // 2000 jhn
            continue;
        }

        client.printf(
            "GET /events HTTP/1.1\r\n"
            "Host: %s\r\n"
            "Accept: text/event-stream\r\n"
            "Cache-Control: no-cache\r\n"
            "Connection: keep-alive\r\n\r\n",
            gPrefs.meterHost
        );
        client.setTimeout(3000);

        // Discard HTTP response headers
        while (client.connected()) {
            String hdr = client.readStringUntil('\n');
            hdr.trim();
            if (hdr.length() == 0) break;
        }

        if (xSemaphoreTake(gStateMutex, portMAX_DELAY) == pdTRUE) {
            gState.sseConnected = true;
            gState.dirty = true;
            xSemaphoreGive(gStateMutex);
        }

        // Stream loop
        while (client.connected()) {
            if (client.available()) {
                int len = client.readBytesUntil('\n', lineBuf, sizeof(lineBuf) - 1);
                lineBuf[len] = '\0';
                // Trim trailing \r
                if (len > 0 && lineBuf[len - 1] == '\r') lineBuf[--len] = '\0';

                if (strncmp(lineBuf, "data: ", 6) == 0 && len > 6) {
                    applyJson(lineBuf + 6);
                }
            } else {
                vTaskDelay(pdMS_TO_TICKS(5));
            }
        }

        if (xSemaphoreTake(gStateMutex, portMAX_DELAY) == pdTRUE) {
            gState.sseConnected = false;
            gState.dirty = true;
            xSemaphoreGive(gStateMutex);
        }
        vTaskDelay(pdMS_TO_TICKS(500)); // 2000 jhn
    }
}
