/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_WIFI_CONFIG_H
#define PSWR_WIFI_CONFIG_H

#include <Arduino.h>

constexpr size_t WIFI_SSID_MAX_CHARS = 32;
constexpr size_t WIFI_PASSWORD_MAX_CHARS = 63;
constexpr size_t GRID_MAX_CHARS = 10;
constexpr uint8_t CLOCK_PRIMARY_UTC = 0;
constexpr uint8_t CLOCK_PRIMARY_LOCAL = 1;

// Clock dim timeout selection. Encoding 0 is intentionally 5 minutes so
// existing V3.67 EEPROM blocks automatically get the safe default.
constexpr uint8_t CLOCK_DIM_5_MIN  = 0;
constexpr uint8_t CLOCK_DIM_10_MIN = 1;
constexpr uint8_t CLOCK_DIM_30_MIN = 2;
constexpr uint8_t CLOCK_DIM_OFF    = 3;
constexpr uint8_t CLOCK_DIM_COUNT  = 4;

void wifi_config_begin(bool forceReset);
bool wifi_ssid_set(const char *text);
bool wifi_password_set(const char *text);
const char *wifi_ssid_get(void);
const char *wifi_password_get(void);
bool grid_square_set(const char *text);
const char *grid_square_get(void);
uint8_t clock_primary_get(void);
bool clock_primary_set(uint8_t mode);
uint8_t clock_dim_mode_get(void);
bool clock_dim_mode_set(uint8_t mode);
uint16_t clock_dim_minutes_get(void);

#endif
