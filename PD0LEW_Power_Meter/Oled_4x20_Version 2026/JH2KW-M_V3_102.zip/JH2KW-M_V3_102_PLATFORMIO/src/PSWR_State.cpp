/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_State.h"

unsigned long lastTimeButtonStateChanged = 0;

Adafruit_SSD1322 lcd(OLED_WIDTH, OLED_HEIGHT, &SPI, OLED_DC, OLED_RESET, OLED_CS);
U8G2_FOR_ADAFRUIT_GFX u8g2;
TextLCD VirtLCD;
Encoder Enc(EncI, EncQ);
Metro pollMetro(POLL_TIMER);
Metro pushMetro(1);
Metro slowMetro(100);
Chrono screensaver_time;
Chrono screensaver_begin_time;


double adc_ref = AD7991REF;
int16_t fwd = 0;
int16_t rev = 0;
double f_inst = 0.0;
double r_inst = 0.0;
double ad8307_FdBm = -120.0;
double ad8307_RdBm = -120.0;
double fwd_power_mw = 0.0;
double ref_power_mw = 0.0;
double power_mw = 0.0;
double power_mw_pk = 0.0;
double power_mw_pep = 0.0;
double power_mw_lng = 0.0;
double power_mw_avg = 0.0;
double power_mw_1savg = 0.0;
double power_db = -120.0;
double power_db_pk = -120.0;
double power_db_pep = -120.0;
double power_db_lng = -120.0;


double display_dbm_mw = 1.0e-12;
double display_swr = 1.0;
uint16_t display_swr_bar = 0;
bool display_rf_active = false;
bool display_pep_armed = false;
bool screensaver_active = false;
bool display_off_active = false;
double swr = 1.0;
double swr_avg = 1.0;
uint16_t swr_bar = 0;

uint16_t menu_level = 0;
char lcd_buf[82] = {0};
uint16_t Menu_exit_timer = 0;
uint8_t mode_display = DEFAULT_MODE;
flags flag = {};
bool Reverse = false;
byte lastButtonState = LOW;
bool cpl = false;
bool swr_alarm_acknowledged = false;
bool swr_buzzer_active = false;
uint32_t swr_buzzer_started_ms = 0;

var_t R = {
  {
    { CAL1_NOR_VALUE, CALFWD1_DEFAULT, CALREV1_DEFAULT },
    { CAL2_NOR_VALUE, CALFWD2_DEFAULT, CALREV2_DEFAULT }
  },
  LEGACY_METER_CAL_DEFAULT,
  SWR_ALARM,
  SWR_THRESHOLD,
  0,
  REPORT_DATA,
  PEP_PERIOD,
  PK_HOLD_DEFAULT_MS,
  { SCALE_RANGE1, SCALE_RANGE2, SCALE_RANGE3 },
  SLEEPMSG,
  SLEEPTHRESHOLD,
  FLOOR_ONE_mW,
  DEFAULT_MODE,
  SCREENSAVER_DEFAULT_MINUTES,
  DISPLAY_OFF_DEFAULT_MINUTES
};
