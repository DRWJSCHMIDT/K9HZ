#pragma once
#include <stdint.h>
#include <stddef.h>
#include <cstdio>
using portMUX_TYPE=int;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(x) ((void)0)
#define portEXIT_CRITICAL(x) ((void)0)
struct TestSerial { void println(const char*) {} int availableForWrite() { return 64; } size_t write(const uint8_t*,size_t n) { return n; } template<class... T> void printf(const char*,T...) {} };
inline TestSerial Serial;
#include <cstring>
#include <algorithm>
class Stream {};
inline uint32_t millis() {return 1000;}
template<class T> T constrain(T x,T lo,T hi) {return std::min(hi,std::max(lo,x));}

using std::min; using std::max;
