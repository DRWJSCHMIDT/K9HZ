/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_DISPLAY_H
#define PSWR_DISPLAY_H

#include <Arduino.h>

bool display_begin(void);
void display_startup(void);
void display_smoothing_update(void);

// V3.102 temporary display-stage PEP diagnostic snapshot.  This records the
// exact numeric PEP value and formatted text sent to the large Power-screen
// hero field, together with the measurement-block sequence it belongs to.
struct DisplayPepDebugSnapshot
{
  uint32_t frame_sequence;
  uint32_t frame_millis;
  uint32_t measurement_sequence;
  double dsp_pep_mw;
  double dsp_pk_mw;
  double global_pep_mw;
  double global_pep_db;
  bool armed;
  bool rf_active;
  char pep_text[12];
  char pk_text[12];
};

bool display_get_pep_debug_snapshot(DisplayPepDebugSnapshot &out);
void lcd_display_clean(const char *introtext, const char *power_display_indicator, double power);
void lcd_display_clean_dBm(void);
void lcd_display_fwd_rev(void);
void lcd_display_modscope(void);
void lcd_display_clock(void);
void lcd_display_debug(uint8_t page);

#endif // PSWR_DISPLAY_H
