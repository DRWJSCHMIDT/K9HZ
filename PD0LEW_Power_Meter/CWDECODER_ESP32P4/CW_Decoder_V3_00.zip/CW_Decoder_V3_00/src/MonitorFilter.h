#pragma once
#include <cmath>
#include <cstdint>
#include <algorithm>
#include "FilterCalibration.h"

// Independent listening path, matching the decoder's I/Q filter topology.
// No detector gain, threshold, timing, AGC, or decoded-key gating is applied.
// Runs at the selected native 48/96 kHz rate so no resampling/image artifacts are introduced.
class MonitorFilter {
  struct Channel {float lp1=0,lp2=0,one=0,previous=0,z1=0,z2=0;} i,q;
  float co=1,si=0,stepCo=1,stepSi=0,alpha=0;
  float b1=0,a1=0,b0=0,bmid=0,a2=0,a3=0;
  float wet=0;
  float crossfadeStep=1.0f/1920.0f;
  float previousTone=-1;unsigned previousBandwidth=0;
  uint32_t previousSampleRate=0;
  bool weak=false,after=false;
  float lowpass(Channel& c,float x) {
    if(!weak){c.lp1+=alpha*(x-c.lp1);c.lp2+=alpha*(c.lp1-c.lp2);return c.lp2;}
    float first=b1*(x+c.previous)-a1*c.one;c.previous=x;c.one=first;
    float y=b0*first+c.z1;c.z1=bmid*first-a2*y+c.z2;c.z2=b0*first-a3*y;
    return y;
  }
public:
  void configure(float tone,unsigned bandwidth,bool weakMode,bool filtered,uint32_t sampleRate=96000) {
    after=filtered;
    if(sampleRate!=48000 && sampleRate!=96000)sampleRate=96000;
    const bool rateChanged=sampleRate!=previousSampleRate;
    const float fs=static_cast<float>(sampleRate);
    crossfadeStep=1.0f/std::max(1.0f,0.020f*fs);
    if(!std::isfinite(tone))tone=700;
    tone=std::max(300.0f,std::min(1000.0f,tone));
    if(tone!=previousTone || rateChanged){
      const float angle=6.28318530718f*tone/fs;
      stepCo=std::cos(angle);stepSi=std::sin(angle);previousTone=tone;
    }
    if(bandwidth!=previousBandwidth || weakMode!=weak || rateChanged){
      if(weakMode!=weak || rateChanged){i={};q={};co=1;si=0;}
      weak=weakMode;previousBandwidth=bandwidth;
      const float cutoff=weak?12.0f:float(std::max(30u,std::min(120u,bandwidth)));
      // Match the normal decoder's exact two-section full -3 dB bandwidth.
      // Leave the WEAK SIGNAL monitor filter unchanged and independent.
      alpha=weak ? (1-std::exp(-6.28318530718f*cutoff/fs)) :
                   CWFilterCalibration::twoPoleAlphaForFullBandwidth(cutoff,fs);
      const float k=std::tan(3.14159265359f*cutoff/fs),norm=1/(1+k+k*k);
      b1=k/(1+k);a1=(k-1)/(k+1);b0=k*k*norm;bmid=2*b0;
      a2=2*(k*k-1)*norm;a3=(1-k+k*k)*norm;
    }
    previousSampleRate=sampleRate;
    // Renormalize once per block; prevent recursive oscillator amplitude drift.
    const float norm=1/std::sqrt(co*co+si*si);co*=norm;si*=norm;
  }
  int16_t process(int16_t input) {
    const float fi=lowpass(i,input*co),fq=lowpass(q,input*si);
    const float filtered=2*(fi*co+fq*si);
    const float nextCo=co*stepCo-si*stepSi;si=si*stepCo+co*stepSi;co=nextCo;
    // 20 ms crossfade when switching. BEFORE settles to bit-exact passthrough.
    wet=after?std::min(1.0f,wet+crossfadeStep):std::max(0.0f,wet-crossfadeStep);
    if(wet==0)return input;
    const float output=input+wet*(filtered-input);
    return int16_t(std::lround(std::max(-32768.0f,std::min(32767.0f,output))));
  }
};
