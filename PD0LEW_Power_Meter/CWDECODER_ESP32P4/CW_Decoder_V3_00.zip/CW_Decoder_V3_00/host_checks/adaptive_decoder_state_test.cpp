#include "CWDecoder.cpp"
#include <cassert>
#include <cstdio>
int main(){
  CWDecoder::setAdaptiveLearning(true);
  CWDecoder::setAdaptiveLearningProfile(1.92f,2.08f,82);
  CWDecoder::begin(96000);
  auto a=CWDecoder::getState();
  assert(a.adaptiveLearning);
  assert(a.learningApplied);
  assert(a.learningQuality==82);
  assert(a.learnedMarkThresholdRatio>1.91f && a.learnedMarkThresholdRatio<1.93f);
  CWDecoder::reconfigureInputSampleRate(48000);
  a=CWDecoder::getState();
  assert(a.learningApplied && a.learningQuality==82);
  CWDecoder::setAdaptiveLearning(false);
  int32_t slots[16]={};
  CWDecoder::processI2S32(slots,8); publishState();
  a=CWDecoder::getState();
  assert(!a.adaptiveLearning);
  assert(a.learningApplied); // frozen profile remains in use
  CWDecoder::resetAdaptiveLearning();
  CWDecoder::processI2S32(slots,8); publishState();
  a=CWDecoder::getState();
  assert(!a.learningApplied);
  assert(a.learningQuality==0);
  std::puts("PASS adaptive state: persistent seed, live-rate preservation, freeze, reset");
}
