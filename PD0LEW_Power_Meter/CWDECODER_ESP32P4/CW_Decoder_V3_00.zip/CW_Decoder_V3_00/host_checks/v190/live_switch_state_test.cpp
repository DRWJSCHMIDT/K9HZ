#include "CWDecoder.cpp"
#include <cassert>
#include <cstring>
#include <cstdio>
int main(){
  CWDecoder::begin(96000);
  CWDecoder::setManualTone(735.0f);
  CWDecoder::setFilterBandwidthHz(60);
  CWDecoder::setInputLevelPercent(73);
  appendDecoded('C'); appendDecoded('Q');
  const char before[3] = {'C','Q','\0'};
  assert(std::strcmp(decodedText,before)==0);
  CWDecoder::reconfigureInputSampleRate(48000);
  assert(inputRate==48000u && decimation==4u);
  assert(std::strcmp(decodedText,before)==0);
  assert(CWDecoder::manualToneSettingHz()==735.0f);
  assert(CWDecoder::filterBandwidthHz()==60u);
  assert(CWDecoder::inputLevelPercent()==73u);
  CWDecoder::reconfigureInputSampleRate(96000);
  assert(inputRate==96000u && decimation==8u);
  assert(std::strcmp(decodedText,before)==0);
  std::puts("PASS: live rate reconfigure preserves transcript and user decoder settings");
}
