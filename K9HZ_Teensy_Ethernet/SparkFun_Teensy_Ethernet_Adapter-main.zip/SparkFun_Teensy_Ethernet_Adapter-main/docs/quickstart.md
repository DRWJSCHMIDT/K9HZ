<figure markdown>
[![Banner image for the SparkFun Teensy Ethernet Adapter Quickstart Guide](./assets/img/Ethernet_Adapter-Doc_Banner.png){ width="600"}](./assets/img/Ethernet_Adapter-Doc_Banner.png)
</figure>

Welcome to the SparkFun Teensy Ethernet Adapter Quick Start Guide. In this guide we'll go over everything you'll need to use the SparkFun Teensy Ethernet Adapter to connect a Teensy 4.1 development board to the Internet over an Ethernet connection.

## Required Materials

* [SparkFun Teensy Ethernet Adapter](https://www.sparkfun.com/products/29920)
* [Teensy 4.1 (Headers)](https://www.sparkfun.com/teensy-4-1-headers.html) (or other Teensy 4.1)
* [Micro USB Cable](https://www.sparkfun.com/reversible-usb-a-to-reversible-micro-b-cable-0-3m.html)
* [Ethernet Cable](https://www.sparkfun.com/cat-6-cable-3ft.html)
* [Straight Header - Male (PTH, 2mm, 2x3-Pin)](https://www.sparkfun.com/straight-header-male-pth-2mm-2x3-pin.html)
* [Ribbon Cable - 120mm (2mm, 2x3-Pin)](https://www.sparkfun.com/ribbon-cable-120mm-2mm-2x3-pin.html)

### Required Tools

Users will need to solder the 2x3 header to their Teensy 4.1. If you need a soldering iron or solder, check out the following categories on SparkFun:

* [Soldering Irons and Tips](https://www.sparkfun.com/tools/soldering/soldering-irons-and-tips.html)
* [Solder](https://www.sparkfun.com/tools/soldering/solder.html)

If you've never soldered before or would like some tips or a refresher, take a look at our [How to Solder: Through-Hole Soldering](https://learn.sparkfun.com/tutorials/how-to-solder-through-hole-soldering) tutorial.

## Recommended Reading

This guide assumes users are familiar with the [Arduino IDE](https://www.arduino.cc/en/software/#ide) and the [Teensyduino Add-On](https://www.pjrc.com/teensy/teensyduino.html). If you've never worked with Arduino or Teensy before, we recommend reading through these guides:

* [Getting Started with Arduino IDE 2](https://docs.arduino.cc/software/ide-v2/tutorials/getting-started-ide-v2/)
* [Teensyduino Documentation](https://www.pjrc.com/teensy/teensyduino.html)

## Basic Assembly

Start by soldering the 2x3 straight header to the 2x3 PTH connector on the Teensy 4.1. 

<figure markdown>
[![Photo showing 2x3 straight header soldered to the Teensy 4.1](./assets/img/Ethernet_Adapter-2x3_Header_Bottom.jpg){ width="600"}](./assets/img/Ethernet_Adapter-2x3_Header_Bottom.jpg "Click to enlarge")
</figure>

We recommend soldering this header with the longer ends of the pins on the top of the board to make it easy to plug into with the Teensy seated on a breadboard like this:

<figure markdown>
[![Photo showing 2x3 straight header soldered and Teensy mounted on a breadboard.](./assets/img/Ethernet_Adapter-2x3_Header_Top.jpg){ width="600"}](./assets/img/Ethernet_Adapter-2x3_Header_Top.jpg "Click to enlarge")
</figure>

Next, take the 2x3 ribbon cable and connect it to the 2x3 headers on the Teensy 4.1 and Teensy Ethernet Adapter. Take care to align the cable properly to match the pins on the Teensy Ethernet Adapter to the correct pins in the Teensy 4.1:

<figure markdown>
[![Photo showing the SparkFun Teensy Ethernet Adapter connected to the Teensy 4.1 using the 2x3 ribbon cable.](./assets/img/Ethernet_Adapter-Ribbon_Cable.jpg){ width="600"}](./assets/img/Ethernet_Adapter-Ribbon_Cable.jpg "Click to enlarge")
</figure>

Finally, connect the ethernet cable to the RJ45 jack on the Teensy Ethernet Adapter, plug the other end into an Ethernet port either on your router or other Ethernet/Internet hub and then connect the Teensy 4.1 to your computer using a USB MicroB cable. The completed assembly should look similar to the photo below:

<figure markdown>
[![Photo of the completed Teensy Ethernet Adapter assembly](./assets/img/Ethernet_Adapter-Complete_Assembly.jpg){ width="600"}](./assets/img/Ethernet_Adapter-Complete_Assembly.jpg "Click to enlarge")
</figure>

 
## Software Setup - Arduino & Teensyduino

With the hardware assembly complete, let's move on to connecting to the Internet using the [Arduino IDE](https://www.arduino.cc/en/software/). This example requires installation of the Teensyduino add-on and the Ethernet Arduino library. 

### Teensyduino Installation

Using Teensy boards with Arduino requires installing the Teensy boards package also known as Teensyduino. Installing the Teensy boards requires adding a JSON URL to the Arduino "Additional boards manager URLS" field in the Preferences menu. Open the "Preferences" menu by navigating to **File** > **Preferences** and look for the "Additional boards manager URLS" field. Copy the link below into the field and click "Ok":

<code>
https://www.pjrc.com/teensy/package_teensy_index.json
</code>

Next, open to the "Boards Manager" tool on the left side of the Arduino window and search for "Teensy". Install the latest release of the Teensy (for Arduino IDE 2.0.4 or later). This package includes all the board files for Teensy Arduino boards.

### Ethernet Library Installation

If the Ethernet library is not already installed, open the "Library Manager" tool on the left side of the Arduino window and search for "Ethernet". Install the latest release of the Ethernet library.

## Arduino Example

Now that we have everything assembled, connected and installed, let's run a quick test sketch in Arduino to make sure we can connect to the Internet. For this we'll use the **WebClient** example included in the **Ethernet Arduino Library** to connect to a website (in this case, http://www.pjrc.com) and print out . Open the example by navigating to **File** > **Examples** > **Ethernet** > **WebClient**. Select your Board and Port and click the "Upload" button.

After the code finishes compiling and uploading, open the [serial monitor](https://docs.arduino.cc/software/ide-v2/tutorials/ide-v2-serial-monitor/) with the baud set to **9600**. The example attempts to 

<figure markdown>
[![Screenshot of WebClient serial printout](./assets/img/Ethernet_Adapter-Serial.png){ width="600"}](./assets/img/Ethernet_Adapter-Serial.png "Click to enlarge")
</figure>

### Code to Note

You may notice in the screenshot above that the Teensy is connecting to "www.pjrc.com" instead of "www.google.com". The code defaults to use DNS to connect to a website here:

``` c++
//IPAddress server(74,125,232,128);  // numeric IP for Google (no DNS)
char server[] = "www.google.com";    // name address for Google (using DNS)
```

You can enter any full web address here so we changed it to PJRC's website. Alternatively, you can uncomment the <code>IPAddress server ();</code> line and comment out the <code>char server[] = "www.google.com";</code> to connect directly to an IP address and bypass DNS to reduce the size of the sketch.