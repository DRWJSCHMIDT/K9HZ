#include "CWDecoder.cpp"
#include <cassert>
#include <iostream>
int main() {
 CWDecoder::setInputLevelPercent(7);CWDecoder::setAutoTone(true);CWDecoder::begin();
 const char* pattern="1010100011101110111000101010000000";
 uint32_t rng=12345;unsigned sample=0;int32_t slots[960];
 for(int block=0;block<12000;block++) {
  for(int i=0;i<480;i++,sample++) {
   double t=sample/96000.0;int unit=int((t+0.42)/0.06)%int(strlen(pattern));
   rng=rng*1664525u+1013904223u;float noise=(float(rng>>8)/16777216.0f*2-1)*250;
   float amplitude=t>30?600:1000;
   int16_t v=int16_t((t>=2 && pattern[unit]=='1'?amplitude*sin(2*3.141592653589793*713*t):0)+noise);
   slots[2*i]=slots[2*i+1]=int32_t(v)*65536;
  }
  CWDecoder::processI2S32(slots,480);
 }
 std::cout<<decodedText<<"\n";
 assert(decodedCharacters>70 && automaticRelocks==0 && acquisitionComplete);
 assert(strstr(decodedText,"SOS SOS SOS SOS")!=nullptr);
 std::cout<<"PASS: noisy SOS with initial silence and fade, no unnecessary automatic reset\n";
}
