/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_Print.h"
#include "PSWR_State.h"
#include <math.h>

//
//-----------------------------------------------------------------------------
//      Convert mW to dBm x 10 safely.
//-----------------------------------------------------------------------------
//
int16_t db10_from_mw(double mw)
{
  if (!isfinite(mw) || mw <= 1.0e-12)
    return -1200;                    // -120.0 dBm display/calculation floor

  double value = 100.0 * log10(mw); // 10 x dBm = 100 x log10(mW)
  if (value > 32767.0) value = 32767.0;
  if (value < -32768.0) value = -32768.0;
  return (int16_t)lround(value);
}

//
//-----------------------------------------------------------------------------
//      Format SWR into lcd_buf
//-----------------------------------------------------------------------------
//
static void format_swr_value(double value)
{
  if (!isfinite(value) || value < 1.0) value = 1.0;

  if (value < 2.0)
  {
    const uint16_t scaled = (uint16_t)(value * 100.0 + 0.5);
    snprintf(lcd_buf, sizeof(lcd_buf), "%u.%02u", scaled / 100, scaled % 100);
  }
  else if (value <= 10.0)
  {
    const uint16_t scaled = (uint16_t)(value * 10.0 + 0.5);
    snprintf(lcd_buf, sizeof(lcd_buf), " %u.%01u", scaled / 10, scaled % 10);
  }
  else if (value <= 9999.0)
  {
    snprintf(lcd_buf, sizeof(lcd_buf), "%4u", (uint16_t)(value + 0.5));
  }
  else
  {
    snprintf(lcd_buf, sizeof(lcd_buf), "9999");
  }
}

// Measurement/USB SWR remains the original calculated one.
void print_swr(void)
{
  format_swr_value(swr_avg);
}

// LCD-only SWR returns to 1.00 with no RF unless a latched alarm is holding the last value.
void print_swr_display(void)
{
  format_swr_value(display_swr);
}


//
//-----------------------------------------------------------------------------
//      Print dBm, accepts 10x dBm input value, 
//      returns string in lcd_buf
//-----------------------------------------------------------------------------
//
void print_dbm(int16_t db10m)
{
  // Use 32 bits so INT16_MIN can be negated safely.
  int32_t magnitude = db10m;
  if (magnitude < 0) magnitude = -magnitude;

  const uint16_t whole = (uint16_t)(magnitude / 10);
  const uint8_t tenths = (uint8_t)(magnitude % 10);

  if (db10m <= -100)
    snprintf(lcd_buf, sizeof(lcd_buf), "-%2u.%1udBm", whole, tenths);
  else if (db10m < 0)
    snprintf(lcd_buf, sizeof(lcd_buf), " -%1u.%1udBm", whole, tenths);
  else
    snprintf(lcd_buf, sizeof(lcd_buf), "%3u.%1udBm", whole, tenths);
}


//
//-----------------------------------------------------------------------------
//      Print Power, input value is in milliWatts, 
//      returns string in lcd_buf
//-----------------------------------------------------------------------------
//
void print_p_mw(double pwr)
{
  // V3.3.5+ uses a milliwatt display floor. Legacy uW EEPROM values are
  // normalized by sanitizeSettings(), so the live formatter only needs mW+
  // units and can no longer unexpectedly fall back to uW/pW/nW.
  int8_t range = 0;  // 0=mW, 1=W, 2=kW, 3=MW, 4=GW
  uint8_t offs = 0;
  const char *indicator[] = { "mW", "W", "kW", "MW", "GW" };

  if (!isfinite(pwr) || pwr < 0.0) pwr = 0.0;

  if ((R.low_power_floor == FLOOR_TEN_mW && pwr < 10.0) ||
      (R.low_power_floor != FLOOR_TEN_mW && pwr < 1.0))
  {
    snprintf(lcd_buf, sizeof(lcd_buf), "  0 mW");
    return;
  }

  double p = pwr;
  while (p >= 1000.0 && range < 4)
  {
    p /= 1000.0;
    range++;
  }

  // Keep the established six-character alignment for Watts.
  if (range == 1)
  {
    lcd_buf[0] = ' ';
    offs = 1;
  }

  // 9.995 rather than 10.00 gives the expected decimal round-up boundary.
  if      (p >= 99.95) snprintf(lcd_buf + offs, sizeof(lcd_buf) - offs,
                               " %3lu%s", (unsigned long)lround(p), indicator[range]);
  else if (p >= 9.995) snprintf(lcd_buf + offs, sizeof(lcd_buf) - offs,
                               "%2.01f%s", p, indicator[range]);
  else                 snprintf(lcd_buf + offs, sizeof(lcd_buf) - offs,
                               "%1.02f%s", p, indicator[range]);

  if (strlen(lcd_buf) > 6) lcd_buf[6] = '\0';
}
