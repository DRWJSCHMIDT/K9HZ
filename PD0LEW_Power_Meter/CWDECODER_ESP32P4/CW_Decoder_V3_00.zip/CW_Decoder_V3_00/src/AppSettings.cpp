#include "AppSettings.h"

#include <Preferences.h>
#include <math.h>

namespace {

Preferences prefs;
bool ready = false;
bool fadingAssistValue=true;  // V2.29: FADING ASSIST is permanently ON.
uint8_t cwTypeValue=0, farnsworthSpacingValue=20;
bool monitorFilteredValue = false;
bool autoToneValue = true;
uint16_t autoToneResponseMsValue = 500;  // V1.93 normal AUTO tracking time constant
bool autoLevelValue = false;
bool weakSignalValue = false;
float manualToneHzValue = 700.0f;
uint8_t scopeZoomIndexValue = 0;
uint8_t scopeTimeIndexValue = 1;

uint8_t brightnessValue = 100;
uint16_t screensaverValue = 0;
uint16_t filterValue = 40;
uint8_t textColorValue = 0;  // 0 = white
uint8_t headphoneVolumeValue = 65;
bool sampleRate96Value = true;  // 96 kHz remains the V1.80-compatible default
bool adaptiveLearningValue = true;
float learnedMarkRatioValue = 0.0f;
float learnedGapRatioValue = 0.0f;
uint8_t learnedQualityValue = 0;
uint8_t inputGainIndexValue = 0;  // legacy only; V1.23 fixes codec at -6 dB
uint8_t decoderInputLevelValue = 100;
int8_t decoderInputTrimDbValue = 0;

bool validScreensaver(uint16_t v) {
  return v == 0 || v == 1 || v == 5 || v == 10 || v == 30 || v == 60;
}

bool validFilter(uint16_t v) {
  return v == 30 || v == 40 || v == 60 || v == 80 || v == 120;
}

bool validAutoToneResponse(uint16_t v) {
  return v == 150 || v == 500 || v == 1000 || v == 2000;
}

}  // namespace

namespace AppSettings {

void begin() {
  if (ready) return;
  prefs.begin("cwdec17s2", false);

  brightnessValue = prefs.getUChar("bright", 100);
  if (brightnessValue < 10 || brightnessValue > 100) brightnessValue = 100;

  screensaverValue = prefs.getUShort("saver", 0);
  if (!validScreensaver(screensaverValue)) screensaverValue = 0;

  filterValue = prefs.getUShort("filter", 40);
  if (!validFilter(filterValue)) filterValue = 40;

  textColorValue = prefs.getUChar("txtcolor", 0);
  if (textColorValue > 5) textColorValue = 0;

  headphoneVolumeValue = prefs.getUChar("hpvol", 65);
  if (headphoneVolumeValue > 100) headphoneVolumeValue = 65;

  // V1.90 sample-rate test selector. Default is 96 kHz so an upgrade from
  // V1.80 boots with the exact same audio rate until the user changes it.
  sampleRate96Value = prefs.getBool("sr96", true);

  // V1.91 adaptive timing profile. Ratios are normalized to the current dot
  // duration, so the profile remains useful when the next station changes WPM.
  adaptiveLearningValue = prefs.getBool("learnon", true);
  learnedMarkRatioValue = prefs.getFloat("lmark", 0.0f);
  learnedGapRatioValue = prefs.getFloat("lgap", 0.0f);
  learnedQualityValue = prefs.getUChar("lqual", 0);
  if (!isfinite(learnedMarkRatioValue) || learnedMarkRatioValue < 1.40f || learnedMarkRatioValue > 2.80f) learnedMarkRatioValue = 0.0f;
  if (!isfinite(learnedGapRatioValue) || learnedGapRatioValue < 1.20f || learnedGapRatioValue > 3.40f) learnedGapRatioValue = 0.0f;
  if (learnedQualityValue > 100 || (learnedMarkRatioValue == 0.0f && learnedGapRatioValue == 0.0f)) learnedQualityValue = 0;

  // V1.23: the codec itself is fixed at -6 dB for maximum ADC headroom.
  inputGainIndexValue = 0;
  decoderInputLevelValue = prefs.getUChar("inlevel", 100);
  if (decoderInputLevelValue < 1 || decoderInputLevelValue > 100) decoderInputLevelValue = 100;

  // Keep the old decoder trim key only
  // for backward compatibility, but force runtime use to 0 dB.
  decoderInputTrimDbValue = 0;

  monitorFilteredValue = prefs.getBool("hpfilter", false);
  autoToneValue = prefs.getBool("atone", true);
  autoToneResponseMsValue = prefs.getUShort("atrespm", 500);
  if (!validAutoToneResponse(autoToneResponseMsValue)) autoToneResponseMsValue = 500;
  autoLevelValue = prefs.getBool("alevel", false);
  weakSignalValue = prefs.getBool("weak", false);
  manualToneHzValue = prefs.getFloat("mtone", 700.0f);
  scopeZoomIndexValue = prefs.getUChar("zoom", 0);
  scopeTimeIndexValue = prefs.getUChar("time", 1);
  if (!isfinite(manualToneHzValue) || manualToneHzValue < 300 || manualToneHzValue > 1000) manualToneHzValue = 700;
  if (scopeZoomIndexValue > 2) scopeZoomIndexValue = 0;
  if (scopeTimeIndexValue > 2) scopeTimeIndexValue = 1;
  if (weakSignalValue) autoLevelValue = false;

  // V2.29: Always run the proven fading tracker. Disregard any older saved
  // OFF value so firmware updates boot with FADING ASSIST enabled.
  fadingAssistValue=true;
  cwTypeValue=prefs.getUChar("cwtype",0);
  // V2.29: legacy saved CW modes 2/3/4 are no longer selectable.
  // Normalize once in Preferences so the safe STANDARD value survives reboot.
  if(cwTypeValue>1){cwTypeValue=0;prefs.putUChar("cwtype",0);}
  farnsworthSpacingValue=prefs.getUChar("fwspace",20);
  if(farnsworthSpacingValue!=15 && farnsworthSpacingValue!=20 && farnsworthSpacingValue!=30)farnsworthSpacingValue=20;
  ready = true;
}

bool monitorFiltered() { return monitorFilteredValue; }
void setMonitorFiltered(bool value) {
  if (monitorFilteredValue == value) return;
  monitorFilteredValue = value;
  if (ready) prefs.putBool("hpfilter", value);
}

bool fadingAssist(){return true;}
// Keep this old API for callers built with earlier headers. It cannot
// disable fading assistance; no flash writes or decoder resets are needed.
void setFadingAssist(bool /*value*/){ fadingAssistValue=true; }
uint8_t cwType(){return cwTypeValue;}
void setCwType(uint8_t value){
  if(value>1)value=0;
  if(cwTypeValue==value)return;
  cwTypeValue=value;if(ready)prefs.putUChar("cwtype",value);
}
uint8_t farnsworthSpacing(){return farnsworthSpacingValue;}
void setFarnsworthSpacing(uint8_t value){
  if(value!=15 && value!=20 && value!=30)value=20;
  if(farnsworthSpacingValue==value)return;
  farnsworthSpacingValue=value;if(ready)prefs.putUChar("fwspace",value);
}

bool autoTone() { return autoToneValue; }
void setAutoTone(bool value) {
  if (autoToneValue == value) return;
  autoToneValue = value;
  if (ready) prefs.putBool("atone", value);
}

uint16_t autoToneResponseMs() { return autoToneResponseMsValue; }
void setAutoToneResponseMs(uint16_t ms) {
  if (!validAutoToneResponse(ms)) ms = 500;
  if (autoToneResponseMsValue == ms) return;
  autoToneResponseMsValue = ms;
  if (ready) prefs.putUShort("atrespm", autoToneResponseMsValue);
}

bool autoLevel() { return autoLevelValue; }
void setAutoLevel(bool value) {
  if (autoLevelValue == value) return;
  autoLevelValue = value;
  if (ready) prefs.putBool("alevel", value);
}

bool weakSignal() { return weakSignalValue; }
void setWeakSignal(bool value) {
  if (weakSignalValue == value) return;
  weakSignalValue = value;
  if (ready) prefs.putBool("weak", value);
}

float manualToneHz() { return manualToneHzValue; }
void setManualToneHz(float value) {
  if (!isfinite(value) || value < 300 || value > 1000) value = 700;
  if (manualToneHzValue == value) return;
  manualToneHzValue = value;
  if (ready) prefs.putFloat("mtone", value);
}

uint8_t scopeZoomIndex() { return scopeZoomIndexValue; }
void setScopeZoomIndex(uint8_t value) {
  if (value > 2) value = 0;
  if (scopeZoomIndexValue == value) return;
  scopeZoomIndexValue = value;
  if (ready) prefs.putUChar("zoom", value);
}

uint8_t scopeTimeIndex() { return scopeTimeIndexValue; }
void setScopeTimeIndex(uint8_t value) {
  if (value > 2) value = 1;
  if (scopeTimeIndexValue == value) return;
  scopeTimeIndexValue = value;
  if (ready) prefs.putUChar("time", value);
}

uint8_t brightnessPercent() {
  return brightnessValue;
}

void setBrightnessPercent(uint8_t percent) {
  if (percent < 1) percent = 1;
  if (percent > 100) percent = 100;
  brightnessValue = percent;
  if (ready) prefs.putUChar("bright", brightnessValue);
}

uint16_t screensaverMinutes() {
  return screensaverValue;
}

void setScreensaverMinutes(uint16_t minutes) {
  if (!validScreensaver(minutes)) minutes = 0;
  screensaverValue = minutes;
  if (ready) prefs.putUShort("saver", screensaverValue);
}

uint16_t filterBandwidthHz() {
  return filterValue;
}

void setFilterBandwidthHz(uint16_t hz) {
  if (!validFilter(hz)) hz = 40;
  filterValue = hz;
  if (ready) prefs.putUShort("filter", filterValue);
}

uint8_t textColorIndex() {
  return textColorValue;
}

void setTextColorIndex(uint8_t index) {
  if (index > 5) index = 0;
  textColorValue = index;
  if (ready) prefs.putUChar("txtcolor", textColorValue);
}

uint8_t headphoneVolumePercent() {
  return headphoneVolumeValue;
}

void setHeadphoneVolumePercent(uint8_t percent) {
  if (percent > 100) percent = 100;
  headphoneVolumeValue = percent;
  if (ready) prefs.putUChar("hpvol", headphoneVolumeValue);
}


uint32_t audioSampleRateHz() {
  return sampleRate96Value ? 96000U : 48000U;
}

void setAudioSampleRateHz(uint32_t hz) {
  const bool use96 = (hz != 48000U);
  if (sampleRate96Value == use96) return;
  sampleRate96Value = use96;
  if (ready) prefs.putBool("sr96", sampleRate96Value);
}

bool adaptiveLearning() { return adaptiveLearningValue; }
void setAdaptiveLearning(bool enabled) {
  if (adaptiveLearningValue == enabled) return;
  adaptiveLearningValue = enabled;
  if (ready) prefs.putBool("learnon", enabled);
}

float learnedMarkThresholdRatio() { return learnedMarkRatioValue; }
float learnedLetterGapRatio() { return learnedGapRatioValue; }
uint8_t learnedProfileQuality() { return learnedQualityValue; }

void setLearnedProfile(float markThresholdRatio, float letterGapRatio, uint8_t quality) {
  if (!isfinite(markThresholdRatio) || markThresholdRatio < 1.40f || markThresholdRatio > 2.80f) markThresholdRatio = 0.0f;
  if (!isfinite(letterGapRatio) || letterGapRatio < 1.20f || letterGapRatio > 3.40f) letterGapRatio = 0.0f;
  if (quality > 100) quality = 100;
  if (markThresholdRatio == 0.0f && letterGapRatio == 0.0f) quality = 0;
  const bool changed = fabsf(markThresholdRatio - learnedMarkRatioValue) >= 0.01f ||
                       fabsf(letterGapRatio - learnedGapRatioValue) >= 0.01f ||
                       quality != learnedQualityValue;
  learnedMarkRatioValue = markThresholdRatio;
  learnedGapRatioValue = letterGapRatio;
  learnedQualityValue = quality;
  if (ready && changed) {
    prefs.putFloat("lmark", learnedMarkRatioValue);
    prefs.putFloat("lgap", learnedGapRatioValue);
    prefs.putUChar("lqual", learnedQualityValue);
  }
}

void clearLearnedProfile() {
  learnedMarkRatioValue = 0.0f;
  learnedGapRatioValue = 0.0f;
  learnedQualityValue = 0;
  if (ready) {
    prefs.remove("lmark");
    prefs.remove("lgap");
    prefs.remove("lqual");
  }
}


uint8_t decoderInputLevelPercent() {
  return decoderInputLevelValue;
}

void setDecoderInputLevelPercent(uint8_t percent) {
  if (percent < 1) percent = 1;
  if (percent > 100) percent = 100;
  decoderInputLevelValue = percent;
  if (ready) prefs.putUChar("inlevel", decoderInputLevelValue);
}

uint8_t inputGainIndex() {
  return inputGainIndexValue;
}

void setInputGainIndex(uint8_t index) {
  if (index > 19) index = 19;
  inputGainIndexValue = index;
  if (ready) prefs.putUChar("ingain", inputGainIndexValue);
}

int8_t decoderInputTrimDb() {
  return decoderInputTrimDbValue;
}

void setDecoderInputTrimDb(int8_t db) {
  if (db < -24) db = -24;
  if (db > 12) db = 12;
  decoderInputTrimDbValue = db;
  if (ready) prefs.putChar("dtrim", decoderInputTrimDbValue);
}

}  // namespace AppSettings
