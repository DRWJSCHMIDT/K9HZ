#include "CWDecoder.cpp"
#include <iostream>
int main(){
 CWDecoder::begin();CWDecoder::setWeakSignal(true);CWDecoder::setAutoTone(true);
 int32_t slots[960]={};CWDecoder::processI2S32(slots,480);
 weakToneLocked=true;detectorToneHz=spectrumPeakHz=400;weakLastToneSample=dspSampleCounter;
#ifdef RECOVERY71
 acquisitionComplete=true; // isolate tone-lock expiry from startup reset
#endif
 unsigned sample=0;
 for(int b=0;b<800;b++) {
  for(int n=0;n<480;n++,sample++) {
   double t=sample/96000.0;int16_t v=int16_t(3000*sin(2*3.141592653589793*750*t));
   slots[2*n]=slots[2*n+1]=int32_t(v)*65536;
  }
  CWDecoder::processI2S32(slots,480);
 }
 std::cout<<"Detector="<<detectorToneHz<<" locked="<<weakToneLocked<<"\n";
 return fabs(detectorToneHz-750)<5?0:1;
}
