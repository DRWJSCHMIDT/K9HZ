Import("env")
from pathlib import Path

# PlatformIO installs lib_deps before the SCons build. Patch only the one
# revision-sensitive DSI PHY clock selector in Arduino_GFX. Waveshare's current
# rev3.x DSI adapter leaves this field at 0 so ESP-IDF selects the proper source.
libdeps = Path(env.subst("$PROJECT_LIBDEPS_DIR")) / env.subst("$PIOENV")
candidates = [
    libdeps / "GFX Library for Arduino" / "src" / "databus" / "Arduino_ESP32DSIPanel.cpp",
    libdeps / "Arduino_GFX" / "src" / "databus" / "Arduino_ESP32DSIPanel.cpp",
]

src = next((p for p in candidates if p.exists()), None)
if src is None:
    print("[patch_gfx_rev3] Arduino_GFX source not present yet; PlatformIO may install it after configuration.")
else:
    text = src.read_text(encoding="utf-8")
    old = ".phy_clk_src = MIPI_DSI_PHY_CLK_SRC_DEFAULT,"
    new = ".phy_clk_src = (mipi_dsi_phy_pllref_clock_source_t)0, // rev3.x: same value as Espressif/Waveshare C examples, explicitly typed for C++"
    if old in text:
        src.write_text(text.replace(old, new, 1), encoding="utf-8")
        print(f"[patch_gfx_rev3] Patched DSI PHY clock source in {src}")
    elif new in text:
        print("[patch_gfx_rev3] DSI PHY clock patch already applied")
    else:
        print("[patch_gfx_rev3] WARNING: expected DSI PHY clock line not found")
