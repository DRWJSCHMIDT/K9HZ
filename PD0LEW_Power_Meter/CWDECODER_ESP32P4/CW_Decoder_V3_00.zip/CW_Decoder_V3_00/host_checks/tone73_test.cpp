#include "CWDecoder.cpp"
#include <cassert>
#include <iostream>
unsigned sample=0;
void feed(float hz,int blocks){
 int32_t slots[960];
 for(int b=0;b<blocks;b++) {
  for(int n=0;n<480;n++,sample++) {
   int16_t v=int16_t(3000*sin(2*3.141592653589793*hz*sample/96000.0));
   slots[2*n]=slots[2*n+1]=int32_t(v)*65536;
  }
  CWDecoder::processI2S32(slots,480);
 }
}
int main(){
 CWDecoder::setAutoTone(true);CWDecoder::begin();acquisitionComplete=true;
 feed(713,80);float initial=detectorToneHz;
 feed(625,40);float transient=detectorToneHz;
 feed(713,60);float recovered=detectorToneHz;
 feed(750,800);float moved=detectorToneHz;
 std::cout<<"initial="<<initial<<" gap interferer="<<transient<<" restored="<<recovered<<" station change="<<moved<<"\n";
 CWDecoder::setManualTone(713);feed(625,80);
 assert(fabs(detectorToneHz-713)<0.01);
 CWDecoder::setAutoTone(true);feed(625,80);
 assert(fabs(detectorToneHz-625)<3);
 return fabs(initial-713)<3 && fabs(transient-713)<3 && fabs(recovered-713)<3 && fabs(moved-750)<3 ? 0:1;
}
