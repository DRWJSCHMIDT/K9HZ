import os
import csv
import shutil
import esptool

Import("env")

# Bootloader location is fixed per chip family — not part of the partition table
_BOOTLOADER_OFFSETS = {
    "esp32":   0x1000,
    "esp32s2": 0x1000,
    "esp32s3": 0x0,
    "esp32c2": 0x0,
    "esp32c3": 0x0,
    "esp32c6": 0x0,
    "esp32h2": 0x0,
}

CHIP = env.BoardConfig().get("build.mcu")
BOOTLOADER_OFFSET = _BOOTLOADER_OFFSETS.get(CHIP)
if BOOTLOADER_OFFSET is None:
    raise RuntimeError(
        f"Unknown chip '{CHIP}' — add bootloader offset to _BOOTLOADER_OFFSETS"
    )
PARTITIONS_OFFSET = 0x8000

PROJECT_DIR = env["PROJECT_DIR"]
BUILD_DIR   = env.subst("$BUILD_DIR")
PIOENV      = env["PIOENV"]
PROG_BIN    = env.subst("$BUILD_DIR/${PROGNAME}.bin")

PARTITIONS_CSV = os.path.join(
    PROJECT_DIR, env.GetProjectOption("board_build.partitions")
)

BOOTLOADER_BIN = os.path.join(BUILD_DIR, "bootloader.bin")
PARTITIONS_BIN = os.path.join(BUILD_DIR, "partitions.bin")
FIRMWARE_BIN   = os.path.join(BUILD_DIR, "firmware.bin")
LITTLEFS_BIN   = os.path.join(BUILD_DIR, "littlefs.bin")

try:
    VERSION = env.GetProjectOption("custom_version")
except Exception:
    raise RuntimeError(
        "Firmware naming failed: 'custom_version' is not defined in the "
        "active PlatformIO environment."
    )

BASE_NAME    = f"{PIOENV}{VERSION}"
FIRMWARE_DIR = os.path.join(PROJECT_DIR, "firmware")
MERGED_OUT   = os.path.join(FIRMWARE_DIR, f"{BASE_NAME}-full.bin")
os.makedirs(FIRMWARE_DIR, exist_ok=True)


def parse_partition_offsets(csv_path):
    """Return offsets keyed by both partition name and subtype.

    Subtype is the reliable key (factory/ota_0/spiffs are standard) since
    partition names vary across CSVs (e.g. ``app0`` vs ``ota_0``).
    """
    by_name = {}
    by_subtype = {}
    with open(csv_path, "r") as f:
        for row in csv.reader(f):
            if not row or row[0].strip().startswith("#"):
                continue
            cells = [c.strip() for c in row]
            if len(cells) < 4 or not cells[3]:
                continue
            name, _ptype, subtype, offset = cells[0], cells[1], cells[2], cells[3]
            try:
                value = int(offset, 0)
            except ValueError:
                continue
            if name:
                by_name[name] = value
            if subtype:
                by_subtype[subtype] = value
    return by_name, by_subtype


def merge_firmware(source, target, env):
    print("BEGIN POST-BUILD SCRIPT")

    # pre_build.py removes littlefs.bin to force a rebuild every run
    if not os.path.exists(LITTLEFS_BIN):
        print("[INFO] Building littlefs filesystem image...")
        ret = env.Execute(
            f'"{env.subst("$PYTHONEXE")}" -m platformio run --target buildfs '
            f'--environment {PIOENV}'
        )
        if ret != 0:
            raise RuntimeError(f"buildfs failed with exit code {ret}")

    by_name, by_subtype = parse_partition_offsets(PARTITIONS_CSV)
    factory_offset  = by_subtype.get("factory", by_subtype.get("ota_0"))
    littlefs_offset = by_subtype.get("spiffs", by_name.get("littlefs"))
    if factory_offset is None or littlefs_offset is None:
        raise RuntimeError(
            f"Required partitions (factory/ota_0 app, spiffs/littlefs data) "
            f"not found in {PARTITIONS_CSV}"
        )

    for label, path in [
        ("bootloader", BOOTLOADER_BIN),
        ("partitions", PARTITIONS_BIN),
        ("firmware",   FIRMWARE_BIN),
        ("littlefs",   LITTLEFS_BIN),
    ]:
        if not os.path.exists(path):
            raise RuntimeError(f"{label} binary not found: {path}")

    components = [
        (f"0x{BOOTLOADER_OFFSET:X}", BOOTLOADER_BIN),
        (f"0x{PARTITIONS_OFFSET:X}", PARTITIONS_BIN),
        (f"0x{factory_offset:X}",    FIRMWARE_BIN),
        (f"0x{littlefs_offset:X}",   LITTLEFS_BIN),
    ]
    args = ["--chip", CHIP, "merge-bin", "--output", MERGED_OUT]
    for offset, binfile in components:
        args.extend([offset, binfile])

    print(f"[INFO] Merging binaries into {MERGED_OUT}...")
    esptool.main(args)
    print(f"[INFO] Merged binary: {MERGED_OUT} ({os.path.getsize(MERGED_OUT)} bytes)")
    print("END POST-BUILD SCRIPT")


def copy_merged_firmware(source, target, env):
    # MERGED_OUT is already written into FIRMWARE_DIR by merge_firmware.
    # Just copy the app and filesystem images alongside it.
    artifacts = [
        (FIRMWARE_BIN, f"{BASE_NAME}-app.bin"),
        (LITTLEFS_BIN, f"{BASE_NAME}-fs.bin"),
    ]
    for src, name in artifacts:
        if not os.path.exists(src):
            raise RuntimeError(f"Cannot copy missing artifact: {src}")
        dest = os.path.join(FIRMWARE_DIR, name)
        shutil.copy2(src, dest)
        print(f"Copied {name} -> {dest}")


def erase_and_flash(source, target, env):
    speed = env.GetProjectOption("upload_speed", "921600")
    esptool.main(["--chip", CHIP, "--baud", speed, "erase-flash"])
    esptool.main(["--chip", CHIP, "--baud", speed, "write-flash", "0x0", MERGED_OUT])


# littlefs_bin is NOT listed as a SCons source — SCons would fail if it checked
# for it before the action runs (pre_build.py deletes it). AlwaysBuild ensures
# the merge runs every build regardless of output file timestamp.
merge_target = env.Command(MERGED_OUT, [PROG_BIN], merge_firmware)
env.AlwaysBuild(merge_target)
env.Default(merge_target)
env.AddPostAction(merge_target, copy_merged_firmware)

env.AddCustomTarget(
    name="upload_merged",
    dependencies=[merge_target],
    actions=[erase_and_flash],
    title="Merge and Flash",
    description="Builds, merges, and flashes to 0x0"
)
