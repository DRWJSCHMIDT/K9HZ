#pragma once
#include <Preferences.h>
#include <cstring>

struct AppPrefs {
    char meterHost[64] = "powermeter.local";
    char ssid[64] = "";
    char password[64] = "";

    bool darkTheme = true;
    bool peakHold = true;
    uint8_t backlightPct = 100;

    //bool touchCalValid = false;
    //float touchCalAx = 0.0f;
    //float touchCalBx = 0.0f;
    //float touchCalCx = 0.0f;
    //float touchCalAy = 0.0f;
    //float touchCalBy = 0.0f;
    //float touchCalCy = 0.0f;
};

extern AppPrefs gPrefs;

void prefsLoad();
void prefsSave();