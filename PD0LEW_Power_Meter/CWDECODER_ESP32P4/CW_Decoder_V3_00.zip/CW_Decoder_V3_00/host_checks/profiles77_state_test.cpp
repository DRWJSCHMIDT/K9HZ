#include "CWDecoder.cpp"
#include <cassert>
#include <iostream>
void block(){int32_t zero[2]={};CWDecoder::processI2S32(zero,1);}
int main(){
 CWDecoder::setCwType(0);CWDecoder::begin();assert(dotMs==60);appendDecoded('K');
 CWDecoder::setCwType(3);block();assert(dotMs==120 && decodedText[0]=='K');
 CWDecoder::setCwType(4);block();assert(dotMs==30 && decodedText[0]=='K');
 CWDecoder::setCwType(2);CWDecoder::setFarnsworthSpacing(30);block();assert(activeCwType==2&&activeSpacing==30);
 CWDecoder::setWeakSignal(true);block();assert(dotMs==100&&weakActive);
 CWDecoder::setCwType(1);block();assert(dotMs==100&&weakActive);
 CWDecoder::setWeakSignal(false);block();assert(dotMs==60&&!weakActive);
 CWDecoder::setCwType(99);CWDecoder::setFarnsworthSpacing(99);block();assert(activeCwType==0&&activeSpacing==20);
 CWDecoder::setFadingAssist(true);block();assert(fadeAssistActive);
 puts("PASS: profile switching, starting speeds, transcript preservation, weak timing, invalid setting fallback, fading toggle");
}
