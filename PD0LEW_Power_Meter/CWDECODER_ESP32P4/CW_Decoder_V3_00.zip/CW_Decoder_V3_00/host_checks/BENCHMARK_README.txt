CW Decoder V2.22 - repeatable WAV benchmark

Purpose
-------
Run the SAME receiver recording through a decoder build repeatedly instead of
judging changes only by ear. The trace records detected mark/gap durations,
confidence, thresholds, dot/dash decisions, whether each mark was allowed to
train the Guenther model, and final character hypotheses.

Input
-----
PCM 16-bit WAV, mono or stereo, at 48 kHz or 96 kHz (the two firmware input
rates). The benchmark uses HAND-SENT + FADING ASSIST and the left input.

Linux
-----
cd host_checks
./build_wav_benchmark.sh
./wav_benchmark recording.wav trace.csv
python3 benchmark_compare.py ./wav_benchmark recording.wav reference.txt trace.csv

Windows (MinGW g++)
-------------------
cd host_checks
build_wav_benchmark.bat
wav_benchmark.exe recording.wav trace.csv
python benchmark_compare.py wav_benchmark.exe recording.wav reference.txt trace.csv

Output
------
The executable prints one JSON line with transcript, WPM, detected tone,
Guenther acquisition state, automatic sending-style estimate, rejected timing
outliers and recovery counters. benchmark_compare.py computes character error
rate (CER) and word error rate (WER) against a reference text.
