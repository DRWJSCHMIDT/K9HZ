#include "wifi_mgr.h"
#include "prefs.h"

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <cstring>

extern void uiShowConnecting(const char* msg);
static const char SAVED_HTML[] PROGMEM = R"html(
<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Saved</title>
<style>
  body{font-family:sans-serif;background:#1a1a2e;color:#fff;display:flex;
       justify-content:center;align-items:center;min-height:100vh}
  .box{background:#0f3460;border-radius:12px;padding:32px;text-align:center}
  h2{color:#00d4aa;margin-bottom:12px}
  p{color:#a0a0a0}
</style></head><body><div class="box">
<h2>Saved!</h2><p>Restarting display&hellip;</p>
</div></body></html>
)html";

static String htmlEscape(String s) {
    s.replace("&", "&amp;");
    s.replace("<", "&lt;");
    s.replace(">", "&gt;");
    s.replace("\"", "&quot;");
    return s;
}

static String makePortalHtml() {
    int n = WiFi.scanNetworks();

    String networks;
    if (n <= 0) {
        networks = "<div class=\"net-empty\">No networks found</div>";
    } else {
        for (int i = 0; i < n; i++) {
            String ssidRaw = WiFi.SSID(i);
            if (ssidRaw.length() == 0) continue;

            String ssid = htmlEscape(ssidRaw);

            networks += "<button class=\"net\" type=\"button\" onclick=\"pickSSID('";
            networks += ssid;
            networks += "')\">";
            networks += "<span class=\"net-name\">";
            networks += ssid;
            networks += "</span><span class=\"net-rssi\">";
            networks += String(WiFi.RSSI(i));
            networks += " dBm</span></button>";
        }
    }

    return String(R"html(
<!DOCTYPE html><html><head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PowerMeter Display Setup</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:sans-serif;background:#1a1a2e;color:#fff;display:flex;
       justify-content:center;align-items:flex-start;padding:20px;min-height:100vh}
  .box{background:#0f3460;border-radius:12px;padding:24px;width:100%;max-width:420px}
  h2{color:#00d4aa;margin-bottom:20px;font-size:1.2rem}
  label{display:block;margin-bottom:4px;font-size:.85rem;color:#a0a0a0}
  input{width:100%;padding:10px;border-radius:6px;border:1px solid #4361ee;
        background:#16213e;color:#fff;margin-bottom:16px;font-size:1rem}
  button{width:100%;padding:12px;background:#4361ee;color:#fff;border:none;
         border-radius:6px;font-size:1rem;cursor:pointer}
  button:active{background:#5a7aff}

  .net-list{margin-bottom:16px;display:flex;flex-direction:column;gap:8px}
  .net{display:flex;justify-content:space-between;align-items:center;
       background:#16213e;border:1px solid #4361ee;text-align:left}
  .net:active,.net.selected{background:#243b80}
  .net-name{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  .net-rssi{font-size:.8rem;color:#a0a0a0;margin-left:12px;white-space:nowrap}
  .net-empty{background:#16213e;border:1px solid #4361ee;border-radius:6px;
             padding:10px;color:#a0a0a0;margin-bottom:16px}
</style>
<script>
function pickSSID(ssid) {
  document.querySelector('[name=ssid]').value = ssid;

  document.querySelectorAll('.net').forEach(function(b) {
    b.classList.remove('selected');
    if (b.querySelector('.net-name').textContent === ssid) {
      b.classList.add('selected');
    }
  });
}
</script>
</head><body><div class="box">
<h2>PowerMeter Display Setup</h2>
<form method="POST" action="/save">

  <label>Found WiFi Networks</label>
  <div class="net-list">
)html") + networks + String(R"html(
  </div>

  <label>WiFi Network (SSID)</label>
  <input name="ssid" type="text" placeholder="Your WiFi network name" required autocomplete="off">

  <label>Password</label>
  <input name="pass" type="password" placeholder="WiFi password" autocomplete="off">

  <label>Meter Address (IP or hostname)</label>
  <input name="host" type="text" value="powermeter.local" placeholder="powermeter.local">

  <button type="submit">Save &amp; Connect</button>
</form>
</div></body></html>
)html");
}

bool wifiConnect() {
    if (strlen(gPrefs.ssid) == 0) return false;

    uiShowConnecting("Connecting to WiFi…");

    WiFi.mode(WIFI_STA);
    WiFi.begin(gPrefs.ssid, gPrefs.password);

    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
        delay(200);
    }

    return WiFi.status() == WL_CONNECTED;
}

void startCaptivePortal() {
    const char* apName = "RemoteMeter-Setup";
    // uiShowPortalActive(apName);

    WiFi.mode(WIFI_AP_STA);
    WiFi.softAP(apName);
    delay(200);

    DNSServer dns;
    dns.start(53, "*", IPAddress(192, 168, 4, 1));

    WebServer server(80);
    bool saved = false;

    auto servePage = [&]() {
        server.send(200, "text/html", makePortalHtml());
    };

    server.onNotFound(servePage);
    server.on("/", HTTP_GET, servePage);
    server.on("/generate_204", HTTP_GET, servePage);
    server.on("/hotspot-detect.html", HTTP_GET, servePage);

    server.on("/save", HTTP_POST, [&]() {
        String ssid = server.arg("ssid");
        String pass = server.arg("pass");
        String host = server.arg("host");

        if (ssid.length() == 0) {
            server.sendHeader("Location", "/");
            server.send(302);
            return;
        }

        strlcpy(gPrefs.ssid, ssid.c_str(), sizeof(gPrefs.ssid));
        strlcpy(gPrefs.password, pass.c_str(), sizeof(gPrefs.password));

        strlcpy(
            gPrefs.meterHost,
            host.length() > 0 ? host.c_str() : "powermeter.local",
            sizeof(gPrefs.meterHost)
        );

        prefsSave();

        server.send_P(200, "text/html", SAVED_HTML);
        saved = true;
    });

    server.begin();

    unsigned long rebootAt = 0;

    while (true) {
        dns.processNextRequest();
        server.handleClient();

        if (saved && rebootAt == 0) {
            rebootAt = millis() + 2000;
        }

        if (rebootAt && millis() >= rebootAt) {
            ESP.restart();
        }

        delay(2);
    }
}