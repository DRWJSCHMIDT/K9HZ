#include "MonitorFilter.h"
#include <cassert>
#include <cmath>
#include <cstdio>
double gain(unsigned bw,bool weak,float hz) {
 MonitorFilter f;double sum=0;
 for(int n=0;n<192000;n++) {
  if(n%256==0)f.configure(750,bw,weak,true);
  int16_t x=int16_t(std::lround(2000*std::sin(6.28318530718*hz*n/96000)));
  auto y=f.process(x);if(n>=96000)sum+=double(y)*y;
 }
 return std::sqrt(sum/96000)/std::sqrt(2000000.0);
}
int main(){
 for(unsigned bw:{30,40,60,80,120}) {
  double pass=gain(bw,false,750),reject=gain(bw,false,1250);
  printf("%u Hz pass %.4f off500 %.4f\n",bw,pass,reject);
  assert(pass>0.97&&pass<1.03&&reject<0.07);
 }
 double pass=gain(24,true,750),off=gain(24,true,830);
 printf("weak pass %.4f off80 %.4f\n",pass,off);assert(pass>0.95&&pass<1.05&&off<0.02);
 MonitorFilter f;f.configure(750,40,false,false);
 for(int n=-32768;n<32768;n+=7)assert(f.process(n)==n);
 f.configure(750,40,false,true);for(int i=0;i<10000;i++)f.process(1000);
 f.configure(750,40,false,false);for(int i=0;i<2000;i++)f.process(1000);
 assert(f.process(-1234)==-1234);
 puts("PASS: passband, off-tone rejection, exact BEFORE passthrough, switch return");
}
