#include "CWUI.h"

#include "AudioEngine.h"
#include "CWDecoder.h"
#include "Transcript.h"
#include "DisplayColors.h"
#include "DisplaySetup.h"
#include "DisplayPower.h"
#include "AppSettings.h"
#include "TuningGuide.h"
#include "AdaptiveLearner.h"

#include <Arduino.h>
#include <math.h>
#include <lvgl.h>

// V2.18 test: user-supplied 32 px monospaced font for decoded CW text.
// Add a subtle +1 px letter spacing for improved readability.
extern "C" {
extern const lv_font_t droid_sans_mono_32;
}

namespace {

lv_obj_t *statusLabel = nullptr;
lv_obj_t *radioModeLabel = nullptr;
lv_obj_t *toneValue = nullptr;
lv_obj_t *wpmValue = nullptr;
lv_obj_t *snrValue = nullptr;
lv_obj_t *levelValue = nullptr;
lv_obj_t *decodedViewport = nullptr;
lv_obj_t *decodedValue = nullptr;
lv_obj_t *decodedSpacer = nullptr;
lv_obj_t *tuningPanel = nullptr;
lv_obj_t *guideAction = nullptr;
TuningGuide tuningGuide;
lv_obj_t *spectrumCanvas = nullptr;
lv_obj_t *waterfallCanvas = nullptr;
lv_obj_t *tunedMarker = nullptr;
lv_obj_t *peakMarker = nullptr;
lv_obj_t *filterLeftMarker = nullptr;
lv_obj_t *filterRightMarker = nullptr;
lv_obj_t *tuneMinLabel = nullptr;
lv_obj_t *tuneMidLabel = nullptr;
lv_obj_t *tuneMaxLabel = nullptr;
lv_obj_t *autoButton = nullptr;
lv_obj_t *autoButtonLabel = nullptr;
lv_obj_t *autoLevelButton = nullptr;
lv_obj_t *autoLevelButtonLabel = nullptr;

// V1.25 experimental front-panel decoder auto-level.  This deliberately
// controls only the decoder copy; headphone audio remains untouched.
bool autoInputLevel = false;
float autoLevelSnrFiltered = 21.0f;
bool autoLevelSnrValid = false;
uint32_t lastAutoLevelAdjust = 0;

// Safe setup overlay.  V1.23 SAFE2 never calls lv_screen_load(); it only
// shows and hides full-screen child panels on top of the proven V1.6 screen.
lv_obj_t *setupOverlay = nullptr;
lv_obj_t *setupHomePage = nullptr;
lv_obj_t *displaySetupPage = nullptr;
lv_obj_t *filterSetupPage = nullptr;
lv_obj_t *scopeSetupPage = nullptr;
bool cwTypesOpen = false;
lv_obj_t *setupMenuButtons[7] = {};
lv_obj_t *setupTitle = nullptr, *setupDescription = nullptr, *cwTypeFooter = nullptr;
uint32_t lastLearningSaveMs = 0, lastLearningSavedRevision = 0;
// V1.92 SAFE: do not create extra LVGL learning controls.  The CW TYPE page
// reuses its existing footer label for status, preserving the proven object tree.
CWDecoderState lastLearningUiState{};
bool haveLearningUiState = false;
void refreshSetupMenu();
lv_obj_t *weakModeButton = nullptr;
lv_obj_t *weakModeLabel = nullptr;
bool lastWeakMode = false;
lv_obj_t *textColorSetupPage = nullptr;
lv_obj_t *headphoneSetupPage = nullptr;
lv_obj_t *textColorButtons[6] = {};
lv_obj_t *textColorPreview = nullptr;
lv_obj_t *brightnessValueLabel = nullptr;
lv_obj_t *screensaverValueLabel = nullptr;
lv_obj_t *filterButtons[5] = {};
lv_obj_t *headphoneVolumeSlider = nullptr;
lv_obj_t *headphoneVolumeValueLabel = nullptr;
lv_obj_t *inputGainSlider = nullptr;
lv_obj_t *inputGainValueLabel = nullptr;
lv_obj_t *adcPeakValueLabel = nullptr;
lv_obj_t *decoderSignalValueLabel = nullptr;
lv_obj_t *setupSnrValueLabel = nullptr;
lv_obj_t *audioOverLed = nullptr;
lv_obj_t *sampleRateButtonLabel = nullptr;
lv_obj_t *autoToneResponseButtonLabel = nullptr;

// V1.93 SAFE AUDIO: entering AUDIO LEVELS must not synchronously update
// sliders or touch the codec from inside an LVGL touch callback.  Defer the
// page sync until the normal UI update loop and suppress slider callbacks
// during programmatic value changes.
bool audioPageProgrammaticUpdate = false;
bool headphoneRefreshPending = false;
uint32_t headphoneRefreshDueMs = 0;
uint32_t lastAudioMetricsUiMs = 0;
uint32_t audioOverHoldUntilMs = 0;
bool audioOverVisualState = false;
constexpr float AUDIO_OVER_THRESHOLD_DBFS = -3.0f;
constexpr uint32_t AUDIO_OVER_HOLD_MS = 800;

// Heavy live sample-rate reconfiguration is also deferred out of the LVGL
// button callback so the event stack is fully unwound before I2S/SGTL changes.
bool sampleRateSwitchPending = false;
uint32_t pendingSampleRateHz = 0;

// V1.95: never hide/show setup pages from inside an LVGL CLICKED callback.
// Navigation is requested by the callback and serviced after lv_timer_handler()
// has returned, from CWUI::update(). This preserves the proven one-screen
// architecture and avoids modifying the active/pressed object tree mid-event.
enum class SetupNav : uint8_t {
  None, OpenHome, Home, Display, Filter, TextColor, Audio, Scope, CwType, Close
};
SetupNav pendingSetupNav = SetupNav::None;
uint32_t pendingSetupNavDueMs = 0;

void requestSetupNav(SetupNav nav) {
  pendingSetupNav = nav;
  // Give LVGL one scheduler/touch cycle after CLICKED before changing the
  // full-screen child visibility. This also makes GT911 release bounce harmless.
  pendingSetupNavDueMs = millis() + 20U;
}

// AUTO TONE response setting is applied instantly to the decoder, but its NVS
// write is deferred out of the touch callback.
bool autoToneResponseSavePending = false;
uint16_t pendingAutoToneResponseMs = 500;

// Slider callbacks only capture the requested values.  Codec/NVS work is
// serviced later from update(), never from the LVGL touch-event stack.
bool headphoneVolumeApplyPending = false;
bool headphoneVolumeSavePending = false;
uint8_t pendingHeadphoneVolume = 65;
bool inputGainSavePending = false;
uint8_t pendingInputGain = 100;
bool autoLevelOffSavePending = false;
bool monitorFilterSavePending = false;
bool pendingMonitorFiltered = false;

uint32_t lastUpdate = 0;
uint32_t lastTextUpdate = 0;
uint32_t lastScopeUpdate = 0;
Transcript transcript;
lv_obj_t *pageLabel = nullptr;
lv_obj_t *pageUpButton = nullptr;
lv_obj_t *pageDownButton = nullptr;
lv_obj_t *printStatus = nullptr;
bool relockNoticeShown = false;


constexpr int TUNE_PANEL_X = (1280 - 565) / 2;
constexpr int TUNE_PANEL_Y = 62;
constexpr int TUNE_PANEL_W = 565;
constexpr int TUNE_PANEL_H = 150;
constexpr int TUNE_CANVAS_X = 10;
constexpr int TUNE_SPECTRUM_Y = 28;
constexpr int TUNE_SPECTRUM_W = 545;
constexpr int TUNE_SPECTRUM_H = 38;
constexpr int TUNE_WATERFALL_Y = 69;
constexpr int TUNE_WATERFALL_W = 545;
constexpr int TUNE_WATERFALL_H = 52;
constexpr int TUNE_SCALE_Y = 120;
const float zoomSpans[] = {100.0f, 50.0f, 200.0f};
const uint32_t waterfallPeriods[] = {20, 40, 80};
uint8_t zoomIndex = 0, timeBaseIndex = 1;
lv_obj_t *zoomButtonLabel = nullptr, *timeBaseButtonLabel = nullptr;

// 320 pixels keeps the RGB565 row stride naturally aligned on ESP32/LVGL.
static uint8_t spectrumCanvasBuffer[TUNE_SPECTRUM_W * TUNE_SPECTRUM_H * 2];
// Display-only envelope smoothing; never fed back into the audio decoder.
static float spectrumTraceLevel[TUNE_SPECTRUM_W] = {};
bool spectrumTraceValid = false;
uint32_t spectrumTraceLastMs = 0;

static uint8_t waterfallCanvasBuffer[TUNE_WATERFALL_W * TUNE_WATERFALL_H * 2];
float tuneWindowMinHz = 650.0f;
float tuneWindowMaxHz = 750.0f;
bool tuneWindowInitialized = false;
uint32_t lastWaterfallLineMs = 0;
float waterfallTrackedPeakHz = 750.0f;
bool waterfallPeakValid = false;

void setLabelIfChanged(lv_obj_t *label, const char *text) {
  if (!label || !text) return;
  if (strcmp(lv_label_get_text(label), text) != 0) lv_label_set_text(label, text);
}

// V1.95: keep lightweight LVGL memory diagnostics around setup navigation.
// Keep a small serial breadcrumb around setup navigation so real hardware can
// confirm free LVGL memory and fragmentation without adding any UI objects.
void logLvglMemory(const char *where) {
  lv_mem_monitor_t mon{};
  lv_mem_monitor(&mon);
  Serial.printf("[LVGL] %s total=%u free=%u used=%u%% frag=%u%% biggest=%u\n",
                where ? where : "?",
                static_cast<unsigned>(mon.total_size),
                static_cast<unsigned>(mon.free_size),
                static_cast<unsigned>(mon.used_pct),
                static_cast<unsigned>(mon.frag_pct),
                static_cast<unsigned>(mon.free_biggest_size));
  if (mon.total_size < 100000U) {
    Serial.println("[LVGL] WARNING: runtime pool is still near the 64 kB default; check -DLV_MEM_SIZE=131072");
  }
  if (mon.free_size < 16384U || mon.free_biggest_size < 8192U) {
    Serial.println("[LVGL] WARNING: low/fragmented UI heap - setup navigation may be unstable");
  }
}

// V2.07: one global disabled-button appearance across the complete UI.
// Use the neutral grey style approved for Pg Up / Pg Down everywhere a
// control is unavailable.  Apply it to DEFAULT, PRESSED and CHECKED states so
// a checkable control (for example AUTO LEVEL or a selected filter preset)
// can never remain blue while it is disabled.
void setButtonAvailableVisual(lv_obj_t *button, bool enabled) {
  if (!button) return;
  if (enabled) lv_obj_add_flag(button, LV_OBJ_FLAG_CLICKABLE);
  else lv_obj_clear_flag(button, LV_OBJ_FLAG_CLICKABLE);

  const lv_color_t bgDefault = enabled ? lv_color_hex(0x0D1924) : lv_color_hex(0x303030);
  const lv_color_t bgPressed = enabled ? lv_color_hex(0x142634) : lv_color_hex(0x303030);
  const lv_color_t bgChecked = enabled ? lv_color_hex(0x0F3B55) : lv_color_hex(0x303030);
  const lv_color_t bgCheckedPressed = enabled ? lv_color_hex(0x164C69) : lv_color_hex(0x303030);
  const lv_color_t borderDefault = enabled ? lv_color_hex(0x2A4A5E) : lv_color_hex(0x555555);
  const lv_color_t borderActive = enabled ? DisplayColors::BrightCyan() : lv_color_hex(0x555555);

  lv_obj_set_style_bg_color(button, bgDefault, LV_STATE_DEFAULT);
  lv_obj_set_style_bg_color(button, bgPressed, LV_STATE_PRESSED);
  lv_obj_set_style_bg_color(button, bgChecked, LV_STATE_CHECKED);
  lv_obj_set_style_bg_color(button, bgCheckedPressed,
                            LV_STATE_CHECKED | LV_STATE_PRESSED);

  lv_obj_set_style_border_color(button, borderDefault,
                                LV_STATE_DEFAULT);
  lv_obj_set_style_border_color(button, borderActive,
                                LV_STATE_PRESSED);
  lv_obj_set_style_border_color(button, borderActive,
                                LV_STATE_CHECKED);
  lv_obj_set_style_border_color(button, borderActive,
                                LV_STATE_CHECKED | LV_STATE_PRESSED);

  lv_obj_t *label = lv_obj_get_child(button, 0);
  if (label) {
    lv_obj_set_style_text_color(label,
        enabled ? DisplayColors::White() : lv_color_hex(0x9A9A9A), 0);
  }
}

// Page navigation now uses exactly the same global enabled/disabled styling.
void setPageNavButtonVisual(lv_obj_t *button, bool enabled) {
  setButtonAvailableVisual(button, enabled);
}


void formatAutoToneResponse(char *text, size_t size, uint16_t ms) {
  if (!text || size == 0) return;
  switch (ms) {
    case 150:  snprintf(text, size, "AUTO TONE 0.15 s"); break;
    case 1000: snprintf(text, size, "AUTO TONE 1.0 s"); break;
    case 2000: snprintf(text, size, "AUTO TONE 2.0 s"); break;
    case 500:
    default:   snprintf(text, size, "AUTO TONE 0.5 s"); break;
  }
}

lv_obj_t *makeLabel(lv_obj_t *parent, const char *text, int x, int y, int w,
                    const lv_font_t *font, lv_color_t color) {
  lv_obj_t *label = lv_label_create(parent);
  setLabelIfChanged(label, text);
  lv_obj_set_pos(label, x, y);
  lv_obj_set_width(label, w);
  lv_obj_set_style_text_font(label, font, 0);
  lv_obj_set_style_text_color(label, color, 0);
  lv_obj_set_style_text_opa(label, LV_OPA_COVER, 0);
  return label;
}

lv_obj_t *makePanel(lv_obj_t *parent, int x, int y, int w, int h) {
  lv_obj_t *panel = lv_obj_create(parent);
  lv_obj_set_pos(panel, x, y);
  lv_obj_set_size(panel, w, h);
  lv_obj_set_style_bg_color(panel, DisplayColors::PanelBackground(), 0);
  lv_obj_set_style_bg_opa(panel, LV_OPA_COVER, 0);
  lv_obj_set_style_border_color(panel, DisplayColors::PanelBorder(), 0);
  lv_obj_set_style_border_width(panel, 1, 0);
  lv_obj_set_style_radius(panel, 10, 0);
  lv_obj_set_style_pad_all(panel, 0, 0);
  lv_obj_clear_flag(panel, LV_OBJ_FLAG_SCROLLABLE);
  return panel;
}

void styleIndustrialSlider(lv_obj_t *slider, lv_color_t accent) {
  if (!slider) return;

  // Compact instrument-style control: a slim 10 px rail with a 28 px round
  // handle. This keeps the value easy to grab without the oversized bar look.
  lv_obj_set_style_bg_color(slider, lv_color_hex(0x162936), LV_PART_MAIN);
  lv_obj_set_style_bg_opa(slider, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_border_color(slider, lv_color_hex(0x355063), LV_PART_MAIN);
  lv_obj_set_style_border_width(slider, 1, LV_PART_MAIN);
  lv_obj_set_style_radius(slider, LV_RADIUS_CIRCLE, LV_PART_MAIN);

  lv_obj_set_style_bg_color(slider, accent, LV_PART_INDICATOR);
  lv_obj_set_style_bg_opa(slider, LV_OPA_COVER, LV_PART_INDICATOR);
  lv_obj_set_style_radius(slider, LV_RADIUS_CIRCLE, LV_PART_INDICATOR);

  lv_obj_set_style_bg_color(slider, DisplayColors::White(), LV_PART_KNOB);
  lv_obj_set_style_bg_opa(slider, LV_OPA_COVER, LV_PART_KNOB);
  lv_obj_set_style_border_color(slider, accent, LV_PART_KNOB);
  lv_obj_set_style_border_width(slider, 2, LV_PART_KNOB);
  lv_obj_set_style_radius(slider, LV_RADIUS_CIRCLE, LV_PART_KNOB);
  lv_obj_set_style_pad_all(slider, 9, LV_PART_KNOB);
}

lv_obj_t *makeThinLine(lv_obj_t *parent, int x, int y, int w, int h, lv_color_t color, lv_opa_t opa = LV_OPA_COVER) {
  lv_obj_t *line = lv_obj_create(parent);
  lv_obj_set_pos(line, x, y);
  lv_obj_set_size(line, w, h);
  lv_obj_set_style_bg_color(line, color, 0);
  lv_obj_set_style_bg_opa(line, opa, 0);
  lv_obj_set_style_border_width(line, 0, 0);
  lv_obj_set_style_radius(line, 0, 0);
  lv_obj_clear_flag(line, LV_OBJ_FLAG_SCROLLABLE);
  return line;
}

// V2.06: restrained receiver-style section rule for the main screen.
// LVGL 9.5 compatibility: use supported LV_OPA_50 (LV_OPA_55 does not exist).
// Reuse the same single LVGL object as the old separator (no extra UI objects),
// but use a shorter inset rail, rounded ends and one consistent subdued tone.
// This visually separates the header, receiver/scope and control sections
// without the harsh full-width horizontal bars used by earlier versions.
lv_obj_t *makeSectionRule(lv_obj_t *parent, int y) {
  constexpr int kInset = 38;
  constexpr int kWidth = 1280 - (2 * kInset);
  lv_obj_t *rule = makeThinLine(parent, kInset, y, kWidth, 2,
                                lv_color_hex(0x2A4A5E), LV_OPA_50);
  lv_obj_set_style_radius(rule, LV_RADIUS_CIRCLE, 0);
  return rule;
}

void makeFlatMetric(lv_obj_t *parent, const char *caption, int x, int w,
                    lv_color_t accent, lv_obj_t **valueTarget) {
  // V1.38 RADIO PRO: cleaner receiver-style metric. The value color is enough to
  // identify the channel; remove the individual colored underline bars.
  lv_obj_t *cap = makeLabel(parent, caption, x, 72, w, &lv_font_montserrat_26,
                            DisplayColors::TextSecondary());
  lv_obj_set_style_text_align(cap, LV_TEXT_ALIGN_CENTER, 0);
  *valueTarget = makeLabel(parent, "--", x, 112, w, &lv_font_montserrat_32, accent);
  lv_obj_set_style_text_align(*valueTarget, LV_TEXT_ALIGN_CENTER, 0);
}

lv_obj_t *makeMetricCard(lv_obj_t *parent, const char *caption, int x, int w,
                         lv_color_t accent, lv_obj_t **valueTarget) {
  lv_obj_t *card = makePanel(parent, x, 64, w, 150);
  lv_obj_set_style_bg_color(card, lv_color_hex(0x0B151E), 0);
  lv_obj_set_style_border_color(card, lv_color_hex(0x28465C), 0);
  lv_obj_set_style_border_width(card, 1, 0);
  lv_obj_set_style_radius(card, 12, 0);

  lv_obj_t *accentBar = lv_obj_create(card);
  lv_obj_set_pos(accentBar, 0, 0);
  lv_obj_set_size(accentBar, w, 4);
  lv_obj_set_style_bg_color(accentBar, accent, 0);
  lv_obj_set_style_bg_opa(accentBar, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(accentBar, 0, 0);
  lv_obj_set_style_radius(accentBar, 0, 0);
  lv_obj_clear_flag(accentBar, LV_OBJ_FLAG_SCROLLABLE);

  lv_obj_t *cap = makeLabel(card, caption, 12, 14, w - 24, &lv_font_montserrat_26,
                            DisplayColors::TextSecondary());
  lv_obj_set_style_text_align(cap, LV_TEXT_ALIGN_CENTER, 0);

  *valueTarget = makeLabel(card, "--", 8, 66, w - 16, &lv_font_montserrat_32, accent);
  lv_obj_set_style_text_align(*valueTarget, LV_TEXT_ALIGN_CENTER, 0);
  return card;
}

lv_obj_t *makeButton(lv_obj_t *parent, const char *text, int x, int w, lv_event_cb_t cb,
                     bool checkable = false) {
  lv_obj_t *button = lv_button_create(parent);
  lv_obj_set_pos(button, x, 646);
  lv_obj_set_size(button, w, 64);
  lv_obj_set_style_pad_hor(button, 8, 0);

  // V1.6: Rotator/PVC-style controls: dark raised face, clear border and a
  // visibly deeper pressed state.  The selected AUTO TONE state is highlighted
  // independently so its mode remains obvious at a glance.
  lv_obj_set_style_bg_color(button, lv_color_hex(0x0D1924), LV_STATE_DEFAULT);
  lv_obj_set_style_bg_color(button, lv_color_hex(0x142634), LV_STATE_PRESSED);
  lv_obj_set_style_bg_color(button, lv_color_hex(0x0F3B55), LV_STATE_CHECKED);
  lv_obj_set_style_bg_color(button, lv_color_hex(0x164C69), LV_STATE_CHECKED | LV_STATE_PRESSED);

  lv_obj_set_style_border_width(button, 2, LV_STATE_DEFAULT);
  lv_obj_set_style_border_color(button, lv_color_hex(0x2A4A5E), LV_STATE_DEFAULT);
  lv_obj_set_style_border_color(button, DisplayColors::BrightCyan(), LV_STATE_PRESSED);
  lv_obj_set_style_border_color(button, DisplayColors::BrightCyan(), LV_STATE_CHECKED);

  lv_obj_set_style_radius(button, 11, LV_STATE_DEFAULT);

  if (checkable) lv_obj_add_flag(button, LV_OBJ_FLAG_CHECKABLE);
  lv_obj_add_event_cb(button, cb, LV_EVENT_CLICKED, nullptr);

  lv_obj_t *label = lv_label_create(button);
  setLabelIfChanged(label, text);
  lv_obj_set_style_text_font(label, &lv_font_montserrat_26, 0);
  lv_obj_set_style_text_color(label, DisplayColors::White(), LV_STATE_DEFAULT);
  lv_obj_set_style_text_color(label, DisplayColors::White(), LV_STATE_PRESSED);
  lv_obj_center(label);
  return button;
}

int transcriptGlyphWidth(char c) {
  // Use the nominal glyph advance; reserve a small margin once per line,
  // instead of charging an extra two pixels for every character.
  // Match the +1 px LVGL letter spacing used by decodedValue.  Counting the
  // spacing here is slightly conservative at the final glyph and prevents
  // the transcript wrapper from ever drawing past the right edge.
  return lv_font_get_glyph_width(&droid_sans_mono_32, static_cast<uint8_t>(c), 0) + 1;
}

void refreshTranscript() {
  if (!decodedValue || !pageLabel) return;
  setLabelIfChanged(decodedValue, transcript.current());
  char label[64];
  snprintf(label, sizeof(label), "PAGE %u/%u   %s", unsigned(transcript.selected() + 1),
           unsigned(transcript.count()), transcript.live() ? "LIVE" : "HISTORY");
  setLabelIfChanged(pageLabel, label);
  lv_obj_t *buttons[] = {pageUpButton, pageDownButton};
  const bool enabled[] = {transcript.selected() > 0, !transcript.live()};
  static int lastEnabled[2] = {-1, -1};
  for (int i = 0; i < 2; ++i) {
    if (lastEnabled[i] == int(enabled[i])) continue;
    lastEnabled[i] = int(enabled[i]);
    setPageNavButtonVisual(buttons[i], enabled[i]);
  }
}

void pageUpEvent(lv_event_t *) { transcript.previous(); refreshTranscript(); }
void pageDownEvent(lv_event_t *) { transcript.next(); refreshTranscript(); }
void liveEvent(lv_event_t *) { transcript.goLive(); refreshTranscript(); }
void relockEvent(lv_event_t *) {
  CWDecoder::relock();
  setLabelIfChanged(printStatus, "RELOCK requested");
  relockNoticeShown = true;
}

void saveToneSettings() {
  AppSettings::setManualToneHz(CWDecoder::manualToneSettingHz());
  AppSettings::setAutoTone(CWDecoder::autoToneEnabled());
}

void autoToneEvent(lv_event_t *) {
  CWDecoder::setAutoTone(!CWDecoder::autoToneEnabled());
  saveToneSettings();
}

void autoLevelEvent(lv_event_t *) {
  if(CWDecoder::weakSignalEnabled()) return;
  autoInputLevel = !autoInputLevel;
  AppSettings::setAutoLevel(autoInputLevel);
  const CWDecoderState c = CWDecoder::getState();
  autoLevelSnrFiltered = c.snrDb;
  autoLevelSnrValid = false;
  lastAutoLevelAdjust = millis();

  // When leaving AUTO, keep the level it found as the new manual starting point.
  if (!autoInputLevel) {
    const uint8_t level = CWDecoder::inputLevelPercent();
    AppSettings::setDecoderInputLevelPercent(level);
    Serial.printf("[AUTO LEVEL] OFF, saved decoder input level %u%%\n",
                  static_cast<unsigned>(level));
  } else {
    Serial.printf("[AUTO LEVEL] ON, target signal -50..-42 dBFS, start %u%%\n",
                  static_cast<unsigned>(CWDecoder::inputLevelPercent()));
  }
}

void toneMinusEvent(lv_event_t *) {
  CWDecoder::adjustManualTone(-1.0f);
  saveToneSettings();
}

void tonePlusEvent(lv_event_t *) {
  CWDecoder::adjustManualTone(+1.0f);
  saveToneSettings();
}

void clearEvent(lv_event_t *) {
  CWDecoder::clearText();
  transcript.clear();
  refreshTranscript();
}


// -----------------------------------------------------------------------------
// Safe setup overlay helpers
// -----------------------------------------------------------------------------

lv_obj_t *makeSetupButton(lv_obj_t *parent, const char *text, int x, int y,
                          int w, int h, lv_event_cb_t cb, void *userData = nullptr) {
  lv_obj_t *button = lv_button_create(parent);
  lv_obj_set_pos(button, x, y);
  lv_obj_set_size(button, w, h);
  lv_obj_set_style_bg_color(button, lv_color_hex(0x0D1924), LV_STATE_DEFAULT);
  lv_obj_set_style_bg_color(button, lv_color_hex(0x142634), LV_STATE_PRESSED);
  lv_obj_set_style_border_width(button, 2, LV_STATE_DEFAULT);
  lv_obj_set_style_border_color(button, lv_color_hex(0x2A4A5E), LV_STATE_DEFAULT);
  lv_obj_set_style_border_color(button, DisplayColors::BrightCyan(), LV_STATE_PRESSED);
  lv_obj_set_style_radius(button, 12, LV_STATE_DEFAULT);
  lv_obj_add_event_cb(button, cb, LV_EVENT_CLICKED, userData);

  lv_obj_t *label = lv_label_create(button);
  setLabelIfChanged(label, text);
  lv_obj_set_style_text_font(label, &lv_font_montserrat_28, 0);
  lv_obj_set_style_text_color(label, DisplayColors::White(), 0);
  lv_obj_center(label);
  return button;
}

lv_obj_t *makeFullPage(lv_obj_t *parent) {
  lv_obj_t *page = lv_obj_create(parent);
  lv_obj_set_pos(page, 0, 0);
  lv_obj_set_size(page, 1280, 720);
  lv_obj_set_style_bg_color(page, DisplayColors::Background(), 0);
  lv_obj_set_style_bg_opa(page, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(page, 0, 0);
  lv_obj_set_style_pad_all(page, 0, 0);
  lv_obj_clear_flag(page, LV_OBJ_FLAG_SCROLLABLE);
  return page;
}

void showSetupPage(lv_obj_t *page) {
  if (!setupHomePage || !displaySetupPage || !filterSetupPage || !textColorSetupPage || !headphoneSetupPage || !page) return;
  lv_obj_add_flag(setupHomePage, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(displaySetupPage, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(filterSetupPage, LV_OBJ_FLAG_HIDDEN);
  if (scopeSetupPage) lv_obj_add_flag(scopeSetupPage, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(textColorSetupPage, LV_OBJ_FLAG_HIDDEN);
  lv_obj_add_flag(headphoneSetupPage, LV_OBJ_FLAG_HIDDEN);
  lv_obj_clear_flag(page, LV_OBJ_FLAG_HIDDEN);
}

void refreshDisplayPage() {
  if (!brightnessValueLabel || !screensaverValueLabel) return;
  char text[32];
  snprintf(text, sizeof(text), "%u %%", static_cast<unsigned>(AppSettings::brightnessPercent()));
  setLabelIfChanged(brightnessValueLabel, text);

  const uint16_t minutes = AppSettings::screensaverMinutes();
  if (minutes == 0) snprintf(text, sizeof(text), "OFF");
  else snprintf(text, sizeof(text), "%u min", static_cast<unsigned>(minutes));
  setLabelIfChanged(screensaverValueLabel, text);
}

void refreshFilterPage() {
  static const uint16_t values[5] = {30, 40, 60, 80, 120};
  const uint16_t selected = AppSettings::filterBandwidthHz();
  const bool weak = CWDecoder::weakSignalEnabled();
  if (weakModeLabel) setLabelIfChanged(weakModeLabel, weak ? "WEAK SIGNAL: ON" : "WEAK SIGNAL: OFF");
  if (weakModeButton) {
    if(weak)lv_obj_add_state(weakModeButton,LV_STATE_CHECKED);
    else lv_obj_remove_state(weakModeButton,LV_STATE_CHECKED);
  }
  for (size_t i = 0; i < 5; ++i) {
    if (!filterButtons[i]) continue;
    setButtonAvailableVisual(filterButtons[i], !weak);
    if (values[i] == selected) lv_obj_add_state(filterButtons[i], LV_STATE_CHECKED);
    else lv_obj_remove_state(filterButtons[i], LV_STATE_CHECKED);
  }
}


lv_color_t incomingTextColor(uint8_t index) {
  switch (index) {
    case 1: return DisplayColors::BrightCyan();
    case 2: return DisplayColors::LightGreen();
    case 3: return DisplayColors::BrightYellow();
    case 4: return DisplayColors::Gold();
    case 5: return DisplayColors::BrightOrange();
    default: return DisplayColors::White();
  }
}

void applyIncomingTextColor() {
  if (!decodedValue) return;
  lv_obj_set_style_text_color(decodedValue,
                              incomingTextColor(AppSettings::textColorIndex()), 0);
}

void refreshTextColorPage() {
  const uint8_t selected = AppSettings::textColorIndex();
  for (uint8_t i = 0; i < 6; ++i) {
    if (!textColorButtons[i]) continue;
    if (i == selected) lv_obj_add_state(textColorButtons[i], LV_STATE_CHECKED);
    else lv_obj_remove_state(textColorButtons[i], LV_STATE_CHECKED);
  }
  if (textColorPreview) {
    lv_obj_set_style_text_color(textColorPreview, incomingTextColor(selected), 0);
  }
}

void textColorPresetEvent(lv_event_t *e) {
  const uintptr_t raw = reinterpret_cast<uintptr_t>(lv_event_get_user_data(e));
  const uint8_t index = static_cast<uint8_t>(raw);
  AppSettings::setTextColorIndex(index);
  applyIncomingTextColor();
  refreshTextColorPage();
}

void textColorPageEvent(lv_event_t *) {
  requestSetupNav(SetupNav::TextColor);
}


void refreshHeadphonePage() {
  if (!headphoneVolumeSlider || !headphoneVolumeValueLabel ||
      !inputGainSlider || !inputGainValueLabel) return;

  // Guard against LVGL versions/configurations that may emit VALUE_CHANGED
  // while a slider is synchronized in software.  Page entry must never
  // cascade into codec I2C or decoder-setting callbacks.
  audioPageProgrammaticUpdate = true;

  const uint8_t volume = AppSettings::headphoneVolumePercent();
  if (lv_slider_get_value(headphoneVolumeSlider) != volume)
    lv_slider_set_value(headphoneVolumeSlider, volume, LV_ANIM_OFF);
  char text[40];
  if (volume == 0) snprintf(text, sizeof(text), "MUTE");
  else snprintf(text, sizeof(text), "%u %%", static_cast<unsigned>(volume));
  setLabelIfChanged(headphoneVolumeValueLabel, text);

  const uint8_t inputLevel = AppSettings::decoderInputLevelPercent();
  if (lv_slider_get_value(inputGainSlider) != inputLevel)
    lv_slider_set_value(inputGainSlider, inputLevel, LV_ANIM_OFF);
  snprintf(text, sizeof(text), "%u %%", static_cast<unsigned>(inputLevel));
  setLabelIfChanged(inputGainValueLabel, text);

  if (sampleRateButtonLabel) {
    snprintf(text, sizeof(text), "SAMPLE %lu kHz",
             static_cast<unsigned long>(AudioEngine::sampleRateHz() / 1000U));
    setLabelIfChanged(sampleRateButtonLabel, text);
  }

  if (autoToneResponseButtonLabel) {
    const uint16_t ms = CWDecoder::autoToneResponseMs();
    formatAutoToneResponse(text, sizeof(text), ms);
    setLabelIfChanged(autoToneResponseButtonLabel, text);
  }

  audioPageProgrammaticUpdate = false;
}

void headphoneVolumeSliderEvent(lv_event_t *e) {
  if (audioPageProgrammaticUpdate || !headphoneVolumeSlider) return;
  const uint8_t value = static_cast<uint8_t>(lv_slider_get_value(headphoneVolumeSlider));

  // Keep the touch callback lightweight. The normal update loop applies the
  // SGTL5000 I2C volume change; on release it also persists the final value.
  pendingHeadphoneVolume = value;
  headphoneVolumeApplyPending = true;
  if (lv_event_get_code(e) == LV_EVENT_RELEASED)
    headphoneVolumeSavePending = true;

  if (headphoneVolumeValueLabel) {
    char text[24];
    if (value == 0) snprintf(text, sizeof(text), "MUTE");
    else snprintf(text, sizeof(text), "%u %%", static_cast<unsigned>(value));
    setLabelIfChanged(headphoneVolumeValueLabel, text);
  }
}

void inputGainSliderEvent(lv_event_t *e) {
  if (audioPageProgrammaticUpdate || !inputGainSlider) return;
  const uint8_t value = static_cast<uint8_t>(lv_slider_get_value(inputGainSlider));

  // Any manual slider movement immediately leaves experimental AUTO LEVEL.
  // Save that state later, outside the LVGL callback.
  if (autoInputLevel) {
    autoInputLevel = false;
    autoLevelOffSavePending = true;
    autoLevelSnrValid = false;
    Serial.println("[AUTO LEVEL] manual slider -> OFF");
  }

  // Decoder-only level after the ADC. Headphone audio is untouched.
  CWDecoder::setInputLevelPercent(value);
  if (inputGainValueLabel) {
    char text[24];
    snprintf(text, sizeof(text), "%u %%", static_cast<unsigned>(value));
    setLabelIfChanged(inputGainValueLabel, text);
  }

  if (lv_event_get_code(e) == LV_EVENT_RELEASED) {
    pendingInputGain = value;
    inputGainSavePending = true;
  }
}

void persistLearningProfile(const CWDecoderState &c, bool force) {
  if (c.learningQuality < AdaptiveLearner::kApplyQuality && !force) return;
  if (c.learnedMarkThresholdRatio <= 0.0f && c.learnedLetterGapRatio <= 0.0f) return;
  const uint32_t now = millis();

  // V1.92 SAFE: all flash/NVS profile writes happen from the normal UI update
  // path, never from inside an LVGL touch event callback.  The first stable
  // profile may be saved after one minute; later saves are rate-limited to
  // once per ten minutes.
  const bool noSavedProfile = AppSettings::learnedProfileQuality() == 0;
  const uint32_t minimumAge = noSavedProfile ? 60000UL : 600000UL;
  if (!force && now - lastLearningSaveMs < minimumAge) return;

  AppSettings::setLearnedProfile(c.learnedMarkThresholdRatio,
                                 c.learnedLetterGapRatio,
                                 c.learningQuality);
  lastLearningSaveMs = now;
  lastLearningSavedRevision = c.learningRevision;
  Serial.printf("[LEARNING] profile saved Q=%u mark=%.2f gap=%.2f\n",
                static_cast<unsigned>(c.learningQuality),
                static_cast<double>(c.learnedMarkThresholdRatio),
                static_cast<double>(c.learnedLetterGapRatio));
}

void refreshLearningFooter(const CWDecoderState &c) {
  if (!cwTypeFooter || !cwTypesOpen) return;
  char info[180];
  if (!c.adaptiveLearning) {
    snprintf(info, sizeof(info),
             "ADAPTIVE LEARNING: FROZEN   |   Profile Q %u%%\n"
             "Learning state is preserved; decoder continues with the stored profile.",
             static_cast<unsigned>(c.learningQuality));
  } else if (c.weakSignal) {
    snprintf(info, sizeof(info),
             "ADAPTIVE LEARNING: PAUSED IN WEAK MODE\n"
             "WEAK keeps its proven independent timing path.");
  } else if (c.learningQuality < AdaptiveLearner::kApplyQuality) {
    snprintf(info, sizeof(info),
             "ADAPTIVE LEARNING: %u%%   |   Samples %u\n"
             "Collecting high-confidence CW timing.",
             static_cast<unsigned>(c.learningQuality),
             static_cast<unsigned>(c.learningSamples));
  } else {
    snprintf(info, sizeof(info),
             "%s   Q %u%%   |   Samples %u\nMARK %.2fx   GAP %.2fx",
             c.learningApplied ? "ADAPTIVE LOCK" : "ADAPTIVE PROFILE",
             static_cast<unsigned>(c.learningQuality),
             static_cast<unsigned>(c.learningSamples),
             static_cast<double>(c.learnedMarkThresholdRatio),
             static_cast<double>(c.learnedLetterGapRatio));
  }
  setLabelIfChanged(cwTypeFooter, info);
}

void headphonePageEvent(lv_event_t *) {
  requestSetupNav(SetupNav::Audio);
}

void setupOpenEvent(lv_event_t *) {
  requestSetupNav(SetupNav::OpenHome);
}

void setupCloseEvent(lv_event_t *) {
  requestSetupNav(SetupNav::Close);
}

void displayPageEvent(lv_event_t *) {
  requestSetupNav(SetupNav::Display);
}

void filterPageEvent(lv_event_t *) {
  requestSetupNav(SetupNav::Filter);
}

void setupHomeEvent(lv_event_t *) {
  requestSetupNav(SetupNav::Home);
}

void brightnessMinusEvent(lv_event_t *) {
  uint8_t v = AppSettings::brightnessPercent();
  v = v <= 10 ? 10 : static_cast<uint8_t>(v - 10);
  AppSettings::setBrightnessPercent(v);
  DisplayPower::setBrightnessPercent(v);
  refreshDisplayPage();
}

void brightnessPlusEvent(lv_event_t *) {
  uint8_t v = AppSettings::brightnessPercent();
  v = v >= 100 ? 100 : static_cast<uint8_t>(v + 10);
  AppSettings::setBrightnessPercent(v);
  DisplayPower::setBrightnessPercent(v);
  refreshDisplayPage();
}

const uint16_t SAVER_VALUES[] = {0, 1, 5, 10, 30, 60};
constexpr size_t SAVER_COUNT = sizeof(SAVER_VALUES) / sizeof(SAVER_VALUES[0]);

void changeScreensaver(int direction) {
  const uint16_t current = AppSettings::screensaverMinutes();
  size_t index = 0;
  for (size_t i = 0; i < SAVER_COUNT; ++i) {
    if (SAVER_VALUES[i] == current) { index = i; break; }
  }
  if (direction < 0) index = index == 0 ? 0 : index - 1;
  else index = index + 1 >= SAVER_COUNT ? SAVER_COUNT - 1 : index + 1;

  AppSettings::setScreensaverMinutes(SAVER_VALUES[index]);
  DisplayPower::setScreensaverMinutes(SAVER_VALUES[index]);
  refreshDisplayPage();
}

void saverMinusEvent(lv_event_t *) { changeScreensaver(-1); }
void saverPlusEvent(lv_event_t *) { changeScreensaver(+1); }

void filterPresetEvent(lv_event_t *e) {
  const uintptr_t raw = reinterpret_cast<uintptr_t>(lv_event_get_user_data(e));
  const uint16_t hz = static_cast<uint16_t>(raw);
  AppSettings::setFilterBandwidthHz(hz);
  CWDecoder::setFilterBandwidthHz(hz);
  refreshFilterPage();
}

void scopePageEvent(lv_event_t *) {
  requestSetupNav(SetupNav::Scope);
}

// Reuse the seven existing Setup buttons instead of building another LVGL
// tree inside the touch callback. Keep the proven display-memory configuration.
void refreshSetupMenu() {
  if(!setupTitle || !setupDescription)return;
  const bool weak=CWDecoder::weakSignalEnabled();
  const uint8_t selected=AppSettings::cwType();
  const char* homeNames[]={"DISPLAY","CW FILTER","TEXT COLOR","AUDIO LEVELS","TUNE","CW TYPE","MAIN SCREEN"};
  const char* typeNames[]={"STANDARD","HAND-SENT","FARNSWORTH","SLOW / QRS","FAST / QRQ","","BACK TO SETUP"};
  const char* descriptions[]={
    "STANDARD: automatic timing for regular on/off Morse.",
    "HAND-SENT: enable FADING ASSIST for adaptive mark / gap timing.",
    "FARNSWORTH: tap again to change the letter / word gap spacing.",
    "SLOW / QRS: starts at 10 WPM, then follows the sender.",
    "FAST / QRQ: starts at 40 WPM. Tested maximum: 50 WPM."
  };
  setLabelIfChanged(setupTitle,cwTypesOpen?"CW TYPE":"SETUP");
  setLabelIfChanged(setupDescription,cwTypesOpen?
      (weak?"WEAK has separate timing. Turn WEAK off to select a CW type.":descriptions[selected]):
      "Display, CW type, filtering, audio and tuning settings");
  for(uint8_t i=0;i<7;++i) {
    auto* button=setupMenuButtons[i];
    const bool unavailable=cwTypesOpen && weak && i<6;
    const char* caption=cwTypesOpen?typeNames[i]:homeNames[i];
    char text[64];
    if(cwTypesOpen && i==2) {
      const unsigned spacing=AppSettings::farnsworthSpacing();
      snprintf(text,sizeof(text),"FARNSWORTH\nGAP x%u.%u",spacing/10,spacing%10);caption=text;
    } else if(cwTypesOpen && i==5)caption=AppSettings::fadingAssist()?"FADING ASSIST: ON":"FADING ASSIST: OFF";
    setLabelIfChanged(lv_obj_get_child(button,0),caption);
    setButtonAvailableVisual(button, !unavailable);
    if (!unavailable) {
      lv_obj_set_style_bg_color(button,
          lv_color_hex(cwTypesOpen && i==selected ? 0x0F3B55 : 0x0D1924),
          LV_PART_MAIN);
    }
  }
  lv_obj_set_pos(setupMenuButtons[6],475,cwTypesOpen?610:465);
  lv_obj_set_size(setupMenuButtons[6],330,cwTypesOpen?76:110);

  // V1.92 SAFE: reuse the existing footer object for adaptive-learning
  // information instead of adding extra buttons/labels to this memory-tight
  // full-screen setup page.  No decoder-state lock is taken in this touch
  // callback; the normal 50 ms update refreshes the live values.
  if (cwTypesOpen) {
    lv_obj_clear_flag(cwTypeFooter, LV_OBJ_FLAG_HIDDEN);
    if (haveLearningUiState) refreshLearningFooter(lastLearningUiState);
    else setLabelIfChanged(cwTypeFooter, "ADAPTIVE LEARNING: STARTING...");
  } else {
    lv_obj_add_flag(cwTypeFooter, LV_OBJ_FLAG_HIDDEN);
  }
}
void cwTypePageEvent(lv_event_t*) {
  requestSetupNav(SetupNav::CwType);
}
void setupMenuEvent(lv_event_t* e) {
  const uint8_t index=static_cast<uint8_t>(reinterpret_cast<uintptr_t>(lv_event_get_user_data(e)));
  if(cwTypesOpen) {
    if(index==6){setupHomeEvent(e);return;}
    if(CWDecoder::weakSignalEnabled())return;
    if(index<5) {
      if(index==2 && AppSettings::cwType()==2) {
        const uint8_t current=AppSettings::farnsworthSpacing();
        const uint8_t next=current==15?20:(current==20?30:15);
        AppSettings::setFarnsworthSpacing(next);CWDecoder::setFarnsworthSpacing(next);
      } else {AppSettings::setCwType(index);CWDecoder::setCwType(index);}
    } else if(index==5) {
      const bool enabled=!AppSettings::fadingAssist();
      AppSettings::setFadingAssist(enabled);CWDecoder::setFadingAssist(enabled);
    }
    refreshSetupMenu();return;
  }
  switch(index) {
    case 0:displayPageEvent(e);break;
    case 1:filterPageEvent(e);break;
    case 2:textColorPageEvent(e);break;
    case 3:headphonePageEvent(e);break;
    case 4:scopePageEvent(e);break;
    case 5:cwTypePageEvent(e);break;
    case 6:setupCloseEvent(e);break;
  }
}
void createSetupHome() {
  setupHomePage=makeFullPage(setupOverlay);
  setupTitle=makeLabel(setupHomePage,"SETUP",40,24,800,&lv_font_montserrat_36,DisplayColors::Gold());
  setupDescription=makeLabel(setupHomePage,"",40,72,1160,&lv_font_montserrat_26,DisplayColors::TextSecondary());
  for(uint8_t i=0;i<7;++i) {
    setupMenuButtons[i]=makeSetupButton(setupHomePage,"",i<6?85+(i%3)*390:475,
        i<6?130+(i/3)*150:465,330,i<6?125:110,setupMenuEvent,reinterpret_cast<void*>(uintptr_t(i)));
    lv_obj_set_style_text_align(lv_obj_get_child(setupMenuButtons[i],0),LV_TEXT_ALIGN_CENTER,0);
  }
  cwTypeFooter=makeLabel(setupHomePage,
      "ADAPTIVE LEARNING: STARTING...",
      70,475,1140,&lv_font_montserrat_24,DisplayColors::TextSecondary());
  lv_obj_set_style_text_align(cwTypeFooter, LV_TEXT_ALIGN_CENTER, 0);
  cwTypesOpen=false;refreshSetupMenu();
}

void createDisplaySetupPage() {
  displaySetupPage = makeFullPage(setupOverlay);
  lv_obj_add_flag(displaySetupPage, LV_OBJ_FLAG_HIDDEN);

  makeLabel(displaySetupPage, "DISPLAY SETUP", 40, 24, 500,
            &lv_font_montserrat_36, DisplayColors::Gold());
  makeLabel(displaySetupPage, "Screensaver dims the backlight to 10%. First touch only wakes it.",
            40, 72, 1160, &lv_font_montserrat_26, DisplayColors::TextSecondary());

  lv_obj_t *brightPanel = makePanel(displaySetupPage, 70, 135, 1140, 175);
  makeLabel(brightPanel, "DISPLAY INTENSITY", 30, 22, 360,
            &lv_font_montserrat_28, DisplayColors::White());
  brightnessValueLabel = makeLabel(brightPanel, "100 %", 450, 53, 240,
                                   &lv_font_montserrat_36, DisplayColors::BrightCyan());
  lv_obj_set_style_text_align(brightnessValueLabel, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_t* brightnessMinusButton = makeSetupButton(brightPanel, "-", 755, 40, 130, 85, brightnessMinusEvent);
  lv_obj_set_style_text_font(lv_obj_get_child(brightnessMinusButton, 0), &lv_font_montserrat_48, 0);
  lv_obj_t* brightnessPlusButton = makeSetupButton(brightPanel, "+", 925, 40, 130, 85, brightnessPlusEvent);
  lv_obj_set_style_text_font(lv_obj_get_child(brightnessPlusButton, 0), &lv_font_montserrat_48, 0);
  makeLabel(brightPanel, "Range 10 - 100%", 30, 82, 360,
            &lv_font_montserrat_26, DisplayColors::TextSecondary());

  lv_obj_t *saverPanel = makePanel(displaySetupPage, 70, 335, 1140, 190);
  makeLabel(saverPanel, "SCREENSAVER", 30, 22, 360,
            &lv_font_montserrat_28, DisplayColors::White());
  screensaverValueLabel = makeLabel(saverPanel, "OFF", 450, 60, 240,
                                    &lv_font_montserrat_36, DisplayColors::BrightCyan());
  lv_obj_set_style_text_align(screensaverValueLabel, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_t* saverMinusButton = makeSetupButton(saverPanel, "-", 755, 48, 130, 85, saverMinusEvent);
  lv_obj_set_style_text_font(lv_obj_get_child(saverMinusButton, 0), &lv_font_montserrat_48, 0);
  lv_obj_t* saverPlusButton = makeSetupButton(saverPanel, "+", 925, 48, 130, 85, saverPlusEvent);
  lv_obj_set_style_text_font(lv_obj_get_child(saverPlusButton, 0), &lv_font_montserrat_48, 0);
  makeLabel(saverPanel, "OFF / 1 / 5 / 10 / 30 / 60 min", 30, 88, 390,
            &lv_font_montserrat_26, DisplayColors::TextSecondary());

  makeSetupButton(displaySetupPage, "BACK TO SETUP", 70, 610, 310, 76, setupHomeEvent);
  makeSetupButton(displaySetupPage, "MAIN SCREEN", 900, 610, 310, 76, setupCloseEvent);
  refreshDisplayPage();
}

void weakModeEvent(lv_event_t *) {
  const bool enabled=!CWDecoder::weakSignalEnabled();
  CWDecoder::setWeakSignal(enabled);
  // The old SNR-targeting auto-gain must not fight the independent noise detector.
  AppSettings::setWeakSignal(enabled);
  if(enabled) {autoInputLevel=false;autoLevelSnrValid=false;AppSettings::setAutoLevel(false);}
  saveToneSettings();
  tuneWindowInitialized=false;
  refreshFilterPage();
}

void createFilterSetupPage() {
  filterSetupPage = makeFullPage(setupOverlay);
  lv_obj_add_flag(filterSetupPage, LV_OBJ_FLAG_HIDDEN);

  makeLabel(filterSetupPage, "CW FILTER SETUP", 40, 24, 500,
            &lv_font_montserrat_36, DisplayColors::Gold());

  static const uint16_t values[5] = {30, 40, 60, 80, 120};
  constexpr int buttonW = 205;
  constexpr int gap = 24;
  int x = 72;
  for (size_t i = 0; i < 5; ++i) {
    char label[24];
    snprintf(label, sizeof(label), "%u Hz", static_cast<unsigned>(values[i]));
    lv_obj_t *button = makeSetupButton(
        filterSetupPage, label, x, 190, buttonW, 110, filterPresetEvent,
        reinterpret_cast<void *>(static_cast<uintptr_t>(values[i])));
    lv_obj_set_style_bg_color(button, lv_color_hex(0x0F3B55), LV_STATE_CHECKED);
    lv_obj_set_style_border_color(button, DisplayColors::BrightCyan(), LV_STATE_CHECKED);
    filterButtons[i] = button;
    x += buttonW + gap;
  }

  makeLabel(filterSetupPage, "30 Hz: strongest selectivity     40 Hz: normal     60 - 120 Hz: more tolerance",
            72, 345, 1136, &lv_font_montserrat_26, DisplayColors::TextSecondary());

  weakModeButton=makeSetupButton(filterSetupPage,"WEAK SIGNAL: OFF",72,420,480,72,weakModeEvent);
  weakModeLabel=lv_obj_get_child(weakModeButton,0);
  lv_obj_set_style_bg_color(weakModeButton,lv_color_hex(0x0F3B55),LV_STATE_CHECKED);
  lv_obj_set_style_border_color(weakModeButton,DisplayColors::BrightCyan(),LV_STATE_CHECKED);
  makeLabel(filterSetupPage,"WEAK: 300-1000 Hz search, 12 Hz low-pass; best for slower CW.",
            72,510,1136,&lv_font_montserrat_26,DisplayColors::TextSecondary());
  makeLabel(filterSetupPage,"Allow tone acquisition. RELOCK searches again. This mode is saved for next boot.",
            72,550,1136,&lv_font_montserrat_26,DisplayColors::TextSecondary());
  makeSetupButton(filterSetupPage, "BACK TO SETUP", 70, 610, 310, 76, setupHomeEvent);
  makeSetupButton(filterSetupPage, "MAIN SCREEN", 900, 610, 310, 76, setupCloseEvent);
  refreshFilterPage();
}


void createTextColorSetupPage() {
  textColorSetupPage = makeFullPage(setupOverlay);
  lv_obj_add_flag(textColorSetupPage, LV_OBJ_FLAG_HIDDEN);

  makeLabel(textColorSetupPage, "INCOMING TEXT COLOR", 40, 24, 650,
            &lv_font_montserrat_36, DisplayColors::Gold());
  makeLabel(textColorSetupPage, "Choose the color used for decoded CW text.",
            40, 72, 1160, &lv_font_montserrat_26, DisplayColors::TextSecondary());

  const char *names[6] = {"WHITE", "CYAN", "GREEN", "YELLOW", "GOLD", "ORANGE"};
  constexpr int bw = 175;
  constexpr int gap = 18;
  int x = 55;
  for (uint8_t i = 0; i < 6; ++i) {
    lv_obj_t *button = makeSetupButton(
        textColorSetupPage, names[i], x, 155, bw, 95, textColorPresetEvent,
        reinterpret_cast<void *>(static_cast<uintptr_t>(i)));
    lv_obj_set_style_bg_color(button, lv_color_hex(0x0F3B55), LV_STATE_CHECKED);
    lv_obj_set_style_border_color(button, DisplayColors::BrightCyan(), LV_STATE_CHECKED);
    textColorButtons[i] = button;
    x += bw + gap;
  }

  lv_obj_t *previewPanel = makePanel(textColorSetupPage, 70, 300, 1140, 200);
  makeLabel(previewPanel, "PREVIEW", 25, 20, 250,
            &lv_font_montserrat_26, DisplayColors::TextSecondary());
  textColorPreview = makeLabel(previewPanel, "CQ CQ DE TEST  CW DECODER",
                               30, 85, 1080, &lv_font_montserrat_32,
                               DisplayColors::White());
  lv_obj_set_style_text_align(textColorPreview, LV_TEXT_ALIGN_CENTER, 0);

  makeSetupButton(textColorSetupPage, "BACK TO SETUP", 70, 610, 310, 76, setupHomeEvent);
  makeSetupButton(textColorSetupPage, "MAIN SCREEN", 900, 610, 310, 76, setupCloseEvent);
  refreshTextColorPage();
}

void monitorFilterEvent(lv_event_t* event) {
  const bool enabled=!AudioEngine::monitorFiltered();
  AudioEngine::setMonitorFiltered(enabled);
  pendingMonitorFiltered = enabled;
  monitorFilterSavePending = true;
  auto* button=static_cast<lv_obj_t*>(lv_event_get_target(event));
  setLabelIfChanged(lv_obj_get_child(button,0),enabled?"MONITOR AFTER":"MONITOR BEFORE");
}

void sampleRateEvent(lv_event_t* event) {
  if (sampleRateSwitchPending) return;

  const uint32_t current = AudioEngine::sampleRateHz();
  pendingSampleRateHz = (current == 96000U) ? 48000U : 96000U;
  sampleRateSwitchPending = true;

  auto* button = static_cast<lv_obj_t*>(lv_event_get_target(event));
  auto* label = button ? lv_obj_get_child(button, 0) : nullptr;
  if (label) setLabelIfChanged(label, "SWITCHING...");
}

void autoToneResponseEvent(lv_event_t*) {
  const uint16_t current = CWDecoder::autoToneResponseMs();
  uint16_t next = 500;
  if (current == 150) next = 500;
  else if (current == 500) next = 1000;
  else if (current == 1000) next = 2000;
  else next = 150;

  CWDecoder::setAutoToneResponseMs(next);
  pendingAutoToneResponseMs = next;
  autoToneResponseSavePending = true;

  if (autoToneResponseButtonLabel) {
    char text[40];
    formatAutoToneResponse(text, sizeof(text), next);
    setLabelIfChanged(autoToneResponseButtonLabel, text);
  }
}

void createHeadphoneSetupPage() {
  headphoneSetupPage = makeFullPage(setupOverlay);
  lv_obj_add_flag(headphoneSetupPage, LV_OBJ_FLAG_HIDDEN);

  makeLabel(headphoneSetupPage, "AUDIO LEVELS", 40, 24, 650,
            &lv_font_montserrat_36, DisplayColors::Gold());

  lv_obj_t *panel = makePanel(headphoneSetupPage, 70, 125, 1140, 455);

  makeLabel(panel, "OUTPUT VOLUME", 35, 18, 360,
            &lv_font_montserrat_28, DisplayColors::White());
  headphoneVolumeValueLabel = makeLabel(panel, "65 %", 430, 14, 280,
                                         &lv_font_montserrat_36, DisplayColors::BrightCyan());
  lv_obj_set_style_text_align(headphoneVolumeValueLabel, LV_TEXT_ALIGN_CENTER, 0);

  headphoneVolumeSlider = lv_slider_create(panel);
  lv_obj_set_pos(headphoneVolumeSlider, 80, 87);
  lv_obj_set_size(headphoneVolumeSlider, 980, 10);
  lv_slider_set_range(headphoneVolumeSlider, 0, 100);
  lv_slider_set_value(headphoneVolumeSlider, AppSettings::headphoneVolumePercent(), LV_ANIM_OFF);
  styleIndustrialSlider(headphoneVolumeSlider, DisplayColors::BrightCyan());
  lv_obj_add_event_cb(headphoneVolumeSlider, headphoneVolumeSliderEvent, LV_EVENT_VALUE_CHANGED, nullptr);
  lv_obj_add_event_cb(headphoneVolumeSlider, headphoneVolumeSliderEvent, LV_EVENT_RELEASED, nullptr);

  makeLabel(panel, "DECODER INPUT LEVEL", 35, 145, 430,
            &lv_font_montserrat_28, DisplayColors::White());
  inputGainValueLabel = makeLabel(panel, "100 %", 430, 141, 280,
                                   &lv_font_montserrat_36, DisplayColors::Gold());
  lv_obj_set_style_text_align(inputGainValueLabel, LV_TEXT_ALIGN_CENTER, 0);

  inputGainSlider = lv_slider_create(panel);
  lv_obj_set_pos(inputGainSlider, 80, 217);
  lv_obj_set_size(inputGainSlider, 980, 10);
  lv_slider_set_range(inputGainSlider, 1, 100);
  lv_slider_set_value(inputGainSlider, AppSettings::decoderInputLevelPercent(), LV_ANIM_OFF);
  styleIndustrialSlider(inputGainSlider, DisplayColors::Gold());
  lv_obj_add_event_cb(inputGainSlider, inputGainSliderEvent, LV_EVENT_VALUE_CHANGED, nullptr);
  lv_obj_add_event_cb(inputGainSlider, inputGainSliderEvent, LV_EVENT_RELEASED, nullptr);
  makeLabel(panel, "1 %", 65, 250, 150, &lv_font_montserrat_26, DisplayColors::TextSecondary());
  lv_obj_t *levelMax = makeLabel(panel, "100 %", 900, 250, 200,
                                 &lv_font_montserrat_26, DisplayColors::TextSecondary());
  lv_obj_set_style_text_align(levelMax, LV_TEXT_ALIGN_RIGHT, 0);

  // Three equal instrument readouts: caption above value prevents collisions.
  constexpr int metricYCaption = 286;
  constexpr int metricYValue = 323;
  constexpr int metricW = 350;
  constexpr int metricX0 = 20;
  constexpr int metricX1 = 395;
  constexpr int metricX2 = 770;

  lv_obj_t *adcCaption = makeLabel(panel, "ADC PEAK", metricX0, metricYCaption, metricW,
                                   &lv_font_montserrat_26, DisplayColors::TextSecondary());
  lv_obj_set_style_text_align(adcCaption, LV_TEXT_ALIGN_CENTER, 0);
  adcPeakValueLabel = makeLabel(panel, "-- dBFS", metricX0, metricYValue, metricW,
                                &lv_font_montserrat_32, DisplayColors::BrightCyan());
  lv_obj_set_style_text_align(adcPeakValueLabel, LV_TEXT_ALIGN_CENTER, 0);

  // V2.00: overload status is shown on the MAIN decoder page. Keep this
  // readout dedicated to the measured ADC peak value.

  lv_obj_t *decoderCaption = makeLabel(panel, "DECODER SIGNAL", metricX1, metricYCaption, metricW,
                                       &lv_font_montserrat_26, DisplayColors::TextSecondary());
  lv_obj_set_style_text_align(decoderCaption, LV_TEXT_ALIGN_CENTER, 0);
  decoderSignalValueLabel = makeLabel(panel, "-- dBFS", metricX1, metricYValue, metricW,
                                      &lv_font_montserrat_32, DisplayColors::BrightCyan());
  lv_obj_set_style_text_align(decoderSignalValueLabel, LV_TEXT_ALIGN_CENTER, 0);

  lv_obj_t *snrCaption = makeLabel(panel, "SNR", metricX2, metricYCaption, metricW,
                                   &lv_font_montserrat_26, DisplayColors::TextSecondary());
  lv_obj_set_style_text_align(snrCaption, LV_TEXT_ALIGN_CENTER, 0);
  setupSnrValueLabel = makeLabel(panel, "-- dB", metricX2, metricYValue, metricW,
                                 &lv_font_montserrat_32, DisplayColors::Gold());
  lv_obj_set_style_text_align(setupSnrValueLabel, LV_TEXT_ALIGN_CENTER, 0);

  makeThinLine(panel, 382, 292, 1, 62, DisplayColors::PanelBorder(), LV_OPA_60);
  makeThinLine(panel, 757, 292, 1, 62, DisplayColors::PanelBorder(), LV_OPA_60);

  // V1.93: compact three-button engineering row.  AUTO TONE cycles the
  // normal tracking response time: 0.15 / 0.50 / 1.0 / 2.0 seconds.
  makeSetupButton(panel, AppSettings::monitorFiltered() ? "MONITOR AFTER" : "MONITOR BEFORE",
                  35, 372, 330, 64, monitorFilterEvent);

  char sampleRateText[40];
  snprintf(sampleRateText, sizeof(sampleRateText), "SAMPLE %lu kHz",
           static_cast<unsigned long>(AppSettings::audioSampleRateHz() / 1000U));
  lv_obj_t *sampleRateButton = makeSetupButton(panel, sampleRateText,
                                               385, 372, 330, 64, sampleRateEvent);
  sampleRateButtonLabel = lv_obj_get_child(sampleRateButton, 0);

  char autoToneResponseText[40];
  const uint16_t responseMs = AppSettings::autoToneResponseMs();
  formatAutoToneResponse(autoToneResponseText, sizeof(autoToneResponseText), responseMs);
  lv_obj_t *autoToneResponseButton =
      makeSetupButton(panel, autoToneResponseText, 735, 372, 330, 64,
                      autoToneResponseEvent);
  autoToneResponseButtonLabel = lv_obj_get_child(autoToneResponseButton, 0);

  makeSetupButton(headphoneSetupPage, "BACK TO SETUP", 70, 610, 310, 76, setupHomeEvent);
  makeSetupButton(headphoneSetupPage, "MAIN SCREEN", 900, 610, 310, 76, setupCloseEvent);

  // V2.00: overload indication moved to the MAIN decoder page.
  // AUDIO LEVELS now remains an adjustment/diagnostic page only.

}

void zoomEvent(lv_event_t *);
void timeBaseEvent(lv_event_t *);

void createScopeSetupPage() {
  scopeSetupPage=makeFullPage(setupOverlay);
  lv_obj_add_flag(scopeSetupPage,LV_OBJ_FLAG_HIDDEN);
  makeLabel(scopeSetupPage,"TUNE SETUP",40,24,800,&lv_font_montserrat_36,DisplayColors::Gold());
  makeLabel(scopeSetupPage,"Bring the signal marker to the centre using TONE - or TONE +.",
            40,80,1160,&lv_font_montserrat_26,DisplayColors::TextSecondary());
  char label[40];snprintf(label,sizeof(label),"Range +/- %d Hz",int(zoomSpans[zoomIndex]/2));
  auto button=makeSetupButton(scopeSetupPage,label,70,180,530,100,zoomEvent);
  zoomButtonLabel=lv_obj_get_child(button,0);
  makeLabel(scopeSetupPage,"Ranges: +/-50, +/-25 or +/-100 Hz. The choice is saved.",
            70,310,1140,&lv_font_montserrat_26,DisplayColors::TextSecondary());
  makeLabel(scopeSetupPage,"Green: within about 3 Hz. -- Hz: no clear recent tone.",
            70,400,1140,&lv_font_montserrat_26,DisplayColors::TextSecondary());
  makeSetupButton(scopeSetupPage,"BACK TO SETUP",70,610,310,76,setupHomeEvent);
  makeSetupButton(scopeSetupPage,"MAIN SCREEN",900,610,310,76,setupCloseEvent);
}

void createSetupOverlay(lv_obj_t *screen) {
  setupOverlay = makeFullPage(screen);
  lv_obj_add_flag(setupOverlay, LV_OBJ_FLAG_HIDDEN);
  createSetupHome();
  createDisplaySetupPage();
  createFilterSetupPage();
  createTextColorSetupPage();
  createHeadphoneSetupPage();
  createScopeSetupPage();
  showSetupPage(setupHomePage);
}

void serviceSetupNavigation(uint32_t now) {
  if (pendingSetupNav == SetupNav::None) return;
  if (static_cast<int32_t>(now - pendingSetupNavDueMs) < 0) return;

  const SetupNav nav = pendingSetupNav;
  pendingSetupNav = SetupNav::None;

  switch (nav) {
    case SetupNav::OpenHome:
      Serial.println("[UI] SETUP open");
      cwTypesOpen = false;
      refreshSetupMenu();
      showSetupPage(setupHomePage);
      if (setupOverlay) lv_obj_clear_flag(setupOverlay, LV_OBJ_FLAG_HIDDEN);
      logLvglMemory("SETUP open");
      break;

    case SetupNav::Home:
      cwTypesOpen = false;
      refreshSetupMenu();
      showSetupPage(setupHomePage);
      logLvglMemory("SETUP home");
      break;

    case SetupNav::Display:
      refreshDisplayPage();
      showSetupPage(displaySetupPage);
      logLvglMemory("DISPLAY page");
      break;

    case SetupNav::Filter:
      refreshFilterPage();
      showSetupPage(filterSetupPage);
      logLvglMemory("FILTER page");
      break;

    case SetupNav::TextColor:
      refreshTextColorPage();
      showSetupPage(textColorSetupPage);
      logLvglMemory("TEXT COLOR page");
      break;

    case SetupNav::Audio:
      showSetupPage(headphoneSetupPage);
      headphoneRefreshPending = true;
      headphoneRefreshDueMs = now + 80;
      logLvglMemory("AUDIO LEVELS page");
      break;

    case SetupNav::Scope:
      showSetupPage(scopeSetupPage);
      logLvglMemory("TUNE page");
      break;

    case SetupNav::CwType:
      cwTypesOpen = true;
      refreshSetupMenu();
      showSetupPage(setupHomePage);
      logLvglMemory("CW TYPE page");
      break;

    case SetupNav::Close:
      Serial.println("[UI] SETUP close");
      cwTypesOpen = false;
      if (setupOverlay) lv_obj_add_flag(setupOverlay, LV_OBJ_FLAG_HIDDEN);
      logLvglMemory("SETUP close");
      break;

    case SetupNav::None:
    default:
      break;
  }

  // V2.10: a page change can place a different clickable object under the
  // same physical touch coordinates.  Tell LVGL to ignore any residual GT911
  // press/bounce until a clean release is seen before accepting another click.
  DisplaySetup::waitForTouchRelease();
}

int frequencyToTuneX(float hz, float displayMinHz, float displayMaxHz) {
  hz = constrain(hz, displayMinHz, displayMaxHz);
  const float frac = (hz - displayMinHz) / (displayMaxHz - displayMinHz);
  return TUNE_CANVAS_X + static_cast<int>(lroundf(frac * static_cast<float>(TUNE_SPECTRUM_W - 1)));
}

float spectrumValueAt(const CWDecoderState &c, float hz) {
  const float step=(c.spectrumMaxHz-c.spectrumMinHz)/(CWDecoderState::kSpectrumBins-1);
  const float bin = (hz - c.spectrumMinHz) / step;
  if (bin <= 0.0f) return static_cast<float>(c.spectrum[0]);
  const float maxBin = static_cast<float>(CWDecoderState::kSpectrumBins - 1);
  if (bin >= maxBin) return static_cast<float>(c.spectrum[CWDecoderState::kSpectrumBins - 1]);
  const int i0 = static_cast<int>(floorf(bin));
  const int i1 = i0 + 1;
  const float f = bin - static_cast<float>(i0);
  return static_cast<float>(c.spectrum[i0]) * (1.0f - f) +
         static_cast<float>(c.spectrum[i1]) * f;
}

lv_color_t waterfallColor(float level) {
  // Radio-style heat map: black, blue, cyan, yellow, pale yellow.
  level = constrain(level, 0.0f, 100.0f);
  static const uint32_t colors[] = {0x010408, 0x00103D, 0x0037C8,
                                   0x00C7F0, 0xFFFF00, 0xFFFFC0};
  const float position = level / 20.0f;
  const int index = min(4, static_cast<int>(position));
  const float fraction = position - index;
  const uint32_t a = colors[index], b = colors[index + 1];
  uint32_t rgb = 0;
  for (int shift = 0; shift <= 16; shift += 8) {
    const float av = float((a >> shift) & 255), bv = float((b >> shift) & 255);
    rgb |= uint32_t(lroundf(av + (bv - av) * fraction)) << shift;
  }
  return lv_color_hex(rgb);
}

void setCanvasPixel(lv_obj_t *canvas, int x, int y, lv_color_t color, lv_opa_t) {
  lv_draw_buf_t *buf = lv_canvas_get_draw_buf(canvas);
  if (!buf || x < 0 || y < 0 || x >= int(buf->header.w) || y >= int(buf->header.h)) return;
  const uint16_t pixel = lv_color_to_u16(color);
  memcpy(buf->data + y * buf->header.stride + x * 2, &pixel, sizeof(pixel));
}

void clearWaterfall() {
  spectrumTraceValid = false; // frequency scale/history changed
  if (!waterfallCanvas) return;
  waterfallPeakValid = false;
  lv_canvas_fill_bg(waterfallCanvas, lv_color_hex(0x010408), LV_OPA_COVER);
  lv_obj_invalidate(waterfallCanvas);
}

void drawLiveSpectrum(const CWDecoderState &c, float displayMinHz, float displayMaxHz) {
  if (!spectrumCanvas) return;
  const uint32_t traceNow = millis();
  const uint32_t elapsed = traceNow - spectrumTraceLastMs;
  // Restart directly after setup/long pauses rather than showing a stale trace.
  const bool seedTrace = !spectrumTraceValid || elapsed > 500;
  const float riseAlpha = 1.0f - expf(-static_cast<float>(elapsed) / 100.0f);
  const float fallAlpha = 1.0f - expf(-static_cast<float>(elapsed) / 220.0f);
  spectrumTraceLastMs = traceNow;
  lv_canvas_fill_bg(spectrumCanvas, lv_color_hex(0x02070B), LV_OPA_COVER);

  // Solid divisions as on a receiver spectrum display. Heights are relative,
  // so no calibrated dB scale or attenuation readout is implied.
  const lv_color_t grid = lv_color_hex(0x344D60);
  for (int division = 0; division <= 4; ++division) {
    const int gx = division * (TUNE_SPECTRUM_W - 1) / 4;
    const int gy = division * (TUNE_SPECTRUM_H - 1) / 4;
    for (int y = 0; y < TUNE_SPECTRUM_H; ++y)
      setCanvasPixel(spectrumCanvas, gx, y, grid, LV_OPA_COVER);
    for (int x = 0; x < TUNE_SPECTRUM_W; ++x)
      setCanvasPixel(spectrumCanvas, x, gy, grid, LV_OPA_COVER);
  }
  // Precompute the vertical blue fill once per draw, not per pixel.
  uint16_t fillColors[TUNE_SPECTRUM_H];
  for (int y = 0; y < TUNE_SPECTRUM_H; ++y) {
    const uint32_t green = 45 + 80 * (TUNE_SPECTRUM_H - 1 - y) / (TUNE_SPECTRUM_H - 1);
    fillColors[y] = lv_color_to_u16(lv_color_hex((green << 8) | 0xD0));
  }
  lv_draw_buf_t *traceBuffer = lv_canvas_get_draw_buf(spectrumCanvas);

  const lv_color_t trace = lv_color_hex(0x49D9FF);
  bool previousValid = false;
  int previousY = TUNE_SPECTRUM_H - 1;
  for (int x = 0; x < TUNE_SPECTRUM_W; ++x) {
    const float frac = static_cast<float>(x) / static_cast<float>(TUNE_SPECTRUM_W - 1);
    const float hz = displayMinHz + frac * (displayMaxHz - displayMinHz);
    const float raw = constrain(spectrumValueAt(c, hz), 0.0f, 100.0f);
    const float target = 100.0f * powf(raw / 100.0f, 9.0f); // sharper display-only peak
    float &level = spectrumTraceLevel[x];
    if (seedTrace) level = target;
    else level += (target > level ? riseAlpha : fallAlpha) * (target - level);
    const float v = level;

    // Do not connect the noise floor into a long horizontal line.  Only draw
    // bins with useful energy; when the trace drops below threshold, break the
    // line and resume at the next real peak.
    if (v < 5.0f) {
      previousValid = false;
      continue;
    }

    const int y = (TUNE_SPECTRUM_H - 2) -
                  static_cast<int>(lroundf(v * static_cast<float>(TUNE_SPECTRUM_H - 4) / 100.0f));
    // Filled spectrum; direct RGB565 writes retain one invalidation per frame.
    for (int yy = y + 1; yy < TUNE_SPECTRUM_H - 1; ++yy)
      memcpy(traceBuffer->data + yy * traceBuffer->header.stride + x * 2,
             &fillColors[yy], sizeof(uint16_t));
    if (previousValid) {
      const int y0 = min(previousY, y);
      const int y1 = max(previousY, y);
      for (int yy = y0; yy <= y1; ++yy)
        setCanvasPixel(spectrumCanvas, x, yy, trace, LV_OPA_COVER);
    } else {
      setCanvasPixel(spectrumCanvas, x, y, trace, LV_OPA_COVER);
    }
    // Single-pixel edge keeps the peak crisp.
    previousY = y;
    previousValid = true;
  }
  spectrumTraceValid = true;
  lv_obj_invalidate(spectrumCanvas);
}

void appendWaterfallLine(const CWDecoderState &c, float displayMinHz, float displayMaxHz, uint32_t rows = 1) {
  if (!waterfallCanvas) return;

  // One bounded shift regardless of how late the UI is. Never render a backlog.
  if (rows < 1) rows = 1;
  if (rows > TUNE_WATERFALL_H) rows = TUNE_WATERFALL_H;
  lv_draw_buf_t *buf = lv_canvas_get_draw_buf(waterfallCanvas);
  const size_t rowBytes = buf->header.stride;
  memmove(buf->data + rowBytes * rows, buf->data,
          rowBytes * (TUNE_WATERFALL_H - rows));
  // Missing measurements stay blank, preserving the selected elapsed-time scale.
  const uint16_t blank = lv_color_to_u16(lv_color_hex(0x010408));
  for (uint32_t y = 0; y < rows; ++y)
    for (int x = 0; x < TUNE_WATERFALL_W; ++x)
      memcpy(buf->data + y * rowBytes + x * 2, &blank, sizeof(blank));

  // Locate the strongest visible measured sample. Limit the hot-color core
  // to ten physical pixels; surrounding energy remains blue/cyan.
  static float visibleLevel[TUNE_WATERFALL_W];
  float peakLevel = -1.0f;
  int peakX = 0;
  for (int x = 0; x < TUNE_WATERFALL_W; ++x) {
    const float frac = static_cast<float>(x) / static_cast<float>(TUNE_WATERFALL_W - 1);
    const float hz = displayMinHz + frac * (displayMaxHz - displayMinHz);
    const float raw = constrain(spectrumValueAt(c, hz), 0.0f, 100.0f);
    visibleLevel[x] = 100.0f * powf(raw / 100.0f, 3.8f);
    if (visibleLevel[x] > peakLevel) { peakLevel = visibleLevel[x]; peakX = x; }
  }
  for (int x = 0; x < TUNE_WATERFALL_W; ++x) {
    const float level = (x >= peakX - 4 && x <= peakX + 5)
        ? visibleLevel[x] : min(60.0f, visibleLevel[x]);
    setCanvasPixel(waterfallCanvas, x, 0, waterfallColor(level), LV_OPA_COVER);
  }

  lv_obj_invalidate(waterfallCanvas);
}

void drawTuningGuide(const CWDecoderState &c,uint32_t now) {
  tuningGuide.update(now,c.spectrumSequence,c.measuredToneValid,c.measuredToneHz);
  const bool available=tuningGuide.available(now);
  const float target=CWDecoder::autoToneEnabled() ? c.toneHz : CWDecoder::manualToneSettingHz();
  const float error=tuningGuide.measured-target;
  const float halfRange=zoomSpans[zoomIndex]*0.5f;
  const int center=TUNE_SPECTRUM_W/2;
  const bool centered=available && fabsf(error)<=3.0f;
  const lv_color_t color=centered ? DisplayColors::BrightGreen() : DisplayColors::Gold();
  lv_canvas_fill_bg(spectrumCanvas,lv_color_hex(0x02070B),LV_OPA_COVER);
  const int targetHalf=max(2,int(lroundf(3.0f*(center-14)/halfRange)));
  for(int x=14;x<TUNE_SPECTRUM_W-14;++x)
    for(int y=17;y<21;++y)setCanvasPixel(spectrumCanvas,x,y,lv_color_hex(0x315269),LV_OPA_COVER);
  for(int x=center-targetHalf;x<=center+targetHalf;++x)
    for(int y=6;y<32;++y)setCanvasPixel(spectrumCanvas,x,y,lv_color_hex(0x164F40),LV_OPA_COVER);
  for(int n=0;n<5;++n) {
    const int x=14+n*(TUNE_SPECTRUM_W-29)/4;
    for(int y=11;y<27;++y)setCanvasPixel(spectrumCanvas,x,y,lv_color_hex(0x7995A6),LV_OPA_COVER);
  }
  for(int y=0;y<TUNE_SPECTRUM_H;++y)setCanvasPixel(spectrumCanvas,center,y,DisplayColors::BrightGreen(),LV_OPA_COVER);
  if(available) {
    const int cursor=center+int(lroundf(constrain(error,-halfRange,halfRange)*(center-14)/halfRange));
    for(int x=cursor-4;x<=cursor+4;++x)
      for(int y=5;y<33;++y)setCanvasPixel(spectrumCanvas,x,y,color,LV_OPA_COVER);
  }
  lv_obj_invalidate(spectrumCanvas);
  char text[64];snprintf(text,sizeof(text),"-%d Hz",int(halfRange));setLabelIfChanged(tuneMinLabel,text);
  snprintf(text,sizeof(text),"+%d Hz",int(halfRange));setLabelIfChanged(tuneMaxLabel,text);
  // Numeric display only: average each half-second window. The marker and
  // actual decoder remain responsive; no AUTO/CENTERED wording to alternate.
  static bool offsetShown=false;
  static uint32_t offsetShownAt=0;
  static float offsetSum=0;
  static unsigned offsetSamples=0;
  static int previousColor=-1;
  int colorState=previousColor;
  if(!available) {
    offsetShown=false;offsetSum=0;offsetSamples=0;
    setLabelIfChanged(guideAction,"-- Hz");
    colorState=0;
  } else {
    offsetSum+=error;++offsetSamples;
    if(!offsetShown || now-offsetShownAt>=500) {
      const float average=offsetSum/offsetSamples;
      const long hz=lroundf(average);
      if(hz==0)snprintf(text,sizeof(text),"0 Hz");
      else snprintf(text,sizeof(text),"%+ld Hz",hz);
      setLabelIfChanged(guideAction,text);
      colorState=fabsf(average)<=3.0f ? 1 : 2;
      offsetShown=true;offsetShownAt=now;offsetSum=0;offsetSamples=0;
    }
  }
  if(colorState!=previousColor) {
    previousColor=colorState;
    lv_obj_set_style_text_color(guideAction,colorState==0 ? DisplayColors::Gray70() :
        (colorState==1 ? DisplayColors::BrightGreen() : DisplayColors::Gold()),0);
  }

}

void zoomEvent(lv_event_t *) {
  zoomIndex = (zoomIndex + 1) % 3;
  AppSettings::setScopeZoomIndex(zoomIndex);
  tuneWindowInitialized = false;
  clearWaterfall();
  char label[32];
  snprintf(label, sizeof(label), "Range +/- %d Hz", int(zoomSpans[zoomIndex]/2));
  setLabelIfChanged(zoomButtonLabel, label);
}

void timeBaseEvent(lv_event_t *) {
  timeBaseIndex = (timeBaseIndex + 1) % 3;
  AppSettings::setScopeTimeIndex(timeBaseIndex);
  lastWaterfallLineMs = millis();
  clearWaterfall();
  char label[32];
  snprintf(label, sizeof(label), "Time %.1f s", TUNE_WATERFALL_H * waterfallPeriods[timeBaseIndex] / 1000.0);
  setLabelIfChanged(timeBaseButtonLabel, label);
}

void serviceWaterfall(uint32_t now, const CWDecoderState &c) {
  if (!waterfallCanvas || !tuneWindowInitialized) return;
  const uint32_t period = waterfallPeriods[timeBaseIndex];
  const uint32_t elapsedRows = (now - lastWaterfallLineMs) / period;
  if (!elapsedRows) return;
  lastWaterfallLineMs += elapsedRows * period;
  appendWaterfallLine(c, tuneWindowMinHz, tuneWindowMaxHz, elapsedRows);
}

void serviceTranscript(uint32_t now) {
  if (now - lastTextUpdate < 10) return;
  lastTextUpdate = now;
  char received[256];
  bool overflow = false;
  const size_t n = CWDecoder::readText(received, sizeof(received), overflow);
  for (size_t i = 0; i < n; ++i) transcript.append(received[i], transcriptGlyphWidth, 1208);
  if (n) refreshTranscript();
  if (overflow) setLabelIfChanged(printStatus, "Text overrun: some text lost");
}

void chooseTuneWindow(float peakHz, float &displayMinHz, float &displayMaxHz,
                      float minHz = CWDecoder::SPECTRUM_MIN_HZ, float maxHz = CWDecoder::SPECTRUM_MAX_HZ) {
  // Center the selected frequency span on the received CW tone.  Round the
  // center to 10 Hz so the scale stays calm and uses readable numbers.
  float center = roundf(peakHz / 10.0f) * 10.0f;
  displayMinHz = center - zoomSpans[zoomIndex] * 0.5f;
  displayMaxHz = displayMinHz + zoomSpans[zoomIndex];

  if (displayMinHz < minHz) {
    displayMinHz = minHz;
    displayMaxHz = displayMinHz + zoomSpans[zoomIndex];
  }
  if (displayMaxHz > maxHz) {
    displayMaxHz = maxHz;
    displayMinHz = displayMaxHz - zoomSpans[zoomIndex];
  }
}

} // namespace

namespace CWUI {

void create() {
  zoomIndex = AppSettings::scopeZoomIndex();
  timeBaseIndex = AppSettings::scopeTimeIndex();
  autoInputLevel = AppSettings::autoLevel() && !AppSettings::weakSignal();
  lv_obj_t *screen = lv_screen_active();
  lv_obj_set_style_bg_color(screen, DisplayColors::Background(), 0);
  lv_obj_set_style_bg_opa(screen, LV_OPA_COVER, 0);
  lv_obj_clear_flag(screen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_clean(screen);

  // V1.39 SAFE2 CLEAN SCOPE: one slim operating line only.
  // Keep the main screen focused on the two values that matter during CW use.
  lv_obj_t *titleLabel = makeLabel(screen, "CW DECODER", 24, 9, 220,
                                   &lv_font_montserrat_28, DisplayColors::Gold());
  lv_obj_set_style_text_letter_space(titleLabel, -2, 0);
  lv_label_set_long_mode(titleLabel, LV_LABEL_LONG_CLIP);
  lv_obj_set_style_text_align(titleLabel, LV_TEXT_ALIGN_LEFT, 0);

  // V2.16: give SPEED a little more room before AUDIO.
  // All text remains Montserrat 28 on one baseline, but the metric groups now
  // have generous fixed spacing. SNR is anchored at the far right and the
  // AUDIO LED has its own clearance so it can never touch the AUDIO caption.
  constexpr int TOP_Y = 9;
  constexpr int TOP_H = 34;

  makeThinLine(screen, 238, 9, 1, 34, lv_color_hex(0x294757), LV_OPA_50);

  toneValue = makeLabel(screen, "RX TONE  #00E0E0 -- Hz#", 252, TOP_Y, 240,
                        &lv_font_montserrat_28, DisplayColors::TextSecondary());
  lv_label_set_recolor(toneValue, true);
  lv_label_set_long_mode(toneValue, LV_LABEL_LONG_CLIP);
  lv_obj_set_height(toneValue, TOP_H);
  lv_obj_set_style_text_align(toneValue, LV_TEXT_ALIGN_LEFT, 0);

  makeThinLine(screen, 520, 9, 1, 34, lv_color_hex(0x294757), LV_OPA_50);
  wpmValue = makeLabel(screen, "SPEED  #00D000 -- WPM#", 545, TOP_Y, 240,
                       &lv_font_montserrat_28, DisplayColors::TextSecondary());
  lv_label_set_recolor(wpmValue, true);
  lv_label_set_long_mode(wpmValue, LV_LABEL_LONG_CLIP);
  lv_obj_set_height(wpmValue, TOP_H);
  lv_obj_set_style_text_align(wpmValue, LV_TEXT_ALIGN_LEFT, 0);

  makeThinLine(screen, 810, 9, 1, 34, lv_color_hex(0x294757), LV_OPA_50);
  lv_obj_t *audioCaption = makeLabel(screen, "AUDIO", 840, TOP_Y, 96,
                                     &lv_font_montserrat_28, DisplayColors::TextSecondary());
  lv_label_set_long_mode(audioCaption, LV_LABEL_LONG_CLIP);
  lv_obj_set_height(audioCaption, TOP_H);
  lv_obj_set_style_text_align(audioCaption, LV_TEXT_ALIGN_LEFT, 0);
  audioOverLed = lv_obj_create(screen);
  lv_obj_remove_style_all(audioOverLed);
  lv_obj_set_pos(audioOverLed, 960, 12);
  lv_obj_set_size(audioOverLed, 26, 26);
  lv_obj_set_style_radius(audioOverLed, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_opa(audioOverLed, LV_OPA_COVER, 0);
  lv_obj_set_style_bg_color(audioOverLed, lv_color_hex(0x2ECC71), 0);
  lv_obj_set_style_border_width(audioOverLed, 2, 0);
  lv_obj_set_style_border_color(audioOverLed, lv_color_hex(0xB8FFD4), 0);
  lv_obj_clear_flag(audioOverLed, LV_OBJ_FLAG_CLICKABLE);

  // Fault messages use the lower status row, leaving SNR on the operating line.
  statusLabel = makeLabel(screen, "", 904, 608, 350,
                          &lv_font_montserrat_26, DisplayColors::StatusWarning());
  lv_obj_set_style_text_align(statusLabel, LV_TEXT_ALIGN_RIGHT, 0);

  makeThinLine(screen, 1020, 9, 1, 34, lv_color_hex(0x294757), LV_OPA_50);
  snrValue = makeLabel(screen, "SNR  #00D000 -- dB#", 1060, TOP_Y, 196,
                       &lv_font_montserrat_28, DisplayColors::TextSecondary());
  lv_label_set_recolor(snrValue, true);
  lv_label_set_long_mode(snrValue, LV_LABEL_LONG_CLIP);
  lv_obj_set_height(snrValue, TOP_H);
  lv_obj_set_style_text_align(snrValue, LV_TEXT_ALIGN_RIGHT, 0);

  makeSectionRule(screen, 54);

  // FLDIGI-inspired flat CW scope.  Keep the black receiver window, but use a
  // square 1-pixel outline instead of a rounded card.
  tuningPanel = lv_obj_create(screen);
  lv_obj_set_pos(tuningPanel, TUNE_PANEL_X, TUNE_PANEL_Y);
  lv_obj_set_size(tuningPanel, TUNE_PANEL_W, TUNE_PANEL_H);
  lv_obj_set_style_bg_color(tuningPanel, lv_color_hex(0x020609), 0);
  lv_obj_set_style_bg_opa(tuningPanel, LV_OPA_COVER, 0);
  lv_obj_set_style_border_color(tuningPanel, lv_color_hex(0x203A48), 0);
  lv_obj_set_style_border_width(tuningPanel, 1, 0);
  lv_obj_set_style_radius(tuningPanel, 0, 0);
  lv_obj_set_style_pad_all(tuningPanel, 0, 0);
  lv_obj_clear_flag(tuningPanel, LV_OBJ_FLAG_SCROLLABLE);
  makeLabel(tuningPanel, "TUNE", 10, 0, 210,
            &lv_font_montserrat_26, DisplayColors::Gold());
  printStatus = makeLabel(tuningPanel, "", 220, 0, 325,
                         &lv_font_montserrat_26, DisplayColors::White());
  lv_obj_set_style_text_align(printStatus, LV_TEXT_ALIGN_RIGHT, 0);
  spectrumCanvas = lv_canvas_create(tuningPanel);
  lv_canvas_set_buffer(spectrumCanvas, spectrumCanvasBuffer,
                       TUNE_SPECTRUM_W, TUNE_SPECTRUM_H, LV_COLOR_FORMAT_RGB565);
  lv_obj_set_pos(spectrumCanvas, TUNE_CANVAS_X, 36);
  lv_canvas_fill_bg(spectrumCanvas, lv_color_hex(0x02070B), LV_OPA_COVER);
  tuneMinLabel=makeLabel(tuningPanel,"-50 Hz",10,76,145,&lv_font_montserrat_26,DisplayColors::Gray70());
  tuneMidLabel=makeLabel(tuningPanel,"0",227,76,110,&lv_font_montserrat_26,DisplayColors::White());
  lv_obj_set_style_text_align(tuneMidLabel,LV_TEXT_ALIGN_CENTER,0);
  tuneMaxLabel=makeLabel(tuningPanel,"+50 Hz",400,76,145,&lv_font_montserrat_26,DisplayColors::Gray70());
  lv_obj_set_style_text_align(tuneMaxLabel,LV_TEXT_ALIGN_RIGHT,0);
  guideAction=makeLabel(tuningPanel,"-- Hz",10,111,535,&lv_font_montserrat_28,DisplayColors::Gray70());
  lv_obj_set_style_text_align(guideAction,LV_TEXT_ALIGN_CENTER,0);

  // V1.75: receiver controls flank the tuning guide.
  autoButton = makeButton(screen, "AUTO TONE", 24, 309, autoToneEvent, true);
  lv_obj_set_pos(autoButton, 24, 62);
  lv_obj_set_size(autoButton, 309, 68);
  autoButtonLabel = lv_obj_get_child(autoButton, 0);
  autoLevelButton = makeButton(screen, "AUTO LEVEL", 24, 309, autoLevelEvent, true);
  lv_obj_set_pos(autoLevelButton, 24, 144);
  lv_obj_set_size(autoLevelButton, 309, 68);
  autoLevelButtonLabel = lv_obj_get_child(autoLevelButton, 0);
  lv_obj_t *toneMinusButton = makeSetupButton(screen, "TONE -", 946, 62, 308, 68, toneMinusEvent);
  lv_obj_t *tonePlusButton = makeSetupButton(screen, "TONE +", 946, 144, 308, 68, tonePlusEvent);
  // V2.08: keep TONE - / TONE + typography identical to AUTO TONE.
  // makeSetupButton() uses Montserrat 28 by default, while AUTO TONE uses
  // makeButton() with Montserrat 26. Override only these two labels.
  if (lv_obj_get_child_count(toneMinusButton) > 0)
    lv_obj_set_style_text_font(lv_obj_get_child(toneMinusButton, 0), &lv_font_montserrat_26, 0);
  if (lv_obj_get_child_count(tonePlusButton) > 0)
    lv_obj_set_style_text_font(lv_obj_get_child(tonePlusButton, 0), &lv_font_montserrat_26, 0);
  lv_obj_t *scopeControls[] = {autoButton, autoLevelButton, toneMinusButton, tonePlusButton};
  for (lv_obj_t *button : scopeControls) {
    lv_obj_set_style_pad_hor(button, 8, 0);
    lv_obj_set_style_pad_ver(button, 4, 0);
  }
  pageLabel = makeLabel(screen, "PAGE 1/1   LIVE", 28, 608, 550,
                        &lv_font_montserrat_26, DisplayColors::BrightCyan());

  makeSectionRule(screen, 219);

  // Keep the proven V1.33 decoded-text viewport geometry exactly unchanged.
  // V1.36: remove the extra separator directly above the text area.

  decodedViewport = lv_obj_create(screen);
  // V1.38: move the transcript upward by 30 px, but keep its proven
  // V1.33/V1.36 height unchanged so the number of visible text lines
  // and redraw workload stay the same.
  lv_obj_set_pos(decodedViewport, 28, 236);
  lv_obj_set_size(decodedViewport, 1224, 365);
  lv_obj_set_style_bg_opa(decodedViewport, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(decodedViewport, 0, 0);
  lv_obj_set_style_pad_all(decodedViewport, 0, 0);
  lv_obj_clear_flag(decodedViewport, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_scrollbar_mode(decodedViewport, LV_SCROLLBAR_MODE_OFF);

  decodedValue = lv_label_create(decodedViewport);
  setLabelIfChanged(decodedValue, "");
  lv_label_set_long_mode(decodedValue, LV_LABEL_LONG_WRAP);
  lv_obj_set_pos(decodedValue, 0, 0);
  lv_obj_set_width(decodedValue, 1224);
  lv_obj_set_height(decodedValue, LV_SIZE_CONTENT);
  lv_obj_set_style_text_font(decodedValue, &droid_sans_mono_32, 0);
  lv_obj_set_style_text_letter_space(decodedValue, 1, 0);
  lv_obj_set_style_text_color(decodedValue, incomingTextColor(AppSettings::textColorIndex()), 0);
  lv_obj_set_style_text_line_space(decodedValue, 7, 0);

  // Invisible bottom spacer used only to allow line-aligned scrolling.
  decodedSpacer = lv_obj_create(decodedViewport);
  lv_obj_set_pos(decodedSpacer, 0, 0);
  lv_obj_set_size(decodedSpacer, 1, 1);
  lv_obj_set_style_bg_opa(decodedSpacer, LV_OPA_TRANSP, 0);
  lv_obj_set_style_border_width(decodedSpacer, 0, 0);
  lv_obj_set_style_pad_all(decodedSpacer, 0, 0);
  lv_obj_clear_flag(decodedSpacer, LV_OBJ_FLAG_SCROLLABLE);

  // V1.75: six equal bottom controls, 12 px gaps and 10 px outer margins.
  constexpr int buttonWidth = 200;
  constexpr int gap = 12;
  static_assert(6 * buttonWidth + 5 * gap == 1280 - 20, "Bottom row margins");
  int x = 10;
  pageUpButton = makeButton(screen, "Pg Up", x, buttonWidth, pageUpEvent); x += buttonWidth + gap;
  pageDownButton = makeButton(screen, "Pg Down", x, buttonWidth, pageDownEvent); x += buttonWidth + gap;
  makeButton(screen, "CLR Buf", x, buttonWidth, clearEvent); x += buttonWidth + gap;
  makeButton(screen, "LIVE", x, buttonWidth, liveEvent); x += buttonWidth + gap;
  makeButton(screen, "RELOCK", x, buttonWidth, relockEvent); x += buttonWidth + gap;
  makeButton(screen, "SETUP", x, buttonWidth, setupOpenEvent);

  // V1.38: receiver-style lower rule, balanced between the transcript
  // and the control row.
  makeSectionRule(screen, 639);

  refreshTranscript();
  createSetupOverlay(screen);
  logLvglMemory("UI created");
  lv_refr_now(nullptr);
}

void update() {
  const uint32_t now = millis();
  serviceTranscript(now);
  if (relockNoticeShown && !CWDecoder::relockPending()) {
    relockNoticeShown = false;
    if (printStatus && strcmp(lv_label_get_text(printStatus), "RELOCK requested") == 0)
      setLabelIfChanged(printStatus, "");
  }

  // Service requested setup navigation only after LVGL's event/touch handler
  // has returned. This avoids hiding the object that is still processing the
  // CLICKED event.
  serviceSetupNavigation(now);

  if (now - lastUpdate < 50) return;
  lastUpdate = now;

  // V1.93 SAFE AUDIO: service operations requested by touch callbacks only
  // after LVGL has returned to the regular UI loop.
  if (headphoneVolumeApplyPending) {
    headphoneVolumeApplyPending = false;
    AudioEngine::setHeadphoneVolumePercent(pendingHeadphoneVolume);
  }

  if (headphoneVolumeSavePending) {
    headphoneVolumeSavePending = false;
    AppSettings::setHeadphoneVolumePercent(pendingHeadphoneVolume);
    Serial.printf("[AUDIO] saved headphone volume %u%%\n",
                  static_cast<unsigned>(pendingHeadphoneVolume));
  }

  if (inputGainSavePending) {
    inputGainSavePending = false;
    AppSettings::setDecoderInputLevelPercent(pendingInputGain);
    Serial.printf("[AUDIO] saved decoder input level %u%%\n",
                  static_cast<unsigned>(pendingInputGain));
  }

  if (autoLevelOffSavePending) {
    autoLevelOffSavePending = false;
    AppSettings::setAutoLevel(false);
  }

  if (monitorFilterSavePending) {
    monitorFilterSavePending = false;
    AppSettings::setMonitorFiltered(pendingMonitorFiltered);
  }

  if (autoToneResponseSavePending) {
    autoToneResponseSavePending = false;
    AppSettings::setAutoToneResponseMs(pendingAutoToneResponseMs);
    Serial.printf("[AUTO TONE] response %.2f s saved\n",
                  static_cast<double>(pendingAutoToneResponseMs) / 1000.0);
  }

  if (sampleRateSwitchPending) {
    const uint32_t requested = pendingSampleRateHz;
    sampleRateSwitchPending = false;

    const bool ok = AudioEngine::switchSampleRate(requested);
    if (ok) {
      AppSettings::setAudioSampleRateHz(requested);
      Serial.printf("[AUDIO] sample rate now %lu kHz; deferred live switch, no reboot\n",
                    static_cast<unsigned long>(requested / 1000U));
    } else {
      Serial.printf("[AUDIO] sample-rate switch to %lu kHz FAILED; staying at %lu kHz\n",
                    static_cast<unsigned long>(requested / 1000U),
                    static_cast<unsigned long>(AudioEngine::sampleRateHz() / 1000U));
    }

    if (sampleRateButtonLabel) {
      char rateText[40];
      snprintf(rateText, sizeof(rateText), ok ? "SAMPLE %lu kHz" : "FAILED %lu kHz",
               static_cast<unsigned long>(AudioEngine::sampleRateHz() / 1000U));
      setLabelIfChanged(sampleRateButtonLabel, rateText);
    }
  }

  if (headphoneRefreshPending &&
      static_cast<int32_t>(now - headphoneRefreshDueMs) >= 0) {
    headphoneRefreshPending = false;
    if (headphoneSetupPage &&
        !lv_obj_has_flag(headphoneSetupPage, LV_OBJ_FLAG_HIDDEN))
      refreshHeadphonePage();
  }

  const AudioMetrics a = AudioEngine::getMetrics();
  const CWDecoderState c = CWDecoder::getState();

  lastLearningUiState = c;
  haveLearningUiState = true;
  if (c.learningRevision != lastLearningSavedRevision &&
      c.learningQuality >= AdaptiveLearner::kApplyQuality)
    persistLearningProfile(c, false);
  if (cwTypesOpen) refreshLearningFooter(c);

  // V1.70: regulate amplitude, not SNR (digital gain scales signal AND
  // noise). The 100..260-count mark band leaves margin above the fixed
  // 18-count key threshold without chasing noise or quiet key-up gaps.
  if (autoInputLevel && !c.weakSignal) {
    const float rawPeak = c.inputChannel ? a.peakDbRight : a.peakDbLeft;
    const bool validCw = c.measuredToneValid && c.spectralSnrDb >= 8.0f &&
                         rawPeak > -75.0f && !CWDecoder::relockPending();
    if (validCw && now - lastAutoLevelAdjust >= 1000) {
      lastAutoLevelAdjust = now;
      int level = static_cast<int>(CWDecoder::inputLevelPercent());
      int step = 0;
      if (c.signalDbfs > -38.0f) step = -3;
      else if (c.signalDbfs > -42.0f) step = -1;
      else if (c.signalDbfs < -56.0f) step = +3;
      else if (c.signalDbfs < -50.0f) step = +1;
      const int next = constrain(level + step, 1, 30);
      if (next != level) {
        CWDecoder::setInputLevelPercent(static_cast<uint8_t>(next));
        Serial.printf("[AUTO LEVEL] signal %.1f dBFS -> input %d%%\n",
                      static_cast<double>(c.signalDbfs), next);
      }
    }
  }

  char text[320];
  const bool audioPageVisible =
      setupOverlay && headphoneSetupPage &&
      !lv_obj_has_flag(setupOverlay, LV_OBJ_FLAG_HIDDEN) &&
      !lv_obj_has_flag(headphoneSetupPage, LV_OBJ_FLAG_HIDDEN);

  if (!a.i2sOk || !a.codecOk) {
    snprintf(text, sizeof(text), "AUDIO ERROR");
    lv_obj_set_style_text_color(statusLabel, DisplayColors::StatusError(), 0);
    setLabelIfChanged(statusLabel, text);
  } else {
    lv_obj_set_style_text_color(statusLabel,DisplayColors::BrightCyan(),0);
    setLabelIfChanged(statusLabel,c.weakSignal ? (c.toneLocked ? "WEAK: TONE HELD" : "WEAK: SEARCHING") : "");
  }

  // V1.6: integer readouts are calmer and fit the enlarged metric cards cleanly.
  const float displayedToneHz = c.autoTone ? c.peakHz : c.toneHz;
  snprintf(text, sizeof(text), "RX TONE  #00E0E0 %d Hz#",
           static_cast<int>(lroundf(displayedToneHz)));
  setLabelIfChanged(toneValue, text);
  snprintf(text, sizeof(text), "SPEED  #00D000 %d WPM#",
           static_cast<int>(lroundf(c.wpm)));
  setLabelIfChanged(wpmValue, text);
  snprintf(text, sizeof(text), "SNR  #00D000 %d dB#",
           static_cast<int>(lroundf(c.snrDb)));
  setLabelIfChanged(snrValue, text);

  // V2.00: overload warning belongs on the MAIN decoder page, not inside
  // AUDIO LEVELS. Check the input every 50 ms so short peaks are caught, but
  // only modify LVGL styles when the visible state actually changes.
  const float inputPeakDbfs = fmaxf(a.peakDbLeft, a.peakDbRight);
  if (inputPeakDbfs >= AUDIO_OVER_THRESHOLD_DBFS) {
    audioOverHoldUntilMs = now + AUDIO_OVER_HOLD_MS;
  }
  const bool audioTooHigh = (static_cast<int32_t>(audioOverHoldUntilMs - now) > 0);
  if (audioTooHigh != audioOverVisualState) {
    audioOverVisualState = audioTooHigh;
    if (audioOverLed) {
      lv_obj_set_style_bg_color(audioOverLed,
          audioTooHigh ? lv_color_hex(0xE53935) : lv_color_hex(0x2ECC71), 0);
      lv_obj_set_style_border_color(audioOverLed,
          audioTooHigh ? lv_color_hex(0xFFB0A8) : lv_color_hex(0xB8FFD4), 0);
    }
  }

  // Only touch AUDIO LEVELS diagnostics while that page is visible. Hidden
  // setup objects stay quiet in the background.
  if (audioPageVisible && now - lastAudioMetricsUiMs >= 200) {
    lastAudioMetricsUiMs = now;
    if (adcPeakValueLabel) {
      snprintf(text, sizeof(text), "%d dBFS", static_cast<int>(lroundf(inputPeakDbfs)));
      setLabelIfChanged(adcPeakValueLabel, text);
      lv_obj_set_style_text_color(adcPeakValueLabel,
          audioTooHigh ? lv_color_hex(0xFF6B66) : DisplayColors::BrightCyan(), 0);
    }
    if (decoderSignalValueLabel) {
      snprintf(text, sizeof(text), "%d dBFS", static_cast<int>(lroundf(c.signalDbfs)));
      setLabelIfChanged(decoderSignalValueLabel, text);
    }
    if (setupSnrValueLabel) {
      snprintf(text, sizeof(text), "%d dB", static_cast<int>(lroundf(c.snrDb)));
      setLabelIfChanged(setupSnrValueLabel, text);
    }
  }

  if(c.weakSignal != lastWeakMode) {
    lastWeakMode=c.weakSignal;
    tuneWindowInitialized=false;
    setButtonAvailableVisual(autoLevelButton, !c.weakSignal);
  }
  setLabelIfChanged(autoButtonLabel, c.autoTone ? "AUTO TONE" : "MANUAL");
  if (autoButton) {
    if (c.autoTone) lv_obj_add_state(autoButton, LV_STATE_CHECKED);
    else lv_obj_remove_state(autoButton, LV_STATE_CHECKED);
  }
  if (autoLevelButton) {
    if (autoInputLevel) lv_obj_add_state(autoLevelButton, LV_STATE_CHECKED);
    else lv_obj_remove_state(autoLevelButton, LV_STATE_CHECKED);
  }

  // Keep the setup slider/value synchronized with AUTO LEVEL without writing
  // Preferences on every automatic adjustment.
  if (audioPageVisible && inputGainSlider && autoInputLevel) {
    const uint8_t level = CWDecoder::inputLevelPercent();
    if (lv_slider_get_value(inputGainSlider) != level) {
      audioPageProgrammaticUpdate = true;
      lv_slider_set_value(inputGainSlider, level, LV_ANIM_OFF);
      audioPageProgrammaticUpdate = false;
    }
    if (inputGainValueLabel) {
      snprintf(text, sizeof(text), "%u %%", static_cast<unsigned>(level));
      setLabelIfChanged(inputGainValueLabel, text);
    }
  }

  if (setupOverlay && !lv_obj_has_flag(setupOverlay, LV_OBJ_FLAG_HIDDEN)) {
    lastWaterfallLineMs = now;
    return;
  }
  if (now - lastScopeUpdate < 50) return;
  lastScopeUpdate = now;

  drawTuningGuide(c,now);

}

} // namespace CWUI
