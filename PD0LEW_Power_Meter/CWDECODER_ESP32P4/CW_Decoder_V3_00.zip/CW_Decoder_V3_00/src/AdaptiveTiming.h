#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstring>

// Audio-task-owned timing learner for HAND-SENT + FADING ASSIST.
// The sender's mark lengths and gaps are learned independently: hand keying
// need not have an exact 1:3 dot/dash ratio or a three-dot letter gap.
// Fixed histories only; no dictionary, callsign knowledge or heap allocation.
class AdaptiveTiming {
 public:
  void reset() {
    markCount = markWrite = gapCount = gapWrite = 0;
    markCutoff = letterGap = referenceDot = 0;
  }
  float markThreshold() const { return markCutoff; }
  float letterThreshold() const { return letterGap; }

  void observeMark(float ms, float dot) {
    checkSpeed(dot);
    if (ms < dot*0.5f || ms > dot*5.0f) return;
    marks[markWrite] = ms;
    markWrite = (markWrite+1) % kHistory;
    if (markCount < kHistory) ++markCount;
    if (markCount < 8) return;
    float sorted[kHistory];
    std::copy(marks, marks+markCount, sorted);
    std::sort(sorted, sorted+markCount);
    float best = 0, threshold = 0;
    for (size_t split=3; split+3<=markCount; ++split) {
      float lo=0, hi=0;
      means(sorted, markCount, split, lo, hi);
      if (hi < lo*1.7f || hi > lo*4.5f || lo < dot*0.5f || lo > dot*1.8f) continue;
      const float quality = separation(sorted, markCount, split, lo, hi);
      if (quality > best && quality > 9) {
        best = quality;
        threshold = (lo+hi)*0.5f;
      }
    }
    if (threshold > dot*1.4f && threshold < dot*2.8f) markCutoff = threshold;
  }

  void observeGap(float ms, float dot) {
    checkSpeed(dot);
    if (ms < dot*0.35f || ms > dot*4.0f) return;
    gaps[gapWrite] = ms;
    gapWrite = (gapWrite+1) % kHistory;
    if (gapCount < kHistory) ++gapCount;
    if (gapCount < 8) return;
    float sorted[kHistory];
    std::copy(gaps, gaps+gapCount, sorted);
    std::sort(sorted, sorted+gapCount);
    float best=0, threshold=0;
    for (size_t split=4; split+2<=gapCount; ++split) {
      float lo=0, hi=0;
      means(sorted, gapCount, split, lo, hi);
      if (hi < lo*1.5f || hi > lo*4.0f || hi-lo < dot*0.45f) continue;
      const float quality = separation(sorted, gapCount, split, lo, hi);
      if (quality > best && quality > 9) {
        best = quality;
        threshold = (lo+hi)*0.5f;
      }
    }
    if (threshold > dot*0.9f && threshold < dot*2.2f) {
      // Keep the shortest qualified letter spacing: later, longer letters
      // must not make us merge the sender's short C-to-Q gaps again.
      letterGap = letterGap > 0 ? std::fmin(letterGap, threshold) : threshold;
    }
  }
 private:
  static constexpr size_t kHistory = 32;
  float marks[kHistory] = {}, gaps[kHistory] = {};
  size_t markCount=0, markWrite=0, gapCount=0, gapWrite=0;
  float markCutoff=0, letterGap=0, referenceDot=0;

  void checkSpeed(float dot) {
    if (referenceDot == 0) referenceDot = dot;
    else if (dot < referenceDot*0.8f || dot > referenceDot*1.25f) {
      // Discard old spacing when the sending speed materially changes.
      reset();
      referenceDot = dot;
    }
  }
  static void means(const float* sorted, size_t count, size_t split, float& lo, float& hi) {
    for (size_t i=0; i<split; ++i) lo += sorted[i];
    lo /= split;
    for (size_t i=split; i<count; ++i) hi += sorted[i];
    hi /= count-split;
  }
  static float separation(const float* sorted, size_t count, size_t split, float lo, float hi) {
    float variance=0;
    for (size_t i=0; i<count; ++i) {
      const float delta=sorted[i]-(i<split ? lo : hi);
      variance += delta*delta;
    }
    return (hi-lo)*(hi-lo)/(variance/count+1.0f);
  }
};
