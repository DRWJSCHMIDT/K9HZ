#include "CWUI.cpp"
#include <cassert>
#include <fstream>
#include <iostream>
#include <string>
namespace AudioEngine {
 AudioMetrics getMetrics() { AudioMetrics a; a.i2sOk=a.codecPresent=a.codecOk=a.streamOk=true;return a; }
 void setSerialDiagnosticsEnabled(bool) {}
 bool setHeadphoneVolumePercent(uint8_t) { return true; }
}
namespace DisplayPower {void setBrightnessPercent(uint8_t){} void setScreensaverMinutes(uint16_t){} }
static unsigned char frame[1280*720*3];
void flush(lv_display_t *d,const lv_area_t *a,uint8_t *px) {
 for(int y=a->y1;y<=a->y2;++y) for(int x=a->x1;x<=a->x2;++x) {
   auto i=(y*1280+x)*3;
   frame[i]=px[2];frame[i+1]=px[1];frame[i+2]=px[0];px+=3;
 }
 lv_display_flush_ready(d);
}
int main() {
 lv_init();auto d=lv_display_create(1280,720);lv_display_set_color_format(d,LV_COLOR_FORMAT_RGB888);
 static uint8_t draw[1280*90*3];lv_display_set_buffers(d,draw,nullptr,sizeof(draw),LV_DISPLAY_RENDER_MODE_PARTIAL);
 lv_display_set_flush_cb(d,flush);AppSettings::begin();CWDecoder::begin();
 std::cerr<<"Creating UI\n";CWUI::create();std::cerr<<"UI created\n";
 lv_obj_update_layout(lv_screen_active());lv_refr_now(nullptr);std::cerr<<"Initial frame rendered\n";
 CWDecoderState c;c.toneHz=700;c.autoTone=false;
 CWDecoder::setManualTone(700);
#ifdef TEST_GUIDE
 c.measuredToneValid=true;c.measuredToneHz=712;
 for(int n=1;n<=20;n++){c.spectrumSequence=n;drawTuningGuide(c,1000+n*50);lv_refr_now(nullptr);}
 assert(std::string(lv_label_get_text(guideAction))=="+12 Hz");
 CWDecoder::setManualTone(724);
 for(int n=21;n<=24;n++){c.spectrumSequence=n;drawTuningGuide(c,1000+n*50);}
 const std::string held=lv_label_get_text(guideAction);
 c.spectrumSequence=25;drawTuningGuide(c,2250);assert(held==lv_label_get_text(guideAction));
 for(int n=26;n<=50;n++){c.spectrumSequence=n;drawTuningGuide(c,1000+n*50);lv_refr_now(nullptr);}
 assert(std::string(lv_label_get_text(guideAction))=="-12 Hz");
 c.measuredToneValid=false;c.spectrumSequence++;drawTuningGuide(c,5000);
 assert(std::string(lv_label_get_text(guideAction))=="-- Hz");
#endif
 std::ofstream f("/tmp/guide_full.ppm",std::ios::binary);f<<"P6\n1280 720\n255\n";f.write((char*)frame,sizeof(frame));
 lv_mem_monitor_t m;lv_mem_monitor(&m);std::cerr<<"Used="<<m.total_size-m.free_size<<" free="<<m.free_size<<" largest="<<m.free_biggest_size<<"\n";
 setupOpenEvent(nullptr);scopePageEvent(nullptr);lv_refr_now(nullptr);setupCloseEvent(nullptr);
 std::cout<<"PASS: complete UI render and setup navigation\n";
}
