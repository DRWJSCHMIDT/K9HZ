#pragma once
#include <ArduinoJson.h>

// POST a raw JSON string to /api/command on the meter.
void sendCommand(const char* json);

// GET /api/cal?set=N  — returns parsed document (empty on error).
JsonDocument fetchCal(int setIdx);
