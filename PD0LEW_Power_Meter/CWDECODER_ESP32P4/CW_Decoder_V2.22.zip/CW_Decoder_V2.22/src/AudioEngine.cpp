#include "AudioEngine.h"
#include <atomic>
#include "CWDecoder.h"
#include "MonitorFilter.h"

#include <ESP_I2S.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <math.h>

namespace {
std::atomic<bool> serialDiagnosticsEnabled{true};
std::atomic<bool> filteredMonitor{false};
MonitorFilter listeningFilter;

AudioSGTL5000 *codec = nullptr;
I2SClass *audioI2S = nullptr;
TaskHandle_t audioTaskHandle = nullptr;
portMUX_TYPE metricsMux = portMUX_INITIALIZER_UNLOCKED;
AudioMetrics metrics;
volatile bool running = false;
volatile bool monitor = false;
volatile uint8_t headphoneVolumePct = 65;
volatile uint8_t analogInputGainIndex = 0;
uint32_t activeSampleRateHz = AudioEngine::DEFAULT_SAMPLE_RATE;

constexpr size_t FRAMES_PER_BLOCK = 256;
// PJRC/SGTL5000 standard I2S framing: 32-bit slots, 16 significant audio bits.
// The codec places its 16-bit sample in the upper half of each 32-bit slot.
struct StereoFrame32 {
  int32_t left;
  int32_t right;
};
static StereoFrame32 audioBuffer[FRAMES_PER_BLOCK];
static StereoFrame32 monitorBuffer[FRAMES_PER_BLOCK];

static inline int16_t sample16(int32_t slot) {
  return static_cast<int16_t>(slot >> 16);
}

static inline int16_t saturate16(int32_t v) {
  if (v > 32767) return 32767;
  if (v < -32768) return -32768;
  return static_cast<int16_t>(v);
}

static inline int32_t slotFromSample16(int16_t v) {
  return static_cast<int32_t>(v) * 65536;
}

float toDbfs(float linear) {
  if (linear <= 0.000001f) return -120.0f;
  const float db = 20.0f * log10f(linear);
  return db < -120.0f ? -120.0f : db;
}

void updateMetrics(const StereoFrame32 *frames, size_t frameCount,
                   uint32_t fps, uint32_t overruns) {
  if (!frames || frameCount == 0) return;

  int32_t peakL = 0;
  int32_t peakR = 0;
  double sumL = 0.0;
  double sumR = 0.0;
  int16_t minL = INT16_MAX, maxL = INT16_MIN;
  int16_t minR = INT16_MAX, maxR = INT16_MIN;
  size_t nonZero = 0;

  for (size_t i = 0; i < frameCount; ++i) {
    const int16_t l = sample16(frames[i].left);
    const int16_t r = sample16(frames[i].right);
    if (l < minL) minL = l;
    if (l > maxL) maxL = l;
    if (r < minR) minR = r;
    if (r > maxR) maxR = r;
    if (l != 0 || r != 0) ++nonZero;
    const int32_t al = (l == INT16_MIN) ? 32768 : abs(l);
    const int32_t ar = (r == INT16_MIN) ? 32768 : abs(r);
    peakL = max(peakL, al);
    peakR = max(peakR, ar);
    sumL += static_cast<double>(l) * static_cast<double>(l);
    sumR += static_cast<double>(r) * static_cast<double>(r);
  }

  const float rmsL = sqrtf(static_cast<float>(sumL / frameCount)) / 32768.0f;
  const float rmsR = sqrtf(static_cast<float>(sumR / frameCount)) / 32768.0f;
  const float pkL = peakL / 32768.0f;
  const float pkR = peakR / 32768.0f;

  portENTER_CRITICAL(&metricsMux);
  metrics.peakDbLeft = toDbfs(pkL);
  metrics.peakDbRight = toDbfs(pkR);
  metrics.rmsDbLeft = toDbfs(rmsL);
  metrics.rmsDbRight = toDbfs(rmsR);
  metrics.framesPerSecond = fps;
  metrics.overruns = overruns;
  metrics.streamOk = true;
  metrics.monitorEnabled = monitor;
  metrics.rawMinLeft = minL;
  metrics.rawMaxLeft = maxL;
  metrics.rawMinRight = minR;
  metrics.rawMaxRight = maxR;
  metrics.nonZeroPermille = static_cast<uint16_t>((nonZero * 1000U) / frameCount);
  metrics.rawDataActive = (peakL > 2 || peakR > 2);

  const size_t points = AudioMetrics::kWaveformPoints;
  for (size_t i = 0; i < points; ++i) {
    size_t src = (i * frameCount) / points;
    if (src >= frameCount) src = frameCount - 1;
    metrics.waveformLeft[i] = sample16(frames[src].left);
    metrics.waveformRight[i] = sample16(frames[src].right);
  }
  portEXIT_CRITICAL(&metricsMux);
}

void audioTask(void *) {
  uint32_t secondStart = millis();
  uint32_t framesThisSecond = 0;
  uint32_t lastFps = 0;
  uint32_t overruns = 0;

  while (running) {
    const size_t bytesRead = audioI2S->readBytes(
      reinterpret_cast<char *>(audioBuffer),
      sizeof(audioBuffer)
    );

    if (bytesRead == 0) {
      ++overruns;
      vTaskDelay(1);
      continue;
    }

    const size_t framesRead = bytesRead / sizeof(StereoFrame32);
    framesThisSecond += static_cast<uint32_t>(framesRead);

    // Feed the selected 48/96 kHz SGTL5000 stream into the independent CW DSP.
    CWDecoder::processI2S32(reinterpret_cast<const int32_t *>(audioBuffer), framesRead);

    if (monitor) {
      // Filter a separate unity-gain listening branch; leave decoder input,
      // samples and gain handling unchanged. Both ears receive the same audio.
      const CWDecoderState monitorState = CWDecoder::getState();
      listeningFilter.configure(monitorState.toneHz, monitorState.filterBandwidthHz,
                                monitorState.weakSignal, filteredMonitor.load(),
                                activeSampleRateHz);
      for (size_t i = 0; i < framesRead; ++i) {
        const int16_t in = sample16(audioBuffer[i].left);
        const int32_t outSlot = slotFromSample16(listeningFilter.process(in));
        monitorBuffer[i].left = outSlot;
        monitorBuffer[i].right = outSlot;
      }

      const size_t txBytes = framesRead * sizeof(StereoFrame32);
      const size_t bytesWritten = audioI2S->write(
        reinterpret_cast<const uint8_t *>(monitorBuffer),
        txBytes
      );
      if (bytesWritten != txBytes) ++overruns;
    }

    const uint32_t now = millis();
    if (now - secondStart >= 1000) {
      lastFps = framesThisSecond;
      framesThisSecond = 0;
      secondStart = now;
    }

    updateMetrics(audioBuffer, framesRead, lastFps, overruns);

    static uint32_t lastRawPrint = 0;
    if (serialDiagnosticsEnabled.load() && now - lastRawPrint >= 1000) {
      lastRawPrint = now;
      AudioMetrics m = AudioEngine::getMetrics();
      Serial.printf("Audio RAW: L[%d..%d] R[%d..%d] nonzero=%u.%u%%  rate=%lu frames/s\n",
                    m.rawMinLeft, m.rawMaxLeft, m.rawMinRight, m.rawMaxRight,
                    m.nonZeroPermille / 10, m.nonZeroPermille % 10,
                    static_cast<unsigned long>(m.framesPerSecond));
      const CWDecoderState cw = CWDecoder::getState();
      Serial.printf("CW: tone=%5.0f Hz  WPM=%4.1f  key=%s  SNR=%4.1f dB  Morse=%s\n",
                    cw.toneHz, cw.wpm, cw.keyDown ? "DOWN" : "UP", cw.snrDb,
                    cw.currentMorse[0] ? cw.currentMorse : "-");
    }
  }

  audioTaskHandle = nullptr;
  vTaskDelete(nullptr);
}


bool runHeadphoneSelfTest() {
  if (!codec || !audioI2S) return false;

  Serial.println("Audio: headphone self-test - 700 Hz stereo tone for 1 second");

  // Route I2S_IN -> DAC -> headphone for this test only.
  if (!codec->setHeadphoneSourceLineIn(false)) return false;
  if (!codec->setHeadphoneVolume(0.65f)) return false;
  if (!codec->setHeadphoneMute(false)) return false;

  constexpr float testHz = 700.0f;
  constexpr float amplitude = 0.12f;  // deliberately modest / safe
  constexpr size_t testFrames = 256;
  StereoFrame32 testBuffer[testFrames];
  double phase = 0.0;
  const double phaseStep = 2.0 * M_PI * testHz / static_cast<double>(activeSampleRateHz);
  const uint32_t start = millis();
  size_t totalWritten = 0;

  while (millis() - start < 1000) {
    for (size_t i = 0; i < testFrames; ++i) {
      const int16_t sample = static_cast<int16_t>(sinf(static_cast<float>(phase)) * (32767.0f * amplitude));
      const int32_t slot = static_cast<int32_t>(sample) * 65536;
      testBuffer[i].left = slot;
      testBuffer[i].right = slot;
      phase += phaseStep;
      if (phase >= 2.0 * M_PI) phase -= 2.0 * M_PI;
    }
    const size_t bytes = sizeof(testBuffer);
    const size_t n = audioI2S->write(reinterpret_cast<const uint8_t *>(testBuffer), bytes);
    totalWritten += n;
    if (n != bytes) {
      Serial.printf("Audio: headphone self-test short write %u/%u bytes\n",
                    static_cast<unsigned>(n), static_cast<unsigned>(bytes));
    }
  }

  codec->setHeadphoneMute(true);
  Serial.printf("Audio: headphone self-test complete, TX bytes=%u\n",
                static_cast<unsigned>(totalWritten));
  delay(30);
  return totalWritten > 0;
}

bool initI2S(uint32_t sampleRateHz) {
  // BCLK, WS/LRCLK, DOUT, DIN, MCLK
  audioI2S->setPins(
    AudioEngine::PIN_BCLK,
    AudioEngine::PIN_LRCLK,
    AudioEngine::PIN_DOUT,
    AudioEngine::PIN_DIN,
    AudioEngine::PIN_MCLK
  );
  audioI2S->setTimeout(100);

  return audioI2S->begin(
    I2S_MODE_STD,
    sampleRateHz,
    I2S_DATA_BIT_WIDTH_32BIT,
    I2S_SLOT_MODE_STEREO,
    -1,
    I2S_ROLE_MASTER
  );
}

bool startAudioTask() {
  if (audioTaskHandle) return true;
  running = true;
  BaseType_t taskResult = xTaskCreatePinnedToCore(
    audioTask,
    "pjrc_audio",
    6144,
    nullptr,
    4,
    &audioTaskHandle,
    0
  );
  if (taskResult != pdPASS) {
    running = false;
    audioTaskHandle = nullptr;
    return false;
  }
  return true;
}

bool stopAudioTask(uint32_t timeoutMs = 350) {
  running = false;
  const uint32_t started = millis();
  while (audioTaskHandle && (millis() - started) < timeoutMs) {
    vTaskDelay(pdMS_TO_TICKS(5));
  }
  if (audioTaskHandle) {
    // readBytes() uses a 100 ms timeout, so normally the task exits itself.
    // This is only a final safety net if the driver does not return in time.
    vTaskDelete(audioTaskHandle);
    audioTaskHandle = nullptr;
  }
  return audioTaskHandle == nullptr;
}

bool applyLiveRateHardware(uint32_t sampleRateHz) {
  if (!audioI2S || !codec) return false;
  audioI2S->end();
  delay(5);
  if (!initI2S(sampleRateHz)) return false;
  delay(2);
  if (!codec->setSampleRate(sampleRateHz)) {
    audioI2S->end();
    return false;
  }
  return true;
}

void restoreMonitorState(bool enabled, uint8_t volumePercent) {
  if (!codec) return;
  if (volumePercent > 0) {
    codec->setHeadphoneVolume(static_cast<float>(volumePercent) / 100.0f);
  }
  codec->setHeadphoneMute(!enabled || volumePercent == 0);
  monitor = enabled;
  portENTER_CRITICAL(&metricsMux);
  metrics.monitorEnabled = enabled;
  portEXIT_CRITICAL(&metricsMux);
}

} // namespace

namespace AudioEngine {
void setMonitorFiltered(bool enabled) { filteredMonitor.store(enabled); }
bool monitorFiltered() { return filteredMonitor.load(); }

void setSerialDiagnosticsEnabled(bool enabled) { serialDiagnosticsEnabled.store(enabled); }

bool begin(uint32_t sampleRateHz) {
  if (sampleRateHz != SAMPLE_RATE_48K && sampleRateHz != SAMPLE_RATE_96K) {
    Serial.printf("Audio: unsupported sample rate %lu Hz, using 96 kHz\n",
                  static_cast<unsigned long>(sampleRateHz));
    sampleRateHz = DEFAULT_SAMPLE_RATE;
  }
  activeSampleRateHz = sampleRateHz;

  Serial.println();
  Serial.println("Initializing PJRC Audio Adapter / SGTL5000");
  Serial.printf("Audio sample rate selected: %lu kHz\n",
                static_cast<unsigned long>(activeSampleRateHz / 1000U));
  Serial.printf("I2S1 pins: MCLK=%d BCLK=%d LRCLK=%d TX=%d RX=%d\n",
                PIN_MCLK, PIN_BCLK, PIN_LRCLK, PIN_DOUT, PIN_DIN);

  // Construct audio hardware objects only AFTER DSI/LVGL is fully running.
  // This completely removes I2S/codec global construction from pre-setup startup.
  if (!audioI2S) audioI2S = new I2SClass(I2S_NUM_1);
  if (!codec) codec = new AudioSGTL5000(Wire);
  if (!audioI2S || !codec) {
    Serial.println("Audio: unable to allocate I2S/codec objects");
    return false;
  }

  // GT911 already initialized Wire on GPIO7/8. Re-applying the same pins keeps
  // this audio module self-contained while sharing the same I2C bus.
  // DisplaySetup/GT911 has already started the shared Wire bus on GPIO7/8.
  Wire.setClock(400000);

  // I2S master is started first so the SGTL5000 sees MCLK/BCLK/LRCLK while
  // its registers are configured.
  if (!initI2S(activeSampleRateHz)) {
    Serial.println("Audio: I2S initialization FAILED");
    portENTER_CRITICAL(&metricsMux);
    metrics.i2sOk = false;
    portEXIT_CRITICAL(&metricsMux);
    return false;
  }

  portENTER_CRITICAL(&metricsMux);
  metrics.i2sOk = true;
  portEXIT_CRITICAL(&metricsMux);
  Serial.printf("Audio: I2S1 OK (%lu kHz, 32-bit slots / 16-bit SGTL audio, MCLK=%.3f MHz, BCLK=%.3f MHz)\n",
                static_cast<unsigned long>(activeSampleRateHz / 1000U),
                static_cast<double>(activeSampleRateHz * 256.0 / 1000000.0),
                static_cast<double>(activeSampleRateHz * 64.0 / 1000000.0));

  if (!codec->isPresent()) {
    Serial.println("Audio: SGTL5000 not found at I2C address 0x0A");
    portENTER_CRITICAL(&metricsMux);
    metrics.codecPresent = false;
    metrics.codecOk = false;
    portEXIT_CRITICAL(&metricsMux);
    return false;
  }

  const uint16_t id = codec->chipId();
  portENTER_CRITICAL(&metricsMux);
  metrics.codecPresent = true;
  metrics.codecId = id;
  portEXIT_CRITICAL(&metricsMux);
  Serial.printf("Audio: SGTL5000 CHIP_ID=0x%04X\n", id);

  if (!codec->beginLineIn(activeSampleRateHz)) {
    Serial.println("Audio: SGTL5000 configuration FAILED");
    return false;
  }

  codec->setLineInGainIndex(0);  // -6 dB analog input gain for maximum ADC headroom
  analogInputGainIndex = 0;

  // V1.15 SAFE2: first prove the physical headphone output with a known digital
  // test tone in BOTH channels.  This is independent of receiver audio.
  const bool hpTestOk = runHeadphoneSelfTest();
  Serial.printf("Audio: headphone self-test TX %s\n", hpTestOk ? "OK" : "FAILED");

  // Normal operation: keep the SAME proven digital DAC/headphone route that
  // produced the startup test tone.  The audio task copies LINE IN LEFT to both
  // headphone channels while the original RX data is still sent to the CW DSP.
  codec->setHeadphoneSourceLineIn(false);   // DAC -> headphone
  codec->setHeadphoneVolume(0.65f);         // startup/default monitor level
  headphoneVolumePct = 65;
  codec->setHeadphoneMute(false);
  monitor = true;                           // enable continuous I2S RX -> TX monitor

  codec->setAdcHighPass(true);
  codec->dumpAudioRegisters(Serial);

  portENTER_CRITICAL(&metricsMux);
  metrics.codecPresent = true;
  metrics.codecOk = true;
  metrics.codecId = id;
  metrics.lineInLevel = 0;
  metrics.inputGainIndex = 0;
  metrics.monitorEnabled = true;  // digital LINE IN LEFT -> both headphone channels
  portEXIT_CRITICAL(&metricsMux);

  // CW DSP is intentionally initialized only after I2S + SGTL5000 are proven.
  CWDecoder::begin(activeSampleRateHz);

  if (!startAudioTask()) {
    Serial.println("Audio: unable to create audio task");
    return false;
  }

  Serial.printf("Audio: %lu kHz LINE IN ready + CW DSP + clean LEFT-to-both-ear headphone monitor enabled\n",
                static_cast<unsigned long>(activeSampleRateHz / 1000U));
  return true;
}

bool switchSampleRate(uint32_t sampleRateHz) {
  if (sampleRateHz != SAMPLE_RATE_48K && sampleRateHz != SAMPLE_RATE_96K) return false;
  if (sampleRateHz == activeSampleRateHz) return true;
  if (!audioI2S || !codec) return false;

  const AudioMetrics before = getMetrics();
  if (!before.i2sOk || !before.codecOk) return false;

  const uint32_t oldRate = activeSampleRateHz;
  const bool oldMonitor = monitor;
  const uint8_t oldVolume = headphoneVolumePct;

  Serial.printf("[AUDIO] live sample-rate switch %lu -> %lu kHz\n",
                static_cast<unsigned long>(oldRate / 1000U),
                static_cast<unsigned long>(sampleRateHz / 1000U));

  // Remove any audible clock-transition transient, then let readBytes() return
  // and the core-0 audio task exit cleanly before touching the I2S clocks.
  codec->setHeadphoneMute(true);
  if (!stopAudioTask()) {
    restoreMonitorState(oldMonitor, oldVolume);
    Serial.println("[AUDIO] live switch FAILED: audio task would not stop");
    return false;
  }

  portENTER_CRITICAL(&metricsMux);
  metrics.streamOk = false;
  portEXIT_CRITICAL(&metricsMux);

  bool ok = applyLiveRateHardware(sampleRateHz);
  if (ok) {
    activeSampleRateHz = sampleRateHz;
    CWDecoder::reconfigureInputSampleRate(sampleRateHz);
    ok = startAudioTask();
  }

  if (!ok) {
    Serial.println("[AUDIO] new rate failed; restoring previous rate");
    stopAudioTask();
    const bool restored = applyLiveRateHardware(oldRate);
    if (restored) {
      activeSampleRateHz = oldRate;
      CWDecoder::reconfigureInputSampleRate(oldRate);
      if (!startAudioTask()) {
        Serial.println("[AUDIO] FATAL: previous rate restored but audio task could not restart");
      }
    } else {
      Serial.println("[AUDIO] FATAL: unable to restore previous I2S/codec rate");
      portENTER_CRITICAL(&metricsMux);
      metrics.i2sOk = false;
      metrics.codecOk = false;
      portEXIT_CRITICAL(&metricsMux);
    }
    restoreMonitorState(oldMonitor, oldVolume);
    return false;
  }

  restoreMonitorState(oldMonitor, oldVolume);
  portENTER_CRITICAL(&metricsMux);
  metrics.i2sOk = true;
  metrics.codecOk = true;
  metrics.streamOk = false;  // first new-rate block will mark it true
  portEXIT_CRITICAL(&metricsMux);

  Serial.printf("[AUDIO] live switch complete: %lu kHz, no ESP32 reboot\n",
                static_cast<unsigned long>(activeSampleRateHz / 1000U));
  return true;
}

bool isRunning() { return running; }
uint32_t sampleRateHz() { return activeSampleRateHz; }

AudioMetrics getMetrics() {
  AudioMetrics copy;
  portENTER_CRITICAL(&metricsMux);
  copy = metrics;
  portEXIT_CRITICAL(&metricsMux);
  return copy;
}

bool setMonitorEnabled(bool enabled) {
  AudioMetrics m = getMetrics();
  if (!m.codecOk) return false;
  if (!codec || !codec->setHeadphoneMute(!enabled)) return false;
  monitor = enabled;
  portENTER_CRITICAL(&metricsMux);
  metrics.monitorEnabled = enabled;
  portEXIT_CRITICAL(&metricsMux);
  Serial.printf("Audio monitor: %s\n", enabled ? "ON" : "OFF");
  return true;
}

bool monitorEnabled() { return monitor; }

bool setLineInLevel(uint8_t level) {
  if (level > 15) level = 15;
  if (!codec || !codec->setLineInLevel(level)) return false;
  portENTER_CRITICAL(&metricsMux);
  metrics.lineInLevel = level;
  portEXIT_CRITICAL(&metricsMux);
  Serial.printf("LINE IN level: %u\n", level);
  return true;
}

uint8_t lineInLevel() {
  portENTER_CRITICAL(&metricsMux);
  const uint8_t level = metrics.lineInLevel;
  portEXIT_CRITICAL(&metricsMux);
  return level;
}


bool setInputGainIndex(uint8_t index) {
  if (index > 19) index = 19;
  if (!codec || !codec->setLineInGainIndex(index)) return false;
  analogInputGainIndex = index;
  portENTER_CRITICAL(&metricsMux);
  metrics.inputGainIndex = index;
  portEXIT_CRITICAL(&metricsMux);
  const float db = -6.0f + 1.5f * static_cast<float>(index);
  Serial.printf("LINE IN analog gain: %+.1f dB (index %u)\n",
                static_cast<double>(db), static_cast<unsigned>(index));
  return true;
}

uint8_t inputGainIndex() {
  return analogInputGainIndex;
}

float inputGainDb() {
  return -6.0f + 1.5f * static_cast<float>(analogInputGainIndex);
}

bool setHeadphoneVolumePercent(uint8_t percent) {
  if (percent > 100) percent = 100;
  if (!codec) return false;

  bool ok = true;
  if (percent == 0) {
    ok &= codec->setHeadphoneMute(true);
  } else {
    ok &= codec->setHeadphoneVolume(static_cast<float>(percent) / 100.0f);
    ok &= codec->setHeadphoneMute(false);
  }
  if (!ok) return false;

  headphoneVolumePct = percent;
  Serial.printf("Headphone volume: %u%%\n", static_cast<unsigned>(percent));
  return true;
}

uint8_t headphoneVolumePercent() {
  return headphoneVolumePct;
}


} // namespace AudioEngine
