#include "api_client.h"
#include "prefs.h"
#include <WiFi.h>
#include <WiFiClient.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

void sendCommand(const char* json) {
    if (WiFi.status() != WL_CONNECTED) return;

    WiFiClient client;
    if (!client.connect(gPrefs.meterHost, 80)) return;
    client.setTimeout(2000);

    int len = strlen(json);
    client.printf(
        "POST /api/command HTTP/1.1\r\n"
        "Host: %s\r\n"
        "Content-Type: application/json\r\n"
        "Content-Length: %d\r\n"
        "Connection: close\r\n\r\n",
        gPrefs.meterHost, len
    );
    client.print(json);

    unsigned long t = millis();
    while (client.connected() && millis() - t < 1000)
        while (client.available()) client.read();
    client.stop();
}

JsonDocument fetchCal(int setIdx) {
    DynamicJsonDocument doc(32768);
    if (WiFi.status() != WL_CONNECTED) return doc;

    char url[128];
    snprintf(url, sizeof(url), "http://%s/api/cal?set=%d", gPrefs.meterHost, setIdx);

    HTTPClient http;
    http.begin(url);
    http.setTimeout(3000);
    if (http.GET() == 200) {
        String body = http.getString();
        deserializeJson(doc, body);
    }
    http.end();
    return doc;
}
