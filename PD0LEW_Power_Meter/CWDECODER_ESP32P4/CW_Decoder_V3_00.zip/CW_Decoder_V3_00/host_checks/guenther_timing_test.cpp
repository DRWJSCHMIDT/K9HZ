#include <cmath>
#include <cstdio>
#include "../src/GuentherTiming.h"

static int failures = 0;
static void check(bool ok, const char *msg) {
  if (!ok) { std::printf("FAIL: %s\n", msg); ++failures; }
}

int main() {
  GuentherTiming g;
  g.reset(60.0f);
  check(std::fabs(g.markBoundary() - 105.0f) < 0.6f,
        "exact Eq. 3.2 boundary DOT/4 + DASH/2");
  check(g.acquisitionStage() == GuentherTiming::AcquisitionStage::Fast,
        "starts in 1/2 acquisition stage");
  check(!g.ready(), "not ready before first 16 accepted marks");

  // 16 marks: 1/2 update stage.
  for (int i=0; i<16; ++i) {
    const float m = (i & 1) ? (180.0f + (i%3-1)*3.0f) : (60.0f + (i%3-1)*2.0f);
    g.observeMark(m, 92.0f);
  }
  check(g.ready(), "ready after 16 clean marks");
  check(!g.fullyAcquired(), "still refining before 49 marks");
  check(g.acquisitionStage() == GuentherTiming::AcquisitionStage::Refine,
        "uses 1/4 refinement stage after 16 marks");

  for (int i=16; i<49; ++i) {
    const float m = (i & 1) ? (181.0f + (i%5-2)*2.0f) : (60.0f + (i%5-2)*1.2f);
    g.observeMark(m, 92.0f);
  }
  check(g.fullyAcquired(), "49-pulse Guenther acquisition completes");
  check(g.acquisitionStage() == GuentherTiming::AcquisitionStage::Tracking,
        "uses final 1/8 tracking stage");
  check(!g.classifyDash(75.0f), "75 ms remains dot-like");
  check(g.classifyDash(125.0f), "125 ms remains dash-like");

  for (int i=0; i<12; ++i) g.observeSymbolGap(60.0f + (i&1 ? 3.0f : -3.0f), 90.0f);
  for (int i=0; i<8; ++i) g.observeCharacterGap(180.0f + (i&1 ? 8.0f : -8.0f), 90.0f);
  for (int i=0; i<8; ++i) g.observeNonSymbolGapAfter(210.0f + (i&1 ? 12.0f : -10.0f), 60.0f, false, 90.0f);

  const float afterDot = g.symbolBoundaryAfter(60.0f, false);
  const float afterDash = g.symbolBoundaryAfter(180.0f, true);
  check(afterDash < afterDot, "Eq. 3.4 dash compensation shortens symbol boundary");
  check(g.cwSpaceReady(), "C-W space average acquired from non-symbol spaces after dots");
  check(std::fabs(g.wordBoundaryAfter(180.0f, true) - g.wordBoundaryAfter(60.0f, false)) > 1.0f,
        "Eq. 3.5 dash-dependent C-W boundary is active");

  check(g.suspiciousShortPulse(25.0f), "sub-half-dot pulse is recoverable spike candidate");
  check(!g.suspiciousShortPulse(50.0f), "normal dot is not spike candidate");
  check(g.suspiciousInternalGap(150.0f, 60.0f, false), "long internal gap can trigger run-on recovery");
  check(!g.suspiciousInternalGap(62.0f, 60.0f, false), "normal symbol gap is retained");
  check(g.qsbMergeGap(20.0f), "very short internal gap is QSB merge candidate");

  check(g.sendingStyle() == GuentherTiming::SendingStyle::Keyer,
        "regular marks/gaps are automatically recognized as keyer-like");

  const uint16_t rejectedBefore = g.rejectedOutliers();
  g.observeMark(420.0f, 95.0f); // extreme dash outlier after stable acquisition
  check(g.rejectedOutliers() > rejectedBefore, "statistical outlier cannot retrain timing");

  const uint16_t lowBefore = g.rejectedLowConfidence();
  g.observeMark(61.0f, 20.0f);
  check(g.rejectedLowConfidence() > lowBefore, "low-confidence mark cannot retrain timing");

  GuentherTiming slow;
  slow.reset(60.0f);
  slow.syncDotEstimate(220.0f);
  check(std::fabs(slow.dotAverage() - 220.0f) < 0.6f, "slow hand-send sync avoids 20 WPM seed lock");
  check(!slow.classifyDash(220.0f), "220 ms slow dot is dot after cycle sync");
  check(slow.classifyDash(660.0f), "660 ms slow dash is dash after cycle sync");

  GuentherTiming fast;
  fast.reset(60.0f);
  fast.syncDotEstimate(24.0f);
  check(std::fabs(fast.dotAverage() - 24.0f) < 0.6f, "50 WPM sync follows fast dot estimate");
  check(!fast.classifyDash(24.0f), "24 ms fast dot remains dot");
  check(fast.classifyDash(72.0f), "72 ms fast dash remains dash");

  if (failures) return 1;
  std::puts("PASS: exact Guenther stages/boundaries, confidence gate and outlier guard");
  return 0;
}
