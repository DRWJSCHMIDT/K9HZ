#include "CWDecoder.h"
#include <fstream>
#include <iostream>
#include <vector>
int main(int argc,char**argv){
 if(argc<3)return 1;
 std::ifstream f(argv[1],std::ios::binary);std::vector<int16_t>x;
 int16_t sample;while(f.read((char*)&sample,2))x.push_back(sample);
 CWDecoder::begin();if(argc>4)CWDecoder::setWeakSignal(true);CWDecoder::setInputLevelPercent(uint8_t(atoi(argv[2])));
 if(argc>3 && atof(argv[3])>0)CWDecoder::setManualTone(float(atof(argv[3])));
 int32_t slots[512];std::string text;
 for(size_t i=0;i<x.size()+192000;i+=256){
  size_t n=std::min(size_t(256),x.size()+192000-i);
  for(size_t k=0;k<n;++k){int32_t v=i+k<x.size()?int32_t(x[i+k])*65536:0;slots[k*2]=slots[k*2+1]=v;}
  CWDecoder::processI2S32(slots,n);
  char b[256];bool over=false;size_t count=CWDecoder::readText(b,sizeof(b),over);text.append(b,count);
 }
 auto c=CWDecoder::getState();std::cout<<"text=["<<text<<"] wpm="<<c.wpm<<" tone="<<c.toneHz<<"\n";
}
