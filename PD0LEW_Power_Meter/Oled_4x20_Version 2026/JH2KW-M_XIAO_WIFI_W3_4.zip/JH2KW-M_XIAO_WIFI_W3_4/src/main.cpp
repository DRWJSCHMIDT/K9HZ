/*
 * ESP32 Power Meter - SSE Protocol Handler
 * Teensy-managed WiFi + AsyncWebServer + Server-Sent Events
 * UART2 @ 921600 baud
 * 
 * Copyright (c) 2026 Paul Davis
 * 
 * Interface between ESP32 and Teensy microcontroller to provide realtime display
 * of power meter data over WiFi and remote operation via web interface. 
 * 
 * Features:
 * - Efficient bidirectional TEENSY interface (JSON over UART2 @ 921600 baud)
 * - Periodic heartbeat to Teensy to indicate ESP32 is alive
 * - Provides time to Teensy via NTP sync
 * 
 * Network Features: 
 * - Modern responsive web interface
 * - WiFi credentials supplied by JH2KW-M Teensy over UART
 * - High frequency data updates via SSE (50ms to 200ms intervals)
 * - NTP client for UTC time synchronization (Web & Meter)
 * - mDNS for easy local network access
 * - Low bandwidth requirements (~4kbps @75ms interval)
 * 
 * Web Interface Features:
 * - JSON-based command and data protocol
 * - Autoranging bargraph display of power levels
 * - Optional peak-hold mode
 * - Control and display of band buttons - selections track both ways
 * - Control and display of pep modes - selections track both ways
 * - Display of calibration sets values
 * - Calibration data save/restore via web interface
 * - 'Classic' interface available at /classic.html
 * Future Enhancements:
 * - OTA updates of application firmware, web interface
 * - OTA updates of Teensy firmware via ESP32
 */

#include <Arduino.h>
#include <WiFi.h>
#include <LittleFS.h>
#include <Update.h>
#include <time.h>

#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <ArduinoJson.h>
#include <ESPmDNS.h>

#define RELEASE PLATFORM "" VERSION 

// ============== NTP Configuration ==============
#define NTP_SERVER1      "pool.ntp.org"
#define NTP_SERVER2      "time.nist.gov"
#define NTP_SYNC_INTERVAL 3600000  // Re-sync every hour (ms)
#define UTC_OFFSET       0         // Keep system epoch/NTP in UTC
#define UTC_OFFSET_DST   0
// Netherlands local time. POSIX TZ rule: CET in winter, CEST in summer,
// DST starts last Sunday of March at 02:00 and ends last Sunday of October at 03:00.
#define LOCAL_TZ         "CET-1CEST,M3.5.0/2,M10.5.0/3"

// ============== Configuration ==============
#define SERIAL_BAUD      921600

#define SSE_UPDATE_MS    75      // SSE update interval (configurable)
#define MDNS_HOSTNAME    "powermeter"


// ============== Configuration ==============
#ifdef ESPC3
#define Serial2 Serial1          // Reassign for C3
#define UART2_RX         D7      // Johan mapping was 9/10 
#define UART2_TX         D6      // now D6/D7 for v1.1 board
#define WIFI_PIN         D1      // Standard for C3 modules?
#else
#define UART2_RX         16
#define UART2_TX         17
#define WIFI_PIN         23     // WiFi connected LED
#endif

// ============== Debug Output Control ==============
#define DEBUG_SERIAL     1       // Set to 1 to enable Serial output, 0 to disable

#if DEBUG_SERIAL
  #define DEBUG_PRINT(x)     Serial.print(x)
  #define DEBUG_PRINTLN(x)   Serial.println(x)
  #define DEBUG_PRINTF(...)  Serial.printf(__VA_ARGS__)
#else
  #define DEBUG_PRINT(x)
  #define DEBUG_PRINTLN(x)
  #define DEBUG_PRINTF(...)
#endif

#define RELEASE PLATFORM "" VERSION 

// ============== Global Objects ==============
AsyncWebServer server(80);
AsyncEventSource events("/events");  // SSE endpoint

// ============== Data Structures ==============
struct RealtimeData {
    int pep_val = 1;
    int cpl = 1;
    int btns = 0;
    String fwd = "0.0W";
    String pep = "0.0W";
    String avg = "0.0W";
    String dbm = "0.0dBm";
    String vswr = "1.0";
    String pk = "0.0W";
    String ref = "0.0W";
    String inst = "0.0W";
    float volf = 0.0;
    float volr = 0.0;
    String swrt = "Off";
} rtData;

struct CalibrationData {
    String set = "A";
    float cal1_db = 0.0;
    float cal1_fwd = 0.0;
    float cal1_rev = 0.0;
    float cal2_db = 0.0;
    float cal2_fwd = 0.0;
    float cal2_rev = 0.0;
    String call = "";
} calData[8];

String teensyFirmwareVersion = "";

static const char* getCalLabel(int idx) {
    static const char* labels[8] = {
        "HF", "HF", "6M", "6M", "2M", "2M", "70cm", "70cm"
    };
    if (idx < 0 || idx > 7) return "";
    return labels[idx];
}

// Build a "sets" array from calData[] with proper float formatting.
// ArduinoJson drops ".0" from whole-number floats; serialized(String()) bypasses that.
static void buildCalSets(JsonObject dest) {
    JsonArray sets = dest["sets"].to<JsonArray>();
    for (int i = 0; i < 8; i++) {
        JsonObject s = sets.add<JsonObject>();
        s["set"] = i;
        s["label"] = getCalLabel(i);
        s["cal1_db"]  = serialized(String(calData[i].cal1_db,  1));
        s["cal1_fwd"] = serialized(String(calData[i].cal1_fwd, 3));
        s["cal1_rev"] = serialized(String(calData[i].cal1_rev, 3));
        s["cal2_db"]  = serialized(String(calData[i].cal2_db,  1));
        s["cal2_fwd"] = serialized(String(calData[i].cal2_fwd, 3));
        s["cal2_rev"] = serialized(String(calData[i].cal2_rev, 3));
    }
}

struct WifiInfo {
    String ssid = "";
    String ip = "";
    String utc = "00:00:00";
    String local = "00:00:00";
    String date = "--- -- --- ----";
    String dateUtc = "--- -- --- ----";
    String dateLocal = "--- -- --- ----";
    String zone = "CET";
    int rssi = 0;
} wifiInfo;

// On-demand nearby-network scan for the JH2KW-M OLED.  Keep this fully
// asynchronous so UART, web server and watchdog servicing continue normally.
constexpr uint8_t WIFI_SCAN_MAX_RESULTS = 12;
struct WifiScanItem {
    String ssid;
    int32_t rssi = -127;
    bool secure = false;
};
WifiScanItem wifiScanItems[WIFI_SCAN_MAX_RESULTS];
bool oledScanRequested = false;
bool oledScanActive = false;
bool oledScanSending = false;
bool oledScanCancelConnect = false;
bool oledScanReconnectAfter = false;
uint8_t oledScanCount = 0;
uint8_t oledScanSendIndex = 0;
unsigned long oledScanStartAt = 0;
unsigned long oledScanLastSend = 0;

// WiFi credentials are owned by JH2KW-M/Teensy. The XIAO keeps only a RAM
// copy and requests them again after every boot; no WiFiManager/NVS portal.
String teensyWifiSsid = "";
String teensyWifiPassword = "";
bool wifiCredentialsReceived = false;
bool wifiConnectRequested = false;
bool wifiConnecting = false;
bool wifiMdnsStarted = false;
bool wifiNtpStarted = false;
unsigned long wifiConnectStart = 0;
unsigned long lastWifiCredentialRequest = 0;
unsigned long lastWifiRetry = 0;
constexpr unsigned long WIFI_CONNECT_TIMEOUT_MS = 20000;
constexpr unsigned long WIFI_CREDENTIAL_REQUEST_MS = 2000;
constexpr unsigned long WIFI_RETRY_MS = 10000;


// ============== Config Data Storage ==============
// Stores config sections received from Teensy (as JSON strings)
String configSections[8];  // cal, swr, meter, usb, timing, scale, bands, display
const char* configSectionNames[] = { "cfg_cal", "cfg_swr", "cfg_meter", "cfg_usb",
                                      "cfg_timing", "cfg_scale", "cfg_bands", "cfg_display" };
bool configComplete = false;
bool configRequested = false;

// ============== State Variables ==============
unsigned long lastSseUpdate = 0;
unsigned long sseUpdateInterval = SSE_UPDATE_MS;
unsigned long lastWifiInfoUpdate = 0;
unsigned long lastUtcUpdate = 0;
unsigned long lastNtpSync = 0;
unsigned long lastHeartbeat = 0;
bool ntpSynced = false;
#define WIFI_INFO_INTERVAL 2000  // Send WiFi info to Teensy every x ms
#define UTC_UPDATE_INTERVAL 1000 // Update UTC every second
#define HEARTBEAT_INTERVAL  1000 // Heartbeat to Teensy every second
int currentCalSet = 0;
String serialBuffer = "";

// UART diagnostics: cumulative counters are required because handleSerialData()
// drains Serial2 before the periodic USB status line is printed.
uint64_t teensyRxBytes = 0;
uint32_t teensyRxLines = 0;
unsigned long lastTeensyRxMs = 0;

// Pre-allocated heartbeat message
static const char heartbeatMsg[] = "{\"hb\":1}\n";
static const size_t heartbeatLen = sizeof(heartbeatMsg) - 1;

// ============== Function Prototypes ==============
void setupWiFi();
void serviceWiFi();
void startWiFiConnection();
void setupWebServer();
void setupSSE();
void setupNTP();
void updateUTC();
void handleSerialData();
void parseJsonMessage(const String& json);
void broadcastData();
void sendToTeensy(const String& json);
void requestNetworkScan();
void serviceNetworkScan();
void connectToStrongestAP();
void resetWiFiConfig();
// ============== Setup ==============
void setup() {
    #if DEBUG_SERIAL
    Serial.begin(115200);
    Serial.setDebugOutput(true);
    // Give native USB CDC time to enumerate after reset. Do not wait forever.
    unsigned long serialStart = millis();
    while (!Serial && (millis() - serialStart < 1500)) {
        delay(10);
    }
    Serial.printf("\n=== JH2KW-M XIAO %s BOOT ===\n", VERSION);
    Serial.flush();
    #endif

    // Initialize Serial2 AFTER network is up to avoid buffer issues during startup
    // Increase RX buffer to accommodate large calibration JSON (898 bytes)
    Serial2.setRxBufferSize(2048);
    Serial2.setTxBufferSize(2048);
    Serial2.begin(SERIAL_BAUD, SERIAL_8N1, UART2_RX, UART2_TX);

    pinMode(WIFI_PIN,OUTPUT);

    // Heartbeat is scheduled from loop() instead of a hardware ISR.
    // UART writes from an ESP32-C3 timer ISR can block the interrupt and
    // trigger the interrupt watchdog under Arduino-ESP32 3.x.

    DEBUG_PRINTLN("\n=== ESP32 Power Meter (SSE) ===");

    if (!LittleFS.begin(true, "/littlefs", 10, "littlefs")) {
        Serial.println("LittleFS mount failed");
    }

    // Initialize calibration set identifiers
    const char* sets = "ABCDEFGH";
    for (int i = 0; i < 8; i++) {
        calData[i].set = String(sets[i]);
    }
    
    // Request calibration data from Teensy at startup
    // Response is buffered by UART and processed in handleSerialData() on first pass
    // This populates the static data early
    sendToTeensy("{\"reqCal\":true}");

    // Send placeholder UTC to Teensy immediately
    Serial2.print("{\"utc\":\"99:99:99\"}\n");
    setupWiFi();
    delay(50);
    setupSSE();
    delay(100);
    setupWebServer();
    
    // Initialize Serial2 AFTER network is up to avoid buffer issues during startup
    // Serial2.begin(SERIAL_BAUD, SERIAL_8N1, UART2_RX, UART2_TX);
    
    DEBUG_PRINTLN("Setup complete");
}

// ============== Main Loop ==============
void loop() {
    const unsigned long now = millis();
    // Handle incoming serial data from Teensy first; WiFi credentials arrive here.
    handleSerialData();
    serviceWiFi();
    serviceNetworkScan();

    // USB diagnostic heartbeat. PlatformIO monitor uses DTR/RTS inactive, so it
    // may attach after the one-time boot messages were already printed. Keep a
    // low-rate status line running during hardware validation.
    #if DEBUG_SERIAL
    static unsigned long lastDebugAlive = 0;
    if (now - lastDebugAlive >= 2000) {
        lastDebugAlive = now;
        String ipText = (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : String("-");
        const unsigned long rxAge = lastTeensyRxMs ? (now - lastTeensyRxMs) : 0xFFFFFFFFUL;
        DEBUG_PRINTF("[ALIVE] ms=%lu wifi=%d ip=%s rssi=%d rx_bytes=%llu rx_lines=%lu rx_age_ms=%lu fwd=%s vswr=%s cpl=%d\n",
                     now,
                     (int)WiFi.status(),
                     ipText.c_str(),
                     (WiFi.status() == WL_CONNECTED) ? WiFi.RSSI() : 0,
                     (unsigned long long)teensyRxBytes,
                     (unsigned long)teensyRxLines,
                     rxAge,
                     rtData.fwd.c_str(),
                     rtData.vswr.c_str(),
                     rtData.cpl);
    }
    #endif

    // Periodic heartbeat to Teensy.  Keep UART access in normal task context;
    // never write Serial2 from a hardware timer ISR.
    if (now - lastHeartbeat >= HEARTBEAT_INTERVAL) {
        lastHeartbeat = now;
        Serial2.write((const uint8_t*)heartbeatMsg, heartbeatLen);
    }
    
    // Update the clock every second. Once NTP has synchronized, the ESP32's
    // system clock keeps running even through a temporary WiFi outage, so keep
    // feeding the Teensy clock screen without requiring a live AP connection.
    if ((ntpSynced || WiFi.status() == WL_CONNECTED) &&
        now - lastUtcUpdate >= UTC_UPDATE_INTERVAL) {
        lastUtcUpdate = millis();
        updateUTC();
        if (ntpSynced) {
            // Fixed-format fields contain only digits/letters/space/colon, so
            // write the small JSON packet directly without a per-second heap
            // allocation from ArduinoJson/String serialization.
            Serial2.print(F("{\"type\":\"clock\",\"utc\":\""));
            Serial2.print(wifiInfo.utc);
            Serial2.print(F("\",\"local\":\""));
            Serial2.print(wifiInfo.local);
            Serial2.print(F("\",\"date\":\""));
            Serial2.print(wifiInfo.dateLocal);
            Serial2.print(F("\",\"date_utc\":\""));
            Serial2.print(wifiInfo.dateUtc);
            Serial2.print(F("\",\"date_local\":\""));
            Serial2.print(wifiInfo.dateLocal);
            Serial2.print(F("\",\"zone\":\""));
            Serial2.print(wifiInfo.zone);
            Serial2.println(F("\"}"));
        }
    }
    
    // Periodic NTP re-sync
    if (ntpSynced && (millis() - lastNtpSync >= NTP_SYNC_INTERVAL)) {
        configTime(0, 0, NTP_SERVER1, NTP_SERVER2);
        lastNtpSync = now;
        DEBUG_PRINTLN("NTP re-sync triggered");
    }
    
    // Broadcast to SSE clients at configured interval
    if (now - lastSseUpdate >= sseUpdateInterval) {
        lastSseUpdate = now;
        broadcastData();
    }
    
    // Update WiFi info and send to Teensy periodically
if (now - lastWifiInfoUpdate >= WIFI_INFO_INTERVAL) {
    lastWifiInfoUpdate = now;

    const bool wifiConnected = (WiFi.status() == WL_CONNECTED);

    static bool wifiLedState = LOW;

    if (wifiConnected) {
        wifiLedState = !wifiLedState;       // toggle LED
        digitalWrite(WIFI_PIN, wifiLedState);
    } else {
        wifiLedState = LOW;                 // ensure LED stays off
        digitalWrite(WIFI_PIN, LOW);
    }

    if (wifiConnected) {
        wifiInfo.rssi = WiFi.RSSI();
        wifiInfo.ip = WiFi.localIP().toString();
        wifiInfo.ssid = WiFi.SSID();

        JsonDocument doc;
        doc["wifi"] = "connected";
        doc["ssid"] = wifiInfo.ssid;
        doc["ip"] = wifiInfo.ip;
        doc["rssi"] = wifiInfo.rssi;
        doc["version"] = RELEASE;

        String json;
        serializeJson(doc, json);
        sendToTeensy(json);
    }
}



}

// ============== JH2KW-M Nearby Network Scan ==============
void requestNetworkScan() {
    if (oledScanRequested || oledScanActive || oledScanSending) {
        DEBUG_PRINTLN("[SCAN] duplicate request ignored; scan already active");
        return;
    }

    DEBUG_PRINTF("[SCAN] request status=%d connecting=%d requested=%d ssid='%s' pass_len=%u\n",
                 (int)WiFi.status(), wifiConnecting ? 1 : 0,
                 wifiConnectRequested ? 1 : 0,
                 teensyWifiSsid.c_str(), (unsigned)teensyWifiPassword.length());

    // If the STA is currently trying to associate, scanning can fail with
    // ESP_ERR_WIFI_STATE. Stop only that in-progress association without
    // erasing credentials or changing WIFI_STA mode, then let the scan start
    // after a short settle period. A previously connected station is left
    // connected; ESP32 supports background scanning in STA mode.
    oledScanCancelConnect = wifiConnecting || wifiConnectRequested ||
                            (WiFi.status() != WL_CONNECTED && wifiCredentialsReceived);
    oledScanReconnectAfter = wifiCredentialsReceived &&
                             teensyWifiSsid.length() > 0 &&
                             teensyWifiSsid != "Your SSID";

    wifiConnectRequested = false;
    wifiConnecting = false;

    if (oledScanCancelConnect) {
        WiFi.disconnect(false, false);   // stop association; do NOT erase AP config
        oledScanStartAt = millis() + 250UL;
    } else {
        oledScanStartAt = millis() + 20UL;
    }

    oledScanRequested = true;
}

static void finishNetworkScan(bool failed) {
    if (failed) {
        sendToTeensy("{\"type\":\"wifi_scan_error\"}");
    }

    WiFi.scanDelete();
    oledScanRequested = false;
    oledScanActive = false;

    if (oledScanReconnectAfter && WiFi.status() != WL_CONNECTED) {
        // Re-enter the original proven W1.9 connection state machine. Do not
        // call WiFi.begin() from the scan code itself.
        wifiConnectRequested = true;
        wifiConnecting = false;
        lastWifiRetry = 0;
    }
}

void serviceNetworkScan() {
    const unsigned long now = millis();

    if (oledScanRequested && !oledScanActive && !oledScanSending) {
        if ((long)(now - oledScanStartAt) < 0) return;

        WiFi.scanDelete();
        WiFi.setScanTimeout(15000);
        const int16_t rc = WiFi.scanNetworks(true, true, false, 300);
        DEBUG_PRINTF("[SCAN] async start rc=%d wifi=%d\n", (int)rc, (int)WiFi.status());

        if (rc != WIFI_SCAN_RUNNING) {
            DEBUG_PRINTLN("[SCAN] start failed");
            finishNetworkScan(true);
            return;
        }

        oledScanActive = true;
        sendToTeensy("{\"type\":\"wifi_scan_begin\"}");
        return;
    }

    if (oledScanActive) {
        const int16_t n = WiFi.scanComplete();
        if (n == WIFI_SCAN_RUNNING) return;

        if (n == WIFI_SCAN_FAILED) {
            DEBUG_PRINTF("[SCAN] scanComplete failed wifi=%d\n", (int)WiFi.status());
            finishNetworkScan(true);
            return;
        }

        DEBUG_PRINTF("[SCAN] complete raw=%d wifi=%d\n", (int)n, (int)WiFi.status());
        oledScanCount = 0;

        for (int i = 0; i < n; ++i) {
            const String ssid = WiFi.SSID(i);
            if (ssid.length() == 0) continue;

            const int32_t rssi = WiFi.RSSI(i);
            const bool secure = WiFi.encryptionType(i) != WIFI_AUTH_OPEN;

            int duplicate = -1;
            for (uint8_t j = 0; j < oledScanCount; ++j) {
                if (wifiScanItems[j].ssid == ssid) {
                    duplicate = j;
                    break;
                }
            }

            if (duplicate >= 0) {
                if (rssi > wifiScanItems[duplicate].rssi) {
                    wifiScanItems[duplicate].rssi = rssi;
                    wifiScanItems[duplicate].secure = secure;
                }
                continue;
            }

            if (oledScanCount < WIFI_SCAN_MAX_RESULTS) {
                wifiScanItems[oledScanCount].ssid = ssid;
                wifiScanItems[oledScanCount].rssi = rssi;
                wifiScanItems[oledScanCount].secure = secure;
                ++oledScanCount;
            } else {
                uint8_t weakest = 0;
                for (uint8_t j = 1; j < oledScanCount; ++j) {
                    if (wifiScanItems[j].rssi < wifiScanItems[weakest].rssi) weakest = j;
                }
                if (rssi > wifiScanItems[weakest].rssi) {
                    wifiScanItems[weakest].ssid = ssid;
                    wifiScanItems[weakest].rssi = rssi;
                    wifiScanItems[weakest].secure = secure;
                }
            }
        }

        for (uint8_t i = 0; i < oledScanCount; ++i) {
            for (uint8_t j = i + 1; j < oledScanCount; ++j) {
                if (wifiScanItems[j].rssi > wifiScanItems[i].rssi) {
                    WifiScanItem tmp = wifiScanItems[i];
                    wifiScanItems[i] = wifiScanItems[j];
                    wifiScanItems[j] = tmp;
                }
            }
        }

        WiFi.scanDelete();
        oledScanActive = false;
        oledScanSending = true;
        oledScanSendIndex = 0;
        oledScanLastSend = 0;
        DEBUG_PRINTF("[SCAN] unique=%u; sending to Teensy\n", (unsigned)oledScanCount);
    }

    if (oledScanSending) {
        if (oledScanSendIndex < oledScanCount) {
            if (oledScanLastSend != 0 && now - oledScanLastSend < 25UL) return;
            oledScanLastSend = now;

            JsonDocument ap;
            ap["type"] = "wifi_ap";
            ap["ssid"] = wifiScanItems[oledScanSendIndex].ssid;
            ap["rssi"] = wifiScanItems[oledScanSendIndex].rssi;
            ap["secure"] = wifiScanItems[oledScanSendIndex].secure ? 1 : 0;
            String msg;
            serializeJson(ap, msg);
            sendToTeensy(msg);
            DEBUG_PRINTF("[SCAN] AP %02u/%02u %ld dBm '%s'\n",
                         (unsigned)(oledScanSendIndex + 1), (unsigned)oledScanCount,
                         (long)wifiScanItems[oledScanSendIndex].rssi,
                         wifiScanItems[oledScanSendIndex].ssid.c_str());
            ++oledScanSendIndex;
            return;
        }

        JsonDocument done;
        done["type"] = "wifi_scan_end";
        done["count"] = oledScanCount;
        String msg;
        serializeJson(done, msg);
        sendToTeensy(msg);
        DEBUG_PRINTF("[SCAN] end count=%u wifi=%d\n",
                     (unsigned)oledScanCount, (int)WiFi.status());

        oledScanSending = false;
        oledScanRequested = false;

        if (oledScanReconnectAfter && WiFi.status() != WL_CONNECTED) {
            wifiConnectRequested = true;
            wifiConnecting = false;
            lastWifiRetry = 0;
        }
    }
}

// ============== Connect to Strongest AP ==============
void connectToStrongestAP() {
    // After initial connection, scan for all APs with the same SSID
    // and switch to the strongest one if we're not already on it.
    String ssid = WiFi.SSID();
    String password = WiFi.psk();
    int8_t currentRSSI = WiFi.RSSI();

    DEBUG_PRINTF("connectToStrongestAP: connected to SSID '%s', BSSID=%s, RSSI=%d\n",
                 ssid.c_str(), WiFi.BSSIDstr().c_str(), currentRSSI);

    // Full active scan — need reliable results
    int n = WiFi.scanNetworks();
    if (n <= 0) {
        DEBUG_PRINTLN("  Scan returned no results, keeping current AP");
        WiFi.scanDelete();
        return;
    }

    int8_t bestRSSI = -127;
    uint8_t bestBSSID[6];
    int matchCount = 0;

    for (int i = 0; i < n; i++) {
        if (WiFi.SSID(i) == ssid) {
            matchCount++;
            int8_t rssi = WiFi.RSSI(i);
            DEBUG_PRINTF("  AP %d: BSSID=%s RSSI=%d%s\n",
                         matchCount, WiFi.BSSIDstr(i).c_str(), rssi,
                         (WiFi.BSSID(i) && WiFi.BSSID() &&
                          memcmp(WiFi.BSSID(i), WiFi.BSSID(), 6) == 0)
                         ? " (current)" : "");
            if (rssi > bestRSSI) {
                bestRSSI = rssi;
                memcpy(bestBSSID, WiFi.BSSID(i), 6);
            }
        }
    }
    WiFi.scanDelete();

    if (matchCount <= 1) {
        DEBUG_PRINTLN("  Single AP for this SSID, no switch needed");
        return;
    }

    // Already on strongest?
    uint8_t* currentBSSID = WiFi.BSSID();
    if (currentBSSID && memcmp(currentBSSID, bestBSSID, 6) == 0) {
        DEBUG_PRINTLN("  Already on strongest AP");
        return;
    }

    DEBUG_PRINTF("  Switching: current RSSI=%d, best RSSI=%d\n", currentRSSI, bestRSSI);

    // Disconnect and connect to the strongest AP by BSSID
    WiFi.disconnect(false, true);
    delay(200);
    WiFi.begin(ssid.c_str(), password.c_str(), 0, bestBSSID);

    unsigned long start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
        delay(100);
    }

    if (WiFi.status() == WL_CONNECTED) {
        DEBUG_PRINTF("  Switched OK: BSSID=%s RSSI=%d\n",
                     WiFi.BSSIDstr().c_str(), WiFi.RSSI());
        return;
    }

    // BSSID-targeted connect failed — fall back to any AP with this SSID
    DEBUG_PRINTLN("  BSSID connect failed, falling back to any AP");
    WiFi.disconnect(false, true);
    delay(200);
    WiFi.begin(ssid.c_str(), password.c_str());

    start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
        delay(100);
    }

    if (WiFi.status() == WL_CONNECTED) {
        DEBUG_PRINTF("  Fallback connected: BSSID=%s RSSI=%d\n",
                     WiFi.BSSIDstr().c_str(), WiFi.RSSI());
    } else {
        // Last resort — we were connected before, try one more time
        DEBUG_PRINTLN("  Fallback failed, attempting WiFi.reconnect()");
        WiFi.reconnect();
        start = millis();
        while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
            delay(100);
        }
        DEBUG_PRINTF("  Final result: %s\n",
                     WiFi.status() == WL_CONNECTED ? "CONNECTED" : "FAILED");
    }
}

// ============== WiFi Setup ==============
void setupWiFi() {
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    WiFi.disconnect(false, true);
    digitalWrite(WIFI_PIN, LOW);

    // The Teensy is the single source of truth for SSID/password.
    sendToTeensy("{\"wifi_req\":1,\"fw\":\"" VERSION "\"}");
    lastWifiCredentialRequest = millis();
}

void startWiFiConnection() {
    if (!wifiCredentialsReceived || teensyWifiSsid.length() == 0 ||
        teensyWifiSsid == "Your SSID") {
        wifiConnecting = false;
        return;
    }

    DEBUG_PRINTF("Connecting to Teensy SSID '%s'\n", teensyWifiSsid.c_str());
    WiFi.disconnect(false, true);
    delay(50);
    WiFi.begin(teensyWifiSsid.c_str(), teensyWifiPassword.c_str());
    wifiConnectStart = millis();
    wifiConnecting = true;
    wifiConnectRequested = false;
}

void serviceWiFi() {
    const unsigned long now = millis();

    // A WiFi scan and a station connection both use the same ESP32 radio
    // state machine. Never start/retry a connection while an OLED scan is
    // pending, running or still transmitting its results.
    if (oledScanRequested || oledScanActive || oledScanSending) {
        return;
    }

    if (!wifiCredentialsReceived) {
        if (now - lastWifiCredentialRequest >= WIFI_CREDENTIAL_REQUEST_MS) {
            sendToTeensy("{\"wifi_req\":1,\"fw\":\"" VERSION "\"}");
            lastWifiCredentialRequest = now;
        }
        return;
    }

    if (wifiConnectRequested)
        startWiFiConnection();

    if (WiFi.status() == WL_CONNECTED) {
        if (wifiConnecting) {
            wifiConnecting = false;
            wifiInfo.ssid = WiFi.SSID();
            wifiInfo.ip = WiFi.localIP().toString();
            wifiInfo.rssi = WiFi.RSSI();

            if (!wifiMdnsStarted && MDNS.begin(MDNS_HOSTNAME)) {
                MDNS.addService("http", "tcp", 80);
                wifiMdnsStarted = true;
            }

            if (!wifiNtpStarted) {
                setupNTP();
                wifiNtpStarted = true;
            }

            JsonDocument doc;
            doc["wifi"] = "connected";
            doc["ssid"] = wifiInfo.ssid;
            doc["ip"] = wifiInfo.ip;
            doc["rssi"] = wifiInfo.rssi;
            doc["version"] = RELEASE;
            String msg;
            serializeJson(doc, msg);
            sendToTeensy(msg);
        }
        return;
    }

    if (wifiConnecting && now - wifiConnectStart >= WIFI_CONNECT_TIMEOUT_MS) {
        wifiConnecting = false;
        lastWifiRetry = now;
        sendToTeensy("{\"wifi\":\"failed\",\"fw\":\"" VERSION "\"}");
    }
    else if (!wifiConnecting && now - lastWifiRetry >= WIFI_RETRY_MS) {
        lastWifiRetry = now;
        wifiConnectRequested = true;
    }
}

// ============== NTP Setup ==============
void setupNTP() {
    DEBUG_PRINTLN("Configuring NTP...");
    configTime(0, 0, NTP_SERVER1, NTP_SERVER2);
    
    // Wait for time sync (max 10 seconds)
    DEBUG_PRINT("Waiting for NTP sync");
    int attempts = 0;
    while (time(nullptr) < 1000000000 && attempts < 100) {
        delay(100);
        DEBUG_PRINT(".");
        attempts++;
    }
    DEBUG_PRINTLN();
    
    if (time(nullptr) > 1000000000) {
        ntpSynced = true;
        lastNtpSync = millis();
        updateUTC();
        DEBUG_PRINT("NTP synced: ");
        DEBUG_PRINTLN(wifiInfo.utc);
    } else {
        DEBUG_PRINTLN("NTP sync failed - will retry");
    }
}

// ============== Netherlands Local Time Helpers ==============
int dayOfWeekYMD(int year, int month, int day)
{
    static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
    if (month < 3) year -= 1;
    return (year + year / 4 - year / 100 + year / 400 + t[month - 1] + day) % 7;
}

int lastSundayOfMonth(int year, int month)
{
    const int wday31 = dayOfWeekYMD(year, month, 31);
    return 31 - wday31;
}

bool isNetherlandsDST(time_t utcEpoch)
{
    struct tm utcTm {};
    gmtime_r(&utcEpoch, &utcTm);

    const int year = utcTm.tm_year + 1900;
    const int month = utcTm.tm_mon + 1;
    const int day = utcTm.tm_mday;
    const int hour = utcTm.tm_hour;

    if (month < 3 || month > 10) return false;
    if (month > 3 && month < 10) return true;

    if (month == 3)
    {
        const int lastSunday = lastSundayOfMonth(year, 3);
        if (day > lastSunday) return true;
        if (day < lastSunday) return false;
        return hour >= 1;  // 01:00 UTC -> 03:00 local switch to CEST
    }

    const int lastSunday = lastSundayOfMonth(year, 10);
    if (day < lastSunday) return true;
    if (day > lastSunday) return false;
    return hour < 1;       // 01:00 UTC -> 02:00 local switch back to CET
}

// ============== Update UTC + Netherlands Local Time ==============
void updateUTC() {
    const time_t nowEpoch = time(nullptr);
    if (nowEpoch > 1000000000) {
        const bool dst = isNetherlandsDST(nowEpoch);
        const time_t localEpoch = nowEpoch + (dst ? 7200 : 3600);

        struct tm utcTm {};
        struct tm localTm {};
        gmtime_r(&nowEpoch, &utcTm);
        gmtime_r(&localEpoch, &localTm);

        char utcStr[9];
        char localStr[9];
        char utcDateStr[20];
        char localDateStr[20];

        snprintf(utcStr, sizeof(utcStr), "%02d:%02d:%02d",
                 utcTm.tm_hour, utcTm.tm_min, utcTm.tm_sec);
        snprintf(localStr, sizeof(localStr), "%02d:%02d:%02d",
                 localTm.tm_hour, localTm.tm_min, localTm.tm_sec);

        static const char *days[] = {"SUN","MON","TUE","WED","THU","FRI","SAT"};
        static const char *months[] = {"JAN","FEB","MAR","APR","MAY","JUN",
                                       "JUL","AUG","SEP","OCT","NOV","DEC"};
        const int localWday = (localTm.tm_wday >= 0 && localTm.tm_wday <= 6) ? localTm.tm_wday : 0;
        const int localMon = (localTm.tm_mon >= 0 && localTm.tm_mon <= 11) ? localTm.tm_mon : 0;
        const int utcWday = (utcTm.tm_wday >= 0 && utcTm.tm_wday <= 6) ? utcTm.tm_wday : 0;
        const int utcMon = (utcTm.tm_mon >= 0 && utcTm.tm_mon <= 11) ? utcTm.tm_mon : 0;
        snprintf(localDateStr, sizeof(localDateStr), "%s %02d %s %04d",
                 days[localWday], localTm.tm_mday, months[localMon], localTm.tm_year + 1900);
        snprintf(utcDateStr, sizeof(utcDateStr), "%s %02d %s %04d",
                 days[utcWday], utcTm.tm_mday, months[utcMon], utcTm.tm_year + 1900);

        wifiInfo.utc = String(utcStr);
        wifiInfo.local = String(localStr);
        wifiInfo.dateUtc = String(utcDateStr);
        wifiInfo.dateLocal = String(localDateStr);
        wifiInfo.date = wifiInfo.dateLocal;
        wifiInfo.zone = dst ? "CEST" : "CET";

        static unsigned long lastClockDebug = 0;
        const unsigned long debugNow = millis();
        if (debugNow - lastClockDebug >= 10000UL) {
            lastClockDebug = debugNow;
            DEBUG_PRINTF("[CLOCK] UTC=%s LOCAL=%s ZONE=%s OFFSET=%+dh\n",
                         wifiInfo.utc.c_str(), wifiInfo.local.c_str(),
                         wifiInfo.zone.c_str(), dst ? 2 : 1);
        }

        if (!ntpSynced) {
            ntpSynced = true;
            lastNtpSync = millis();
            DEBUG_PRINTLN("NTP sync confirmed");
        }
    } else if (!ntpSynced) {
        configTime(0, 0, NTP_SERVER1, NTP_SERVER2);
    }
}

// ============== SSE Setup ==============
void setupSSE() {
    events.onConnect([](AsyncEventSourceClient *client) {
        if(client->lastId()) {
            DEBUG_PRINTF("SSE client reconnected! Last message ID: %u\n", client->lastId());
        } else {
            DEBUG_PRINTF("SSE client connected\n");
        }
        // Send initial connection message
        client->send("connected", NULL, millis(), 1000);
    });
    
    server.addHandler(&events);
    DEBUG_PRINTLN("SSE endpoint setup at /events");
}

// ============== Web Server Setup ==============
void setupWebServer() {
    // Classic version
    server.on("/classic", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->send(LittleFS, "/classic.html", "text/html");
    });

    // Classic version
    server.on("/retro", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->send(LittleFS, "/retro.html", "text/html");
    });
    
    // Modern version
    server.on("/modern", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->send(LittleFS, "/modern.html", "text/html");
    });
    
    // Command endpoint - replaces WebSocket messaging
    server.on("/api/command", HTTP_POST, [](AsyncWebServerRequest *request) {}, NULL,
        [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total) {
            String body = "";
            for(size_t i = 0; i < len; i++) {
                body += (char)data[i];
            }
            
            JsonDocument doc;
            if (deserializeJson(doc, body) == DeserializationError::Ok) {
                // Forward command to Teensy
                sendToTeensy(body);

                // Handle config commands locally
                if (doc["sseInterval"].is<JsonVariant>()) {
                    sseUpdateInterval = doc["sseInterval"].as<int>();
                    DEBUG_PRINTF("SSE interval set to %lu ms\n", sseUpdateInterval);
                }

                // Handle calibration upload locally (update ESP32's calData array)
                if (doc["type"] == "cal_all" && doc["sets"].is<JsonArray>()) {
                    JsonArray sets = doc["sets"].as<JsonArray>();
                    int idx = 0;
                    for (JsonObject set : sets) {
                        if (idx < 8) {
                            calData[idx].cal1_db = set["cal1_db"] | 0.0;
                            calData[idx].cal1_fwd = set["cal1_fwd"] | 0.0;
                            calData[idx].cal1_rev = set["cal1_rev"] | 0.0;
                            calData[idx].cal2_db = set["cal2_db"] | 0.0;
                            calData[idx].cal2_fwd = set["cal2_fwd"] | 0.0;
                            calData[idx].cal2_rev = set["cal2_rev"] | 0.0;
                            idx++;
                        }
                    }
                    if (doc["callsign"]) {
                        calData[0].call = doc["callsign"].as<String>();
                    }
                    DEBUG_PRINTF("Uploaded %d calibration sets\n", idx);
                }

                // Handle WiFi reset command
                if (doc["cmd"].is<JsonVariant>() && doc["cmd"] == "resetWifi") {
                    request->send(200, "application/json", "{\"status\":\"resetting\"}");
                    resetWiFiConfig();
                    return;
                }
                
                request->send(200, "application/json", "{\"status\":\"ok\"}");
            } else {
                request->send(400, "application/json", "{\"error\":\"invalid json\"}");
            }
        }
    );
    
    // API endpoints for backward compatibility
    server.on("/api/data", HTTP_GET, [](AsyncWebServerRequest *request) {
        JsonDocument doc;
        doc["fwd"] = rtData.fwd;
        doc["pep"] = rtData.pep;
        doc["avg"] = rtData.avg;
        doc["dbm"] = rtData.dbm;
        doc["vswr"] = rtData.vswr;
        doc["pk"] = rtData.pk;
        doc["ref"] = rtData.ref;
        doc["inst"] = rtData.inst;
        doc["swrt"] = rtData.swrt;
        doc["cpl"] = rtData.cpl;
        doc["pep_val"] = rtData.pep_val;
        doc["rssi"] = wifiInfo.rssi;
        doc["utc"] = wifiInfo.utc;
        doc["local"] = wifiInfo.local;
        doc["date"] = wifiInfo.dateLocal;
        doc["date_utc"] = wifiInfo.dateUtc;
        doc["date_local"] = wifiInfo.dateLocal;
        doc["zone"] = wifiInfo.zone;
        
        String json;
        serializeJson(doc, json);
        request->send(200, "application/json", json);
    });
    
    // WiFi reset endpoint
    server.on("/api/wifi/reset", HTTP_POST, [](AsyncWebServerRequest *request) {
        request->send(200, "application/json", "{\"status\":\"resetting\"}");
        resetWiFiConfig();
    });

    server.on("/api/wifi", HTTP_GET, [](AsyncWebServerRequest *request) {
        JsonDocument doc;
        doc["wifi"] = "connected";
        doc["ssid"] = wifiInfo.ssid;
        doc["ip"] = wifiInfo.ip;
        doc["rssi"] = wifiInfo.rssi;
        
        String json;
        serializeJson(doc, json);
        request->send(200, "application/json", json);
    });

    server.on("/api/firmware", HTTP_GET, [](AsyncWebServerRequest *request) {
        JsonDocument doc;
        doc["release"]  = RELEASE;
        doc["platform"] = PLATFORM;
        doc["version"]  = VERSION;

        String json;
        serializeJson(doc, json);
        request->send(200, "application/json", json);
    });

    // More specific route must come first
    server.on("/api/cal/all", HTTP_GET, [](AsyncWebServerRequest *request) {
        JsonDocument doc;
        buildCalSets(doc.to<JsonObject>());
        doc["callsign"] = calData[0].call;
        doc["version"] = teensyFirmwareVersion;

        String json;
        serializeJson(doc, json);
        request->send(200, "application/json", json);
    });

    server.on("/api/cal/download", HTTP_GET, [](AsyncWebServerRequest *request) {
        JsonDocument doc;
        buildCalSets(doc.to<JsonObject>());
        doc["callsign"] = calData[0].call;
        doc["version"] = teensyFirmwareVersion;

        String json;
        serializeJsonPretty(doc, json);
        AsyncWebServerResponse *response = request->beginResponse(200, "application/json", json);
        response->addHeader("Content-Disposition", "attachment; filename=powermeter-calibration.json");
        request->send(response);
    });

    server.on("/api/cal", HTTP_GET, [](AsyncWebServerRequest *request) {
        int set = 0;
        if (request->hasParam("set")) {
            set = request->getParam("set")->value().toInt();
            if (set < 0 || set > 7) set = 0;
        }

        JsonDocument doc;
        doc["set"] = calData[set].set;
        doc["cal1_db"]  = serialized(String(calData[set].cal1_db,  1));
        doc["cal1_fwd"] = serialized(String(calData[set].cal1_fwd, 3));
        doc["cal1_rev"] = serialized(String(calData[set].cal1_rev, 3));
        doc["cal2_db"]  = serialized(String(calData[set].cal2_db,  1));
        doc["cal2_fwd"] = serialized(String(calData[set].cal2_fwd, 3));
        doc["cal2_rev"] = serialized(String(calData[set].cal2_rev, 3));
        doc["call"] = calData[0].call;

        String json;
        serializeJson(doc, json);
        request->send(200, "application/json", json);
    });

    // Config download — returns combined JSON from all stored sections
    // NOTE: must be registered before /api/config to avoid prefix match
    server.on("/api/config/all", HTTP_GET, [](AsyncWebServerRequest *request) {
        JsonDocument combined;
        combined["type"] = "config";
        combined["version"] = 1;

        // Cal section: build from calData[] to preserve float formatting
        buildCalSets(combined["cal"].to<JsonObject>());

        // Remaining sections: copy from cached JSON strings
        const char* keys[] = { NULL, "swr", "meter", "usb", "timing", "scale", "bands", "display" };
        for (int i = 1; i < 8; i++) {
            if (configSections[i].length() > 0) {
                JsonDocument section;
                if (deserializeJson(section, configSections[i]) == DeserializationError::Ok) {
                    JsonObject dest = combined[keys[i]].to<JsonObject>();
                    JsonObject src = section.as<JsonObject>();
                    for (JsonPair kv : src) {
                        if (strcmp(kv.key().c_str(), "type") != 0) {
                            dest[kv.key()] = kv.value();
                        }
                    }
                }
            }
        }

        combined["esp32_fw"] = RELEASE;
        combined["teensy_fw"] = teensyFirmwareVersion;

        String json;
        serializeJson(combined, json);
        request->send(200, "application/json", json);
    });

    server.on("/api/config/download", HTTP_GET, [](AsyncWebServerRequest *request) {
        JsonDocument combined;
        combined["type"] = "config";
        combined["version"] = 1;

        // Cal section: build from calData[] to preserve float formatting
        buildCalSets(combined["cal"].to<JsonObject>());

        // Remaining sections: copy from cached JSON strings
        const char* keys[] = { NULL, "swr", "meter", "usb", "timing", "scale", "bands", "display" };
        for (int i = 1; i < 8; i++) {
            if (configSections[i].length() > 0) {
                JsonDocument section;
                if (deserializeJson(section, configSections[i]) == DeserializationError::Ok) {
                    JsonObject dest = combined[keys[i]].to<JsonObject>();
                    JsonObject src = section.as<JsonObject>();
                    for (JsonPair kv : src) {
                        if (strcmp(kv.key().c_str(), "type") != 0) {
                            dest[kv.key()] = kv.value();
                        }
                    }
                }
            }
        }

        combined["esp32_fw"] = RELEASE;
        combined["teensy_fw"] = teensyFirmwareVersion;

        String json;
        serializeJsonPretty(combined, json);
        AsyncWebServerResponse *response = request->beginResponse(200, "application/json", json);
        response->addHeader("Content-Disposition", "attachment; filename=powermeter-config.json");
        request->send(response);
    });

    // Config upload — receives combined JSON, splits into sections, sends to Teensy
    server.on("/api/config/all", HTTP_POST, [](AsyncWebServerRequest *request) {}, NULL,
        [](AsyncWebServerRequest *request, uint8_t *data, size_t len, size_t index, size_t total) {
            static String body;
            if (index == 0) {
                body = "";
                body.reserve(total);
            }
            for (size_t i = 0; i < len; i++) {
                body += (char)data[i];
            }
            if (index + len < total) return;  // Wait for all chunks

            JsonDocument doc;
            if (deserializeJson(doc, body) != DeserializationError::Ok) {
                request->send(400, "application/json", "{\"error\":\"invalid json\"}");
                return;
            }

            const char* keys[] = { "cal", "swr", "meter", "usb", "timing", "scale", "bands", "display" };
            const char* types[] = { "cfg_cal", "cfg_swr", "cfg_meter", "cfg_usb",
                                    "cfg_timing", "cfg_scale", "cfg_bands", "cfg_display" };

            for (int i = 0; i < 8; i++) {
                if (doc[keys[i]].is<JsonObject>()) {
                    JsonDocument section;
                    section["type"] = types[i];
                    JsonObject src = doc[keys[i]].as<JsonObject>();
                    for (JsonPair kv : src) {
                        section[kv.key()] = kv.value();
                    }
                    String json;
                    serializeJson(section, json);
                    sendToTeensy(json);

                    // Also store locally
                    configSections[i] = json;

                    delay(20);  // Small delay between sections to avoid overwhelming Teensy
                }
            }

            if (doc["cal"].is<JsonObject>()) {
                JsonObject cal = doc["cal"].as<JsonObject>();
                if (cal["sets"].is<JsonArray>()) {
                    JsonArray sets = cal["sets"].as<JsonArray>();
                    int idx = 0;
                    for (JsonObject set : sets) {
                        if (idx < 8) {
                            calData[idx].cal1_db = set["cal1_db"] | 0.0;
                            calData[idx].cal1_fwd = set["cal1_fwd"] | 0.0;
                            calData[idx].cal1_rev = set["cal1_rev"] | 0.0;
                            calData[idx].cal2_db = set["cal2_db"] | 0.0;
                            calData[idx].cal2_fwd = set["cal2_fwd"] | 0.0;
                            calData[idx].cal2_rev = set["cal2_rev"] | 0.0;
                            idx++;
                        }
                    }
                    if (cal["callsign"].is<JsonVariant>()) {
                        calData[0].call = cal["callsign"].as<String>();
                    }
                }
            }

            request->send(200, "application/json", "{\"status\":\"ok\"}");
        }
    );

    // Request config from Teensy (triggers cfg_* section transfer)
    server.on("/api/config/request", HTTP_POST, [](AsyncWebServerRequest *request) {
        configComplete = false;
        sendToTeensy("{\"reqConfig\":true}");
        request->send(200, "application/json", "{\"status\":\"requested\"}");
    });

    server.on("/api/config", HTTP_GET, [](AsyncWebServerRequest *request) {
        JsonDocument doc;
        doc["sseInterval"] = sseUpdateInterval;

        String json;
        serializeJson(doc, json);
        request->send(200, "application/json", json);
    });

    // ---------- OTA: firmware + filesystem upload ----------
    server.on("/update", HTTP_GET, [](AsyncWebServerRequest *request) {
        request->send(LittleFS, "/update.html", "text/html");
    });

    server.on("/update", HTTP_POST,
        [](AsyncWebServerRequest *request) {
            bool ok = !Update.hasError();
            String type = request->arg("type");
            String body;
            if (ok) {
                body = "{\"status\":\"ok\"}";
            } else {
                String msg = Update.errorString();
                msg.replace("\"", "'");
                body = String("{\"status\":\"err\",\"target\":\"") + type +
                       "\",\"message\":\"" + msg + "\"}";
            }
            AsyncWebServerResponse *response =
                request->beginResponse(ok ? 200 : 500, "application/json", body);
            response->addHeader("Connection", "close");
            request->send(response);
        },
        [](AsyncWebServerRequest *request, String filename, size_t index,
           uint8_t *data, size_t len, bool final) {
            String type = request->arg("type");
            int cmd = (type == "filesystem") ? U_SPIFFS : U_FLASH;
            if (index == 0) {
                if (cmd == U_SPIFFS) {
                    LittleFS.end();  // unmount before writing partition
                }
                DEBUG_PRINTF("OTA begin: %s (%s)\n", filename.c_str(),
                             cmd == U_FLASH ? "firmware" : "filesystem");
                if (!Update.begin(UPDATE_SIZE_UNKNOWN, cmd)) {
                    #if DEBUG_SERIAL
                    Update.printError(Serial);
                    #endif
                    // Re-mount FS immediately on begin failure so the page
                    // stays usable while we wait for the upload to drain.
                    if (cmd == U_SPIFFS) {
                        LittleFS.begin(true, "/littlefs", 10, "littlefs");
                    }
                }
            }
            // Skip writes once an error is set — the upload still drains
            // (AsyncWebServer has no clean abort for in-flight uploads),
            // but we don't waste flash cycles on a dead transaction.
            if (!Update.hasError()) {
                if (Update.write(data, len) != len) {
                    #if DEBUG_SERIAL
                    Update.printError(Serial);
                    #endif
                }
            }
            if (final) {
                if (!Update.hasError()) {
                    if (Update.end(true)) {
                        DEBUG_PRINTF("OTA success: %u bytes\n", index + len);
                    } else {
                        #if DEBUG_SERIAL
                        Update.printError(Serial);
                        #endif
                    }
                }
                // After a successful filesystem upload, re-mount LittleFS so
                // /update and other pages keep working until manual reboot.
                if (cmd == U_SPIFFS && !Update.hasError()) {
                    LittleFS.begin(true, "/littlefs", 10, "littlefs");
                }
            }
        }
    );

    server.on("/reboot", HTTP_POST, [](AsyncWebServerRequest *request) {
        AsyncWebServerResponse *response =
            request->beginResponse(200, "application/json", "{\"status\":\"rebooting\"}");
        response->addHeader("Connection", "close");
        request->send(response);
        request->onDisconnect([]() { ESP.restart(); });
    });

    // Serve static files from LittleFS
    server.serveStatic("/", LittleFS, "/").setDefaultFile("index.html");

    // Handle 404
    server.onNotFound([](AsyncWebServerRequest *request) {
        request->send(404, "text/plain", "Not found");
    });
    
    server.begin();
    DEBUG_PRINTLN("HTTP server started");
}

// ============== Serial Data Handler ==============
void handleSerialData() {
    while (Serial2.available()) {
        char c = Serial2.read();
        teensyRxBytes++;
        lastTeensyRxMs = millis();
        
        if (c == '\n') {
            teensyRxLines++;
            serialBuffer.trim();
            
            // Check for reset command
            if (serialBuffer == "reset") {
                DEBUG_PRINTLN("Reset command received");
                resetWiFiConfig();
            } else if (serialBuffer.length() > 0 && serialBuffer[0] == '{') {
                parseJsonMessage(serialBuffer);
            }
            
            serialBuffer = "";
        } else if (c != '\r') {
            serialBuffer += c;
            
            // Prevent buffer overflow
            if (serialBuffer.length() > 2048) {
                serialBuffer = "";
            }
        }
    }
}

// ============== JSON Parser ==============
void parseJsonMessage(const String& json) {
    JsonDocument doc;
    DeserializationError error = deserializeJson(doc, json);

    if (error) {
        DEBUG_PRINT("JSON parse error: ");
        DEBUG_PRINTLN(error.c_str());
        return;
    }

    // Nearby WiFi scan requested by the JH2KW-M setup menu. Queue it and
    // return immediately; the actual radio work is serviced from loop().
    if ((doc["wifi_scan"] | 0) == 1) {
        requestNetworkScan();
        return;
    }

    // WiFi credentials from JH2KW-M. They are intentionally kept only in RAM
    // on the XIAO; the Teensy EEPROM remains the single source of truth.
    if (doc["type"].is<const char*>() && String(doc["type"].as<const char*>()) == "wifi_cfg") {
        String newSsid = doc["ssid"] | "";
        String newPassword = doc["password"] | "";

        bool changed = !wifiCredentialsReceived ||
                       newSsid != teensyWifiSsid ||
                       newPassword != teensyWifiPassword;

        teensyWifiSsid = newSsid;
        teensyWifiPassword = newPassword;
        wifiCredentialsReceived = true;
        DEBUG_PRINTF("[WIFI_CFG] ssid='%s' pass_len=%u changed=%d status=%d\n",
                     teensyWifiSsid.c_str(), (unsigned)teensyWifiPassword.length(),
                     changed ? 1 : 0, (int)WiFi.status());
        sendToTeensy("{\"wifi_ack\":1,\"fw\":\"" VERSION "\"}");

        if (changed || WiFi.status() != WL_CONNECTED) {
            wifiConnectRequested = true;
            wifiMdnsStarted = false;
            wifiNtpStarted = false;
            ntpSynced = false;
        }
        return;
    }
    
    // Check if it's batch calibration data (all sets at once)
    if (doc["type"].is<JsonVariant>() && doc["type"] == "cal_all") {
        DEBUG_PRINTLN("Received cal_all type message");
        if (doc["sets"].is<JsonArray>()) {
            JsonArray sets = doc["sets"].as<JsonArray>();
            DEBUG_PRINTF("Sets array size: %d\n", sets.size());
            int idx = 0;
            for (JsonObject set : sets) {
                if (idx < 8) {
                    calData[idx].cal1_db = set["cal1_db"] | 0.0;
                    calData[idx].cal1_fwd = set["cal1_fwd"] | 0.0;
                    calData[idx].cal1_rev = set["cal1_rev"] | 0.0;
                    calData[idx].cal2_db = set["cal2_db"] | 0.0;
                    calData[idx].cal2_fwd = set["cal2_fwd"] | 0.0;
                    calData[idx].cal2_rev = set["cal2_rev"] | 0.0;
                    if (idx == 0) {
                        DEBUG_PRINTF("Set A: db=%.1f fwd=%.3f rev=%.3f\n",
                                    calData[0].cal1_db, calData[0].cal1_fwd, calData[0].cal1_rev);
                    }
                    idx++;
                }
            }
            if (doc["callsign"].is<JsonVariant>()) {
                calData[0].call = doc["callsign"].as<String>();
            }
            if (doc["version"].is<JsonVariant>()) {
                teensyFirmwareVersion = doc["version"].as<String>();
            }
            DEBUG_PRINTF("Stored %d calibration sets\n", idx);
        } else {
            DEBUG_PRINTLN("ERROR: 'sets' is not a JsonArray!");
        }
    }
    // Check if it's single calibration data (legacy/upload format)
    else if (doc["type"].is<JsonVariant>() && doc["type"] == "cal") {
        int setIdx = doc["set"] | 0;
        if (setIdx >= 0 && setIdx < 8) {
            calData[setIdx].cal1_db = doc["cal1_db"] | 0.0;
            calData[setIdx].cal1_fwd = doc["cal1_fwd"] | 0.0;
            calData[setIdx].cal1_rev = doc["cal1_rev"] | 0.0;
            calData[setIdx].cal2_db = doc["cal2_db"] | 0.0;
            calData[setIdx].cal2_fwd = doc["cal2_fwd"] | 0.0;
            calData[setIdx].cal2_rev = doc["cal2_rev"] | 0.0;

            if (doc["call"].is<JsonVariant>()) {
                calData[0].call = doc["call"].as<String>();
            }

            currentCalSet = setIdx;
        }
    }
    // Config section messages from Teensy
    else if (doc["type"].is<JsonVariant>()) {
        String type = doc["type"].as<String>();
        if (type.startsWith("cfg_")) {
            // Store the section JSON
            for (int i = 0; i < 8; i++) {
                if (type == configSectionNames[i]) {
                    configSections[i] = json;
                    DEBUG_PRINTF("Stored config section: %s\n", configSectionNames[i]);
                    break;
                }
            }
        }
        if (type == "cfg_end") {
            configComplete = true;
            DEBUG_PRINTLN("Config transfer complete");
        }
    }
    // Real-time data
    else {
        if (doc["pep_val"].is<JsonVariant>()) rtData.pep_val = doc["pep_val"];
        if (doc["cpl"].is<JsonVariant>()) rtData.cpl = doc["cpl"];
        if (doc["btns"].is<JsonVariant>()) rtData.btns = doc["btns"];
        if (doc["fwd"].is<JsonVariant>()) rtData.fwd = doc["fwd"].as<String>();
        if (doc["pep"].is<JsonVariant>()) rtData.pep = doc["pep"].as<String>();
        if (doc["avg"].is<JsonVariant>()) rtData.avg = doc["avg"].as<String>();
        if (doc["dbm"].is<JsonVariant>()) rtData.dbm = doc["dbm"].as<String>();
        if (doc["vswr"].is<JsonVariant>()) rtData.vswr = doc["vswr"].as<String>();
        if (doc["pk"].is<JsonVariant>()) rtData.pk = doc["pk"].as<String>();
        if (doc["ref"].is<JsonVariant>()) rtData.ref = doc["ref"].as<String>();
        if (doc["inst"].is<JsonVariant>()) rtData.inst = doc["inst"].as<String>();
        if (doc["volf"].is<JsonVariant>()) rtData.volf = doc["volf"];
        if (doc["volr"].is<JsonVariant>()) rtData.volr = doc["volr"];
        if (doc["swrt"].is<JsonVariant>()) rtData.swrt = doc["swrt"].as<String>();
        if (doc["callsign"].is<JsonVariant>()) calData[0].call = doc["callsign"].as<String>();
        if (doc["version"].is<JsonVariant>()) teensyFirmwareVersion = doc["version"].as<String>();
    }
    
    // Commands from ESP32 → Teensy that we also process locally
    if (doc["utc"].is<JsonVariant>()) wifiInfo.utc = doc["utc"].as<String>();
    if (doc["rssi"].is<JsonVariant>()) wifiInfo.rssi = doc["rssi"];
}

// ============== Broadcast to SSE Clients ==============
void broadcastData() {
    if (events.count() == 0) return;
    
    JsonDocument doc;
    
    // Real-time data
    doc["fwd"] = rtData.fwd;
    doc["pep"] = rtData.pep;
    doc["avg"] = rtData.avg;
    doc["dbm"] = rtData.dbm;
    doc["vswr"] = rtData.vswr;
    doc["pk"] = rtData.pk;
    doc["ref"] = rtData.ref;
    doc["inst"] = rtData.inst;
    doc["swrt"] = rtData.swrt;
    doc["cpl"] = rtData.cpl;
    doc["pep_val"] = rtData.pep_val;
    doc["volf"] = rtData.volf;
    doc["volr"] = rtData.volr;
    doc["btns"] = rtData.btns;
    
    // WiFi info
    doc["rssi"] = wifiInfo.rssi;
    doc["utc"] = wifiInfo.utc;
    doc["local"] = wifiInfo.local;
    doc["date"] = wifiInfo.dateLocal;
    doc["date_utc"] = wifiInfo.dateUtc;
    doc["date_local"] = wifiInfo.dateLocal;
    doc["zone"] = wifiInfo.zone;
    
    doc["call"] = calData[0].call;
    
    String json;
    serializeJson(doc, json);
    events.send(json.c_str(), "data", millis());
}

// ============== Send to Teensy ==============
void sendToTeensy(const String& json) {
    Serial2.println(json);
}

// ============== Reset WiFi Configuration ==============
void resetWiFiConfig() {
    // Credentials are not stored on the XIAO. A reset simply drops the current
    // link and asks the Teensy to resend its EEPROM-owned settings.
    DEBUG_PRINTLN("Restarting Teensy-managed WiFi connection...");
    WiFi.disconnect(false, true);
    wifiCredentialsReceived = false;
    wifiConnectRequested = false;
    wifiConnecting = false;
    wifiMdnsStarted = false;
    wifiNtpStarted = false;
    ntpSynced = false;
    sendToTeensy("{\"wifi_req\":1,\"fw\":\"" VERSION "\"}");
    lastWifiCredentialRequest = millis();
}

