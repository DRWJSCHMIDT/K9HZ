/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_CALLSIGN_H
#define PSWR_CALLSIGN_H

#include <Arduino.h>

// Initialize the independent callsign EEPROM block.
// forceReset=true restores the explicit factory placeholder "Your Call".
void callsign_begin(bool forceReset);

// Store a new startup callsign/name. Accepts 1..30 printable characters.
bool callsign_set(const char *text);

// Return the currently active null-terminated startup callsign/name.
const char *callsign_get(void);

#endif // PSWR_CALLSIGN_H
