/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#define                VERSION " JH2KW-M V3.102"
#define                DATE    "07-09-2026"
//**
//*********************************************************************************

//-----------------------------------------------------------------------------
// Target platform: Teensy 4.0
//-----------------------------------------------------------------------------

#ifndef PSWR_CONFIG_H
#define PSWR_CONFIG_H

#include <Arduino.h>
#include <stdint.h>
#include <stddef.h>

//
//-----------------------------------------------------------------------------
// Features Selection
//-----------------------------------------------------------------------------  
//

//-----------------------------------------------------------------------------
// Detector hardware: 2x AD8307 (fixed for this project)

//-----------------------------------------------------------------------------
// ADC hardware is fixed: external AD7991 on Teensy 4.x LPI2C1.
// The working LJ-2000M design uses the I2C High-Speed master-code protocol.
// Standard Wire is used only for AD7991 discovery/configuration. The measurement
// data phase uses the same direct LPI2C 3 MHz Hs timing proven in the 5-inch TFT build.
#define I2C_CONFIG_CLOCK_HZ        400000UL
#define I2C_HS_DATA_CLOCK_HZ      3000000UL
#define I2C_HS_PREAMBLE_CLOCK_HZ  1000000UL

//-----------------------------------------------------------------------------
// Sampling and measurement timing
// The TimerOne ISR performs the bounded AD7991 High-Speed read and queues raw
// ADC codes. All calibration, power, PEP and SWR math is done in normal context.
#define SAMPLE_TIMER             50  // microseconds; deterministic 20 kHz acquisition target

// Measurement statistics use real 100 ms time blocks and are independent of sample count.
#define PEP_BUFFER                20  // 20 x 100 ms = 2 s maximum PEP window
#define LONG_BUFFER              300  // 300 x 100 ms = 30 s long-term peak window
#define PEAK_MEDIAN_SAMPLES        5  // Reject 1-2 isolated ADC/RF spikes before peak detection (250 us span)
#define PEAK_FILTER_SAMPLES       64  // 64 x 50 us = 3.2 ms envelope filter at deterministic 20 kHz capture

// V3.102 TFT-ADC timing verification release.
// Keeps the proven V3.101 START/END, PK/PEP and TAIL logic unchanged, but copies
// the AD7991 High-Speed data-phase timing from the 5-inch TFT firmware: 3.0 MHz
// MCCR1 instead of 2.0 MHz. The TFT uses the same Hs master-code transaction and
// shows no key-down overshoot on the user's hardware. This controlled test changes
// only the AD7991 Hs data clock; calibration, 20 kHz sample cadence, SWR math,
// ordinary averages, peak filters and display guard logic remain unchanged.
// Every actual Power-screen frame gets a
// separate DSP trace containing the exact large PEP number/text and small PK
// number/text sent to the OLED. Debug printing remains outside the 20 kHz ISR
// and sample-processing path. It is ON by default for this test release and can
// be toggled with $pepdebugon / $pepdebugoff.
#define PEP_DEBUG_TRACE_DEFAULT_ON  1

// A steady carrier should have Peak == Average. The max-of-many peak detector
// can otherwise sit a few tenths of a dB high because of AD8307/ADC noise.
// If Peak is no more than this amount above the current 100 ms average, treat
// the difference as measurement noise. Genuine modulation/keying peaks larger
// than this remain untouched. 0.70 dB = about 17.5% in power.
#define PEAK_CARRIER_NOISE_DB      0.70

// AD7991 external reference voltage
#define AD7991REF              2.60

//-----------------------------------------------------------------------------
// DEFS for FWD and REF coupler, 2x AD8307
//-----------------------------------------------------------------------------
// DEFS for AD8307 Calibration (dBm *10)
// levels for the forward and reverse measurements - in order to allow a Calibration
//
//-----------------------------------------------------------------------------
#define LOGAMP1_SLOPE          25 // mV/dB.  Used with Single Level Calibration //23.5
#define LOGAMP2_SLOPE          25 // mV/dB.  Used with Single Level Calibration
                                    // Typical value for AD8307 is 25mV/dB if AD input is ~1Mohm or higher
                                    // Typical value for ADL5519 is 22mV/dB

// Minimum directional separation needed to decide whether the calibration
// signal is Forward or Reverse.  The old 12 dB requirement was unnecessarily
// strict: it could report "Poor signal quality" even with plenty of RF power
// when the opposite detector was only a few dB lower.  3 dB is enough to make
// the direction unambiguous while remaining tolerant of real coupler directivity.
#define CAL_DIRECTION_MIN_DB    3.0

// Calibration-value encoder acceleration (dBm entry only).
// The stored calibration value is in tenths of a dB (db10m), therefore:
//   1  = 0.1 dB per detent (fine)
//   10 = 1.0 dB per detent (coarse)
//
// CAL_ENCODER_1DB_INTERVAL_MS is the maximum time between two encoder
// detents that selects the 1.0 dB step. Increase it if you want the 1.0 dB
// step to engage with slightly slower knob movement; decrease it if you want
// to require faster turning. This affects calibration only.
#define CAL_ENCODER_FINE_DB10             1
#define CAL_ENCODER_COARSE_DB10          10
#define CAL_ENCODER_1DB_INTERVAL_MS   300UL
#define CAL_ENCODER_FINE_RESET_MS      400UL

// Fixed 20:1 Tandem Match used by this OLED hardware.
// The unused 30:1 compile-time branch has been removed deliberately.
#define CAL1_NOR_VALUE          400 // 40 dBm, default high calibration point
#define CAL2_NOR_VALUE          100 // 10 dBm, default low calibration point
#define CALFWD1_DEFAULT       2.452 // Forward detector voltage at 40 dBm
#define CALREV1_DEFAULT       2.452 // Reverse detector voltage at 40 dBm
#define CALFWD2_DEFAULT       1.702 // Forward detector voltage at 10 dBm
#define CALREV2_DEFAULT       1.702 // Reverse detector voltage at 10 dBm
//-----------------------------------------------------------------------------
// Timer for Power/SWR calculations and LCD prints, milliseconds
#define POLL_TIMER              100 // LCD/menu service period in milliseconds

// Display-only smoothing for the dBm detector readout.
// This does NOT feed back into ADC sampling, SWR, PK/PEP, averages, alarms,
// calibration or USB reporting. The dBm screen is NOT noise-floor gated; this
// smoothing only makes the real detector/noise reading easier to read.
#define DISPLAY_SMOOTH_ALPHA    0.6

// If LIVE dBm falls by this much or more between display updates, treat it as
// a genuine RF drop/key-up and jump directly to the new detector value.
// Smaller changes still use DISPLAY_SMOOTH_ALPHA for a stable readable display.
#define DISPLAY_FAST_FALL_DB     3.0

// Central no-signal / noise-floor setting, expressed directly in milliwatts.
// Change this ONE value when the detector noise floor needs adjustment.
#define NOISE_FLOOR_MW                1.0f

// Display-only RF-present hysteresis. Below OFF, live LCD power goes immediately
// to 0 and LCD SWR to 1.00. Above ON, normal live display resumes.
// Measurement, PK/PEP histories, averages, alarms, calibration and USB values
// are NOT changed by this display gate.
#define DISPLAY_RF_OFF_THRESHOLD_MW   NOISE_FLOOR_MW
#define DISPLAY_RF_ON_THRESHOLD_MW    (NOISE_FLOOR_MW * 2.0f)
                                    

//-----------------------------------------------------------------------------
// Power/SWR validity thresholds for the fixed 20:1 coupler.
#define MIN_PWR_FOR_SWR_CALC   0.5  // Minimum averaged forward power in mW for SWR calculation
#define SWR_MAX_VALUE          10.0  // Maximum published/displayed SWR value

// A new SWR value is accepted only when the 100 ms directional-power block
// also contains real net transmitted power. This rejects common-mode pickup
// from strong broadcast stations when the user's transmitter is not keyed.
constexpr double SWR_TX_NET_MIN_MW = (double)NOISE_FLOOR_MW * 2.0;
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
//Text for Startup Display... Play with and tailor to your own liking
#define STARTUPDISPLAY1         "JH2KW-M"
#define STARTUPDISPLAY2         "POWER & SWR METER"

//-----------------------------------------------------------------------------
// EEPROM settings Serial Number. Increment this number when firmware mods necessitate
// fresh "Factory Default Settings" to be forced into the EEPROM at first boot after
// an upgrade
#define COLDSTART_REF          0x05 // When started, the firmware examines this "Serial Number
                                    // and enforce factory reset if there is a mismatch.
                                    // This is useful if the EEPROM structure has been modified


constexpr int EEPROM_COLDSTART_ADDR = 0;
constexpr int EEPROM_SETTINGS_ADDR  = 1;

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
// Various Initial Default settings for Meter
// (many of these are configurable by user through Config Menu or USB commands)
//
//-----------------------------------------------------------------------------
// DEFS for SWR Alarm
#define LEGACY_METER_CAL_DEFAULT 150 // Reserved EEPROM byte; keep historical value/layout
#define SWR_ALARM                30 // 30=3.0, default SWR Alarm Trigger
#define SWR_THRESHOLD            10 // Default SWR Alarm Power Threshold in mW

//-----------------------------------------------------------------------------
// DEFS for User Definable Scale Ranges
#define SCALE_RANGE1              6 // User definable Scale Ranges, up to 3 ranges per decade                   
#define SCALE_RANGE2             12 // e.g. ... 6W 12W 24W 60W 120W 240W ...
#define SCALE_RANGE3             24 // If all values set as "2", then ... 2W 20W 200W ...

// Power-bar autorange behaviour. Higher ranges are selected immediately.
// A lower range is accepted only after the measured power has remained in
// that lower range for this time. Increase for a steadier bar, decrease for
// faster return after a high-power transmission.
#define POWER_BAR_DOWNSCALE_DELAY_MS 3000UL

//-----------------------------------------------------------------------------
// Peak display hold and PEP history timing.
// PK_HOLD_DEFAULT_MS controls only the OLED PK indication: a new higher peak
// appears immediately, while a falling PK is held for this time. It does not
// feed the PEP history or alter the RF measurement itself.
#define PK_HOLD_DEFAULT_MS       300 // Default 0.3 s; menu range 0.1 .. 2.0 s

// PEP is selectable as exactly 0.1, 1.0 or 2.0 seconds (100 ms blocks).
#define PEP_PERIOD               10 // Default 1.0 second

//-----------------------------------------------------------------------------
// DEFS for Default Screensaver Message
#define SLEEPMSG   "ZZZzzzz.." // Shown when nothing else to display on LCD
#define SLEEPTHRESHOLD          NOISE_FLOOR_MW // Default no-signal threshold in mW

//-----------------------------------------------------------------------------
// Rotary encoder resolution for the installed encoder. Real hardware testing
// confirms four quadrature counts per mechanical detent.
#define ENCODER_COUNTS_PER_DETENT 4

//-----------------------------------------------------------------------------
// Fixed UI timing and display settings (milliseconds unless noted).
constexpr uint8_t DISPLAY_CONTRAST_ACTIVE    = 127;
constexpr uint8_t DISPLAY_CONTRAST_CLOCK_DIM = 4;
constexpr uint8_t DISPLAY_CONTRAST_SLEEP     = 0;
constexpr uint32_t COUPLER_DEBOUNCE_MS    = 50;
// External coupler button has two normal operating actions:
//   short press/release           -> Coupler 1 / Coupler 2
//   hold this long or longer      -> open Band Select
// SWR alarm acknowledgement bypasses both actions and remains immediate.
constexpr uint32_t COUPLER_BAND_SELECT_HOLD_MS = 800;
constexpr uint16_t BUTTON_SHORT_MIN_MS     = 15;
constexpr uint16_t BUTTON_LONG_MS          = 500;
constexpr uint16_t SCREENSAVER_SHIFT_MS    = 1500;
// Default screensaver timeout. The active timeout is stored in EEPROM as minutes.
// 0 minutes means disabled.
constexpr uint16_t SCREENSAVER_DEFAULT_MINUTES = 10;
// Additional delay after the dimmed screensaver before the OLED controller is
// switched fully off. 0 minutes disables the full-off stage.
constexpr uint16_t DISPLAY_OFF_DEFAULT_MINUTES = 0;

// NHD-3.12-25664UCB2 / SSD1322 256x64 graphical OLED.
// Hardware SPI on Teensy 4.0 uses the fixed SCLK=13 and MOSI=11 pins.
#define OLED_CS     10
#define OLED_DC      8
#define OLED_RESET 255
constexpr uint16_t OLED_WIDTH  = 256;
constexpr uint16_t OLED_HEIGHT = 64;

// Graphical menu canvas for the SSD1322. With X11 6x12, 42 columns fit
// across 256 pixels and five rows fit comfortably in 64 pixels.
constexpr uint8_t OLED_ROWS      = 5;
constexpr uint8_t OLED_COLUMNS   = 42;

//-----------------------------------------------------------------------------  
// Assign pins to inputs and outputs (Arduino style)
//-----------------------------------------------------------------------------  
//
//-----------------------------------------------------------------------------

// Teensy 4.0
// 255 means "not fitted" on this hardware revision. Always access these
// optional indicator outputs through optionalPinMode()/optionalDigitalWrite().
constexpr int R_Led          = 255; // optional separate SWR alarm LED
constexpr int G_Led          = 255; // optional RF/power-detected LED

// SWR alarm annunciation. Pin 14 drives the existing buzzer with 50% PWM.
// The front-panel CouplerLed is reserved for SWR alarm flashing only;
// normal Coupler 1/2 selection never lights it.
constexpr int      SwrBuzzerPin          = 14;
constexpr uint8_t  SWR_BUZZER_PWM          = 128;
constexpr uint32_t SWR_BUZZER_AUTO_OFF_MS  = 3000;
constexpr uint16_t SWR_ALARM_LED_FLASH_MS  = 250;

static inline void swrBuzzerOn()
{
  analogWrite(SwrBuzzerPin, SWR_BUZZER_PWM);
}

static inline void swrBuzzerOff()
{
  analogWrite(SwrBuzzerPin, 0);
}

static inline bool optionalPinEnabled(int pin)
{
  return pin != 255;
}

static inline void optionalPinMode(int pin, uint8_t mode)
{
  if (optionalPinEnabled(pin)) pinMode(pin, mode);
}

static inline void optionalDigitalWrite(int pin, uint8_t value)
{
  if (optionalPinEnabled(pin)) digitalWrite(pin, value);
}
constexpr int EncI           = 1;
constexpr int EncQ           = 0;
constexpr int EnactSW        = 3; // Menu/Enact Switch
constexpr int CouplerSW      = 6;  // front-panel coupler select switch
constexpr int CouplerLed     = 7;  // front-panel coupler indicator LED
constexpr int CouplerSelect  = 15; // external coupler select output

// ADC input is exclusively the external AD7991. The former built-in ADC fallback
// is intentionally removed because Teensy A1 is pin 15, already used by CouplerSelect.
//
//-----------------------------------------------------------------------------
// Miscellaneous non-configurable software defines and variables
//-----------------------------------------------------------------------------
//

//-----------------------------------------------------------------------------
// Structures and Unions

// Legacy ISR circular buffer removed in V3.3: sampling is serviced safely from loop().
               
typedef struct {
          int16_t  db10m;                     // Calibrate, value in dBm x 10
          double   Fwd;                       // corresponding AD8307 forward output value, V * 10000
          double   Rev;                       // corresponding AD8307 reverse output value, V * 10000
               }  cal_t;

typedef struct {
          cal_t    cal_AD[2];                 // 2 calibration points for both fixed AD8307 detectors
          uint8_t  reserved_meter_cal;        // Reserved legacy EEPROM byte; keep layout unchanged
          uint8_t  SWR_alarm_trig;            // SWR level*10 for Alarm trigger
          uint16_t SWR_alarm_pwr_thresh;      // Minimum Power required to trigger SWR Alarm
          uint8_t  usb_report_cont;           // Continuous USB Serial Reporting of Power and SWR
          uint8_t  usb_report_type;           // Which type of Power reporting is active over USB?
                                              // serial/USB (selected/deselected w USB commands $pcont/$ppoll)
                     #define  REPORT_DATA      1    // Report Instantaneous Power (raw format) and SWR to USB
                     #define  REPORT_INST      2    // Report Instantaneous Power (formatted) and SWR to USB
                     #define  REPORT_PK        3    // Report Peak (100ms) Power and SWR to USB
                     #define  REPORT_PEP       4    // Report PEP (1s) Power and SWR to USB
                     #define  REPORT_AVG       5    // Report Average (1s) Power and SWR to USB
                     #define  REPORT_1SAVG     6    // Report Average (1s) Power and SWR to USB
                     #define  REPORT_INSTDB    7    // Report Instantaneous Power (formatted) and SWR to USB
                     #define  REPORT_PKDB      8    // Report Peak (100ms) Power and SWR to USB
                     #define  REPORT_PEPDB     9    // Report PEP (1s) Power and SWR to USB
                     #define  REPORT_AVGDB    10    // Report Average (1s) Power and SWR to USB
                     #define  REPORT_1SAVGDB  11    // Report Average (1s) Power and SWR to USB
                     #define  REPORT_LONG     12    // Report Power and SWR to USB, long Human Readable format                   
                     #define  REPORT_AD_DEBUG 13    // Report raw AD values
          uint16_t PEP_period;                // PEP window in 100 ms blocks: 1, 10 or 20
          uint16_t PK_hold_ms;                // OLED PK hold time; reuses legacy 16-bit EEPROM slot
          uint8_t  ScaleRange[3];             // User settable Scale ranges, up to 3 ranges per decade.
          char     idle_disp[21];             // Sleep Display (configurable by USB serial command)
          float    idle_disp_thresh;          // Minimum level in mW to exit Sleep Display  
     
          uint8_t  low_power_floor;
          #define  FLOOR_ONE_uW                1    // Legacy EEPROM value; migrated to FLOOR_ONE_mW
                     #define  FLOOR_TEN_uW     2    // Legacy EEPROM value; normalized to FLOOR_ONE_mW
                     #define  FLOOR_100_uW     3    // Legacy EEPROM value; normalized to FLOOR_ONE_mW
                     #define  FLOOR_ONE_mW     4    // Display values below 1 mW as 0 mW
                     #define  FLOOR_TEN_mW     5    // Display values below 10 mW as 0 mW
     
          uint8_t  mode_display;              // Selectable front-panel display mode
          uint16_t screensaver_minutes;        // 0=Off; otherwise idle timeout in minutes
          uint16_t display_off_minutes;         // 0=Off; additional minutes after screensaver before OLED OFF
                     #define  POWER_BARPK       1    // 100 ms Peak Power
                     #define  POWER_CLEAN_DBM   2    // Power in dBm
                     #define  POWER_FWD_REV     3    // Live forward and reflected power
                     #define  POWER_MOD_SCOPE   4    // Live modulation envelope scope
                     #define  POWER_CLOCK       5    // NTP clock: local time, date and UTC (WiFi module only)
                     #define  DEFAULT_MODE      POWER_BARPK
                     #define  MAX_MODE          5
               } var_t;

// Guard the proven V3.4 EEPROM byte layout.  If a future edit moves one of
// these fields, fail the build instead of silently loading calibration data
// into the wrong member.
static_assert(sizeof(var_t) == 96, "EEPROM var_t size changed");
static_assert(offsetof(var_t, cal_AD) == 0, "EEPROM cal_AD offset changed");
static_assert(offsetof(var_t, reserved_meter_cal) == 48, "EEPROM legacy byte offset changed");
static_assert(offsetof(var_t, SWR_alarm_trig) == 49, "EEPROM SWR alarm offset changed");
static_assert(offsetof(var_t, SWR_alarm_pwr_thresh) == 50, "EEPROM SWR power offset changed");
static_assert(offsetof(var_t, PEP_period) == 54, "EEPROM PEP offset changed");
static_assert(offsetof(var_t, PK_hold_ms) == 56, "EEPROM PK hold offset changed");
static_assert(offsetof(var_t, ScaleRange) == 58, "EEPROM scale offset changed");
static_assert(offsetof(var_t, idle_disp) == 61, "EEPROM idle message offset changed");
static_assert(offsetof(var_t, idle_disp_thresh) == 84, "EEPROM threshold offset changed");
static_assert(offsetof(var_t, low_power_floor) == 88, "EEPROM power-floor offset changed");
static_assert(offsetof(var_t, mode_display) == 89, "EEPROM mode offset changed");
static_assert(offsetof(var_t, screensaver_minutes) == 90, "EEPROM screensaver-time offset changed");
static_assert(offsetof(var_t, display_off_minutes) == 92, "EEPROM display-off-time offset changed");


typedef struct  {
          unsigned short_push          : 1;   // Short Push Button Action
          unsigned mode_change         : 1;   // Display mode changed; refresh setup/render state
          unsigned swr_alarm           : 1;   // Latched SWR alarm
          unsigned idle_refresh        : 1;   // Force screensaver reprint
          unsigned menu_lcd_upd        : 1;   // Refresh/update LCD while in menu mode
          unsigned config_mode         : 1;   // Configuration menu is active
                } flags;


//-----------------------------------------------------------------------------
// Soft Reset
#define RESTART_ADDR       0xE000ED0C
#define RESTART_VAL        0x5FA0004
#define SOFT_RESET()       ((*(volatile uint32_t *)RESTART_ADDR) = (RESTART_VAL))

#endif // PSWR_CONFIG_H
