#include "CWDecoder.h"
#include "WeakDetector.h"
#include "FadingTracker.h"
#include "AdaptiveTiming.h"
#include "AdaptiveLearner.h"
#include "GuentherTiming.h"

#include <math.h>
#include <string.h>

// Optional host-benchmark hooks. They compile to nothing in firmware, so the
// real-time decoder pays no logging or allocation cost. host_checks/wav_benchmark.cpp
// defines them before including this source file.
#ifndef CW_BENCH_TRACE_MARK
#define CW_BENCH_TRACE_MARK(sampleIndex, durationMs, confidence, thresholdMs, isDash, accepted) do {} while (0)
#endif
#ifndef CW_BENCH_TRACE_GAP
#define CW_BENCH_TRACE_GAP(sampleIndex, durationMs, confidence, thresholdMs, kind) do {} while (0)
#endif
#ifndef CW_BENCH_TRACE_CHAR
#define CW_BENCH_TRACE_CHAR(sampleIndex, rawPattern, finalPattern, decodedChar) do {} while (0)
#endif

namespace {

constexpr float PI_F = 3.14159265358979323846f;
constexpr size_t SPECTRUM_WINDOW = 600;              // 50 ms @ 12 kHz
constexpr size_t SPECTRUM_HOP = 240;                 // update every 20 ms
constexpr size_t DEBOUNCE_SAMPLES = 24;              // 2 ms @ 12 kHz
constexpr float DEFAULT_DOT_MS = 60.0f;               // 20 WPM
constexpr float MIN_DOT_MS = 20.0f;                   // 60 WPM
constexpr float MAX_DOT_MS = 240.0f;                  // 5 WPM
constexpr size_t TIMING_HISTORY_SIZE = 11;             // robust recent dot estimates

portMUX_TYPE stateMux = portMUX_INITIALIZER_UNLOCKED;
portMUX_TYPE configMux = portMUX_INITIALIZER_UNLOCKED;
CWDecoderState published;

float measuredToneHz = 700.0f;
bool measuredToneValid = false;
uint32_t spectrumSequence = 0;
bool running = false;
// Audio-task startup supervisor, independent of resetInternal's sample clock.
uint64_t acquisitionSamples = 0, acquisitionAttemptStart = 0;
uint64_t acquisitionLastTone = 0, acquisitionLastEdge = 0;
float acquisitionToneHz = 700.0f;
unsigned acquisitionToneHits = 0, automaticRelocks = 0;
bool acquisitionComplete = false;
bool normalToneLocked = false;
float normalCandidateHz = 700;
unsigned normalCandidateHits = 0;
uint64_t normalLastToneSample = 0;
void resetInternal(bool preserveText);

bool autoTone = true;
uint16_t requestedAutoToneResponseMs = 500;
bool requestedWeak = false;
bool requestedFadeAssist=false, fadeAssistActive=false;
uint8_t requestedCwType=0, activeCwType=0;
// V1.91: adaptive learning is confidence-gated. Disabling it freezes the
// current profile; it does not throw away what has already been learned.
bool requestedAdaptiveLearning=true, adaptiveLearningActive=true;
bool resetAdaptiveLearningRequested=false;
float requestedLearnMarkRatio=0.0f, requestedLearnGapRatio=0.0f;
uint8_t requestedLearnQuality=0;
uint8_t requestedSpacing=20, activeSpacing=20;
bool weakActive = false;
// Opt-in profile: STANDARD and the other modes retain V1.79 decisions.
bool handTimingActive() { return !weakActive && fadeAssistActive && activeCwType==1; }
// V2.22: Guenther timing is tied to HAND-SENT mode itself. The radio front end
// remains independent; only timing recognition, learning guards and conservative
// recovery use this path.
bool guentherActive() { return !weakActive && activeCwType==1; }
bool weakToneLocked = false;
float weakCandidateHz = 700;
unsigned weakCandidateHits = 0;
uint64_t weakLastToneSample = 0;
WeakDetector weakDetector;
float searchMin() { return weakActive ? 300.0f : CWDecoder::SPECTRUM_MIN_HZ; }
float searchMax() { return weakActive ? 1000.0f : CWDecoder::SPECTRUM_MAX_HZ; }
float searchStep() { return (searchMax()-searchMin())/(CWDecoderState::kSpectrumBins-1); }

uint8_t selectedChannel = 0;
float manualToneHz = 700.0f;
float detectorAlpha = 0.02073f;
uint16_t selectedFilterBandwidthHz = 40;
int8_t selectedInputTrimDb = 0;
float selectedInputTrimLinear = 1.0f;
float appliedInputGain = 1.0f; // audio-task-owned scale of detector history
uint8_t selectedInputLevelPercent = 100;
bool clearRequested = false;
bool relockRequested = false;
bool relockInProgress = false;
portMUX_TYPE textMux = portMUX_INITIALIZER_UNLOCKED;
char textQueue[2048] = {};
size_t textRead = 0, textWrite = 0;
bool textOverflow = false;
bool textClearing = false;

uint32_t inputRate = CWDecoder::INPUT_SAMPLE_RATE;
uint32_t decimation = CWDecoder::DECIMATION;

int32_t decimSum = 0;
uint8_t decimCount = 0;
float previousInput = 0.0f;
float hpState = 0.0f;

float spectrumRing[SPECTRUM_WINDOW] = {};
float spectrumWindow[SPECTRUM_WINDOW] = {};
float hannWindow[SPECTRUM_WINDOW] = {};
float goertzelCoeff[CWDecoderState::kSpectrumBins] = {};
void configureSpectrum() {
  for(size_t b=0;b<CWDecoderState::kSpectrumBins;++b) {
    const float freq=searchMin()+b*searchStep();
    goertzelCoeff[b]=2*cosf(6.283185307179586f*freq/CWDecoder::DSP_SAMPLE_RATE);
  }
}
float spectrumDb[CWDecoderState::kSpectrumBins] = {};
size_t spectrumWrite = 0;
size_t spectrumFilled = 0;
size_t samplesSinceSpectrum = 0;

float detectorToneHz = 700.0f;
float spectrumPeakHz = 700.0f;
float phase = 0.0f;
float iLp1 = 0.0f;
float qLp1 = 0.0f;
float iLp2 = 0.0f;
float qLp2 = 0.0f;
float envelope = 0.0f;
float noiseEnvelope = 20.0f;
float signalEnvelope = 30.0f;
float spectralSnrDb = 0.0f;
FadingTracker fadingTracker;

bool keyDown = false;
bool candidateState = false;
size_t candidateSamples = 0;
uint64_t dspSampleCounter = 0;
uint64_t stateStartSample = 0, precedingGapStart=0;
float dotMs = DEFAULT_DOT_MS;
constexpr size_t CYCLE_HISTORY_SIZE = 32;
float cyclePeriods[CYCLE_HISTORY_SIZE] = {}, cycleMarks[CYCLE_HISTORY_SIZE] = {};
size_t cycleCount = 0, cycleWrite = 0;
uint64_t previousRiseSample = 0;
float previousMarkMs = 0, previousMarkConfidence = 0, edgeBiasMs = 0;
bool cycleTimingReady = false;
float displayDotMs = DEFAULT_DOT_MS;
AdaptiveTiming handTiming;
AdaptiveLearner adaptiveLearner;
GuentherTiming guentherTiming;
// Raw mark/gap durations for the current HAND-SENT character.  These are used
// only for Guenther-style recovery when the normal lookup yields an invalid
// Morse pattern.  Fixed arrays: no allocation in the audio task.
float guentherMarks[16] = {};
float guentherGaps[16] = {};
float guentherMarkConfidence[16] = {};
size_t guentherMarkCount = 0;
uint32_t guentherCorrections = 0;
uint32_t guentherHypothesisCorrections = 0;
float learningMarks[16] = {};
size_t learningMarkCount = 0;
float timingHistory[TIMING_HISTORY_SIZE] = {};
size_t timingHistoryCount = 0;
size_t timingHistoryWrite = 0;
bool characterGapHandled = false;
bool wordGapHandled = false;

char symbolBuffer[16] = {};
size_t symbolLength = 0;
float weakMarks[16] = {};
size_t weakMarkCount = 0;
char lastMorse[16] = {};
char decodedText[CWDecoderState::kDecodedText] = {};
uint32_t decodedCharacters = 0;

uint8_t spectrumDisplay[CWDecoderState::kSpectrumBins] = {};
uint32_t publishDivider = 0;

struct MorseEntry {
  const char *code;
  char value;
};

struct ProsignEntry {
  const char *code;
  const char *text;
};

// Common amateur-radio CW procedural signals. These are sent as one
// uninterrupted Morse character, without the normal inter-character gap.
// Where a prosign shares a pattern with punctuation (for example AR/+ or
// BT/=), the procedural interpretation is intentionally preferred.
const ProsignEntry PROSIGN_TABLE[] = {
  {".-.-.",   "<AR>"},   // end of message / transmission
  {".-...",   "<AS>"},   // wait / stand by
  {"...-.-",  "<SK>"},   // end of contact
  {"-...-.-", "<BK>"},   // break / back to you
  {"-...-",   "<BT>"},   // separator / break
  {"-.--.",   "<KN>"},   // go ahead, named station only
  {"-.-..-..", "<CL>"},  // closing station
  {"........", "<HH>"},  // error / correction
  {"...---...", "<SOS>"} // distress signal
};

const MorseEntry MORSE_TABLE[] = {
  {".-", 'A'}, {"-...", 'B'}, {"-.-.", 'C'}, {"-..", 'D'}, {".", 'E'},
  {"..-.", 'F'}, {"--.", 'G'}, {"....", 'H'}, {"..", 'I'}, {".---", 'J'},
  {"-.-", 'K'}, {".-..", 'L'}, {"--", 'M'}, {"-.", 'N'}, {"---", 'O'},
  {".--.", 'P'}, {"--.-", 'Q'}, {".-.", 'R'}, {"...", 'S'}, {"-", 'T'},
  {"..-", 'U'}, {"...-", 'V'}, {".--", 'W'}, {"-..-", 'X'}, {"-.--", 'Y'},
  {"--..", 'Z'},
  {"-----", '0'}, {".----", '1'}, {"..---", '2'}, {"...--", '3'}, {"....-", '4'},
  {".....", '5'}, {"-....", '6'}, {"--...", '7'}, {"---..", '8'}, {"----.", '9'},
  {".-.-.-", '.'}, {"--..--", ','}, {"..--..", '?'}, {"-..-.", '/'},
  {"-....-", '-'}, {".-.--.", '\''}, {"-.--.", '('}, {"-.--.-", ')'},
  {".-.-.", '+'}, {"-...-", '='}, {"---...", ':'}, {"-.-.-.", ';'},
  {".-..-.", '"'}, {".--.-.", '@'}
};

static inline float clampf(float v, float lo, float hi) {
  return v < lo ? lo : (v > hi ? hi : v);
}

float learningConfidenceNow() {
  bool localAuto = true;
  portENTER_CRITICAL(&configMux);
  localAuto = autoTone;
  portEXIT_CRITICAL(&configMux);
  const bool toneStable = normalToneLocked ||
      (!localAuto && measuredToneValid && fabsf(measuredToneHz - detectorToneHz) <= 25.0f);
  if (weakActive || !toneStable || spectralSnrDb < 8.0f) return 0.0f;
  const float snr = clampf(20.0f * log10f((signalEnvelope + 1.0f) /
                                          (noiseEnvelope + 1.0f)), 0.0f, 60.0f);
  return clampf((snr - 2.0f) * 5.0f + spectralSnrDb * 1.5f, 0.0f, 100.0f);
}

float adaptiveBlend(uint8_t quality, float maxBlend) {
  if (quality < AdaptiveLearner::kApplyQuality) return 0.0f;
  const float t = clampf((static_cast<float>(quality) - AdaptiveLearner::kApplyQuality) /
                         (100.0f - AdaptiveLearner::kApplyQuality), 0.0f, 1.0f);
  return 0.20f + t * (maxBlend - 0.20f);
}

static inline float toDbfs(float amplitude) {
  if (amplitude < 0.0001f) return -120.0f;
  const float norm = amplitude / 32768.0f;
  const float db = 20.0f * log10f(norm);
  return db < -120.0f ? -120.0f : db;
}

static inline int16_t slotToSample(int32_t slot) {
  return static_cast<int16_t>(slot >> 16);
}

const char *decodeProsign(const char *code) {
  for (const auto &entry : PROSIGN_TABLE) {
    if (strcmp(entry.code, code) == 0) return entry.text;
  }
  return nullptr;
}

char decodeMorse(const char *code) {
  for (const auto &entry : MORSE_TABLE) {
    if (strcmp(entry.code, code) == 0) return entry.value;
  }
  return '?';
}

void appendDecoded(char c) {
  size_t len = strlen(decodedText);
  if (len >= sizeof(decodedText) - 2) {
    // Keep the most recent text without dynamic allocation.
    const size_t keep = sizeof(decodedText) - 128;
    memmove(decodedText, decodedText + (len - keep), keep);
    len = keep;
    decodedText[len] = '\0';
  }

  // Avoid repeated word spaces.
  if (c == ' ' && (len == 0 || decodedText[len - 1] == ' ')) return;
  decodedText[len++] = c;
  decodedText[len] = '\0';
  if (c != ' ') ++decodedCharacters;
  if (c != ' ' && c != '?') acquisitionComplete = true;
  portENTER_CRITICAL(&textMux);
  if (!textClearing) {
    const size_t next = (textWrite + 1) % sizeof(textQueue);
    if (next == textRead) {
      textRead = (textRead + 1) % sizeof(textQueue);
      textOverflow = true;
    }
    textQueue[textWrite] = c;
    textWrite = next;
  }
  portEXIT_CRITICAL(&textMux);
}

void appendDecodedText(const char *text) {
  if (!text) return;
  while (*text) appendDecoded(*text++);
}

bool patternIsValid(const char *pattern) {
  if (!pattern || !pattern[0]) return false;
  return decodeProsign(pattern) != nullptr || decodeMorse(pattern) != '?';
}

void emitPattern(const char *pattern) {
  const char *prosign = decodeProsign(pattern);
  if (prosign) appendDecodedText(prosign);
  else appendDecoded(decodeMorse(pattern));
}

void buildGuentherPattern(size_t first, size_t lastExclusive, int skip,
                          char *out, size_t capacity) {
  if (!out || capacity == 0) return;
  size_t n = 0;
  for (size_t i = first; i < lastExclusive && n + 1 < capacity; ++i) {
    if (static_cast<int>(i) == skip) continue;
    out[n++] = guentherTiming.classifyDash(guentherMarks[i]) ? '-' : '.';
  }
  out[n] = '\0';
}

// Score a one-element-per-mark interpretation. This is not a language model:
// it only asks how well the raw durations fit the learned dot/dash and
// intra-character gap clusters.
float guentherPatternScore(const char *pattern) {
  if (!pattern || strlen(pattern) != guentherMarkCount) return 1.0e9f;
  float score = 0.0f;
  for (size_t i = 0; i < guentherMarkCount; ++i) {
    score += guentherTiming.markFitCost(guentherMarks[i], pattern[i] == '-');
    if (i + 1 < guentherMarkCount && guentherGaps[i] > 0.0f)
      score += 0.30f * guentherTiming.symbolGapFitCost(guentherGaps[i]);
  }
  return score;
}

bool buildMergedGuentherPattern(size_t mergeAfter, char *out, size_t capacity,
                                float &scoreOut) {
  if (!out || capacity < 2 || mergeAfter + 1 >= guentherMarkCount) return false;
  size_t n = 0;
  float score = 0.0f;
  for (size_t i = 0; i < guentherMarkCount && n + 1 < capacity; ++i) {
    if (i == mergeAfter) {
      // A QSB hole inside a dash appears as mark-gap-mark. Reconstruct the
      // continuous mark including the missing-tone interval, then skip the
      // second fragment. This candidate is considered only for a very short
      // internal gap and must still form valid Morse.
      const float combined = guentherMarks[i] + guentherGaps[i] + guentherMarks[i + 1];
      const bool dash = guentherTiming.classifyDash(combined);
      out[n++] = dash ? '-' : '.';
      score += guentherTiming.markFitCost(combined, dash) + 0.25f;
      ++i;
      continue;
    }
    const bool dash = guentherTiming.classifyDash(guentherMarks[i]);
    out[n++] = dash ? '-' : '.';
    score += guentherTiming.markFitCost(guentherMarks[i], dash);
    if (i + 1 < guentherMarkCount && i != mergeAfter && guentherGaps[i] > 0.0f)
      score += 0.30f * guentherTiming.symbolGapFitCost(guentherGaps[i]);
  }
  out[n] = '\0';
  scoreOut = score;
  return n > 0;
}

// Short multi-hypothesis timing layer. It never uses English, callsign or word
// probabilities. It only tries physically plausible alternatives when the raw
// timing is ambiguous: one near-boundary dot/dash flip for an invalid code, or
// one QSB merge across a very short internal gap. A valid existing character is
// changed only when the QSB-merge timing score is decisively better.
bool chooseGuentherHypothesis(char *chosen, size_t capacity) {
  if (!chosen || capacity == 0 || !guentherActive() || !cycleTimingReady ||
      !guentherTiming.ready() || guentherMarkCount < 1 ||
      guentherMarkCount != symbolLength) return false;

  char base[16];
  buildGuentherPattern(0, guentherMarkCount, -1, base, sizeof(base));
  strncpy(chosen, base, capacity - 1);
  chosen[capacity - 1] = '\0';
  const bool baseValid = patternIsValid(base);
  float bestScore = guentherPatternScore(base);
  bool changed = false;

  // If the nearest-boundary pattern is invalid, allow one genuinely ambiguous
  // mark to take its second-best class. This is Morse-structure validation,
  // not language correction.
  if (!baseValid) {
    for (size_t i = 0; i < guentherMarkCount; ++i) {
      if (!guentherTiming.ambiguousMark(guentherMarks[i])) continue;
      char candidate[16];
      strncpy(candidate, base, sizeof(candidate) - 1);
      candidate[sizeof(candidate) - 1] = '\0';
      candidate[i] = candidate[i] == '-' ? '.' : '-';
      if (!patternIsValid(candidate)) continue;
      const float score = guentherPatternScore(candidate) + 0.20f;
      if (!changed || score < bestScore) {
        strncpy(chosen, candidate, capacity - 1);
        chosen[capacity - 1] = '\0';
        bestScore = score;
        changed = true;
      }
    }
  }

  // QSB/dropout candidate. This can repair a valid-but-wrong character when a
  // dash was split into two fragments, but only with a strong physical timing
  // advantage over the unmerged interpretation.
  for (size_t i = 0; i + 1 < guentherMarkCount; ++i) {
    if (!guentherTiming.qsbMergeGap(guentherGaps[i])) continue;
    char candidate[16];
    float score = 0.0f;
    if (!buildMergedGuentherPattern(i, candidate, sizeof(candidate), score) ||
        !patternIsValid(candidate)) continue;
    const bool decisive = !baseValid || score + 1.15f < bestScore;
    if (decisive) {
      strncpy(chosen, candidate, capacity - 1);
      chosen[capacity - 1] = '\0';
      bestScore = score;
      changed = strcmp(chosen, base) != 0;
    }
  }

  if (changed) {
    ++guentherHypothesisCorrections;
    Serial.printf("[GUENTHER] timing hypothesis %s -> %s (#%lu)\n",
                  base, chosen,
                  static_cast<unsigned long>(guentherHypothesisCorrections));
  }
  return changed;
}

// Conservative recovery inspired by the error-correction stage in Guenther's
// 1973 method.  It runs ONLY after ordinary Morse/prosign lookup fails:
//   1) discard one implausibly short pulse (noise spike/dropout artefact), or
//   2) split a run-on character at an unusually long internal space.
// No dictionary/language guessing is used.
bool tryGuentherRecovery() {
  if (!guentherActive() || !cycleTimingReady || !guentherTiming.ready() || guentherMarkCount < 2 ||
      guentherMarkCount != symbolLength) return false;

  // 1) Shortest-pulse suppression.  Only one pulse may be removed and only if
  // it is less than about half the learned dot duration.
  size_t shortest = 0;
  for (size_t i = 1; i < guentherMarkCount; ++i)
    if (guentherMarks[i] < guentherMarks[shortest]) shortest = i;
  if (guentherTiming.suspiciousShortPulse(guentherMarks[shortest])) {
    char candidate[16];
    buildGuentherPattern(0, guentherMarkCount, static_cast<int>(shortest),
                         candidate, sizeof(candidate));
    if (patternIsValid(candidate)) {
      emitPattern(candidate);
      ++guentherCorrections;
      Serial.printf("[GUENTHER] short-pulse recovery %s -> %s (#%lu)\n",
                    symbolBuffer, candidate,
                    static_cast<unsigned long>(guentherCorrections));
      return true;
    }
  }

  // 2) Run-on recovery.  Choose the strongest suspicious internal gap and
  // require BOTH halves to decode before emitting anything.
  int splitAfter = -1;
  float bestScore = 0.0f;
  for (size_t i = 0; i + 1 < guentherMarkCount; ++i) {
    const float gap = guentherGaps[i];
    const bool dash = guentherTiming.classifyDash(guentherMarks[i]);
    if (!guentherTiming.suspiciousInternalGap(gap, guentherMarks[i], dash)) continue;
    const float boundary = guentherTiming.characterBoundaryAfter(guentherMarks[i], dash);
    const float score = boundary > 1.0f ? gap / boundary : 0.0f;
    if (score > bestScore) { bestScore = score; splitAfter = static_cast<int>(i); }
  }
  if (splitAfter >= 0) {
    char left[16], right[16];
    buildGuentherPattern(0, static_cast<size_t>(splitAfter + 1), -1,
                         left, sizeof(left));
    buildGuentherPattern(static_cast<size_t>(splitAfter + 1), guentherMarkCount, -1,
                         right, sizeof(right));
    if (patternIsValid(left) && patternIsValid(right)) {
      emitPattern(left);
      emitPattern(right);
      ++guentherCorrections;
      Serial.printf("[GUENTHER] run-on recovery %s -> %s | %s (#%lu)\n",
                    symbolBuffer, left, right,
                    static_cast<unsigned long>(guentherCorrections));
      return true;
    }
  }

  return false;
}

void finishCharacter() {
  if (symbolLength == 0) return;
  if (weakActive && weakMarkCount == symbolLength) {
    float sum=0;
    for(size_t i=0;i<weakMarkCount;++i) {
      const bool dash=weakMarks[i]>2.0f*dotMs;
      symbolBuffer[i]=dash ? '-' : '.';
      sum += weakMarks[i]/(dash ? 3.0f : 1.0f);
    }
    if(weakMarkCount) dotMs=clampf(dotMs+0.15f*(sum/weakMarkCount-dotMs),MIN_DOT_MS,MAX_DOT_MS);
    displayDotMs += 0.2f*(dotMs-displayDotMs);
  }
  if(handTimingActive() && handTiming.markThreshold()>0 && weakMarkCount==symbolLength) {
    for(size_t i=0;i<weakMarkCount;i++)symbolBuffer[i]=weakMarks[i]>handTiming.markThreshold()?'-':'.';
  }
  // V2.22: once Guenther timing has enough acquisition data, make the final
  // per-character decision from the published moving averages. During the
  // first 49 pulses, the proven decoder remains active while the staged
  // Guenther estimator converges in parallel.
  char rawGuentherPattern[16] = {};
  if (guentherActive() && cycleTimingReady && guentherTiming.ready() && guentherMarkCount == symbolLength) {
    buildGuentherPattern(0, guentherMarkCount, -1, rawGuentherPattern, sizeof(rawGuentherPattern));
    strncpy(symbolBuffer, rawGuentherPattern, sizeof(symbolBuffer) - 1);
    symbolBuffer[sizeof(symbolBuffer) - 1] = '\0';
    char hypothesis[16];
    if (chooseGuentherHypothesis(hypothesis, sizeof(hypothesis))) {
      strncpy(symbolBuffer, hypothesis, sizeof(symbolBuffer) - 1);
      symbolBuffer[sizeof(symbolBuffer) - 1] = '\0';
      symbolLength = strlen(symbolBuffer);
    }
  } else {
    strncpy(rawGuentherPattern, symbolBuffer, sizeof(rawGuentherPattern) - 1);
  }
  weakMarkCount=0;
  symbolBuffer[symbolLength] = '\0';
  strncpy(lastMorse, symbolBuffer, sizeof(lastMorse) - 1);
  lastMorse[sizeof(lastMorse) - 1] = '\0';
  const char *prosign = decodeProsign(symbolBuffer);
  const char decoded = prosign ? '\0' : decodeMorse(symbolBuffer);
  const bool validDecoded = (prosign != nullptr) || (decoded != '?');
  CW_BENCH_TRACE_CHAR(dspSampleCounter, rawGuentherPattern, symbolBuffer,
                      prosign ? '*' : decoded);
  // Train only from a valid Morse character/prosign on a strong, stable
  // signal. Raw measured mark lengths are used; decoded text/dictionaries
  // are never fed back into the learner. This avoids self-reinforcing errors.
  if (adaptiveLearningActive && !weakActive && validDecoded &&
      cycleTimingReady && learningMarkCount == symbolLength) {
    const float confidence = learningConfidenceNow();
    for (size_t i = 0; i < learningMarkCount; ++i)
      adaptiveLearner.observeMark(learningMarks[i], dotMs, confidence);
  }
  learningMarkCount = 0;

  bool recovered = false;
  if (!validDecoded) recovered = tryGuentherRecovery();
  if (!recovered) {
    if (prosign) appendDecodedText(prosign);
    else appendDecoded(decoded);
  }

  symbolLength = 0;
  symbolBuffer[0] = '\0';
  guentherMarkCount = 0;
  memset(guentherMarks, 0, sizeof(guentherMarks));
  memset(guentherGaps, 0, sizeof(guentherGaps));
  memset(guentherMarkConfidence, 0, sizeof(guentherMarkConfidence));
}

void appendElement(char element) {
  if (symbolLength < sizeof(symbolBuffer) - 1) {
    symbolBuffer[symbolLength++] = element;
    symbolBuffer[symbolLength] = '\0';
  } else {
    // Invalid/very long symbol: close it as unknown and start clean.
    finishCharacter();
    symbolBuffer[symbolLength++] = element;
    symbolBuffer[symbolLength] = '\0';
  }
}

float robustTimingEstimate() {
  if (timingHistoryCount == 0) return dotMs;

  float sorted[TIMING_HISTORY_SIZE];
  for (size_t i = 0; i < timingHistoryCount; ++i) sorted[i] = timingHistory[i];
  for (size_t i = 1; i < timingHistoryCount; ++i) {
    const float v = sorted[i];
    size_t j = i;
    while (j > 0 && sorted[j - 1] > v) {
      sorted[j] = sorted[j - 1];
      --j;
    }
    sorted[j] = v;
  }

  const float median = sorted[timingHistoryCount / 2];

  // Average only values near the median.  This rejects one distorted mark or
  // a threshold glitch without letting the displayed WPM jump.
  float sum = 0.0f;
  size_t used = 0;
  const float lo = median * 0.72f;
  const float hi = median * 1.38f;
  for (size_t i = 0; i < timingHistoryCount; ++i) {
    if (sorted[i] >= lo && sorted[i] <= hi) {
      sum += sorted[i];
      ++used;
    }
  }
  return used ? (sum / static_cast<float>(used)) : median;
}

void addTimingMeasurement(float measuredDot) {
  if (measuredDot < MIN_DOT_MS || measuredDot > MAX_DOT_MS) return;

  // Once we have a stable history, reject implausible one-off timing spikes.
  if (timingHistoryCount >= 5) {
    const float reference = robustTimingEstimate();
    if (measuredDot < reference * 0.55f || measuredDot > reference * 1.75f) return;
  }

  timingHistory[timingHistoryWrite] = measuredDot;
  timingHistoryWrite = (timingHistoryWrite + 1) % TIMING_HISTORY_SIZE;
  if (timingHistoryCount < TIMING_HISTORY_SIZE) ++timingHistoryCount;

  const float robust = robustTimingEstimate();
  // Decoder timing follows changes reasonably quickly; the displayed speed is
  // deliberately calmer so it behaves like a useful WPM meter rather than a
  // per-element instantaneous reading.
  dotMs += 0.16f * (robust - dotMs);

  // Acquire the displayed speed quickly once five consistent timing samples are
  // available, then smooth it heavily.  This avoids a long startup drift from
  // the 20 WPM default while still preventing the readout from jumping on each
  // individual dot or dash.
  if (timingHistoryCount == 5) {
    displayDotMs = robust;
  } else if (timingHistoryCount > 5) {
    displayDotMs += 0.06f * (robust - displayDotMs);
  }

  dotMs = clampf(dotMs, MIN_DOT_MS, MAX_DOT_MS);
  displayDotMs = clampf(displayDotMs, MIN_DOT_MS, MAX_DOT_MS);
}

// A dot plus its following intra-element gap is two dot units. Measuring
// rising-edge to rising-edge cancels the filter/threshold delay that stretches
// marks and shortens gaps. Select a repeated short-cycle cluster without using
// the existing WPM estimate or first deciding that a mark was a dot/dash.
void learnCycle(float periodMs, float markMs) {
  if (periodMs < 1.6f*MIN_DOT_MS || periodMs > 2.2f*MAX_DOT_MS ||
      markMs <= 0 || markMs >= periodMs*0.92f) return;
  cyclePeriods[cycleWrite]=periodMs;cycleMarks[cycleWrite]=markMs;
  cycleWrite=(cycleWrite+1)%CYCLE_HISTORY_SIZE;
  if(cycleCount<CYCLE_HISTORY_SIZE)++cycleCount;
  if(cycleCount<6)return;
  float best=1e9f, bestBias=0;
  for(size_t i=0;i<cycleCount;++i) {
    float sum=0,bias=0;size_t hits=0;
    for(size_t j=0;j<cycleCount;++j) {
      if(fabsf(cyclePeriods[j]-cyclePeriods[i])<cyclePeriods[i]*(activeCwType==1?0.20f:0.12f)) {
        sum+=cyclePeriods[j];bias+=cycleMarks[j]-cyclePeriods[j]*0.5f;++hits;
      }
    }
    if(hits>=3 && sum/hits<best){best=sum/hits;bestBias=bias/hits;}
  }
  if(best==1e9f)return;
  float estimate=clampf(best*0.5f,MIN_DOT_MS,MAX_DOT_MS);
  // Hand keying tolerates a wider timing cluster and follows it gradually.
  dotMs=(activeCwType==1 && cycleTimingReady)?dotMs+0.35f*(estimate-dotMs):estimate;
  edgeBiasMs=clampf(bestBias,-0.8f*dotMs,0.8f*dotMs);
  if(!cycleTimingReady)displayDotMs=dotMs;
  else displayDotMs+=0.15f*(dotMs-displayDotMs);
  cycleTimingReady=true;
}

void handleMark(float durationMs) {
  durationMs = clampf(durationMs, 5.0f, 2000.0f);

  // Midpoint between a 1-dot mark and a 3-dot dash is approximately 2 dots.
  if(handTimingActive())handTiming.observeMark(durationMs,dotMs);
  if (guentherActive() && cycleTimingReady) guentherTiming.syncDotEstimate(dotMs);
  float cutoff=handTimingActive() && handTiming.markThreshold()>0 ? handTiming.markThreshold() :
      (dotMs * 2.0f + (cycleTimingReady && !weakActive ? edgeBiasMs : 0.0f));
  if (guentherActive() && cycleTimingReady && guentherTiming.ready()) {
    // During the 49-pulse Guenther acquisition, keep more of the proven modern
    // threshold. Once fully acquired, the exact thesis boundary gets the strong
    // majority vote.
    const float gBlend = guentherTiming.fullyAcquired() ? 0.78f : 0.55f;
    cutoff = gBlend * guentherTiming.markBoundary() + (1.0f - gBlend) * cutoff;
  }
  if (!weakActive && adaptiveLearner.markReady()) {
    const float learned = adaptiveLearner.markThresholdRatio() * dotMs;
    // HAND-SENT already has its own fast local timing learner, so persistent
    // learning is blended more gently there.
    const float blend = adaptiveBlend(adaptiveLearner.markQuality(), handTimingActive() ? 0.35f : 0.60f);
    cutoff += blend * (learned - cutoff);
  }
  const bool dash = durationMs > cutoff;
  appendElement(dash ? '-' : '.');
  if (guentherActive() && guentherMarkCount < 16) {
    const float confidence = learningConfidenceNow();
    previousMarkConfidence = confidence;
    const size_t slot = guentherMarkCount;
    guentherMarks[slot] = durationMs;
    guentherGaps[slot] = 0.0f;
    guentherMarkConfidence[slot] = confidence;
    ++guentherMarkCount;
    const bool accepted = guentherTiming.observeMark(durationMs, confidence);
    CW_BENCH_TRACE_MARK(dspSampleCounter, durationMs, confidence, cutoff, dash, accepted);
  }
  if((weakActive || handTimingActive()) && weakMarkCount<16)weakMarks[weakMarkCount++]=durationMs;
  if(!weakActive && learningMarkCount<16)learningMarks[learningMarkCount++]=durationMs;

  // Learn sending speed from both dots and dashes, but use a robust recent
  // timing history rather than allowing each individual mark to move WPM.
  const float measuredDot = dash ? durationMs / 3.0f : durationMs;
  if(!weakActive && !cycleTimingReady) addTimingMeasurement(measuredDot);

  characterGapHandled = false;
  wordGapHandled = false;
}

void handleStateTransition(bool newState) {
  acquisitionLastEdge = acquisitionSamples;
  const uint64_t nowSample = dspSampleCounter;
  const uint64_t durationSamples = nowSample - stateStartSample;
  const float durationMs = (1000.0f * static_cast<float>(durationSamples)) /
                           static_cast<float>(CWDecoder::DSP_SAMPLE_RATE);

  // Ignore sub-dot impulses. In HAND-SENT mode this is active even when the
  // optional FADING ASSIST UI switch is off: a pulse shorter than about 0.4 dot
  // is far more likely contact bounce/noise than an intentional Morse element.
  // Restore the preceding gap so the rejected click cannot split a word.
  if((handTimingActive() || guentherActive()) && keyDown && !newState && durationMs<dotMs*.4f) {
    keyDown=false;stateStartSample=precedingGapStart;candidateSamples=0;
    previousRiseSample=0;previousMarkMs=0;previousMarkConfidence=0;
    return;
  }
  if(!keyDown && newState)precedingGapStart=stateStartSample;
  if (guentherActive() && !keyDown && newState) {
    // A space contains no tone, so its teaching confidence comes mainly from
    // the clean mark that preceded it. Requiring a live tone during the gap
    // would prevent the Guenther space averages from ever learning.
    const float confidence = fmaxf(learningConfidenceNow(), previousMarkConfidence * 0.92f);
    const float previous = guentherMarkCount > 0 ?
        guentherMarks[guentherMarkCount - 1] : previousMarkMs;
    const bool previousDash = guentherTiming.classifyDash(previous);
    const float symbolBoundary = guentherTiming.symbolBoundaryAfter(previous, previousDash);
    if (characterGapHandled) {
      guentherTiming.observeCharacterGap(durationMs, confidence);
      guentherTiming.observeNonSymbolGapAfter(durationMs, previous, previousDash, confidence);
      CW_BENCH_TRACE_GAP(dspSampleCounter, durationMs, confidence,
                         guentherTiming.wordBoundaryAfter(previous, previousDash), "CHAR/WORD");
    } else if (symbolLength > 0) {
      guentherTiming.observeSymbolGap(durationMs, confidence);
      if (guentherMarkCount > 0 && guentherMarkCount <= 16)
        guentherGaps[guentherMarkCount - 1] = durationMs;
      CW_BENCH_TRACE_GAP(dspSampleCounter, durationMs, confidence,
                         symbolBoundary, "SYMBOL");
    }
  }
  if (!weakActive) {
    if(handTimingActive() && !keyDown && newState && cycleTimingReady)handTiming.observeGap(durationMs,dotMs);
    if(adaptiveLearningActive && !keyDown && newState && cycleTimingReady)
      adaptiveLearner.observeGap(durationMs,dotMs,learningConfidenceNow());
    if (keyDown && !newState) previousMarkMs=durationMs;
    else if (!keyDown && newState) {
      if(previousRiseSample>0)learnCycle((nowSample-previousRiseSample)/12.0f,previousMarkMs);
      previousRiseSample=nowSample;
    }
  }

  if (keyDown && !newState) {
    if(handTimingActive() && durationMs>fmaxf(800.0f,dotMs*7.0f)) {
      symbolLength=0;symbolBuffer[0]=0;weakMarkCount=0;learningMarkCount=0;previousRiseSample=0;
    } else if (!weakActive || durationMs >= fmaxf(16.0f,dotMs*0.35f)) handleMark(durationMs);
  } else if (weakActive && !keyDown && newState && symbolLength>0 && !characterGapHandled) {
    if(durationMs>=MIN_DOT_MS && durationMs<=dotMs*1.65f) {
      // Intra-element gaps reveal dot duration even when the first mark was a
      // dash. Reclassify the buffered marks when the character closes.
      dotMs=clampf(dotMs+0.5f*(durationMs-dotMs),MIN_DOT_MS,MAX_DOT_MS);
      displayDotMs += 0.15f*(dotMs-displayDotMs);
    }
  } else if (!weakActive && !cycleTimingReady && !keyDown && newState && timingHistoryCount >= 5 &&
             symbolLength > 0 && !characterGapHandled) {
    // V1.12 WPM accuracy improvement:
    // A narrow CW filter plus hysteresis tends to make measured key-down marks
    // slightly short (rising threshold crossed late, falling threshold crossed
    // early).  The 1-unit gap between elements is biased in the opposite
    // direction.  Learn from both so the two edge-delay errors largely cancel.
    //
    // Only accept a gap that is close to one current dot.  Character and word
    // gaps are deliberately rejected and continue to be handled below by the
    // normal Morse spacing logic.
    const float reference = robustTimingEstimate();
    if (durationMs >= reference * 0.55f && durationMs <= reference * 1.65f) {
      addTimingMeasurement(durationMs);
    }
  }

  keyDown = newState;
  stateStartSample = nowSample;
  candidateSamples = 0;
}

float goertzelPower(const float *data, size_t count, float coeff) {
  float s0 = 0.0f;
  float s1 = 0.0f;
  float s2 = 0.0f;
  for (size_t i = 0; i < count; ++i) {
    s0 = data[i] + coeff * s1 - s2;
    s2 = s1;
    s1 = s0;
  }
  float power = s1 * s1 + s2 * s2 - coeff * s1 * s2;
  return power > 0.0f ? power : 0.0f;
}

void analyzeSpectrum() {
  if (spectrumFilled < SPECTRUM_WINDOW) return;

  // Ring -> contiguous Hann-windowed buffer.
  for (size_t i = 0; i < SPECTRUM_WINDOW; ++i) {
    const size_t idx = (spectrumWrite + i) % SPECTRUM_WINDOW;
    spectrumWindow[i] = spectrumRing[idx] * hannWindow[i];
  }

  size_t peakIndex = 0;
  float peakDb = -160.0f;

  for (size_t b = 0; b < CWDecoderState::kSpectrumBins; ++b) {
    const float p = goertzelPower(spectrumWindow, SPECTRUM_WINDOW, goertzelCoeff[b]);
    const float amp = (2.0f * sqrtf(p)) / static_cast<float>(SPECTRUM_WINDOW);
    const float db = toDbfs(amp);
    spectrumDb[b] = db;
    if (db > peakDb) {
      peakDb = db;
      peakIndex = b;
    }
  }

  // Median bin level is a robust estimate of the spectral noise floor.
  float sorted[CWDecoderState::kSpectrumBins];
  memcpy(sorted, spectrumDb, sizeof(sorted));
  for (size_t i = 1; i < CWDecoderState::kSpectrumBins; ++i) {
    float v = sorted[i];
    size_t j = i;
    while (j > 0 && sorted[j - 1] > v) {
      sorted[j] = sorted[j - 1];
      --j;
    }
    sorted[j] = v;
  }
  const float medianDb = sorted[CWDecoderState::kSpectrumBins / 2];
  spectralSnrDb = clampf(peakDb - medianDb, 0.0f, 60.0f);

  // V1.3 display spectrum is normalized relative to the local CW-band floor.
  // This gives a cleaner tuning instrument than a full-scale absolute dB plot.
  for (size_t b = 0; b < CWDecoderState::kSpectrumBins; ++b) {
    const float relDb = spectrumDb[b] - medianDb;
    const float normalized = clampf(6.0f + relDb * 3.2f, 2.0f, 100.0f);
    spectrumDisplay[b] = static_cast<uint8_t>(normalized + 0.5f);
  }

  bool localAuto = true;
  uint16_t localAutoToneResponseMs = 500;
  portENTER_CRITICAL(&configMux);
  localAuto = autoTone;
  localAutoToneResponseMs = requestedAutoToneResponseMs;
  portEXIT_CRITICAL(&configMux);

  // Release a stale weak AUTO lock. Previously this latch never expired:
  // a different startup peak could leave keying disabled until RELOCK.
  if (weakActive && localAuto && weakToneLocked &&
      dspSampleCounter - weakLastToneSample >= 3ULL * CWDecoder::DSP_SAMPLE_RATE) {
    weakToneLocked = false;
    weakCandidateHits = 0;
  }

  if (!weakActive && normalToneLocked &&
      dspSampleCounter-normalLastToneSample >= 3ULL*CWDecoder::DSP_SAMPLE_RATE) {
    normalToneLocked = false;
    normalCandidateHits = 0;
  }

  ++spectrumSequence;
  measuredToneValid = false;
  if (spectralSnrDb >= 5.0f && peakDb > -85.0f) {
    float refined = searchMin() + static_cast<float>(peakIndex) * searchStep();

    // Parabolic peak interpolation in dB gives a smoother frequency estimate.
    if (peakIndex > 0 && peakIndex + 1 < CWDecoderState::kSpectrumBins) {
      const float y1 = spectrumDb[peakIndex - 1];
      const float y2 = spectrumDb[peakIndex];
      const float y3 = spectrumDb[peakIndex + 1];
      const float denom = y1 - 2.0f * y2 + y3;
      if (fabsf(denom) > 0.001f) {
        const float delta = clampf(0.5f * (y1 - y3) / denom, -0.5f, 0.5f);
        refined += delta * searchStep();
      }
    }

    // Keep the independent frequency measurement for the tuning guide.
    // AUTO detector frequency is separately qualified and held below.
    refined = clampf(refined, searchMin(), searchMax());
    measuredToneHz = refined;
    measuredToneValid = spectralSnrDb >= 8.0f && peakIndex > 0 &&
        peakIndex + 1 < CWDecoderState::kSpectrumBins;
    if (!weakActive && localAuto) {
      if (spectralSnrDb >= 8.0f) {
        if (!normalToneLocked) {
          if (fabsf(refined-normalCandidateHz) <= 12.0f) ++normalCandidateHits;
          else {normalCandidateHz=refined;normalCandidateHits=1;}
          if (normalCandidateHits >= 3) {
            // Reset for initial acquisition or a different station. Returning
            // to the same tone after a quiet gap retains learned Morse timing.
            if (!cycleTimingReady || fabsf(refined-detectorToneHz)>20.0f)
              resetInternal(true);
            detectorToneHz = spectrumPeakHz = refined;
            normalToneLocked = true;
            normalLastToneSample = dspSampleCounter;
          }
        } else if (fabsf(refined-detectorToneHz) <= 20.0f) {
          // V1.93: user-selectable AUTO TONE response. Keep initial acquisition
          // fast so the beginning of a transmission is not lost; once locked,
          // use a first-order time constant to avoid visibly chasing every
          // 20 ms spectral estimate. 150 ms closely matches the old response.
          const float tau = fmaxf(0.150f, static_cast<float>(localAutoToneResponseMs) / 1000.0f);
          const float hopSeconds = static_cast<float>(SPECTRUM_HOP) /
                                   static_cast<float>(CWDecoder::DSP_SAMPLE_RATE);
          const float followAlpha = 1.0f - expf(-hopSeconds / tau);
          detectorToneHz += followAlpha*(refined-detectorToneHz);
          spectrumPeakHz = detectorToneHz;
          normalLastToneSample = dspSampleCounter;
        }
      } else normalCandidateHits=0;
    } else if (weakActive && spectralSnrDb >= 8.0f) {
      if (!localAuto) {
        if(fabsf(refined-detectorToneHz)<25.0f) {
          if(++weakCandidateHits>=2)weakLastToneSample=dspSampleCounter;
        } else weakCandidateHits=0;
      } else if (!weakToneLocked) {
        if (fabsf(refined-weakCandidateHz)<20) ++weakCandidateHits;
        else { weakCandidateHz=refined; weakCandidateHits=1; }
        if (weakCandidateHits >= 5) {
          detectorToneHz=refined; spectrumPeakHz=refined;
          weakToneLocked=true; weakLastToneSample=dspSampleCounter;
          // Retain the noise history collected during acquisition.
        }
      } else if (fabsf(refined-detectorToneHz)<18.0f) {
        // Small, slow corrections only. Hold the station through key-up gaps;
        // a distant noise peak or stronger neighbour cannot drag the lock away.
        detectorToneHz += 0.08f*(refined-detectorToneHz);
        spectrumPeakHz=detectorToneHz;
        weakLastToneSample=dspSampleCounter;
      }
    }
  }
  if (!weakActive && (spectralSnrDb<8.0f || peakDb<=-85.0f)) normalCandidateHits=0;
  if(weakActive && (spectralSnrDb<8.0f || peakDb<=-85.0f))weakCandidateHits=0;
}

void publishState() {
  CWDecoderState snapshot;
  snapshot.running = running;
  snapshot.measuredToneHz = measuredToneHz;
  snapshot.measuredToneValid = measuredToneValid;
  snapshot.spectrumSequence = spectrumSequence;
  snapshot.weakSignal = weakActive;
  snapshot.toneLocked = weakActive ? weakToneLocked : normalToneLocked;
  snapshot.spectrumMinHz = searchMin();
  snapshot.spectrumMaxHz = searchMax();

  portENTER_CRITICAL(&configMux);
  snapshot.autoTone = autoTone;
  snapshot.inputChannel = selectedChannel;
  snapshot.filterBandwidthHz = selectedFilterBandwidthHz;
  portEXIT_CRITICAL(&configMux);

  if (weakActive) snapshot.filterBandwidthHz = 24; // +/-12 Hz baseband cutoff
  snapshot.keyDown = keyDown;
  snapshot.toneHz = detectorToneHz;
  snapshot.peakHz = spectrumPeakHz;
  snapshot.wpm = 1200.0f / displayDotMs;
  snapshot.signalDbfs = toDbfs(signalEnvelope);
  snapshot.noiseDbfs = toDbfs(noiseEnvelope);
  snapshot.snrDb = clampf(20.0f * log10f((signalEnvelope + 1.0f) /
                                          (noiseEnvelope + 1.0f)), 0.0f, 60.0f);
  snapshot.spectralSnrDb = spectralSnrDb;
  snapshot.confidence = clampf((snapshot.snrDb - 2.0f) * 5.0f +
                               snapshot.spectralSnrDb * 1.5f, 0.0f, 100.0f);
  snapshot.adaptiveLearning = adaptiveLearningActive;
  snapshot.learningApplied = !weakActive && adaptiveLearner.ready();
  snapshot.learningQuality = adaptiveLearner.quality();
  snapshot.learningSamples = adaptiveLearner.acceptedSamples();
  snapshot.learningRevision = adaptiveLearner.revision();
  snapshot.learnedMarkThresholdRatio = adaptiveLearner.markThresholdRatio();
  snapshot.learnedLetterGapRatio = adaptiveLearner.letterGapRatio();
  snapshot.handTimingReady = guentherTiming.ready();
  snapshot.handTimingFullyAcquired = guentherTiming.fullyAcquired();
  snapshot.handAcquisitionStage = static_cast<uint8_t>(guentherTiming.acquisitionStage());
  snapshot.handSendingStyle = static_cast<uint8_t>(guentherTiming.sendingStyle());
  snapshot.handTimingSamples = guentherTiming.markSamples();
  snapshot.handRejectedOutliers = guentherTiming.rejectedOutliers();
  snapshot.handRejectedLowConfidence = guentherTiming.rejectedLowConfidence();
  snapshot.handCorrections = guentherCorrections;
  snapshot.handHypothesisCorrections = guentherHypothesisCorrections;
  snapshot.decodedCharacters = decodedCharacters;

  strncpy(snapshot.currentMorse, symbolBuffer, sizeof(snapshot.currentMorse) - 1);
  strncpy(snapshot.lastMorse, lastMorse, sizeof(snapshot.lastMorse) - 1);
  strncpy(snapshot.decodedText, decodedText, sizeof(snapshot.decodedText) - 1);
  memcpy(snapshot.spectrum, spectrumDisplay, sizeof(snapshot.spectrum));

  portENTER_CRITICAL(&stateMux);
  published = snapshot;
  portEXIT_CRITICAL(&stateMux);
}

void processDspSample(float x) {
  ++dspSampleCounter;
  ++acquisitionSamples;

  // First-order DC blocker. Corner is comfortably below any CW pitch.
  const float hp = x - previousInput + 0.995f * hpState;
  previousInput = x;
  hpState = hp;

  spectrumRing[spectrumWrite] = hp;
  spectrumWrite = (spectrumWrite + 1) % SPECTRUM_WINDOW;
  if (spectrumFilled < SPECTRUM_WINDOW) ++spectrumFilled;
  if (++samplesSinceSpectrum >= SPECTRUM_HOP) {
    samplesSinceSpectrum = 0;
    analyzeSpectrum();
    if (measuredToneValid) {
      if (fabsf(measuredToneHz-acquisitionToneHz) <= 15.0f) {
        if (acquisitionToneHits < 25) ++acquisitionToneHits;
      } else acquisitionToneHits = 1;
      acquisitionToneHz = measuredToneHz;
      if (acquisitionToneHits >= 5) acquisitionLastTone = acquisitionSamples;
    } else if (acquisitionSamples-acquisitionLastTone > CWDecoder::DSP_SAMPLE_RATE) {
      acquisitionToneHits = 0;
    }
  }

  bool localAuto = true;
  float localManualTone = 700.0f;
  float localDetectorAlpha = 0.02073f;
  uint16_t localBandwidth=40;
  portENTER_CRITICAL(&configMux);
  localAuto = autoTone;
  localManualTone = manualToneHz;
  localDetectorAlpha = detectorAlpha;
  localBandwidth=selectedFilterBandwidthHz;
  portEXIT_CRITICAL(&configMux);

  if (!localAuto) {
    normalToneLocked = false;
    normalCandidateHits = 0;
    if (weakActive && fabsf(detectorToneHz-localManualTone)>0.1f) weakDetector.reset();
    detectorToneHz = localManualTone;
    if (weakActive) { spectrumPeakHz=localManualTone; weakToneLocked=true; }
  }

  // V1.3 narrow complex CW detector centered on the selected pitch.
  // Two cascaded I/Q low-pass sections are used after the mixer.  Each section
  // has a corner of about 40 Hz, giving useful CW selectivity while preserving
  // normal keying edges.  A tone 100 Hz away is now strongly rejected instead
  // of still passing through the old broad detector.
  const float phaseInc = 2.0f * PI_F * detectorToneHz /
                         static_cast<float>(CWDecoder::DSP_SAMPLE_RATE);
  phase += phaseInc;
  if (phase >= 2.0f * PI_F) phase -= 2.0f * PI_F;

  const float mixI = hp * cosf(phase);
  const float mixQ = hp * sinf(phase);

  if (weakActive) {
    weakDetector.process(mixI,mixQ);
    envelope=weakDetector.envelope;
    noiseEnvelope=weakDetector.noise;
    signalEnvelope=weakDetector.signal;
    const bool desired=weakToneLocked && weakDetector.ready() && weakLastToneSample>0 &&
        dspSampleCounter-weakLastToneSample < CWDecoder::DSP_SAMPLE_RATE &&
        envelope > (keyDown ? weakDetector.off : weakDetector.on);
    // Symmetric persistence rejects short noise bursts and bridges short fades.
    const size_t persistence=size_t(clampf(dotMs*0.15f,8.0f,24.0f)*12.0f);
    if (desired != keyDown) {
      if (candidateState != desired) { candidateState=desired;candidateSamples=1; }
      else if (++candidateSamples>=persistence) handleStateTransition(desired);
    } else {candidateSamples=0;candidateState=keyDown;}
  } else {
  iLp1 += localDetectorAlpha * (mixI - iLp1);
  qLp1 += localDetectorAlpha * (mixQ - qLp1);
  iLp2 += localDetectorAlpha * (iLp1 - iLp2);
  qLp2 += localDetectorAlpha * (qLp1 - qLp2);
  envelope = 2.0f * sqrtf(iLp2 * iLp2 + qLp2 * qLp2);

  // Track the floor quickly downward but extremely slowly upward so a long CW
  // mark is not mistaken for a new noise floor.
  const float noiseAlpha = envelope < noiseEnvelope ? 0.012f : 0.000025f;
  noiseEnvelope += noiseAlpha * (envelope - noiseEnvelope);
  if (noiseEnvelope < 1.0f) noiseEnvelope = 1.0f;

  if (keyDown) {
    signalEnvelope += 0.004f * (envelope - signalEnvelope);
  } else if (envelope > signalEnvelope) {
    signalEnvelope += 0.001f * (envelope - signalEnvelope);
  } else {
    signalEnvelope += 0.0002f * (envelope - signalEnvelope);
  }
  if (signalEnvelope < noiseEnvelope + 1.0f) signalEnvelope = noiseEnvelope + 1.0f;

  // Fading assist: independently measured off-tone noise plus recent mark
  // level. Narrow filters need a higher release fraction to resolve the
  // shortest gaps at 50 WPM. OFF retains the original normal detector.
  const bool recentTone=acquisitionLastTone>0 &&
      acquisitionSamples-acquisitionLastTone < CWDecoder::DSP_SAMPLE_RATE;
  const bool fadeHelp=fadeAssistActive && recentTone;
  if(fadeAssistActive) fadingTracker.process(mixI,mixQ,envelope,localDetectorAlpha,localBandwidth);
  const float fadeNoise=sqrtf(fadingTracker.noisePower);
  const float fadeOffFraction=clampf(6.0f/localBandwidth,0.10f,0.20f);
  const float thresholdOn = fadeAssistActive && fadingTracker.ready() ?
      fmaxf(fadeHelp?6.0f:18.0f,fmaxf(fadeNoise*1.5f,fadingTracker.peak*(handTimingActive()?0.40f:fadeOffFraction*1.5f))) : fmaxf(18.0f, noiseEnvelope*4.0f);
  const float thresholdOff = fadeAssistActive && fadingTracker.ready() ?
      fmaxf(fadeHelp?4.0f:12.0f,fmaxf(fadeNoise*1.0f,fadingTracker.peak*(handTimingActive()?0.30f:fadeOffFraction))) : fmaxf(12.0f, noiseEnvelope*2.2f);
  const size_t normalPersistence=fadeAssistActive ?
      size_t(clampf(dotMs*0.20f,3.0f,10.0f)*12.0f):DEBOUNCE_SAMPLES;
  // Instantaneous strong marks can open the gate immediately after a long
  // pause; waiting for history alone would clip the beginning of slow dots.
  const bool fadeSignal = !fadeAssistActive || (fadingTracker.ready() && fmaxf(fadingTracker.peak,envelope)>fadeNoise*3.0f);
  const bool desired = fadeSignal && (keyDown ? (envelope > thresholdOff) : (envelope > thresholdOn));

  if (desired != keyDown) {
    if (candidateState != desired) {
      candidateState = desired;
      candidateSamples = 1;
    } else if (++candidateSamples >= normalPersistence) {
      handleStateTransition(desired);
    }
  } else {
    candidateSamples = 0;
    candidateState = keyDown;
  }

  }

  // Decode character and word gaps while the key remains up.
  if (!keyDown) {
    const uint64_t gapSamples = dspSampleCounter - stateStartSample;
    const float gapMs = (1000.0f * static_cast<float>(gapSamples)) /
                        static_cast<float>(CWDecoder::DSP_SAMPLE_RATE);

    float characterGapMs = weakActive ? 1.75f*dotMs :
        (cycleTimingReady ? 2.0f*dotMs-edgeBiasMs : 2.25f*dotMs);
    if (handTimingActive()) {
      characterGapMs = handTiming.letterThreshold()>0 ?
          fminf(handTiming.letterThreshold(),2.0f*dotMs-edgeBiasMs) :
          fmaxf(dotMs*0.9f,1.5f*dotMs-edgeBiasMs);
    }
    if (guentherActive() && cycleTimingReady && guentherTiming.ready() && symbolLength > 0) {
      const float previous = guentherMarkCount > 0 ?
          guentherMarks[guentherMarkCount - 1] : previousMarkMs;
      const bool previousDash = guentherMarkCount > 0 ?
          guentherTiming.classifyDash(previous) : (symbolBuffer[symbolLength - 1] == '-');
      const float guentherGap = guentherTiming.symbolBoundaryAfter(previous, previousDash);
      const float gBlend = guentherTiming.fullyAcquired() ? 0.86f : 0.58f;
      characterGapMs = gBlend * guentherGap + (1.0f - gBlend) * characterGapMs;
      characterGapMs = clampf(characterGapMs, 0.72f*dotMs, 2.40f*dotMs);
    }
    if (!weakActive && adaptiveLearner.gapReady() && activeCwType != 2) {
      const float learned = adaptiveLearner.letterGapRatio() * dotMs;
      const float blend = adaptiveBlend(adaptiveLearner.gapQuality(), handTimingActive() ? 0.30f : 0.55f);
      characterGapMs += blend * (learned - characterGapMs);
      characterGapMs = clampf(characterGapMs, 1.15f*dotMs, 3.10f*dotMs);
    }
    if (!characterGapHandled && symbolLength > 0 && gapMs >= characterGapMs) {
      finishCharacter();
      characterGapHandled = true;
    }

    float wordGapMs=cycleTimingReady && !weakActive ? 5.0f*dotMs-edgeBiasMs : 5.5f*dotMs;
    // In HAND-SENT mode, once enough non-symbol spaces have been observed,
    // blend in Guenther's adaptive CHARACTER/WORD boundary. This remains
    // language-independent; the thesis's English last-letter heuristic is not used.
    if (guentherActive() && cycleTimingReady && guentherTiming.fullyAcquired() &&
        guentherTiming.cwSpaceReady()) {
      const float previous = previousMarkMs;
      const bool previousDash = guentherTiming.classifyDash(previous);
      const float gWord = guentherTiming.wordBoundaryAfter(previous, previousDash);
      // Guenther's original system had a real-time C-W adjustment and an
      // English-language correction stage. We intentionally omit the language
      // stage, so use the learned C-W boundary as a conservative advisor rather
      // than allowing it to pull amateur-radio word spacing too short.
      wordGapMs = 0.35f * gWord + 0.65f * wordGapMs;
      wordGapMs = clampf(wordGapMs, 3.6f*dotMs, 7.2f*dotMs);
    }
    // Farnsworth stretches letter/word spacing, not the elements within letters.
    if(!weakActive && activeCwType==2)
      wordGapMs=(cycleTimingReady?5.0f:5.5f)*dotMs*(activeSpacing/10.0f)-(cycleTimingReady?edgeBiasMs:0.0f);
    if (characterGapHandled && !wordGapHandled && gapMs >= wordGapMs) {
      appendDecoded(' ');
      wordGapHandled = true;
    }
  }

  if (++publishDivider >= 120) { // 100 UI-state updates per second max
    publishDivider = 0;
    publishState();
  }
}

void resetInternal(bool preserveText = false) {
  portENTER_CRITICAL(&configMux);
  appliedInputGain = selectedInputTrimLinear;
  portEXIT_CRITICAL(&configMux);
  decimSum = 0;
  decimCount = 0;
  previousInput = 0.0f;
  hpState = 0.0f;
  memset(spectrumRing, 0, sizeof(spectrumRing));
  memset(spectrumWindow, 0, sizeof(spectrumWindow));
  memset(spectrumDb, 0, sizeof(spectrumDb));
  memset(spectrumDisplay, 0, sizeof(spectrumDisplay));
  spectrumWrite = spectrumFilled = samplesSinceSpectrum = 0;

  measuredToneValid = false;
  normalToneLocked = false;
  normalCandidateHits = 0;
  normalLastToneSample = 0;
  detectorToneHz = 700.0f;
  spectrumPeakHz = 700.0f;
  phase = 0.0f;
  iLp1 = qLp1 = iLp2 = qLp2 = envelope = 0.0f;
  fadingTracker.reset();
  noiseEnvelope = 20.0f;
  signalEnvelope = 30.0f;
  spectralSnrDb = 0.0f;

  keyDown = false;
  candidateState = false;
  candidateSamples = 0;
  dspSampleCounter = 0;
  stateStartSample = 0;
  handTiming.reset();
  cycleCount=cycleWrite=0;previousRiseSample=0;
  previousMarkMs=previousMarkConfidence=edgeBiasMs=0;cycleTimingReady=false;
  dotMs = weakActive ? 100.0f : (activeCwType==3?120.0f:(activeCwType==4?30.0f:DEFAULT_DOT_MS));
  displayDotMs = dotMs;
  guentherTiming.reset(dotMs);
  guentherMarkCount = 0;
  memset(guentherMarks, 0, sizeof(guentherMarks));
  memset(guentherGaps, 0, sizeof(guentherGaps));
  memset(guentherMarkConfidence, 0, sizeof(guentherMarkConfidence));
  weakToneLocked=false; weakCandidateHits=0; weakLastToneSample=0;
  weakDetector.reset(); weakDetector.setCutoff(12.0f);
  memset(timingHistory, 0, sizeof(timingHistory));
  timingHistoryCount = 0;
  timingHistoryWrite = 0;
  characterGapHandled = false;
  wordGapHandled = false;

  symbolLength = 0;
  weakMarkCount = 0;
  learningMarkCount = 0;
  symbolBuffer[0] = '\0';
  lastMorse[0] = '\0';
  if (!preserveText) {
    decodedText[0] = '\0';
    decodedCharacters = 0;
  }
  publishDivider = 0;
}

void serviceStartupRecovery() {
  bool localAuto;
  portENTER_CRITICAL(&configMux);
  localAuto = autoTone;
  portEXIT_CRITICAL(&configMux);
  if (!localAuto) return;
  const uint64_t rate = CWDecoder::DSP_SAMPLE_RATE;
  if (acquisitionComplete || automaticRelocks >= 3) return;
  // Six seconds without decoded text AND no keying edges for two seconds.
  // A recent consistent peak is required; silence and normal CW gaps do not
  // trigger resets. At most three attempts, only until first valid character.
  if (acquisitionSamples-acquisitionAttemptStart < 6*rate ||
      acquisitionSamples-acquisitionLastEdge < 2*rate ||
      acquisitionToneHits < 5 || acquisitionLastTone == 0 ||
      acquisitionSamples-acquisitionLastTone > rate) return;
  ++automaticRelocks;
  acquisitionAttemptStart = acquisitionSamples;
  acquisitionLastTone = 0;
  acquisitionToneHits = 0;
  resetInternal(true);
  publishState();
  Serial.printf("[CW START] automatic RELOCK %u/3: tone present, no decoding\n", automaticRelocks);
}

} // namespace

namespace CWDecoder {

void begin(uint32_t inputSampleRate) {
  acquisitionSamples = acquisitionAttemptStart = acquisitionLastTone = acquisitionLastEdge = 0;
  acquisitionToneHits = automaticRelocks = 0;
  acquisitionComplete = false;
  portENTER_CRITICAL(&configMux);
  activeCwType=requestedCwType;activeSpacing=requestedSpacing;fadeAssistActive=requestedFadeAssist;
  adaptiveLearningActive=requestedAdaptiveLearning;
  const float seedMark=requestedLearnMarkRatio, seedGap=requestedLearnGapRatio;
  const uint8_t seedQuality=requestedLearnQuality;
  portEXIT_CRITICAL(&configMux);
  adaptiveLearner.seed(seedMark, seedGap, seedQuality);
  inputRate = inputSampleRate;
  decimation = inputRate / DSP_SAMPLE_RATE;
  if (decimation == 0) decimation = 1;

  for (size_t i = 0; i < SPECTRUM_WINDOW; ++i) {
    hannWindow[i] = 0.5f - 0.5f * cosf((2.0f * PI_F * static_cast<float>(i)) /
                                      static_cast<float>(SPECTRUM_WINDOW - 1));
  }
  for (size_t b = 0; b < CWDecoderState::kSpectrumBins; ++b) {
    const float freq = SPECTRUM_MIN_HZ + static_cast<float>(b) * SPECTRUM_STEP_HZ;
    const float omega = 2.0f * PI_F * freq / static_cast<float>(DSP_SAMPLE_RATE);
    goertzelCoeff[b] = 2.0f * cosf(omega);
  }

  resetInternal();
  running = true;
  publishState();

  Serial.printf("CW Decoder: %lu Hz input -> %lu Hz DSP (/%lu), spectrum %.0f..%.0f Hz\n",
                static_cast<unsigned long>(inputRate),
                static_cast<unsigned long>(DSP_SAMPLE_RATE),
                static_cast<unsigned long>(decimation),
                SPECTRUM_MIN_HZ, SPECTRUM_MAX_HZ);
}

void reconfigureInputSampleRate(uint32_t inputSampleRate) {
  if (inputSampleRate != 48000U && inputSampleRate != 96000U) return;

  inputRate = inputSampleRate;
  decimation = inputRate / DSP_SAMPLE_RATE;
  if (decimation == 0) decimation = 1;

  // A sample-rate change invalidates the decimator/filter history and any
  // partially measured mark/gap. Keep the transcript and all user settings.
  acquisitionSamples = acquisitionAttemptStart = acquisitionLastTone = acquisitionLastEdge = 0;
  acquisitionToneHits = automaticRelocks = 0;
  acquisitionComplete = false;
  resetInternal(true);
  running = true;
  publishState();

  Serial.printf("CW Decoder: live input change -> %lu Hz input -> %lu Hz DSP (/%lu), transcript preserved\n",
                static_cast<unsigned long>(inputRate),
                static_cast<unsigned long>(DSP_SAMPLE_RATE),
                static_cast<unsigned long>(decimation));
}

void processI2S32(const int32_t *slots, size_t frameCount) {
  if (!running || !slots || frameCount == 0) return;

  portENTER_CRITICAL(&configMux);
  const bool doClear = clearRequested;
  const bool doRelock = relockRequested;
  if (doRelock) relockInProgress = true;
  const bool desiredWeak = requestedWeak;
  const bool fadingChanged=fadeAssistActive!=requestedFadeAssist;
  fadeAssistActive=requestedFadeAssist;
  adaptiveLearningActive=requestedAdaptiveLearning;
  const bool doResetLearning=resetAdaptiveLearningRequested;
  resetAdaptiveLearningRequested=false;
  const uint8_t desiredType=requestedCwType, desiredSpacing=requestedSpacing;
  clearRequested = relockRequested = false;
  portEXIT_CRITICAL(&configMux);
  if(doResetLearning) {
    adaptiveLearner.reset();
    learningMarkCount=0;
    Serial.println("[LEARNING] adaptive timing profile reset");
  }
  if(fadingChanged) {fadingTracker.reset();handTiming.reset();}
  const bool typeChanged=desiredType!=activeCwType || desiredSpacing!=activeSpacing;
  activeCwType=desiredType;activeSpacing=desiredSpacing;
  if (desiredWeak != weakActive) {
    weakActive=desiredWeak;
    configureSpectrum();
    resetInternal(true);
  } else if (doRelock || typeChanged) resetInternal(true);
  if (doRelock) {
    acquisitionAttemptStart = acquisitionSamples;
    acquisitionLastTone = 0;
    acquisitionToneHits = 0;
    portENTER_CRITICAL(&configMux);
    relockInProgress = false;
    portEXIT_CRITICAL(&configMux);
  }
  if (doClear) {
    portENTER_CRITICAL(&textMux);
    textRead = textWrite = 0;
    textOverflow = false;
    textClearing = false;
    portEXIT_CRITICAL(&textMux);
    symbolLength = 0;
    weakMarkCount = 0;
    learningMarkCount = 0;
    guentherMarkCount = 0;
    memset(guentherMarks, 0, sizeof(guentherMarks));
    memset(guentherGaps, 0, sizeof(guentherGaps));
    memset(guentherMarkConfidence, 0, sizeof(guentherMarkConfidence));
    symbolBuffer[0] = '\0';
    lastMorse[0] = '\0';
    decodedText[0] = '\0';
    decodedCharacters = 0;
    characterGapHandled = false;
    wordGapHandled = false;
  }

  uint8_t localChannel = 0;
  float localInputTrim = 1.0f;
  portENTER_CRITICAL(&configMux);
  localChannel = selectedChannel;
  localInputTrim = selectedInputTrimLinear;
  portEXIT_CRITICAL(&configMux);

  // Gain changes must not leave the old floor and filter history at a
  // different scale from the new samples. Preserve Morse timing and text.
  if (localInputTrim != appliedInputGain) {
    if (!weakActive && appliedInputGain > 0.0f) {
      const float ratio = localInputTrim / appliedInputGain;
      previousInput *= ratio; hpState *= ratio;
      iLp1 *= ratio; qLp1 *= ratio; iLp2 *= ratio; qLp2 *= ratio;
      envelope *= ratio; noiseEnvelope *= ratio; signalEnvelope *= ratio;
      fadingTracker.scale(ratio);
      for (float &sample : spectrumRing) sample *= ratio;
    }
    appliedInputGain = localInputTrim;
  }

  for (size_t i = 0; i < frameCount; ++i) {
    const int32_t slot = slots[i * 2 + (localChannel ? 1 : 0)];
    decimSum += slotToSample(slot);
    if (++decimCount >= decimation) {
      float sample = (static_cast<float>(decimSum) / static_cast<float>(decimation)) * localInputTrim;
      decimSum = 0;
      decimCount = 0;
      if (sample > 32767.0f) sample = 32767.0f;
      if (sample < -32768.0f) sample = -32768.0f;
      processDspSample(sample);
    }
  }
  serviceStartupRecovery();
}

CWDecoderState getState() {
  CWDecoderState copy;
  portENTER_CRITICAL(&stateMux);
  copy = published;
  portEXIT_CRITICAL(&stateMux);
  return copy;
}

void setFadingAssist(bool enabled) {
  portENTER_CRITICAL(&configMux);requestedFadeAssist=enabled;portEXIT_CRITICAL(&configMux);
}

void setCwType(uint8_t type) {
  portENTER_CRITICAL(&configMux);requestedCwType=type<=4?type:0;portEXIT_CRITICAL(&configMux);
}
void setFarnsworthSpacing(uint8_t tenths) {
  if(tenths!=15 && tenths!=20 && tenths!=30)tenths=20;
  portENTER_CRITICAL(&configMux);requestedSpacing=tenths;portEXIT_CRITICAL(&configMux);
}

void setWeakSignal(bool enabled) {
  portENTER_CRITICAL(&configMux);
  requestedWeak=enabled;
  if (!enabled) manualToneHz=clampf(manualToneHz,SPECTRUM_MIN_HZ,SPECTRUM_MAX_HZ);
  portEXIT_CRITICAL(&configMux);
}
bool weakSignalEnabled() {
  portENTER_CRITICAL(&configMux);
  const bool enabled=requestedWeak;
  portEXIT_CRITICAL(&configMux);
  return enabled;
}

void setAdaptiveLearning(bool enabled) {
  portENTER_CRITICAL(&configMux);
  requestedAdaptiveLearning=enabled;
  portEXIT_CRITICAL(&configMux);
}

bool adaptiveLearningEnabled() {
  portENTER_CRITICAL(&configMux);
  const bool enabled=requestedAdaptiveLearning;
  portEXIT_CRITICAL(&configMux);
  return enabled;
}

void resetAdaptiveLearning() {
  portENTER_CRITICAL(&configMux);
  resetAdaptiveLearningRequested=true;
  requestedLearnMarkRatio=0.0f;
  requestedLearnGapRatio=0.0f;
  requestedLearnQuality=0;
  portEXIT_CRITICAL(&configMux);
}

void setAdaptiveLearningProfile(float markThresholdRatio, float letterGapRatio, uint8_t quality) {
  if (!isfinite(markThresholdRatio) || markThresholdRatio < 1.40f || markThresholdRatio > 2.80f) markThresholdRatio=0.0f;
  if (!isfinite(letterGapRatio) || letterGapRatio < 1.20f || letterGapRatio > 3.40f) letterGapRatio=0.0f;
  if (quality > 100) quality=100;
  portENTER_CRITICAL(&configMux);
  requestedLearnMarkRatio=markThresholdRatio;
  requestedLearnGapRatio=letterGapRatio;
  requestedLearnQuality=quality;
  portEXIT_CRITICAL(&configMux);
}

void setAutoTone(bool enabled) {
  portENTER_CRITICAL(&configMux);
  autoTone = enabled;
  if (!enabled) manualToneHz = detectorToneHz;
  portEXIT_CRITICAL(&configMux);
}

bool autoToneEnabled() {
  portENTER_CRITICAL(&configMux);
  const bool enabled = autoTone;
  portEXIT_CRITICAL(&configMux);
  return enabled;
}

void setAutoToneResponseMs(uint16_t ms) {
  if (ms != 150 && ms != 500 && ms != 1000 && ms != 2000) ms = 500;
  portENTER_CRITICAL(&configMux);
  requestedAutoToneResponseMs = ms;
  portEXIT_CRITICAL(&configMux);
}

uint16_t autoToneResponseMs() {
  portENTER_CRITICAL(&configMux);
  const uint16_t ms = requestedAutoToneResponseMs;
  portEXIT_CRITICAL(&configMux);
  return ms;
}

float manualToneSettingHz() {
  portENTER_CRITICAL(&configMux);
  const float hz = manualToneHz;
  portEXIT_CRITICAL(&configMux);
  return hz;
}

void setManualTone(float hz) {
  portENTER_CRITICAL(&configMux);
  hz = clampf(hz, requestedWeak ? 300.0f : SPECTRUM_MIN_HZ, requestedWeak ? 1000.0f : SPECTRUM_MAX_HZ);
  manualToneHz = hz;
  autoTone = false;
  portEXIT_CRITICAL(&configMux);
}

void adjustManualTone(float deltaHz) {
  float hz;
  portENTER_CRITICAL(&configMux);
  manualToneHz = clampf((autoTone ? detectorToneHz : manualToneHz) + deltaHz,
                        requestedWeak ? 300.0f : SPECTRUM_MIN_HZ, requestedWeak ? 1000.0f : SPECTRUM_MAX_HZ);
  autoTone = false;
  hz = manualToneHz;
  portEXIT_CRITICAL(&configMux);
  (void)hz;
}

void setInputChannel(uint8_t channel) {
  portENTER_CRITICAL(&configMux);
  selectedChannel = channel ? 1 : 0;
  portEXIT_CRITICAL(&configMux);
}

uint8_t inputChannel() {
  portENTER_CRITICAL(&configMux);
  const uint8_t channel = selectedChannel;
  portEXIT_CRITICAL(&configMux);
  return channel;
}


void setInputTrimDb(int8_t db) {
  if (db < -24) db = -24;
  if (db > 12) db = 12;
  const float linear = powf(10.0f, static_cast<float>(db) / 20.0f);
  portENTER_CRITICAL(&configMux);
  selectedInputTrimDb = db;
  selectedInputTrimLinear = linear;
  portEXIT_CRITICAL(&configMux);
  Serial.printf("Decoder input trim: %+d dB (%.3fx)\n", static_cast<int>(db), static_cast<double>(linear));
}

int8_t inputTrimDb() {
  portENTER_CRITICAL(&configMux);
  const int8_t db = selectedInputTrimDb;
  portEXIT_CRITICAL(&configMux);
  return db;
}

void adjustInputTrimDb(int8_t deltaDb) {
  int8_t db = inputTrimDb();
  int16_t next = static_cast<int16_t>(db) + deltaDb;
  if (next < -24) next = -24;
  if (next > 12) next = 12;
  setInputTrimDb(static_cast<int8_t>(next));
}


void setInputLevelPercent(uint8_t percent) {
  if (percent < 1) percent = 1;
  if (percent > 100) percent = 100;
  const float linear = static_cast<float>(percent) / 100.0f;
  portENTER_CRITICAL(&configMux);
  selectedInputLevelPercent = percent;
  selectedInputTrimLinear = linear;
  selectedInputTrimDb = static_cast<int8_t>(lroundf(20.0f * log10f(linear)));
  portEXIT_CRITICAL(&configMux);
  Serial.printf("Decoder input level: %u%% (%.3fx, about %+d dB)\n",
                static_cast<unsigned>(percent), static_cast<double>(linear),
                static_cast<int>(selectedInputTrimDb));
}

uint8_t inputLevelPercent() {
  portENTER_CRITICAL(&configMux);
  const uint8_t percent = selectedInputLevelPercent;
  portEXIT_CRITICAL(&configMux);
  return percent;
}


void setFilterBandwidthHz(uint16_t hz) {
  if (hz != 30 && hz != 40 && hz != 60 && hz != 80 && hz != 120) hz = 40;
  const float alpha = 1.0f - expf((-2.0f * PI_F * static_cast<float>(hz)) /
                                  static_cast<float>(DSP_SAMPLE_RATE));
  portENTER_CRITICAL(&configMux);
  selectedFilterBandwidthHz = hz;
  detectorAlpha = alpha;
  portEXIT_CRITICAL(&configMux);
}

uint16_t filterBandwidthHz() {
  portENTER_CRITICAL(&configMux);
  const uint16_t hz = selectedFilterBandwidthHz;
  portEXIT_CRITICAL(&configMux);
  return hz;
}

size_t readText(char *out, size_t capacity, bool &overflow) {
  size_t n = 0;
  portENTER_CRITICAL(&textMux);
  overflow = textOverflow;
  textOverflow = false;
  while (n < capacity && textRead != textWrite) {
    out[n++] = textQueue[textRead];
    textRead = (textRead + 1) % sizeof(textQueue);
  }
  portEXIT_CRITICAL(&textMux);
  return n;
}

bool relockPending() {
  portENTER_CRITICAL(&configMux);
  const bool pending = relockRequested || relockInProgress;
  portEXIT_CRITICAL(&configMux);
  return pending;
}

void relock() {
  portENTER_CRITICAL(&configMux);
  relockRequested = true;
  portEXIT_CRITICAL(&configMux);
}

void clearText() {
  // Silence the producer immediately until the audio task acknowledges clear.
  portENTER_CRITICAL(&textMux);
  textRead = textWrite = 0;
  textOverflow = false;
  textClearing = true;
  portEXIT_CRITICAL(&textMux);
  portENTER_CRITICAL(&configMux);
  clearRequested = true;
  portEXIT_CRITICAL(&configMux);
}

} // namespace CWDecoder
