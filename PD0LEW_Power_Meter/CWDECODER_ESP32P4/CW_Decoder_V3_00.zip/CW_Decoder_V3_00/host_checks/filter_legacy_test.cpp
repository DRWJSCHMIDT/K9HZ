#include "FilterCalibration.h"
#include <cassert>
#include <cmath>
#include <initializer_list>
#include <cstdio>
int main() {
#ifndef CW_FILTER_LEGACY_BANDWIDTH
#error This test must be built with CW_FILTER_LEGACY_BANDWIDTH
#endif
  for (int fs : {12000,48000,96000}) {
    for (int bw : {30,40,60,80,120}) {
      const double actual=CWFilterCalibration::twoPoleAlphaForFullBandwidth(float(bw),float(fs));
      const double previous=1.0-std::exp(-6.283185307179586*double(bw)/double(fs));
      assert(std::fabs(actual-previous)<1.0e-7);
    }
  }
  puts("PASS: optional build restores original V2.28 filter coefficient");
}
