/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_Encoder.h"

#include "PSWR_Config.h"
#include "PSWR_State.h"

#include <limits.h>

namespace
{
uint32_t lastDetentMs = 0;
uint32_t lastDetentIntervalMs = UINT32_MAX;
}

int16_t encoderTakeSteps(void)
{
  const long raw = Enc.read();
  const long detected = raw / ENCODER_COUNTS_PER_DETENT;

  if (detected == 0)
    return 0;

  // Old/proven behaviour: one accepted encoder movement changes exactly one
  // logical item/value, regardless of how much raw movement accumulated before
  // this service pass.  Then start cleanly from zero for the next movement.
  const int16_t step = (detected > 0) ? 1 : -1;
  Enc.write(0);

  // Keep calibration-only speed timing available.  Normal menus ignore it.
  const uint32_t now = millis();
  if (lastDetentMs != 0)
    lastDetentIntervalMs = now - lastDetentMs;
  else
    lastDetentIntervalMs = UINT32_MAX;

  lastDetentMs = now;


  return step;
}

int16_t encoderCalibrationStepDb10(void)
{
  // A pause always restores fine 0.1 dB control.
  if (lastDetentMs == 0 || (millis() - lastDetentMs) > CAL_ENCODER_FINE_RESET_MS)
    return CAL_ENCODER_FINE_DB10;

  if (lastDetentIntervalMs <= CAL_ENCODER_1DB_INTERVAL_MS)
    return CAL_ENCODER_COARSE_DB10;

  return CAL_ENCODER_FINE_DB10;
}
