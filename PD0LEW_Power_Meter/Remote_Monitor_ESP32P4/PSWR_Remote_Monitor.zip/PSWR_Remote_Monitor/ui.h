#pragma once
#include <Arduino.h>

enum Screen {
    SCR_METER,
    SCR_BACKLIGHT
};

void uiInit();
Screen uiCurrentScreen();
void uiNotifyTouchReleased();
void uiWakeScreen();
void uiHandleScreensaver();
void uiSetScreensaverDelay(int seconds);
void uiShowConnecting(const char* msg);
void uiShowPortalActive(const char* apName);
void uiShowBootHoldProgress(float progress);
void uiRenderAll();
void uiRenderUpdates();
void uiHandleTouch(int x, int y);
void uiShowForecast();
void uiSetForecast(String status, String advice);
void uiUpdateForecastTimer(unsigned long remainingMs);
