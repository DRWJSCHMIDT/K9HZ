/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_MEASUREMENT_H
#define PSWR_MEASUREMENT_H
#include <Arduino.h>
void pswr_service_sampler(void);
void calc_SWR_and_power(void);
void pswr_determine_dBm(void);
void determine_power_pep_pk(void);
double pswr_get_cal_fwd_voltage(void);
double pswr_get_cal_rev_voltage(void);
uint32_t pswr_get_missed_samples(void);
uint32_t pswr_get_adc_read_errors(void);
uint16_t pswr_get_sample_queue_depth(void);
uint16_t pswr_get_sample_queue_high_water(void);
double pswr_get_qualified_net_power_mw(void);

// V3.102 temporary PEP/display diagnostic snapshot. A new snapshot is published only
// after a complete 100 ms measurement block has been finalized. USB printing
// reads this snapshot later from normal loop context, so Serial I/O never runs
// inside the 20 kHz sampling path.
struct PepDebugSnapshot
{
  uint32_t sequence;
  uint32_t capture_tick;
  uint32_t sample_count;
  bool tx_start_event;
  bool tx_end_event;
  bool tx_active;
  bool startup_guard;
  bool trailing_silence;
  bool block_has_rf;
  uint16_t pep_window;
  double block_avg_mw;
  double raw_peak_mw;
  double pk_mw;
  double pep_input_mw;
  double pep_hold_mw;
  double fwd_avg_mw;
  double ref_avg_mw;
  double net_avg_mw;
};

bool pswr_get_pep_debug_snapshot(PepDebugSnapshot &out);
#endif
