#include "AppSettings.cpp"
#include <cassert>
int main(){
 using namespace AppSettings;
 begin();assert(autoTone() && !autoLevel() && !weakSignal() && scopeZoomIndex()==0 && scopeTimeIndex()==1);
 setAutoTone(false);setManualToneHz(351);setAutoLevel(true);setScopeZoomIndex(2);setScopeTimeIndex(2);
 setBrightnessPercent(60);setScreensaverMinutes(5);setFilterBandwidthHz(60);setTextColorIndex(3);setHeadphoneVolumePercent(45);setDecoderInputLevelPercent(7);
 ready=false;begin();
 assert(!autoTone() && autoLevel() && manualToneHz()==351 && scopeZoomIndex()==2 && scopeTimeIndex()==2);
 assert(brightnessPercent()==60 && screensaverMinutes()==5 && filterBandwidthHz()==60 && textColorIndex()==3 && headphoneVolumePercent()==45 && decoderInputLevelPercent()==7);
 setWeakSignal(true);ready=false;begin();assert(weakSignal() && !autoLevel());
 Preferences::data["zoom"]=99;Preferences::data["time"]=99;Preferences::data["mtone"]=NAN;ready=false;begin();
 assert(scopeZoomIndex()==0 && scopeTimeIndex()==1 && manualToneHz()==700);
}
