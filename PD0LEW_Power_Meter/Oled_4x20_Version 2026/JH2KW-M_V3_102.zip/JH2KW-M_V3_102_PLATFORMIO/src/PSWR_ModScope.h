/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef PSWR_MODSCOPE_H
#define PSWR_MODSCOPE_H

#include <Arduino.h>

// 248 samples map directly to the useful horizontal width of the 256x64 OLED.
// Every processed measurement sample is stored for the fastest possible sweep.
constexpr uint16_t MODSCOPE_POINTS = 248;

// Capture one calibrated forward-RF amplitude sample for the display-only scope.
void modscope_capture(double forwardAmplitude);

// Copy the rolling history oldest -> newest. Empty leading history is returned
// as zero so the newest sample always remains at the right edge of the screen.
void modscope_snapshot(float *samples, uint16_t count, float &peakAmplitude);

#endif // PSWR_MODSCOPE_H
