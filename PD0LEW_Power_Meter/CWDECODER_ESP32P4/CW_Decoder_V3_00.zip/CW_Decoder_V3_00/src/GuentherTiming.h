#pragma once

#include <cmath>
#include <cstddef>
#include <cstdint>

// ESP32-P4 implementation of the timing-duration averaging method described by
// Joel A. Guenther, AFIT 1973, "Machine Recognition of Hand-Sent Morse Code
// Using the PDP-12 Computer".  This file is an independent implementation from
// the published thesis equations/flowcharts; no later GPL source is copied.
//
// V2.22 follows the thesis acquisition schedule much more closely:
//   first 16 accepted pulses : 1/2 new sample (Eq. 4.1/4.2)
//   next 33 accepted pulses  : 1/4 new sample (Eq. 4.4/4.5)
//   thereafter               : 1/8 new sample (Eq. 4.6/4.7)
// and uses the published pulse boundary
//   PULSE AVG = DOT AVG / 4 + DASH AVG / 2                 (Eq. 3.2/4.3)
//
// Modern additions are deliberately outside the historical decision equations:
// confidence-gated learning, robust 2-sigma-style outlier rejection, and an
// automatic sender-style estimate used only to choose how tolerant that outlier
// guard should be.  Fixed storage only; safe for the audio task.
class GuentherTiming {
 public:
  enum class SendingStyle : uint8_t { Unknown = 0, StraightKey = 1, Bug = 2, Keyer = 3 };
  enum class AcquisitionStage : uint8_t { Fast = 0, Refine = 1, Tracking = 2 };

  void reset(float dotMs = 60.0f) {
    if (!std::isfinite(dotMs) || dotMs < 20.0f || dotMs > 240.0f) dotMs = 60.0f;
    dotAvg_ = dotMs;
    dashAvg_ = 3.0f * dotMs;
    symbolGapAvg_ = dotMs;
    characterGapAvg_ = 3.0f * dotMs;
    cwSpaceAvg_ = 3.6f * dotMs;
    referenceDot_ = dotMs;
    markSamples_ = symbolGapSamples_ = characterGapSamples_ = cwSpaceSamples_ = 0;
    dotAccepted_ = dashAccepted_ = 0;
    rejectedOutlier_ = rejectedLowConfidence_ = 0;
    dotWrite_ = dashWrite_ = symbolWrite_ = 0;
    dotHistCount_ = dashHistCount_ = symbolHistCount_ = 0;
    speedCandidateDot_ = 0.0f;
    speedCandidateHits_ = 0;
    for (float &v : dotHistory_) v = 0.0f;
    for (float &v : dashHistory_) v = 0.0f;
    for (float &v : symbolHistory_) v = 0.0f;
  }

  // The PDP-12 did not begin normal data recognition until 49 pulses had been
  // used for initialization.  Our receiver must decode immediately, so the
  // modern decoder can use its proven timing path while this class acquires;
  // fullyAcquired() marks the equivalent Guenther transition point.
  bool ready() const { return markSamples_ >= 16; }
  bool fullyAcquired() const { return markSamples_ >= 49; }
  uint16_t markSamples() const { return markSamples_; }
  uint16_t acceptedDots() const { return dotAccepted_; }
  uint16_t acceptedDashes() const { return dashAccepted_; }
  uint16_t rejectedOutliers() const { return rejectedOutlier_; }
  uint16_t rejectedLowConfidence() const { return rejectedLowConfidence_; }

  AcquisitionStage acquisitionStage() const {
    if (markSamples_ < 16) return AcquisitionStage::Fast;
    if (markSamples_ < 49) return AcquisitionStage::Refine;
    return AcquisitionStage::Tracking;
  }

  float dotAverage() const { return dotAvg_; }
  float dashAverage() const { return dashAvg_; }
  float symbolGapAverage() const { return symbolGapAvg_; }
  float characterGapAverage() const { return characterGapAvg_; }
  float cwSpaceAverage() const { return cwSpaceAvg_; }

  // Guenther Eq. 3.2 / 4.3.  Note carefully: this is DOT/4 + DASH/2,
  // not the arithmetic midpoint and not (DOT/4 + DASH)/2.
  float markBoundary() const {
    return clampf(dotAvg_ * 0.25f + dashAvg_ * 0.50f,
                  dotAvg_ * 1.35f, dotAvg_ * 2.45f);
  }

  bool classifyDash(float markMs) const { return markMs > markBoundary(); }

  // V2.27 decode-only classifier. Guenther's published moving boundary remains
  // the primary decision rule and remains the rule used for learning. For marks
  // close to that boundary, however, a hand key can produce a shortened dash or
  // lengthened dot. Once both timing clusters contain enough history, compare
  // the standardized distance to the learned DOT and DASH clusters. A class is
  // changed only when the statistical fit is decisively better, so clean keyer
  // CW is unaffected while borderline hand-sent elements get a second chance.
  bool classifyDashForDecode(float markMs) const {
    const bool boundaryDash = classifyDash(markMs);
    if (!ready() || dotHistCount_ < 5 || dashHistCount_ < 4 || !validDuration(markMs))
      return boundaryDash;
    const float b = markBoundary();
    if (markMs < b * 0.72f || markMs > b * 1.28f) return boundaryDash;
    const float dotCost = markFitCost(markMs, false);
    const float dashCost = markFitCost(markMs, true);
    constexpr float kDecisionMargin = 1.00f;
    if (dashCost + kDecisionMargin < dotCost) return true;
    if (dotCost + kDecisionMargin < dashCost) return false;
    return boundaryDash;
  }

  // Synchronize acquisition to the decoder's independent cycle-based dot
  // estimate. This prevents a 20-WPM startup seed from contaminating very slow
  // or very fast hand sending. A material speed jump restarts Guenther's staged
  // acquisition around the new sender speed.
  void syncDotEstimate(float dotMs) {
    if (!std::isfinite(dotMs) || dotMs < 20.0f || dotMs > 240.0f) return;
    const float ratio = dotMs / (referenceDot_ > 1.0f ? referenceDot_ : dotMs);
    if (ratio >= 0.72f && ratio <= 1.38f) {
      speedCandidateDot_ = 0.0f;
      speedCandidateHits_ = 0;
      return;
    }

    // A single bad cycle estimate (often caused by QSB or interference) must
    // never erase good timing. Even during acquisition require a coherent new
    // speed for several consecutive marks. With no accepted marks yet we may
    // seed immediately; otherwise three hits acquire quickly and four hits are
    // required after a fully established sender profile.
    if (markSamples_ == 0) {
      reset(dotMs);
      return;
    }
    if (speedCandidateDot_ > 1.0f &&
        dotMs > speedCandidateDot_ * 0.88f && dotMs < speedCandidateDot_ * 1.12f) {
      if (speedCandidateHits_ < 255) ++speedCandidateHits_;
      speedCandidateDot_ += 0.25f * (dotMs - speedCandidateDot_);
    } else {
      speedCandidateDot_ = dotMs;
      speedCandidateHits_ = 1;
    }
    const bool supported = speedCandidateSupported(speedCandidateDot_);
    const uint8_t needed = fullyAcquired() ? (supported ? 4 : 7) : (supported ? 3 : 6);
    if (speedCandidateHits_ >= needed) reset(speedCandidateDot_);
  }

  // Returns true only if this observation was allowed to teach the timing
  // model. Decoding may still use rejected observations; they simply cannot
  // drag the learned sender timing around.
  bool observeMark(float markMs, float confidence) {
    if (!validDuration(markMs)) return false;
    if (confidence < kLearningConfidence) {
      satInc(rejectedLowConfidence_);
      return false;
    }

    if (markSamples_ < 4) maybeFollowSpeed(markMs);
    const bool dash = classifyDash(markMs);

    // Gross pulse glitches are never useful training truth.  After a few
    // samples, add a statistical guard similar to Guenther's recommended
    // 2-sigma confidence interval, with style-aware tolerance.
    if (markMs < dotAvg_ * 0.42f || isStatisticalOutlier(markMs, dash)) {
      satInc(rejectedOutlier_);
      return false;
    }

    const float alpha = acquisitionAlpha();
    if (dash) {
      if (markMs > dashAvg_ * 5.0f) {
        satInc(rejectedOutlier_);
        return false;
      }
      dashAvg_ += alpha * (markMs - dashAvg_);
      pushHistory(dashHistory_, dashWrite_, dashHistCount_, markMs);
      satInc(dashAccepted_);
    } else {
      dotAvg_ += alpha * (markMs - dotAvg_);
      pushHistory(dotHistory_, dotWrite_, dotHistCount_, markMs);
      satInc(dotAccepted_);
    }

    dotAvg_ = clampf(dotAvg_, 20.0f, 240.0f);
    dashAvg_ = clampf(dashAvg_, dotAvg_ * 1.60f, dotAvg_ * 4.9f);
    referenceDot_ += (fullyAcquired() ? 0.04f : 0.10f) * (dotAvg_ - referenceDot_);
    satInc(markSamples_);
    return true;
  }

  bool observeSymbolGap(float gapMs, float confidence) {
    if (!validDuration(gapMs) || confidence < kLearningConfidence) {
      if (validDuration(gapMs) && confidence < kLearningConfidence) satInc(rejectedLowConfidence_);
      return false;
    }
    if (gapMs < dotAvg_ * 0.30f || gapMs > dotAvg_ * 1.85f) return false;
    const float alpha = markSamples_ < 49 ? 0.25f : 0.125f;
    symbolGapAvg_ += alpha * (gapMs - symbolGapAvg_);
    symbolGapAvg_ = clampf(symbolGapAvg_, dotAvg_ * 0.40f, dotAvg_ * 1.60f);
    pushHistory(symbolHistory_, symbolWrite_, symbolHistCount_, gapMs);
    satInc(symbolGapSamples_);
    return true;
  }

  bool observeCharacterGap(float gapMs, float confidence) {
    if (!validDuration(gapMs) || confidence < kLearningConfidence) return false;
    // Modern diagnostic cluster only. Guenther's actual CHARACTER-vs-WORD
    // boundary is learned by observeNonSymbolGapAfter() below.
    if (gapMs < dotAvg_ * 1.25f || gapMs > dotAvg_ * 7.5f) return false;
    const float alpha = markSamples_ < 49 ? 0.20f : 0.10f;
    characterGapAvg_ += alpha * (gapMs - characterGapAvg_);
    characterGapAvg_ = clampf(characterGapAvg_, dotAvg_ * 1.50f, dotAvg_ * 6.5f);
    satInc(characterGapSamples_);
    return true;
  }

  // Guenther Eq. 3.3 / 4.8 / 4.9: the CHARACTER-WORD average is updated from
  // non-SYMBOL spaces following a DOT. During initialization it uses 1/4 new
  // data; in normal tracking it uses 1/8.
  bool observeNonSymbolGapAfter(float gapMs, float previousMarkMs,
                                bool previousWasDash, float confidence) {
    if (!validDuration(gapMs) || confidence < kLearningConfidence || previousWasDash) return false;
    if (gapMs < symbolBoundaryAfter(previousMarkMs, false) || gapMs > dotAvg_ * 8.5f) return false;
    const float alpha = markSamples_ < 49 ? 0.25f : 0.125f;
    cwSpaceAvg_ += alpha * (gapMs - cwSpaceAvg_);
    cwSpaceAvg_ = clampf(cwSpaceAvg_, dotAvg_ * 2.0f, dotAvg_ * 7.0f);
    satInc(cwSpaceSamples_);
    return true;
  }

  // Exact thesis SYMBOL/non-SYMBOL boundary. For a preceding DASH the
  // boundary slopes downward as the dash grows (Eq. 3.4). Guenther limits the
  // dash duration used in boundary calculations to twice the current DASH avg.
  float symbolBoundaryAfter(float previousMarkMs, bool previousWasDash) const {
    const float pulse = markBoundary();
    if (!previousWasDash || !validDuration(previousMarkMs)) return pulse;
    const float dashTime = clampf(previousMarkMs, 0.0f, 2.0f * dashAvg_);
    const float boundary = pulse - (dashTime - pulse) * 0.25f;
    return clampf(boundary, dotAvg_ * 0.72f, dotAvg_ * 2.30f);
  }

  // Compatibility name used by V2.21 code paths.
  float characterBoundaryAfter(float previousMarkMs, bool previousWasDash) const {
    return symbolBoundaryAfter(previousMarkMs, previousWasDash);
  }

  // Thesis CHARACTER/WORD boundary (Eq. 3.5). We do not apply Guenther's
  // later English-language letter heuristic because amateur radio contains
  // callsigns, Q-codes, code groups and prosigns.
  float wordBoundaryAfter(float previousMarkMs, bool previousWasDash) const {
    float boundary = cwSpaceAvg_;
    if (previousWasDash && validDuration(previousMarkMs)) {
      const float dashTime = clampf(previousMarkMs, 0.0f, 2.0f * dashAvg_);
      boundary -= (dashTime - cwSpaceAvg_) * 0.25f;
    }
    return clampf(boundary, dotAvg_ * 2.2f, dotAvg_ * 7.2f);
  }

  bool cwSpaceReady() const { return cwSpaceSamples_ >= 5; }

  bool suspiciousInternalGap(float gapMs, float previousMarkMs,
                             bool previousWasDash) const {
    if (!ready() || !validDuration(gapMs)) return false;
    const float boundary = symbolBoundaryAfter(previousMarkMs, previousWasDash);
    return gapMs > boundary * 1.18f && gapMs > symbolGapAvg_ * 1.45f;
  }

  bool suspiciousShortPulse(float markMs) const {
    return ready() && validDuration(markMs) && markMs < dotAvg_ * 0.52f;
  }

  // A very short internal gap can be a QSB dropout inside one long mark. This
  // gate is intentionally conservative and only feeds the hypothesis layer.
  bool qsbMergeGap(float gapMs) const {
    return ready() && validDuration(gapMs) &&
           gapMs < fminf(symbolGapAvg_ * 0.62f, dotAvg_ * 0.66f);
  }

  bool ambiguousMark(float markMs) const {
    if (!validDuration(markMs)) return false;
    const float b = markBoundary();
    return markMs > b * 0.80f && markMs < b * 1.20f;
  }

  float markFitCost(float markMs, bool dash) const {
    const float mean = dash ? dashAvg_ : dotAvg_;
    float sigma = historySigma(dash ? dashHistory_ : dotHistory_,
                               dash ? dashHistCount_ : dotHistCount_, mean);
    sigma = fmaxf(sigma, mean * (dash ? 0.10f : 0.08f));
    const float z = (markMs - mean) / fmaxf(sigma, 1.0f);
    return z * z;
  }

  float symbolGapFitCost(float gapMs) const {
    float sigma = historySigma(symbolHistory_, symbolHistCount_, symbolGapAvg_);
    sigma = fmaxf(sigma, symbolGapAvg_ * 0.10f);
    const float z = (gapMs - symbolGapAvg_) / fmaxf(sigma, 1.0f);
    return z * z;
  }

  SendingStyle sendingStyle() const {
    if (dotHistCount_ < 8 || dashHistCount_ < 5) return SendingStyle::Unknown;
    const float dcv = coeffVar(dotHistory_, dotHistCount_);
    const float acv = coeffVar(dashHistory_, dashHistCount_);
    const float gcv = symbolHistCount_ >= 7 ? coeffVar(symbolHistory_, symbolHistCount_) : 1.0f;
    if (dcv < 0.10f && acv < 0.12f && gcv < 0.15f) return SendingStyle::Keyer;
    if (dcv < 0.10f && acv > 0.14f) return SendingStyle::Bug;
    if (dcv > 0.10f || acv > 0.12f) return SendingStyle::StraightKey;
    return SendingStyle::Unknown;
  }

  const char *sendingStyleName() const {
    switch (sendingStyle()) {
      case SendingStyle::StraightKey: return "STRAIGHT";
      case SendingStyle::Bug: return "BUG";
      case SendingStyle::Keyer: return "KEYER";
      default: return "UNKNOWN";
    }
  }

 private:
  static constexpr float kLearningConfidence = 58.0f;
  static constexpr size_t kStatHistory = 16;

  float dotAvg_ = 60.0f;
  float dashAvg_ = 180.0f;
  float symbolGapAvg_ = 60.0f;
  float characterGapAvg_ = 180.0f;
  float cwSpaceAvg_ = 216.0f;
  float referenceDot_ = 60.0f;
  uint16_t markSamples_ = 0;
  uint16_t symbolGapSamples_ = 0;
  uint16_t characterGapSamples_ = 0;
  uint16_t cwSpaceSamples_ = 0;
  uint16_t dotAccepted_ = 0;
  uint16_t dashAccepted_ = 0;
  uint16_t rejectedOutlier_ = 0;
  uint16_t rejectedLowConfidence_ = 0;

  float dotHistory_[kStatHistory] = {};
  float dashHistory_[kStatHistory] = {};
  float symbolHistory_[kStatHistory] = {};
  size_t dotWrite_ = 0, dashWrite_ = 0, symbolWrite_ = 0;
  size_t dotHistCount_ = 0, dashHistCount_ = 0, symbolHistCount_ = 0;
  float speedCandidateDot_ = 0.0f;
  uint8_t speedCandidateHits_ = 0;

  static float clampf(float v, float lo, float hi) {
    return v < lo ? lo : (v > hi ? hi : v);
  }

  static bool validDuration(float ms) {
    return std::isfinite(ms) && ms >= 2.0f && ms <= 2500.0f;
  }

  static void satInc(uint16_t &v) { if (v < 65535U) ++v; }

  float acquisitionAlpha() const {
    if (markSamples_ < 16) return 0.50f;
    if (markSamples_ < 49) return 0.25f;
    return 0.125f;
  }

  static void pushHistory(float *history, size_t &write, size_t &count, float value) {
    history[write] = value;
    write = (write + 1U) % kStatHistory;
    if (count < kStatHistory) ++count;
  }

  static float historyMean(const float *history, size_t count) {
    if (!count) return 0.0f;
    float s = 0.0f;
    for (size_t i = 0; i < count; ++i) s += history[i];
    return s / static_cast<float>(count);
  }

  static float historySigma(const float *history, size_t count, float fallbackMean) {
    if (count < 3) return fmaxf(fallbackMean * 0.12f, 2.0f);
    const float mean = historyMean(history, count);
    float sum = 0.0f;
    for (size_t i = 0; i < count; ++i) {
      const float d = history[i] - mean;
      sum += d * d;
    }
    return sqrtf(sum / static_cast<float>(count - 1U));
  }

  static float coeffVar(const float *history, size_t count) {
    const float mean = historyMean(history, count);
    if (mean <= 1.0f) return 1.0f;
    return historySigma(history, count, mean) / mean;
  }

  bool isStatisticalOutlier(float markMs, bool dash) const {
    const float *history = dash ? dashHistory_ : dotHistory_;
    const size_t count = dash ? dashHistCount_ : dotHistCount_;
    const float mean = dash ? dashAvg_ : dotAvg_;
    if (count < 6) return false;
    float sigma = historySigma(history, count, mean);
    sigma = fmaxf(sigma, mean * (dash ? 0.085f : 0.070f));
    float k = 2.7f;
    const SendingStyle style = sendingStyle();
    if (style == SendingStyle::Keyer) k = 2.25f;
    else if (style == SendingStyle::Bug) k = dash ? 3.35f : 2.35f;
    else if (style == SendingStyle::StraightKey) k = 3.0f;
    const float delta = fabsf(markMs - mean);
    return delta > k * sigma && delta > mean * 0.20f;
  }

  bool speedCandidateSupported(float candidateDot) const {
    if (!std::isfinite(candidateDot) || candidateDot < 20.0f || candidateDot > 240.0f) return false;
    if (dotHistCount_ >= 2) {
      const float m = historyMean(dotHistory_, dotHistCount_);
      if (candidateDot > m * 0.72f && candidateDot < m * 1.38f) return true;
    }
    if (dashHistCount_ >= 2) {
      const float m = historyMean(dashHistory_, dashHistCount_);
      // The new dot may have been temporarily classified as a dash, or the
      // candidate's 3-dot dash may match the existing long-mark cluster.
      if (candidateDot > m * 0.72f && candidateDot < m * 1.38f) return true;
      const float candDash = candidateDot * 3.0f;
      if (candDash > m * 0.72f && candDash < m * 1.38f) return true;
    }
    return false;
  }

  void maybeFollowSpeed(float markMs) {
    if (markMs < markBoundary()) {
      const float ratio = markMs / (referenceDot_ > 1.0f ? referenceDot_ : 60.0f);
      if (ratio < 0.55f || ratio > 1.80f) reset(clampf(markMs, 20.0f, 240.0f));
    }
  }
};
