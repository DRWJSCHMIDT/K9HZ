/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

/*
 * Libraries used
 * --------------
 * External libraries (install if not already supplied by Teensyduino):
 *   - Adafruit GFX Library              <Adafruit_GFX.h>
 *   - SSD1322 for Adafruit GFX          <SSD1322_for_Adafruit_GFX.h>
 *   - U8g2 for Adafruit GFX             <U8g2_for_Adafruit_GFX.h>
 *   - Chrono                            <Chrono.h>
 *   - Metro                             <Metro.h>
 *   - Encoder                           <Encoder.h>
 *   - TimerOne                          <TimerOne.h>
 *
 * Arduino / Teensy core libraries:
 *   - Wire                              <Wire.h>
 *   - SPI                               <SPI.h>
 *   - EEPROM                            <EEPROM.h>
 *
 * Target controller: Teensy 4.0
 */

/*
 * Hardware connections - Teensy 4.0
 * ---------------------------------
 * SSD1322 256x64 OLED (hardware SPI):
 *   SCLK / CLK        -> pin 13
 *   MOSI / DIN        -> pin 11
 *   CS                -> pin 10
 *   DC                -> pin  8
 *   RESET             -> not controlled by firmware (OLED_RESET = 255)
 *   MISO              -> not used
 *
 * Rotary encoder / menu control:
 *   Encoder A         -> pin  1
 *   Encoder B         -> pin  0
 *   Encoder push      -> pin  3, switch to GND (INPUT_PULLUP)
 *
 * Coupler control:
 *   Coupler switch    -> pin  6, switch to GND (INPUT_PULLUP)
 *                        Short press: Coupler 1 / Coupler 2
 *                        Hold >= 800 ms: open Band Select
 *                        During SWR alarm: immediate alarm acknowledge only
 *   Coupler LED       -> pin  7
 *                        Also flashes while the SWR alarm is latched.
 *   Coupler select    -> pin 15, external Coupler 1 / Coupler 2 select output
 *
 * SWR alarm:
 *   Buzzer output     -> pin 14, PWM output; sounds for 3 seconds per alarm trigger
 *   Separate alarm LED-> not fitted in this hardware revision (R_Led = 255)
 *                        The Coupler LED on pin 7 is used for alarm flashing.
 *
 * AD7991 ADC - Forward / Reflected detector inputs:
 *   Interface         -> I2C / Wire
 *   SDA               -> pin 18 (Teensy 4.0 default Wire SDA)
 *   SCL               -> pin 19 (Teensy 4.0 default Wire SCL)
 *   I2C address       -> 0x29 preferred, 0x28 automatically detected fallback
 *   VIN0              -> Forward detector signal
 *   VIN1              -> Reflected detector signal
 *   External VREF     -> 2.60 V as configured in firmware
 *   Configuration     -> 400 kHz; measurement data uses 2 MHz I2C High-Speed mode
 *
 * Band / calibration selection:
 *   Bands             -> HF, 6M, 2M, 70cm
 *   Calibration banks -> 4 bands x 2 couplers = 8 independent banks
 *   Coupler short push-> Coupler 1 / Coupler 2
 *   Coupler long push -> Band Select
 *   Encoder long push -> Setup menu (disabled on Clock screen)
 *   ModScope push     -> Exit ModScope (unchanged)
 *
 * WiFi / web-server coprocessor - Seeed XIAO ESP32-C3 (direct UART):
 *   Teensy Serial5 TX -> pin 20 -> XIAO D7 / RX
 *   Teensy Serial5 RX <- pin 21 <- XIAO D6 / TX
 *   Baud rate         -> 921600, 8N1
 *   WiFi SSID/password are stored in Teensy EEPROM and edited with the OLED
 *   QWERTY keyboard. The XIAO does not use WiFiManager.
 *
 * USB serial:
 *   Teensy native USB -> configuration, calibration, reporting and $yourcall
 *
 * Notes:
 *   - All modules must share a common GND.
 *   - Pin numbers above are the active Johan / JH2KW-M hardware configuration.
 *   - Optional outputs set to pin 255 are intentionally not fitted.
 *   - SWR uses complete 100 ms averaged forward/reflected linear-power blocks.
 *   - A new SWR value requires qualified net TX power, rejecting common-mode RF pickup.
 */

#include "PSWR_App.h"

void setup() { pswrSetup(); }
void loop()  { pswrLoop();  }
