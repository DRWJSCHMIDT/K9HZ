// V2.29 CW TYPE migration/regression test. Build against native Preferences stubs.
#include "AppSettings.cpp"
#include <cassert>
#include <cstdio>

static void reboot() {
  ready = false;
  cwTypeValue = 99;
  fadingAssistValue = false;
  farnsworthSpacingValue = 20;
  AppSettings::begin();
}

int main() {
  Preferences::data.clear();
  reboot();
  assert(AppSettings::cwType() == 0);
  assert(AppSettings::fadingAssist()); // now permanently ON
  AppSettings::setCwType(1);
  AppSettings::setFadingAssist(false);
  assert(AppSettings::fadingAssist()); // legacy API cannot disable it
  reboot();
  assert(AppSettings::cwType() == 1);
  assert(AppSettings::fadingAssist());
  assert(Preferences::data["cwtype"] == 1);

  for (uint8_t legacy = 2; legacy <= 4; ++legacy) {
    Preferences::data["cwtype"] = legacy;
    reboot();
    assert(AppSettings::cwType() == 0);
    assert(Preferences::data["cwtype"] == 0); // write back normalized setting
    assert(AppSettings::fadingAssist()); // even after legacy mode migration
  }
  AppSettings::setCwType(2);
  assert(AppSettings::cwType() == 0);           // obsolete mode cannot be saved
  AppSettings::setCwType(255);
  assert(AppSettings::cwType() == 0);
  AppSettings::setCwType(1);
  assert(AppSettings::cwType() == 1);
  reboot();
  assert(AppSettings::cwType() == 1);
  // Upgrade from a user who had intentionally saved FADING ASSIST OFF.
  Preferences::data["fadehelp"] = 0;
  reboot();
  assert(AppSettings::fadingAssist());
  AppSettings::setFadingAssist(false);
  assert(AppSettings::fadingAssist());
  std::puts("PASS V2.29: two CW types, NVS migration, FADING ASSIST always ON");
}
