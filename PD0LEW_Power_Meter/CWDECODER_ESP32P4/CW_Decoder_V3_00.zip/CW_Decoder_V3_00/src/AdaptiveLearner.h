#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>

// Confidence-gated, fixed-memory CW timing learner.
//
// It learns NORMALIZED timing ratios rather than absolute milliseconds, so a
// profile learned at (for example) 18 WPM can still help at 30 WPM.  The
// learner is intentionally conservative: it only accepts observations from a
// stable/high-confidence signal and never uses decoded words, dictionaries or
// language guesses as training truth.
//
// Learned quantities:
//   markThresholdRatio  - separator between dots and dashes (nominal ~2.0 dots)
//   letterGapRatio      - separator between intra-character and letter gaps
//
// Word spacing is deliberately not self-trained in V1.91 because incorrectly
// learning a word boundary can create a positive feedback loop.  The proven
// word-gap logic remains unchanged.
class AdaptiveLearner {
 public:
  void reset() {
    markCount_ = markWrite_ = gapCount_ = gapWrite_ = 0;
    markRatio_ = 0.0f;
    gapRatio_ = 0.0f;
    markQuality_ = gapQuality_ = 0;
    accepted_ = 0;
    ++revision_;
  }

  void seed(float markRatio, float gapRatio, uint8_t quality) {
    markCount_ = markWrite_ = gapCount_ = gapWrite_ = 0;
    markRatio_ = validMarkThreshold(markRatio) ? markRatio : 0.0f;
    gapRatio_ = validGapThreshold(gapRatio) ? gapRatio : 0.0f;
    const uint8_t q = quality > 100 ? 100 : quality;
    markQuality_ = markRatio_ > 0.0f ? q : 0;
    gapQuality_ = gapRatio_ > 0.0f ? q : 0;
    accepted_ = 0;
    ++revision_;
  }

  void observeMark(float ms, float dotMs, float confidence) {
    if (!validObservation(ms, dotMs, confidence)) return;
    const float r = ms / dotMs;
    if (r < 0.45f || r > 4.5f) return;
    marks_[markWrite_] = r;
    markWrite_ = (markWrite_ + 1) % kHistory;
    if (markCount_ < kHistory) ++markCount_;
    if (accepted_ < 65535) ++accepted_;
    if (markCount_ >= 10 && (markCount_ < kHistory || (markWrite_ & 3U) == 0U)) recomputeMark();
  }

  void observeGap(float ms, float dotMs, float confidence) {
    if (!validObservation(ms, dotMs, confidence)) return;
    const float r = ms / dotMs;
    // Very long word gaps are excluded from the letter-gap learner.
    if (r < 0.35f || r > 4.3f) return;
    gaps_[gapWrite_] = r;
    gapWrite_ = (gapWrite_ + 1) % kHistory;
    if (gapCount_ < kHistory) ++gapCount_;
    if (accepted_ < 65535) ++accepted_;
    if (gapCount_ >= 12 && (gapCount_ < kHistory || (gapWrite_ & 3U) == 0U)) recomputeGap();
  }

  bool markReady() const { return markRatio_ > 0.0f && markQuality_ >= kApplyQuality; }
  bool gapReady() const { return gapRatio_ > 0.0f && gapQuality_ >= kApplyQuality; }
  bool ready() const { return markReady() || gapReady(); }

  float markThresholdRatio() const { return markRatio_; }
  float letterGapRatio() const { return gapRatio_; }
  uint8_t markQuality() const { return markQuality_; }
  uint8_t gapQuality() const { return gapQuality_; }
  uint8_t quality() const {
    if (markQuality_ && gapQuality_) return static_cast<uint8_t>((markQuality_ + gapQuality_) / 2U);
    return markQuality_ > gapQuality_ ? markQuality_ : gapQuality_;
  }
  uint16_t acceptedSamples() const { return accepted_; }
  uint32_t revision() const { return revision_; }

  static constexpr uint8_t kApplyQuality = 55;

 private:
  static constexpr size_t kHistory = 48;
  float marks_[kHistory] = {};
  float gaps_[kHistory] = {};
  size_t markCount_ = 0, markWrite_ = 0, gapCount_ = 0, gapWrite_ = 0;
  float markRatio_ = 0.0f, gapRatio_ = 0.0f;
  uint8_t markQuality_ = 0, gapQuality_ = 0;
  uint16_t accepted_ = 0;
  uint32_t revision_ = 0;

  static bool validObservation(float ms, float dotMs, float confidence) {
    return std::isfinite(ms) && std::isfinite(dotMs) && std::isfinite(confidence) &&
           dotMs >= 20.0f && dotMs <= 240.0f && confidence >= 58.0f;
  }
  static bool validMarkThreshold(float r) { return std::isfinite(r) && r >= 1.40f && r <= 2.80f; }
  static bool validGapThreshold(float r) { return std::isfinite(r) && r >= 1.20f && r <= 3.40f; }
  static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }

  static void insertionSort(float *v, size_t n) {
    for (size_t i = 1; i < n; ++i) {
      const float x = v[i];
      size_t j = i;
      while (j > 0 && v[j - 1] > x) { v[j] = v[j - 1]; --j; }
      v[j] = x;
    }
  }

  static float separation(const float *v, size_t n, size_t split, float lo, float hi) {
    float variance = 0.0f;
    for (size_t i = 0; i < n; ++i) {
      const float d = v[i] - (i < split ? lo : hi);
      variance += d * d;
    }
    return (hi - lo) * (hi - lo) / (variance / static_cast<float>(n) + 0.0025f);
  }

  static uint8_t scoreQuality(size_t count, float sep) {
    const float countScore = clampf(static_cast<float>(count) * (100.0f / 36.0f), 0.0f, 100.0f);
    const float sepScore = clampf((sep - 4.0f) * 7.0f, 0.0f, 100.0f);
    return static_cast<uint8_t>(clampf(0.55f * countScore + 0.45f * sepScore, 0.0f, 100.0f));
  }

  void recomputeMark() {
    float sorted[kHistory];
    for (size_t i = 0; i < markCount_; ++i) sorted[i] = marks_[i];
    insertionSort(sorted, markCount_);

    float bestSep = 0.0f, bestThreshold = 0.0f;
    for (size_t split = 4; split + 4 <= markCount_; ++split) {
      float lo = 0.0f, hi = 0.0f;
      for (size_t i = 0; i < split; ++i) lo += sorted[i];
      lo /= static_cast<float>(split);
      for (size_t i = split; i < markCount_; ++i) hi += sorted[i];
      hi /= static_cast<float>(markCount_ - split);
      if (lo < 0.55f || lo > 1.55f || hi < 1.95f || hi > 4.20f || hi < lo * 1.75f) continue;
      const float sep = separation(sorted, markCount_, split, lo, hi);
      if (sep > bestSep) {
        bestSep = sep;
        bestThreshold = clampf((lo + hi) * 0.5f, 1.45f, 2.65f);
      }
    }
    if (bestThreshold <= 0.0f) return;
    const uint8_t q = scoreQuality(markCount_, bestSep);
    if (q < 35) return;
    const float old = markRatio_;
    if (markRatio_ <= 0.0f) markRatio_ = bestThreshold;
    else markRatio_ += (q >= 75 ? 0.16f : 0.08f) * (bestThreshold - markRatio_);
    markRatio_ = clampf(markRatio_, 1.45f, 2.65f);
    const uint8_t oldQ = markQuality_;
    markQuality_ = static_cast<uint8_t>(std::max<int>(q, static_cast<int>(markQuality_) - 1));
    if (std::fabs(markRatio_ - old) >= 0.01f || (markQuality_ / 5U) != (oldQ / 5U)) ++revision_;
  }

  void recomputeGap() {
    float sorted[kHistory];
    for (size_t i = 0; i < gapCount_; ++i) sorted[i] = gaps_[i];
    insertionSort(sorted, gapCount_);

    float bestSep = 0.0f, bestThreshold = 0.0f;
    for (size_t split = 5; split + 3 <= gapCount_; ++split) {
      float lo = 0.0f, hi = 0.0f;
      for (size_t i = 0; i < split; ++i) lo += sorted[i];
      lo /= static_cast<float>(split);
      for (size_t i = split; i < gapCount_; ++i) hi += sorted[i];
      hi /= static_cast<float>(gapCount_ - split);
      if (lo < 0.45f || lo > 1.60f || hi < 1.75f || hi > 4.80f || hi < lo * 1.45f) continue;
      const float sep = separation(sorted, gapCount_, split, lo, hi);
      if (sep > bestSep) {
        bestSep = sep;
        bestThreshold = clampf((lo + hi) * 0.5f, 1.25f, 3.20f);
      }
    }
    if (bestThreshold <= 0.0f) return;
    const uint8_t q = scoreQuality(gapCount_, bestSep);
    if (q < 35) return;
    const float old = gapRatio_;
    if (gapRatio_ <= 0.0f) gapRatio_ = bestThreshold;
    else gapRatio_ += (q >= 75 ? 0.14f : 0.07f) * (bestThreshold - gapRatio_);
    gapRatio_ = clampf(gapRatio_, 1.25f, 3.20f);
    const uint8_t oldQ = gapQuality_;
    gapQuality_ = static_cast<uint8_t>(std::max<int>(q, static_cast<int>(gapQuality_) - 1));
    if (std::fabs(gapRatio_ - old) >= 0.01f || (gapQuality_ / 5U) != (oldQ / 5U)) ++revision_;
  }
};
