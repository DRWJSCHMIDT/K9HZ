#pragma once
#include <cmath>

// CW Decoder V2.29: mathematically calibrated *full*, two-sided -3 dB
// bandwidth for the existing two cascaded first-order complex I/Q sections.
// At offset +/- bandwidthHz/2 from the carrier, the combined amplitude is
// 1/sqrt(2) of the DC value (power is down 3.0103 dB).
// This is an exact discrete-time solution, including the pole discretization.
// Do not use the same coefficient for the separate WEAK SIGNAL detector.
namespace CWFilterCalibration {
inline float twoPoleAlphaForFullBandwidth(float bandwidthHz, float sampleRateHz) {
  if (!(bandwidthHz > 0.0f) || !(sampleRateHz > 0.0f) ||
      bandwidthHz >= sampleRateHz) return 0.0f;
  constexpr double kPi = 3.1415926535897932384626433832795;
#if defined(CW_FILTER_LEGACY_BANDWIDTH)
  // Comparison build: exact original per-stage coefficient, before calibrating
  // the combined two-pole passband. Selecting this build restores the proven
  // V2.28/V2.29 filter behavior without altering the Morse engine.
  return static_cast<float>(1.0 - std::exp(-2.0 * kPi * bandwidthHz / sampleRateHz));
#else
  constexpr double kRootTwoMinusOne = 0.4142135623730950488;
  // 1 - cos(w) = 2*sin(w/2)^2 avoids severe cancellation at 96 kHz.
  // Half-power frequency is bandwidthHz/2, hence w/2 = pi*BW/(2*fs).
  const double t = std::sin((kPi * double(bandwidthHz)) /
                            (2.0 * double(sampleRateHz)));
  const double g = 2.0 * t * t;
  const double alpha = (2.0 * g) /
      (g + std::sqrt(g*g + 2.0*g*kRootTwoMinusOne));
  return static_cast<float>(alpha);
#endif
}
} // namespace CWFilterCalibration
