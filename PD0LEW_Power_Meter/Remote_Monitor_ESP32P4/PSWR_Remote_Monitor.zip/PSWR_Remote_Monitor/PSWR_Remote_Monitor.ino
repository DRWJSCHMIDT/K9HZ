// Version 1.01
// Copyright (c) 2026
// Johan Holstein / Paul Davis  June 11th 2026
/***********************************************
Important information
ESP32-P4-WiFi6-Touch-LCD-5
GFX Library for Arduino 1.6.5
ESP core 3.3.10

Flash Size: "16MB (128Mb)"
Flash Mode "QIO"
Partition Scheme:"16M Flash (3MB APP/9.9MB FATFS)"
PSRAM:"Eanabled"

Remote Monitor for Power and SWR meter,
including weather warning system
and a QTH locator calculation via coordinates

************************************************/

#include <Arduino.h>
#include <lvgl.h>
#include "lv_conf.h"

#include "Waveshare_HX8394_DSI.h"
#include <Wire.h>
#include <TAMC_GT911.h>
#include "Adafruit_GFX.h"
#include "esp_heap_caps.h"
#include <WiFi.h>
#include <time.h>
#include <Preferences.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

#include "prefs.h"
#include "wifi_mgr.h"
#include "sse_client.h"
#include "api_client.h"
#include "app_state.h"
#include "ui.h"

LV_FONT_DECLARE(droid_sans_mono_120);

Preferences prefs;

static int brightness_value = 255;

// -----------------------------------------------------------------------------
// Weather
// -----------------------------------------------------------------------------
// Zuidlaren The Netherlands
float latitude = 53.094002;
float longitude = 6.681000;

const unsigned long forecastUpdateInterval =
  1UL * 60UL * 1000UL;  // 10 min


String pendingForecastStatus = "OK";
String pendingForecastAdvice = "Weather looks OK.";

volatile bool weatherRequestPending = false;
volatile bool pendingForecastUpdate = false;
unsigned long lastForecastUpdate = 0;


// -----------------------------------------------------------------------------
// WiFi
// -----------------------------------------------------------------------------

const char *ssid =     "H220N233F92";
const char *password = "BA1572491B64";

// -----------------------------------------------------------------------------
// Touch / Display
// -----------------------------------------------------------------------------

#define TOUCH_INT -1
#define TOUCH_RST -1
#define TOUCH_SDA 7
#define TOUCH_SCL 8

#define SCREEN_W 1280
#define SCREEN_H 720

TAMC_GT911 ts(TOUCH_SDA, TOUCH_SCL, TOUCH_INT, TOUCH_RST, 720, 1280);

Waveshare_HX8394_DSI tft;
Arduino_DSI_Display *gfx;

// -----------------------------------------------------------------------------
// Forward declarations
// -----------------------------------------------------------------------------

void updateWeatherForecast();
void queueForecastUpdate(String status, String advice);
void weatherTask(void *parameter);
void latLonToMaidenhead(float lat, float lon, char *grid);
// -----------------------------------------------------------------------------
// Touch
// -----------------------------------------------------------------------------

bool getTouch(int &x, int &y) {
  ts.read();

  if (!ts.isTouched) {
    return false;
  }

  uiWakeScreen();

  x = ts.points[0].y;
  y = 720 - ts.points[0].x;

  return true;
}

// -----------------------------------------------------------------------------
// LVGL display flush
// -----------------------------------------------------------------------------

void my_disp_flush(lv_display_t *disp,
                   const lv_area_t *area,
                   uint8_t *px_map) {

  int32_t w = area->x2 - area->x1 + 1;
  int32_t h = area->y2 - area->y1 + 1;

  gfx->draw16bitRGBBitmap(
    area->x1,
    area->y1,
    (uint16_t *)px_map,
    w,
    h);

  lv_display_flush_ready(disp);
}

// -----------------------------------------------------------------------------
// LVGL touch read
// -----------------------------------------------------------------------------

void my_touch_read(lv_indev_t *indev,
                   lv_indev_data_t *data) {

  int x, y;

  if (getTouch(x, y)) {
    data->state = LV_INDEV_STATE_PRESSED;
    data->point.x = x;
    data->point.y = y;
  } else {
    data->state = LV_INDEV_STATE_RELEASED;
  }
}

// -----------------------------------------------------------------------------
// Setup
// -----------------------------------------------------------------------------

void setup() {

  pinMode(0, OUTPUT);

  Serial.begin(115200);
  delay(500);

  if (!tft.begin(3)) {
    Serial.println("Display begin failed");

    while (1) {
      delay(500);
    }
  }

  ts.begin();
  ts.setRotation(3);

  prefs.begin("settings", false);
  // PD0LEW, Zuidlaren
  latitude = prefs.getFloat ("wxLat", 53.094002);
  longitude = prefs.getFloat("wxLon", 6.681000);
  
  // K9MR, Vermont USA
  //latitude = prefs.getFloat ("wxLat", 43.2700);
  //longitude = prefs.getFloat("wxLon", -72.5433);


  brightness_value = prefs.getInt("brightness", 190);

  if (brightness_value < 0 || brightness_value > 255) {
    brightness_value = 255;
  }

  Preferences p;
  p.begin("settings", true);

  int savedMinutes = p.getInt("ssMin", 5);

  p.end();

  uiSetScreensaverDelay(savedMinutes * 60);

  tft.setBrightness(brightness_value);

  gfx = tft.gfx();

  lv_init();

  size_t buf_size = SCREEN_W * 40 * sizeof(lv_color_t);

  lv_color_t *buf1 = (lv_color_t *)heap_caps_malloc(
    buf_size,
    MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);

  if (!buf1) {
    Serial.println("LVGL buffer allocation failed");

    while (1) {
      delay(1000);
    }
  }

  lv_display_t *disp = lv_display_create(SCREEN_W, SCREEN_H);

  lv_display_set_color_format(
    disp,
    LV_COLOR_FORMAT_RGB565);

  lv_display_set_flush_cb(
    disp,
    my_disp_flush);

  lv_display_set_buffers(
    disp,
    buf1,
    NULL,
    buf_size,
    LV_DISPLAY_RENDER_MODE_PARTIAL);

  lv_indev_t *indev = lv_indev_create();

  lv_indev_set_type(
    indev,
    LV_INDEV_TYPE_POINTER);

  lv_indev_set_read_cb(
    indev,
    my_touch_read);

  prefsLoad();

  gStateMutex = xSemaphoreCreateMutex();

  uiInit();

  uiShowConnecting("Connecting to WiFi...");

  if (!wifiConnect()) {
    uiShowPortalActive("RemoteMeter-Setup");
    startCaptivePortal();
  }

  uiRenderAll();

  startSseClient();

  Serial.println("WiFi connected");
  Serial.println(WiFi.localIP());

  xTaskCreate(
    weatherTask,
    "weatherTask",
    24000,
    NULL,
    1,
    NULL);

  weatherRequestPending = true;
}

// -----------------------------------------------------------------------------
// Loop
// -----------------------------------------------------------------------------

void loop() {

  static uint32_t last_ms = millis();

  uint32_t now = millis();

  lv_tick_inc(now - last_ms);

  last_ms = now;

  lv_timer_handler();

  uiHandleScreensaver();

  // ---------------------------------------------------------------------------
  // Weather timer
  // ---------------------------------------------------------------------------



  if (millis() - lastForecastUpdate >= forecastUpdateInterval) {
    lastForecastUpdate = millis();
    weatherRequestPending = true;
    lastForecastUpdate = millis();
  }

  // ---------------------------------------------------------------------------
  // Meter state updates
  // ---------------------------------------------------------------------------
  unsigned long elapsed =
    millis() - lastForecastUpdate;

  unsigned long remaining = 0;

  if (elapsed < forecastUpdateInterval) {
    remaining =
      forecastUpdateInterval - elapsed;
  }

  uiUpdateForecastTimer(remaining);



  bool doUpdate = false;

  if (gStateMutex && xSemaphoreTake(gStateMutex, pdMS_TO_TICKS(1)) == pdTRUE) {

    if (gState.dirty) {
      gState.dirty = false;
      doUpdate = true;
    }

    xSemaphoreGive(gStateMutex);
  }

  if (doUpdate) {
    uiRenderUpdates();
  }

  // ---------------------------------------------------------------------------
  // Forecast UI update - LVGL safe
  // ---------------------------------------------------------------------------

  if (pendingForecastUpdate) {
    pendingForecastUpdate = false;

    uiSetForecast(
      pendingForecastStatus,
      pendingForecastAdvice);
  }

  delay(1);
}

// -----------------------------------------------------------------------------
// Weather task
// -----------------------------------------------------------------------------

void weatherTask(void *parameter) {

  for (;;) {

    if (weatherRequestPending) {
      weatherRequestPending = false;

      updateWeatherForecast();
    }

    vTaskDelay(pdMS_TO_TICKS(500));
  }
}

// -----------------------------------------------------------------------------
// Queue forecast result for LVGL loop
// -----------------------------------------------------------------------------

void queueForecastUpdate(String status, String advice) {

  pendingForecastStatus = status;
  pendingForecastAdvice = advice;
  pendingForecastUpdate = true;
}

// -----------------------------------------------------------------------------
// Open-Meteo weather forecast
// -----------------------------------------------------------------------------

void updateWeatherForecast() {

  if (WiFi.status() != WL_CONNECTED) {
    queueForecastUpdate(
      "ERROR",
      "WiFi not connected.");

    return;
  }

  Serial.println();
  Serial.println("Updating Open-Meteo weather...");

  HTTPClient http;

  String url = "http://api.open-meteo.com/v1/forecast";

  url += "?latitude=" + String(latitude, 4);
  url += "&longitude=" + String(longitude, 4);
  url += "&hourly=precipitation,showers,weather_code,wind_speed_10m,wind_gusts_10m,cape";
  url += "&forecast_hours=12";
  url += "&timezone=auto";

  Serial.println(url);

  Serial.print("Free heap before HTTP: ");
  Serial.println(ESP.getFreeHeap());

  http.begin(url);
  http.setTimeout(8000);
  http.setReuse(false);

  int httpCode = http.GET();

  Serial.print("HTTP code = ");
  Serial.println(httpCode);

  if (httpCode != 200) {

    http.end();

    

    queueForecastUpdate(
      "ERROR",
      "Open-Meteo unavailable.");

    return;
  }

  String payload = http.getString();

  http.end();

  Serial.print("Payload size: ");
  Serial.println(payload.length());

  Serial.print("Free heap before JSON: ");
  Serial.println(ESP.getFreeHeap());

  DynamicJsonDocument doc(24576);

  DeserializationError error =
    deserializeJson(doc, payload);

  payload = "";

  if (error) {

    Serial.print("JSON error: ");
    Serial.println(error.c_str());

    queueForecastUpdate(
      "ERROR",
      "Forecast JSON error.");

    return;
  }

  JsonArray rainArray =
    doc["hourly"]["precipitation"];

  JsonArray showersArray =
    doc["hourly"]["showers"];

  JsonArray codeArray =
    doc["hourly"]["weather_code"];

  JsonArray windArray =
    doc["hourly"]["wind_speed_10m"];

  JsonArray gustArray =
    doc["hourly"]["wind_gusts_10m"];

  JsonArray capeArray =
    doc["hourly"]["cape"];

  if (rainArray.isNull() || showersArray.isNull() || codeArray.isNull() || windArray.isNull() || gustArray.isNull() || capeArray.isNull()) {

    queueForecastUpdate(
      "ERROR",
      "Forecast data missing.");

    return;
  }

  String status = "OK";
  String advice = "Weather looks OK.";

  float maxRain = 0.0;
  float maxShowers = 0.0;
  float maxWind = 0.0;
  float maxGust = 0.0;
  float maxCape = 0.0;
  int maxWeatherCode = 0;

  int count = rainArray.size();

  if (showersArray.size() < count) {
    count = showersArray.size();
  }

  if (codeArray.size() < count) {
    count = codeArray.size();
  }

  if (windArray.size() < count) {
    count = windArray.size();
  }

  if (gustArray.size() < count) {
    count = gustArray.size();
  }

  if (capeArray.size() < count) {
    count = capeArray.size();
  }

  for (int i = 0; i < count; i++) {

    float rain = rainArray[i] | 0.0;
    float showers = showersArray[i] | 0.0;
    int weatherCode = codeArray[i] | 0;
    float wind = windArray[i] | 0.0;
    float gust = gustArray[i] | 0.0;
    float cape = capeArray[i] | 0.0;

    if (rain > maxRain) {
      maxRain = rain;
    }

    if (showers > maxShowers) {
      maxShowers = showers;
    }

    if (wind > maxWind) {
      maxWind = wind;
    }

    if (gust > maxGust) {
      maxGust = gust;
    }

    if (cape > maxCape) {
      maxCape = cape;
    }

    if (weatherCode > maxWeatherCode) {
      maxWeatherCode = weatherCode;
    }

    // ---------------------------------------------------------------------
    // Highest priority: thunderstorm weather codes
    // 95, 96, 99 = thunderstorm / thunderstorm with hail
    // ---------------------------------------------------------------------

    if (weatherCode >= 95 && weatherCode <= 99) {

      status = "DANGER";
      advice = "Thunderstorm risk. Disconnect sensitive radio equipment.";
    }

    // ---------------------------------------------------------------------
    // Convective storm risk
    // ---------------------------------------------------------------------

    else if (status != "DANGER" && (cape > 400.0 || showers > 2.0)) {

      status = "STORM";
      advice = "Convective weather risk. Watch antennas and outdoor equipment.";
    }

    // ---------------------------------------------------------------------
    // Drizzle / rain weather codes
    // 51-55 drizzle, 56-57 freezing drizzle, 61-67 rain/freezing rain
    // ---------------------------------------------------------------------

    if (status == "OK" && weatherCode >= 51 && weatherCode <= 67) {

      status = "RAIN/WIND";
      advice = "Drizzle or rain expected. Watch outdoor electronics.";
    }

    // ---------------------------------------------------------------------
    // Rain / wind risk
    // ---------------------------------------------------------------------

    if (status != "DANGER" && status != "STORM" && (rain > 2.0 || wind > 30.0 || gust > 45.0)) {

      status = "RAIN/WIND";
      advice = "Rain or wind expected. Watch outdoor electronics.";
    }

    // ---------------------------------------------------------------------
    // Strong storm risk
    // ---------------------------------------------------------------------

    if (status != "DANGER" && (rain > 5.0 || wind > 45.0 || gust > 65.0)) {

      status = "STORM";
      advice = "Storm risk. Protect sensitive devices.";
    }

    // ---------------------------------------------------------------------
    // Dangerous wind / rain risk
    // ---------------------------------------------------------------------

    if (rain > 10.0 || wind > 70.0 || gust > 90.0) {

      status = "DANGER";
      advice = "Dangerous weather risk. Disconnect sensitive devices.";
    }
  }

  Serial.println("Open-Meteo forecast result:");

  Serial.print("Max rain: ");
  Serial.println(maxRain);

  Serial.print("Max showers: ");
  Serial.println(maxShowers);

  Serial.print("Max wind: ");
  Serial.println(maxWind);

  Serial.print("Max gust: ");
  Serial.println(maxGust);

  Serial.print("Max CAPE: ");
  Serial.println(maxCape);

  Serial.print("Max weather code: ");
  Serial.println(maxWeatherCode);

  Serial.print("Status: ");
  Serial.println(status);

  Serial.print("Free heap after JSON: ");
  Serial.println(ESP.getFreeHeap());
  char grid[7];

    latLonToMaidenhead(
      latitude,
      longitude,
      grid);

    Serial.print("Maidenhead locator: ");
    Serial.println(grid);


  queueForecastUpdate(
    status,
    advice);
}
void latLonToMaidenhead(float lat, float lon, char *grid) {

  lon += 180.0f;
  lat += 90.0f;

  grid[0] = 'A' + (int)(lon / 20.0f);
  grid[1] = 'A' + (int)(lat / 10.0f);

  lon = fmod(lon, 20.0f);
  lat = fmod(lat, 10.0f);

  grid[2] = '0' + (int)(lon / 2.0f);
  grid[3] = '0' + (int)(lat / 1.0f);

  lon = fmod(lon, 2.0f);
  lat = fmod(lat, 1.0f);

  grid[4] = 'a' + (int)(lon / (2.0f / 24.0f));
  grid[5] = 'a' + (int)(lat / (1.0f / 24.0f));

  grid[6] = '\0';
}