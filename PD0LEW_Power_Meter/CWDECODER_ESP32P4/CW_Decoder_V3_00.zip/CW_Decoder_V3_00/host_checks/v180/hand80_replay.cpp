#include "CWDecoder.cpp"
#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <cstdlib>
int main(int argc,char**argv){
 CWDecoder::setCwType(1);CWDecoder::setFadingAssist(true);
 CWDecoder::setAutoTone(true);CWDecoder::setInputLevelPercent(30);CWDecoder::setFilterBandwidthHz(60);CWDecoder::begin();
 struct Run{double seconds;bool on;};std::vector<Run> runs;
 const char *message="TEST DE PA0ABC RST 579 NAME JOHN ";unsigned marks=0,chars=0;
 for(int repeat=0;repeat<5;repeat++)for(const char *c=message;*c;c++){
  if(*c==' '){runs.push_back({.32,false});continue;}
  for(auto entry:MORSE_TABLE)if(entry.value==*c){
   for(const char *p=entry.code;*p;p++){
    double duration=*p=='-'?(.145+.02*(marks%4)):(.07+.004*(marks%3));
    runs.push_back({duration,true});runs.push_back({.060,false});++marks;
   }
   runs.push_back({(++chars%3==0?.105:.050),false});break;
  }
 }
 size_t run=0;double left=runs[0].seconds;uint64_t sample=0;uint32_t rng=8197;int32_t slots[960];
 while(run<runs.size()){
  for(int n=0;n<480;n++,sample++){
   left-=1.0/96000;if(left<=0){run++;if(run<runs.size())left+=runs[run].seconds;}
   rng=rng*1664525u+1013904223u;float noise=(float(rng>>8)/16777216.0f*2-1)*12;
   int16_t v=int16_t(noise+(run<runs.size() && runs[run].on?310*sin(2*3.141592653589793*740*sample/96000.0):0));
   slots[2*n]=slots[2*n+1]=int32_t(v)*65536;
  }
  CWDecoder::processI2S32(slots,480);
 }
 std::cout<<decodedText<<"\n";
 return strstr(decodedText,"TEST DE PA0ABC RST 579 NAME JOHN")?0:1;
}
