#pragma once

#include <Arduino.h>
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

struct AppState {
    char pep[16] = "";
    char pk[16] = "";
    char avg_p[16] = "";
    char ref_p[16] = "";
    char dbm[16] = "";
    char utc[32] = "";
    char callsign[32] = "";
    char swrt[16] = "";

    float vswr = 0.0f;

    int rssi = 0;
    int cpl = 0;
    int band = 0;
    int pep_val = 0;

    bool dirty = false;
    bool sseConnected = false;
};

extern AppState gState;
extern SemaphoreHandle_t gStateMutex;