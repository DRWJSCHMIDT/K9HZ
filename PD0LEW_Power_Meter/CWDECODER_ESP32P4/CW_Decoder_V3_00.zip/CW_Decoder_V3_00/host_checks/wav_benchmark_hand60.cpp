#include <algorithm>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

static std::ofstream *gTrace = nullptr;
static void benchTraceMark(uint64_t sampleIndex, float durationMs, float confidence,
                           float thresholdMs, bool isDash, bool accepted);
static void benchTraceGap(uint64_t sampleIndex, float durationMs, float confidence,
                          float thresholdMs, const char *kind);
static void benchTraceChar(uint64_t sampleIndex, const char *rawPattern,
                           const char *finalPattern, char decodedChar);

#define CW_BENCH_TRACE_MARK(sampleIndex, durationMs, confidence, thresholdMs, isDash, accepted) \
  benchTraceMark(sampleIndex, durationMs, confidence, thresholdMs, isDash, accepted)
#define CW_BENCH_TRACE_GAP(sampleIndex, durationMs, confidence, thresholdMs, kind) \
  benchTraceGap(sampleIndex, durationMs, confidence, thresholdMs, kind)
#define CW_BENCH_TRACE_CHAR(sampleIndex, rawPattern, finalPattern, decodedChar) \
  benchTraceChar(sampleIndex, rawPattern, finalPattern, decodedChar)

#include "../src/CWDecoder.cpp"

static void benchTraceMark(uint64_t sampleIndex, float durationMs, float confidence,
                           float thresholdMs, bool isDash, bool accepted) {
  if (!gTrace) return;
  *gTrace << sampleIndex << ",MARK," << durationMs << ',' << confidence << ','
          << thresholdMs << ',' << (isDash ? "DASH" : "DOT") << ','
          << (accepted ? "LEARN" : "NOLEARN") << "\n";
}

static void benchTraceGap(uint64_t sampleIndex, float durationMs, float confidence,
                          float thresholdMs, const char *kind) {
  if (!gTrace) return;
  *gTrace << sampleIndex << ",GAP," << durationMs << ',' << confidence << ','
          << thresholdMs << ',' << (kind ? kind : "") << ",\n";
}

static void benchTraceChar(uint64_t sampleIndex, const char *rawPattern,
                           const char *finalPattern, char decodedChar) {
  if (!gTrace) return;
  *gTrace << sampleIndex << ",CHAR,0,0,0,"
          << (rawPattern ? rawPattern : "") << "->"
          << (finalPattern ? finalPattern : "") << ','
          << (decodedChar ? decodedChar : '?') << "\n";
}

static uint16_t u16le(const uint8_t *p) {
  return static_cast<uint16_t>(p[0] | (static_cast<uint16_t>(p[1]) << 8));
}
static uint32_t u32le(const uint8_t *p) {
  return static_cast<uint32_t>(p[0]) |
         (static_cast<uint32_t>(p[1]) << 8) |
         (static_cast<uint32_t>(p[2]) << 16) |
         (static_cast<uint32_t>(p[3]) << 24);
}

struct WavInfo {
  uint16_t format = 0;
  uint16_t channels = 0;
  uint32_t sampleRate = 0;
  uint16_t bits = 0;
  size_t dataOffset = 0;
  size_t dataBytes = 0;
};

static bool parseWav(const std::vector<uint8_t> &b, WavInfo &w, std::string &err) {
  if (b.size() < 44 || std::memcmp(b.data(), "RIFF", 4) || std::memcmp(b.data()+8, "WAVE", 4)) {
    err = "not a RIFF/WAVE file"; return false;
  }
  size_t p = 12;
  bool haveFmt = false, haveData = false;
  while (p + 8 <= b.size()) {
    const uint32_t n = u32le(&b[p+4]);
    const size_t body = p + 8;
    if (body + n > b.size()) { err = "truncated WAV chunk"; return false; }
    if (!std::memcmp(&b[p], "fmt ", 4) && n >= 16) {
      w.format = u16le(&b[body]);
      w.channels = u16le(&b[body+2]);
      w.sampleRate = u32le(&b[body+4]);
      w.bits = u16le(&b[body+14]);
      haveFmt = true;
    } else if (!std::memcmp(&b[p], "data", 4)) {
      w.dataOffset = body;
      w.dataBytes = n;
      haveData = true;
    }
    p = body + n + (n & 1U);
  }
  if (!haveFmt || !haveData) { err = "missing fmt or data chunk"; return false; }
  if (w.format != 1 || w.bits != 16 || (w.channels != 1 && w.channels != 2)) {
    err = "benchmark supports PCM16 mono/stereo WAV only"; return false;
  }
  if (w.sampleRate != 48000 && w.sampleRate != 96000) {
    err = "benchmark expects 48 kHz or 96 kHz, matching firmware input modes"; return false;
  }
  return true;
}

static std::string jsonEscape(const std::string &s) {
  std::ostringstream o;
  for (unsigned char c : s) {
    switch (c) {
      case '\\': o << "\\\\"; break;
      case '"': o << "\\\""; break;
      case '\n': o << "\\n"; break;
      case '\r': o << "\\r"; break;
      case '\t': o << "\\t"; break;
      default:
        if (c < 0x20) o << "\\u" << std::hex << std::setw(4) << std::setfill('0') << int(c) << std::dec;
        else o << c;
    }
  }
  return o.str();
}

int main(int argc, char **argv) {
  if (argc < 2) {
    std::cerr << "usage: wav_benchmark <48k-or-96k PCM16.wav> [trace.csv]\n";
    return 2;
  }

  std::ifstream f(argv[1], std::ios::binary);
  if (!f) { std::cerr << "cannot open WAV\n"; return 2; }
  std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  WavInfo wav; std::string err;
  if (!parseWav(bytes, wav, err)) { std::cerr << err << "\n"; return 2; }

  std::ofstream trace;
  if (argc >= 3) {
    trace.open(argv[2]);
    if (!trace) { std::cerr << "cannot create trace file\n"; return 2; }
    trace << "dsp_sample,type,duration_ms,confidence,threshold_ms,decision,learning\n";
    gTrace = &trace;
  }

  CWDecoder::setCwType(1);          // HAND-SENT
  CWDecoder::setFadingAssist(true);
  CWDecoder::setWeakSignal(false);
  CWDecoder::setAutoTone(true);
  CWDecoder::setFilterBandwidthHz(60);
  CWDecoder::setInputLevelPercent(30);
  CWDecoder::setInputChannel(0);
  CWDecoder::begin(wav.sampleRate);

  const size_t frameBytes = wav.channels * 2U;
  const size_t frames = wav.dataBytes / frameBytes;
  constexpr size_t kBlock = 256;
  int32_t slots[kBlock * 2];
  std::string transcript;

  auto drain = [&]() {
    char buf[512]; bool overflow = false;
    size_t n;
    while ((n = CWDecoder::readText(buf, sizeof(buf), overflow)) > 0) transcript.append(buf, n);
  };

  for (size_t base = 0; base < frames; base += kBlock) {
    const size_t n = std::min(kBlock, frames - base);
    for (size_t i = 0; i < n; ++i) {
      const size_t pos = wav.dataOffset + (base + i) * frameBytes;
      const int16_t left = static_cast<int16_t>(u16le(&bytes[pos]));
      const int16_t right = wav.channels == 2 ? static_cast<int16_t>(u16le(&bytes[pos+2])) : left;
      slots[2*i] = static_cast<int32_t>(left) << 16;
      slots[2*i+1] = static_cast<int32_t>(right) << 16;
    }
    CWDecoder::processI2S32(slots, n);
    drain();
  }

  // Flush the final character/word exactly the same way a real quiet interval does.
  const size_t silenceFrames = wav.sampleRate * 2U;
  std::fill(std::begin(slots), std::end(slots), 0);
  for (size_t base = 0; base < silenceFrames; base += kBlock) {
    const size_t n = std::min(kBlock, silenceFrames - base);
    CWDecoder::processI2S32(slots, n);
    drain();
  }

  const CWDecoderState st = CWDecoder::getState();
  std::cout << std::fixed << std::setprecision(2)
            << "{\"text\":\"" << jsonEscape(transcript) << "\""
            << ",\"wpm\":" << st.wpm
            << ",\"tone_hz\":" << st.toneHz
            << ",\"snr_db\":" << st.snrDb
            << ",\"spectral_snr_db\":" << st.spectralSnrDb
            << ",\"hand_samples\":" << st.handTimingSamples
            << ",\"hand_stage\":" << int(st.handAcquisitionStage)
            << ",\"hand_style\":\"" << guentherTiming.sendingStyleName() << "\""
            << ",\"outliers_rejected\":" << st.handRejectedOutliers
            << ",\"low_confidence_rejected\":" << st.handRejectedLowConfidence
            << ",\"error_corrections\":" << st.handCorrections
            << ",\"hypothesis_corrections\":" << st.handHypothesisCorrections
            << "}\n";
  return 0;
}
