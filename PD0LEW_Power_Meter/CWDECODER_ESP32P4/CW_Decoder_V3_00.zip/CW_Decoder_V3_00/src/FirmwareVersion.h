#pragma once
#if defined(CW_TIMING_ROLLBACK)
#define CW_FIRMWARE_VERSION "V3.00-RB"
#else
#define CW_FIRMWARE_VERSION "V3.00"
#endif
