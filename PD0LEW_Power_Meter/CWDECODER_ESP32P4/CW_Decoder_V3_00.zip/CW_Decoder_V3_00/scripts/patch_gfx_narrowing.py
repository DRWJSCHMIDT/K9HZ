Import("env")
from pathlib import Path

# Arduino_GFX 1.6.7 uses aggregate initializers that trigger GCC narrowing
# warnings with the ESP32-P4 / ESP-IDF headers used by this project.  Keep
# compiler diagnostics enabled and make the conversions explicit instead of
# globally suppressing -Wnarrowing.
libdeps = Path(env.subst("$PROJECT_LIBDEPS_DIR")) / env.subst("$PIOENV")
candidates = [
    libdeps / "GFX Library for Arduino" / "src" / "databus" / "Arduino_ESP32DSIPanel.cpp",
    libdeps / "Arduino_GFX" / "src" / "databus" / "Arduino_ESP32DSIPanel.cpp",
]

src = next((p for p in candidates if p.exists()), None)
if src is None:
    print("[patch_gfx_narrowing] Arduino_GFX source not present yet; no warning patch applied.")
else:
    text = src.read_text(encoding="utf-8")
    replacements = [
        (".lane_bit_rate_mbps = _lane_bit_rate,",
         ".lane_bit_rate_mbps = static_cast<float>(_lane_bit_rate),"),
        (".dpi_clock_freq_mhz = speed / 1000000,",
         ".dpi_clock_freq_mhz = static_cast<float>(speed) / 1000000.0f,"),
        (".h_size = w,",
         ".h_size = static_cast<uint32_t>(w),"),
        (".v_size = h,",
         ".v_size = static_cast<uint32_t>(h),"),
    ]

    changed = False
    missing = []
    for old, new in replacements:
        if old in text:
            text = text.replace(old, new, 1)
            changed = True
        elif new not in text:
            missing.append(old)

    if changed:
        src.write_text(text, encoding="utf-8")
        print(f"[patch_gfx_narrowing] Applied explicit DSI casts in {src}")
    else:
        print("[patch_gfx_narrowing] DSI narrowing patch already applied")

    if missing:
        print("[patch_gfx_narrowing] WARNING: one or more expected Arduino_GFX lines were not found")
        for line in missing:
            print(f"  missing: {line}")
