/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#ifndef _PSWR_vLCD_h_
#define _PSWR_vLCD_h_

#include <Arduino.h>
#include "PSWR_Config.h"

#define LCD_TEXTSIZE 210

class TextLCD
{
  public:
    TextLCD();

    // Initialize dimensions. The active matrix is always clamped to LCD_TEXTSIZE.
    void init(uint8_t columns, uint8_t rows);
    void init(void) { init(OLED_COLUMNS, OLED_ROWS); }

    // Transfer only changed character positions to the physical display.
    void transfer(void);

    void write(char ch);
    void print(const char *text);
    void setCursor(uint8_t x, uint8_t y);
    void clear(void);

  private:
    uint8_t Col;
    uint8_t Row;
    char text_lcd[LCD_TEXTSIZE + 1];
    char virt_lcd[LCD_TEXTSIZE + 1];
    uint8_t virt_x;
    uint8_t virt_y;

    uint16_t activeSize(void) const;
};

#endif
