/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_CallSign.h"
#include "PSWR_Eeprom.h"

#include <EEPROM.h>
#include <string.h>

namespace
{
// Legacy V3.46 two-bank calibration storage occupies EEPROM 128..231.
// Keep the callsign record at its proven independent address; V3.47 places
// the new eight-bank calibration store later, after the Startup Logo record.
constexpr int CALLSIGN_EEPROM_ADDR = 240;
constexpr uint32_t CALLSIGN_MAGIC = 0x4A48434CUL; // "JHCL"
constexpr uint8_t CALLSIGN_VERSION = 2;
constexpr uint8_t LEGACY_CALLSIGN_VERSION = 1;
constexpr size_t CALLSIGN_MAX_CHARS = 30;
constexpr size_t LEGACY_CALLSIGN_MAX_CHARS = 15;

constexpr char kFactoryCall[] = "Your Call";
constexpr char kUpgradeCall[] = "PD0LEW";

struct CallSignStore
{
  uint32_t magic;
  uint8_t version;
  char text[CALLSIGN_MAX_CHARS + 1];
};

// V3.03 stored a maximum of 15 characters in a 24-byte record.
// Keep the exact old layout here so an existing user callsign is migrated
// automatically when V3.04 first starts.
struct LegacyCallSignStore
{
  uint32_t magic;
  uint8_t version;
  char text[LEGACY_CALLSIGN_MAX_CHARS + 1];
  uint8_t reserved[3];
};

static_assert(sizeof(CallSignStore) == 36, "Unexpected callsign EEPROM layout");
static_assert(sizeof(LegacyCallSignStore) == 24, "Unexpected legacy callsign EEPROM layout");

CallSignStore store = {};

bool textIsValid(const char *text)
{
  if (!text) return false;

  const size_t len = strnlen(text, CALLSIGN_MAX_CHARS + 1);
  if (len == 0 || len > CALLSIGN_MAX_CHARS) return false;

  for (size_t i = 0; i < len; ++i)
  {
    const unsigned char c = (unsigned char)text[i];
    if (c < 32U || c > 126U) return false;
  }
  return true;
}

bool storeIsValid(const CallSignStore &candidate)
{
  if (candidate.magic != CALLSIGN_MAGIC || candidate.version != CALLSIGN_VERSION)
    return false;

  if (candidate.text[CALLSIGN_MAX_CHARS] != '\0') return false;
  return textIsValid(candidate.text);
}

bool legacyStoreIsValid(const LegacyCallSignStore &candidate)
{
  if (candidate.magic != CALLSIGN_MAGIC || candidate.version != LEGACY_CALLSIGN_VERSION)
    return false;

  if (candidate.text[LEGACY_CALLSIGN_MAX_CHARS] != '\0') return false;

  const size_t len = strnlen(candidate.text, LEGACY_CALLSIGN_MAX_CHARS + 1);
  if (len == 0 || len > LEGACY_CALLSIGN_MAX_CHARS) return false;

  for (size_t i = 0; i < len; ++i)
  {
    const unsigned char c = (unsigned char)candidate.text[i];
    if (c < 32U || c > 126U) return false;
  }
  return true;
}

void persistText(const char *text)
{
  store = {};
  store.magic = CALLSIGN_MAGIC;
  store.version = CALLSIGN_VERSION;
  strncpy(store.text, text, CALLSIGN_MAX_CHARS);
  store.text[CALLSIGN_MAX_CHARS] = '\0';
  EEPROM_writeAnything(CALLSIGN_EEPROM_ADDR, store);
}
}

void callsign_begin(bool forceReset)
{
  if (forceReset)
  {
    persistText(kFactoryCall);
    return;
  }

  CallSignStore loaded = {};
  EEPROM_readAnything(CALLSIGN_EEPROM_ADDR, loaded);

  if (storeIsValid(loaded))
  {
    store = loaded;
    return;
  }

  // Seamless V3.03 -> V3.04 migration: preserve an already programmed
  // 15-character callsign record when expanding the field to 30 characters.
  LegacyCallSignStore legacy = {};
  EEPROM_readAnything(CALLSIGN_EEPROM_ADDR, legacy);
  if (legacyStoreIsValid(legacy))
  {
    persistText(legacy.text);
    return;
  }

  // Seamless V3.01 -> V3.04 migration: retain the previous hard-coded call.
  // A later Factory Reset or $memorywipe deliberately changes it to "Your Call".
  persistText(kUpgradeCall);
}

bool callsign_set(const char *text)
{
  if (!text) return false;

  // Copy first so trailing spaces from a terminal can be removed safely.
  char cleaned[CALLSIGN_MAX_CHARS + 2] = {};
  strncpy(cleaned, text, sizeof(cleaned) - 1);

  size_t len = strlen(cleaned);
  while (len > 0 && (cleaned[len - 1] == ' ' || cleaned[len - 1] == '\t'))
    cleaned[--len] = '\0';

  if (!textIsValid(cleaned)) return false;

  persistText(cleaned);
  return true;
}

const char *callsign_get(void)
{
  return storeIsValid(store) ? store.text : kFactoryCall;
}
