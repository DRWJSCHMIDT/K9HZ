#pragma once
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

struct MeterState {
    char  pep[20]       = "0.0W";
    float vswr          = 1.0f;
    char  pk[20]        = "0.0W";
    char  avg_p[20]     = "0.0W";
    char  ref_p[20]     = "0.0W";
    char  dbm[12]       = "0.0";
    char  utc[12]       = "00:00:00";
    char  callsign[20]  = "--";
    int   rssi          = -100;
    int   cpl           = 1;
    int   band          = 0;    // 0=HF 1=6M 2=2M 3=70cm
    int   pep_val       = 1;    // 1=100ms 2=1s 3=2s
    char  swrt[20]      = "Off";
    bool  sseConnected  = false;
    volatile bool dirty = false;
};

extern MeterState         gState;
extern SemaphoreHandle_t  gStateMutex;
extern bool               gIsCapacitive;
