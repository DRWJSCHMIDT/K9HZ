# JH2KW-M V3.102 — PlatformIO

PlatformIO conversion of the JH2KW-M V3.102 Teensy 4.0 firmware.

## Target

- MCU: Teensy 4.0 / IMXRT1062
- CPU: 600 MHz
- Framework: Arduino / Teensy
- Display: NHD-3.12-25664UCB2, SSD1322 256x64 OLED
- ADC: AD7991 using the V3.102 3 MHz High-Speed data-phase timing

## Build

Open this folder in VS Code with PlatformIO installed, then use **Build**.
The default environment is `teensy40`.

Command line equivalent:

```text
pio run
```

## Upload

Connect the Teensy 4.0 over USB and use **Upload**.
The project uses `teensy-gui`, matching the existing 5-inch TFT PlatformIO project.

Command line equivalent:

```text
pio run -t upload
```

## Serial monitor

```text
pio device monitor
```

Monitor speed is 115200 baud. The Teensy USB type is Serial (`USB_SERIAL`).

## Libraries

`Chrono` is bundled in `lib/Chrono`, copied from the proven 5-inch TFT PlatformIO project.
PlatformIO resolves the SSD1322/Adafruit/U8g2 display dependencies from `lib_deps`.
The Teensy framework supplies SPI, Wire, EEPROM, Metro, Encoder and TimerOne.

## V3.102 firmware status

This conversion intentionally changes no measurement logic. It contains the exact V3.102
firmware modules, including the controlled AD7991 High-Speed timing test at 3 MHz and the
V3.101-derived START/TAIL/PEP/PK protection logic.

The Arduino wrapper is preserved under `arduino_reference/` for comparison and is not compiled.
