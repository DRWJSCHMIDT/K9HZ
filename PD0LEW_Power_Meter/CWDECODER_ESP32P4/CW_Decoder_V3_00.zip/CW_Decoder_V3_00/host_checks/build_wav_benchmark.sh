#!/bin/sh
set -eu
cd "$(dirname "$0")"
g++ -std=c++17 -O2 -I./stubs -I../src wav_benchmark.cpp -o wav_benchmark
echo "Built: host_checks/wav_benchmark"
