#include "AppSettings.cpp"
#include <cassert>
#include <iostream>
int main(){
 AppSettings::begin();assert(!AppSettings::monitorFiltered());
 AppSettings::setMonitorFiltered(true);assert(Preferences::data["hpfilter"]==1);
 ready=false;monitorFilteredValue=false;AppSettings::begin();assert(AppSettings::monitorFiltered());
 AppSettings::setMonitorFiltered(false);ready=false;monitorFilteredValue=true;
 AppSettings::begin();assert(!AppSettings::monitorFiltered());
 std::cout<<"PASS: default BEFORE, AFTER persistence, BEFORE persistence\n";
}
