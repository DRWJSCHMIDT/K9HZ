#ifndef LV_CONF_H
#define LV_CONF_H

//#define LV_COLOR_DEPTH 32

#define LV_USE_SLIDER 1
#define LV_USE_CANVAS 1

// V2.10: the setup UI has grown beyond the safe margin of LVGL 9.5's
// default 64 kB built-in heap. PlatformIO also defines LV_MEM_SIZE globally
// so LVGL library translation units receive the same value.
#ifndef LV_MEM_SIZE
#define LV_MEM_SIZE (128U * 1024U)
#endif


// Montserrat fonts
#define LV_FONT_MONTSERRAT_8  0
#define LV_FONT_MONTSERRAT_10 0
#define LV_FONT_MONTSERRAT_12 0
#define LV_FONT_MONTSERRAT_14 0 // system default font
#define LV_FONT_MONTSERRAT_16 0
#define LV_FONT_MONTSERRAT_18 0
#define LV_FONT_MONTSERRAT_20 0
#define LV_FONT_MONTSERRAT_22 0
#define LV_FONT_MONTSERRAT_24 1
#define LV_FONT_MONTSERRAT_26 1
#define LV_FONT_MONTSERRAT_28 1
#define LV_FONT_MONTSERRAT_30 1
#define LV_FONT_MONTSERRAT_32 1
#define LV_FONT_MONTSERRAT_34 0
#define LV_FONT_MONTSERRAT_36 1
#define LV_FONT_MONTSERRAT_38 0
#define LV_FONT_MONTSERRAT_40 0
#define LV_FONT_MONTSERRAT_42 0
#define LV_FONT_MONTSERRAT_44 0
#define LV_FONT_MONTSERRAT_46 0
#define LV_FONT_MONTSERRAT_48 1
#define LV_FONT_DEFAULT &lv_font_montserrat_32 // Important used for buttons font!


#endif
