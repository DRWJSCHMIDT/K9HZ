#pragma once
#include <stdint.h>
#include <math.h>
// UI-only measurement hold. Fresh spectra, not repeated UI frames, count.
class TuningGuide {
public:
  float measured = 700;
  bool seen = false;
  uint32_t sequence = 0, lastGood = 0, lastSample = 0;
  unsigned stable = 0;
  void update(uint32_t now, uint32_t seq, bool valid, float hz) {
    if (seq == sequence) return;
    sequence = seq;
    if (!valid || !isfinite(hz)) { stable = 0; return; }
    if (stable==0 || now-lastSample>300 || fabsf(hz-measured)>20) {
      measured=hz; stable=1;
    } else { measured += 0.4f*(hz-measured); if(stable<3)++stable; }
    lastSample=now;
    if(stable>=2) { seen=true; lastGood=now; }
  }
  bool available(uint32_t now) const { return seen && now-lastGood<=600; }
};
