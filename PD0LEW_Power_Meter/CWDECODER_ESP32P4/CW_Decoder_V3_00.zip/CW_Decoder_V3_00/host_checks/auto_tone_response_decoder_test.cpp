#include "CWDecoder.cpp"
#include <cassert>
#include <cstdio>

int main() {
  CWDecoder::begin(48000);
  assert(CWDecoder::autoToneResponseMs() == 500);
  CWDecoder::setAutoToneResponseMs(150);
  assert(CWDecoder::autoToneResponseMs() == 150);
  CWDecoder::setAutoToneResponseMs(1000);
  assert(CWDecoder::autoToneResponseMs() == 1000);
  CWDecoder::setAutoToneResponseMs(2000);
  assert(CWDecoder::autoToneResponseMs() == 2000);
  CWDecoder::setAutoToneResponseMs(1234);
  assert(CWDecoder::autoToneResponseMs() == 500);
  std::puts("PASS: AUTO TONE response runtime setter and safe default");
}
