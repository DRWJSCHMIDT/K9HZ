Import("env")
import os
import gzip
import shutil

# Path to the generated littlefs bin
build_dir = env.subst("$BUILD_DIR")
project_dir = env["PROJECT_DIR"]
data_dir = os.path.join(project_dir, "data")
littlefs_file = os.path.join(build_dir, "littlefs.bin")

COMPRESS_EXTS = {".html", ".css", ".js", ".json", ".svg", ".txt", ".xml", ".md"}

def gzip_file(src_path):
    gz_path = src_path + ".gz"
    if os.path.exists(gz_path) and os.path.getmtime(gz_path) >= os.path.getmtime(src_path):
        return
    with open(src_path, "rb") as f_in, gzip.open(gz_path, "wb", compresslevel=9) as f_out:
        shutil.copyfileobj(f_in, f_out)
    print("Compressed " + src_path + " -> " + gz_path)

def cleanup_stale_gz(data_root):
    for root, _, files in os.walk(data_root):
        for name in files:
            if not name.endswith(".gz"):
                continue
            gz_path = os.path.join(root, name)
            src_path = gz_path[:-3]
            if not os.path.exists(src_path):
                print("Removing stale compressed file: " + gz_path)
                os.remove(gz_path)

print("BEGIN PRE-BUILD SCRIPT")

# Remove .gz files whose source asset no longer exists.
cleanup_stale_gz(data_dir)

# Generate .gz siblings for compressible files in data/
for root, _, files in os.walk(data_dir):
    for name in files:
        if name.endswith(".gz"):
            continue
        ext = os.path.splitext(name)[1].lower()
        if ext in COMPRESS_EXTS:
            gzip_file(os.path.join(root, name))

# Delete the file if it exists
if os.path.exists(littlefs_file):
    print("Forcing LittleFS rebuild: Removing " + littlefs_file)
    os.remove(littlefs_file)
