#ifndef DISPLAY_SETUP_H
#define DISPLAY_SETUP_H

#include <Arduino.h>
#include <lvgl.h>   // Must be before using lv_obj_t

void update();
namespace DisplaySetup {

bool begin();

void update();

void setBrightness(uint8_t brightness);

bool getTouch(int32_t &x, int32_t &y);

// Activity flag only; does not change brightness or LVGL state.
bool consumeTouchActivity();

void enableTouchDebug(bool enabled);

// V2.10: after changing a full-screen setup page, ignore any residual GT911
// press state until LVGL observes a clean release.
void waitForTouchRelease();

void applyScreenStyle(lv_obj_t *screen);

}  // namespace DisplaySetup

#endif  // DISPLAY_SETUP_H