#ifndef CW_DECODER_H
#define CW_DECODER_H

#include <Arduino.h>
#include <stddef.h>
#include <stdint.h>

struct CWDecoderState {
  static constexpr size_t kSpectrumBins = 41;   // 300..1000 Hz; interpolated tone estimate
  static constexpr size_t kDecodedText = 1024;

  bool weakSignal = false;
  bool toneLocked = false;
  float spectrumMinHz = 300.0f;
  float spectrumMaxHz = 1000.0f;
  bool running = false;
  bool autoTone = true;
  bool keyDown = false;
  uint8_t inputChannel = 0;                     // 0 = left, 1 = right

  float toneHz = 700.0f;
  float peakHz = 700.0f;                         // actual interpolated spectrum peak
  // Independent measurement for manual tuning, never substituted for detector tone.
  float measuredToneHz = 700.0f;
  bool measuredToneValid = false;
  uint32_t spectrumSequence = 0;
  float wpm = 20.0f;
  float signalDbfs = -120.0f;
  float noiseDbfs = -120.0f;
  float snrDb = 0.0f;
  float spectralSnrDb = 0.0f;
  float confidence = 0.0f;
  uint16_t filterBandwidthHz = 40;

  // V1.91 confidence-gated adaptive timing learner. Learning can be frozen
  // without discarding the already learned profile.
  bool adaptiveLearning = true;
  bool learningApplied = false;
  uint8_t learningQuality = 0;
  uint16_t learningSamples = 0;
  uint32_t learningRevision = 0;
  float learnedMarkThresholdRatio = 0.0f;
  float learnedLetterGapRatio = 0.0f;

  // V2.22 HAND-SENT diagnostics. These are published for host benchmarking
  // and future service/debug pages; the normal UI does not need to display them.
  bool handTimingReady = false;
  bool handTimingFullyAcquired = false;
  uint8_t handAcquisitionStage = 0; // 0 fast, 1 refine, 2 tracking
  uint8_t handSendingStyle = 0;     // GuentherTiming::SendingStyle numeric value
  uint16_t handTimingSamples = 0;
  uint16_t handRejectedOutliers = 0;
  uint16_t handRejectedLowConfidence = 0;
  uint32_t handCorrections = 0;
  uint32_t handHypothesisCorrections = 0;

  uint32_t decodedCharacters = 0;
  char currentMorse[16] = {};
  char lastMorse[16] = {};
  char decodedText[kDecodedText] = {};
  uint8_t spectrum[kSpectrumBins] = {};
};

namespace CWDecoder {

constexpr uint32_t INPUT_SAMPLE_RATE = 96000;
constexpr uint32_t DSP_SAMPLE_RATE = 12000;
constexpr uint8_t DECIMATION = 8;
constexpr float SPECTRUM_MIN_HZ = 300.0f;
constexpr float SPECTRUM_MAX_HZ = 1000.0f;
constexpr float SPECTRUM_STEP_HZ = 17.5f;

void begin(uint32_t inputSampleRate = INPUT_SAMPLE_RATE);
// Live 48/96 kHz test switching: update only the input/decimation side and
// reset transient DSP state while preserving the decoded transcript and settings.
void reconfigureInputSampleRate(uint32_t inputSampleRate);

// I2S data is stereo, 32-bit slots, with the valid SGTL5000 16-bit sample
// in the upper half of every slot: L32, R32, L32, R32, ...
void processI2S32(const int32_t *interleavedSlots, size_t frameCount);

CWDecoderState getState();

// 0 Standard, 1 Hand-sent, 2 Farnsworth, 3 Slow, 4 Fast.
void setCwType(uint8_t type);
void setFadingAssist(bool enabled);
void setFarnsworthSpacing(uint8_t tenths); // 15, 20 or 30
void setWeakSignal(bool enabled);
bool weakSignalEnabled();

// V1.91 adaptive learning. OFF freezes the current profile; RESET clears it.
void setAdaptiveLearning(bool enabled);
bool adaptiveLearningEnabled();
void resetAdaptiveLearning();
void setAdaptiveLearningProfile(float markThresholdRatio, float letterGapRatio, uint8_t quality);

void setAutoTone(bool enabled);
bool autoToneEnabled();
// Normal-mode AUTO TONE tracking response. Initial acquisition remains fast.
void setAutoToneResponseMs(uint16_t ms);
uint16_t autoToneResponseMs();
void setManualTone(float hz);
float manualToneSettingHz();
void adjustManualTone(float deltaHz);

void setInputChannel(uint8_t channel);
uint8_t inputChannel();

void setInputTrimDb(int8_t db);
int8_t inputTrimDb();
void adjustInputTrimDb(int8_t deltaDb);

void setInputLevelPercent(uint8_t percent);
uint8_t inputLevelPercent();

void setFilterBandwidthHz(uint16_t hz);
uint16_t filterBandwidthHz();

void clearText();
// Single UI consumer; drains every decoded byte, including spaces.
size_t readText(char *out, size_t capacity, bool &overflow);
// Applied by the audio task at a block boundary; keeps the transcript.
void relock();
// True until the audio task finishes applying the requested reset.
bool relockPending();

} // namespace CWDecoder

#endif
