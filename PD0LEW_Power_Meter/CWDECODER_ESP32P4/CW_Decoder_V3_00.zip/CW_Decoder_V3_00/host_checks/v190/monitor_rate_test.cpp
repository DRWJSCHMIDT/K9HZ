#include "MonitorFilter.h"
#include <cassert>
#include <cmath>
#include <cstdio>
static double gain(unsigned rate,float hz) {
  MonitorFilter f; double sum=0; unsigned settle=rate, total=rate*2;
  for(unsigned n=0;n<total;++n) {
    if(n%256==0) f.configure(750,40,false,true,rate);
    int16_t x=int16_t(std::lround(2000*std::sin(6.28318530718*hz*n/rate)));
    int16_t y=f.process(x); if(n>=settle) sum+=double(y)*y;
  }
  return std::sqrt(sum/rate)/std::sqrt(2000000.0);
}
int main(){
  for(unsigned rate: {48000u,96000u}) {
    double pass=gain(rate,750), reject=gain(rate,1250);
    std::printf("%u Hz: pass %.4f reject %.4f\n", rate,pass,reject);
    assert(pass>0.97&&pass<1.03&&reject<0.01);
  }
  std::puts("PASS: monitor filter tracks both 48 and 96 kHz");
}
