esptool erase_flash
esptool --chip esp32 merge_bin --output merged_firmware.bin  --flash_mode dio --flash_freq 40m --flash_size 4MB  0x1000 .pio\build\esp32dev\bootloader.bin  0x8000 .pio\build\esp32dev\partitions.bin  0x10000 .pio\build\esp32dev\firmware.bin  0x290000 .pio\build\esp32dev\littlefs.bin
esptool -b 921600 write_flash 0x0 merged_firmware.bin    