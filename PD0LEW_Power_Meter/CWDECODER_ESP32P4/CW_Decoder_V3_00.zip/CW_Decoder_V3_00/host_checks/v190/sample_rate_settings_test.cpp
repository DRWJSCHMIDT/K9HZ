#include "AppSettings.cpp"
#include <cassert>
#include <cstdio>
int main(){
  Preferences::data.clear();
  ready=false; sampleRate96Value=true;
  AppSettings::begin();
  assert(AppSettings::audioSampleRateHz()==96000u);
  AppSettings::setAudioSampleRateHz(48000u);
  assert(AppSettings::audioSampleRateHz()==48000u);
  assert(Preferences::data["sr96"]==0);
  ready=false; sampleRate96Value=true;
  AppSettings::begin();
  assert(AppSettings::audioSampleRateHz()==48000u);
  AppSettings::setAudioSampleRateHz(96000u);
  assert(Preferences::data["sr96"]==1);
  std::puts("PASS: 96 kHz default and 48/96 persistence");
}
