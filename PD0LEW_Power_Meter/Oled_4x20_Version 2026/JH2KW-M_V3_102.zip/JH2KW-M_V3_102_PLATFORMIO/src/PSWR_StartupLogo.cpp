/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#include "PSWR_StartupLogo.h"
#include "PSWR_State.h"
#include "PSWR_Eeprom.h"

#include <EEPROM.h>
#include <math.h>

namespace
{
constexpr int LOGO_EEPROM_ADDR = 280; // Callsign block ends at 275.
constexpr uint32_t LOGO_MAGIC = 0x4A484C47UL; // "JHLG"
constexpr uint8_t LOGO_VERSION = 1;

struct StartupLogoStore
{
  uint32_t magic;
  uint8_t version;
  uint8_t index;
  uint8_t reserved[2];
};

static_assert(sizeof(StartupLogoStore) == 8, "Unexpected startup-logo EEPROM layout");

StartupLogoStore store = {};

const char * const kLogoNames[STARTUP_LOGO_COUNT] =
{
  "RF TOWER",
  "SCOPE WAVE",
  "SWR METER",
  "COUPLER",
  "FWD / REV",
  "RF WAVE",
  "ANTENNA",
  "RF BARS",
  "RF PULSE"
};

bool storeIsValid(const StartupLogoStore &candidate)
{
  return candidate.magic == LOGO_MAGIC &&
         candidate.version == LOGO_VERSION &&
         candidate.index < STARTUP_LOGO_COUNT;
}

void persist(uint8_t index)
{
  store = {};
  store.magic = LOGO_MAGIC;
  store.version = LOGO_VERSION;
  store.index = (index < STARTUP_LOGO_COUNT) ? index : STARTUP_LOGO_DEFAULT;
  EEPROM_writeAnything(LOGO_EEPROM_ADDR, store);
}

void drawArc(int16_t cx, int16_t cy, int16_t r,
             int16_t startDeg, int16_t endDeg, uint8_t shade)
{
  if (r <= 0) return;
  int16_t lastX = cx;
  int16_t lastY = cy;
  bool haveLast = false;

  for (int16_t deg = startDeg; deg <= endDeg; deg += 8)
  {
    const float rad = (float)deg * 0.01745329252f;
    const int16_t px = cx + (int16_t)lroundf(cosf(rad) * r);
    const int16_t py = cy + (int16_t)lroundf(sinf(rad) * r);
    if (haveLast)
      lcd.drawLine(lastX, lastY, px, py, shade);
    lastX = px;
    lastY = py;
    haveLast = true;
  }

  if ((endDeg - startDeg) % 8 != 0)
  {
    const float rad = (float)endDeg * 0.01745329252f;
    const int16_t px = cx + (int16_t)lroundf(cosf(rad) * r);
    const int16_t py = cy + (int16_t)lroundf(sinf(rad) * r);
    lcd.drawLine(lastX, lastY, px, py, shade);
  }
}

void tinyText(int16_t centerX, int16_t baselineY, const char *text, uint8_t shade)
{
  u8g2.setFont(u8g2_font_5x7_tf);
  u8g2.setFontMode(1);
  u8g2.setFontDirection(0);
  u8g2.setForegroundColor(shade);
  const int16_t w = u8g2.getUTF8Width(text);
  u8g2.setCursor(centerX - w / 2, baselineY);
  u8g2.print(text);
}

void drawLogo1Tower(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  const int16_t cx = x + 26;
  const int16_t top = y + 13;
  const int16_t base = y + 39;

  // Three radio-wave arcs from the concept drawing.
  drawArc(cx, top + 1, 8, 205, 335, bright);
  drawArc(cx, top + 1, 14, 205, 335, bright);
  drawArc(cx, top + 1, 20, 205, 335, medium);

  lcd.fillCircle(cx, top + 1, 2, bright);

  // Triangular radio mast with cross braces.
  lcd.drawLine(cx, top + 3, x + 16, base, bright);
  lcd.drawLine(cx, top + 3, x + 36, base, bright);
  lcd.drawLine(x + 16, base, x + 36, base, bright);
  lcd.drawLine(x + 21, y + 30, x + 31, y + 30, medium);
  lcd.drawLine(x + 19, y + 35, x + 33, y + 35, medium);
  lcd.drawLine(x + 21, y + 30, x + 33, y + 35, medium);
  lcd.drawLine(x + 31, y + 30, x + 19, y + 35, medium);

  // Small ground shadow from the reference image.
  lcd.drawLine(x + 12, base + 3, x + 40, base + 3, dim);
  lcd.drawLine(x + 17, base + 4, x + 35, base + 4, dim);
}

void drawLogo2ScopeWave(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  const int16_t cx = x + 26;
  const int16_t cy = y + 22;
  lcd.drawCircle(cx, cy, 20, medium);

  // Clock-like ticks around the circular scope face.
  const int16_t tickAngles[] = {210, 240, 270, 300, 330, 30, 60, 90, 120, 150};
  for (uint8_t i = 0; i < sizeof(tickAngles) / sizeof(tickAngles[0]); ++i)
  {
    const float a = (float)tickAngles[i] * 0.01745329252f;
    const int16_t x1 = cx + (int16_t)lroundf(cosf(a) * 15);
    const int16_t y1 = cy + (int16_t)lroundf(sinf(a) * 15);
    const int16_t x2 = cx + (int16_t)lroundf(cosf(a) * 18);
    const int16_t y2 = cy + (int16_t)lroundf(sinf(a) * 18);
    lcd.drawLine(x1, y1, x2, y2, (i % 2) ? medium : bright);
  }

  // Sine-like waveform across the centre, matching option 2.
  int16_t lastX = x + 7;
  int16_t lastY = cy;
  for (int16_t px = x + 8; px <= x + 45; ++px)
  {
    const float phase = (float)(px - (x + 8)) * 0.52f;
    const int16_t py = cy + (int16_t)lroundf(sinf(phase) * 7.0f);
    lcd.drawLine(lastX, lastY, px, py, bright);
    lastX = px;
    lastY = py;
  }
  lcd.drawLine(x + 5, cy, x + 8, cy, dim);
  lcd.drawLine(x + 45, cy, x + 48, cy, dim);
}

void drawLogo3SwrMeter(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  const int16_t cx = x + 26;
  const int16_t cy = y + 29;

  drawArc(cx, cy, 20, 190, 350, medium);
  drawArc(cx, cy, 18, 190, 350, dim);

  // Gauge ticks.
  for (int16_t deg = 200; deg <= 340; deg += 20)
  {
    const float a = (float)deg * 0.01745329252f;
    const int16_t x1 = cx + (int16_t)lroundf(cosf(a) * 14);
    const int16_t y1 = cy + (int16_t)lroundf(sinf(a) * 14);
    const int16_t x2 = cx + (int16_t)lroundf(cosf(a) * 18);
    const int16_t y2 = cy + (int16_t)lroundf(sinf(a) * 18);
    lcd.drawLine(x1, y1, x2, y2, bright);
  }

  // Needle toward the upper-right, like the concept drawing.
  const float na = 315.0f * 0.01745329252f;
  lcd.drawLine(cx, cy, cx + (int16_t)lroundf(cosf(na) * 15),
               cy + (int16_t)lroundf(sinf(na) * 15), bright);
  lcd.fillCircle(cx, cy, 2, bright);
  tinyText(cx, y + 43, "SWR", medium);
}

void drawLogo4Coupler(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  const int16_t cx = x + 26;
  const int16_t cy = y + 23;

  // Central coupler block.
  lcd.drawRect(cx - 8, cy - 6, 16, 12, medium);
  lcd.fillRect(cx - 6, cy - 4, 12, 8, dim);

  // FWD arrow from left and REV arrow from right.
  lcd.drawLine(x + 3, cy, cx - 9, cy, bright);
  lcd.drawLine(cx - 12, cy - 3, cx - 9, cy, bright);
  lcd.drawLine(cx - 12, cy + 3, cx - 9, cy, bright);

  lcd.drawLine(x + 49, cy, cx + 9, cy, bright);
  lcd.drawLine(cx + 12, cy - 3, cx + 9, cy, bright);
  lcd.drawLine(cx + 12, cy + 3, cx + 9, cy, bright);

  // Wireless/RF arcs above and below the block.
  // Keep the Coupler logo compact enough for the 64 px OLED while
  // preserving the same RF-arc shape.
  drawArc(cx, cy - 6, 10, 205, 335, bright);
  drawArc(cx, cy - 6, 14, 210, 330, medium);
  drawArc(cx, cy + 6, 10, 25, 155, bright);
  drawArc(cx, cy + 6, 14, 30, 150, medium);
}

void drawLogo5FwdRev(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  const int16_t cx = x + 26;
  const int16_t cy = y + 22;
  lcd.drawCircle(cx, cy, 20, medium);

  tinyText(cx, y + 11, "FWD", bright);
  tinyText(cx, y + 39, "REV", bright);

  // Strong right-pointing arrow through the centre.
  lcd.drawLine(x + 8, cy, x + 41, cy, bright);
  lcd.drawLine(x + 34, cy - 6, x + 41, cy, bright);
  lcd.drawLine(x + 34, cy + 6, x + 41, cy, bright);
  lcd.drawLine(x + 9, cy - 1, x + 34, cy - 1, dim);
}

void drawLogo6Wave(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  const int16_t cy = y + 22;
  lcd.drawLine(x + 4, cy, x + 48, cy, dim);

  // Tall multi-lobe RF envelope copied closely from concept option 6.
  const int16_t px[] = {4,8,11,14,17,20,23,26,29,32,35,38,41,44,48};
  const int16_t py[] = {22,22,18,28,12,32,5,39,9,34,14,29,19,22,22};
  constexpr uint8_t n = sizeof(px) / sizeof(px[0]);
  for (uint8_t i = 1; i < n; ++i)
  {
    const uint8_t shade = (i >= 5 && i <= 10) ? bright : medium;
    lcd.drawLine(x + px[i - 1], y + py[i - 1], x + px[i], y + py[i], shade);
  }
}

void drawLogo7AntennaDiamond(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  // Diamond frame.
  lcd.drawLine(x + 26, y + 2, x + 5, y + 22, medium);
  lcd.drawLine(x + 5, y + 22, x + 26, y + 42, medium);
  lcd.drawLine(x + 26, y + 42, x + 47, y + 22, medium);
  lcd.drawLine(x + 47, y + 22, x + 26, y + 2, medium);

  // Stylised vertical antenna inside.
  lcd.drawLine(x + 26, y + 10, x + 26, y + 35, bright);
  lcd.drawLine(x + 16, y + 15, x + 26, y + 24, bright);
  lcd.drawLine(x + 36, y + 15, x + 26, y + 24, bright);
  lcd.drawLine(x + 19, y + 20, x + 26, y + 27, medium);
  lcd.drawLine(x + 33, y + 20, x + 26, y + 27, medium);
  lcd.drawLine(x + 21, y + 35, x + 31, y + 35, dim);
}

void drawLogo8RfBars(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  constexpr int16_t bottom = 33;
  const int16_t heights[6] = {6, 10, 15, 20, 26, 32};
  for (uint8_t i = 0; i < 6; ++i)
  {
    const int16_t bx = x + 8 + i * 6;
    const uint8_t shade = (i >= 4) ? bright : (i >= 2 ? medium : dim);
    lcd.fillRect(bx, y + bottom - heights[i], 4, heights[i], shade);
  }
  tinyText(x + 26, y + 43, "RF", bright);
}

void drawLogo9PulseCircle(int16_t x, int16_t y, uint8_t bright, uint8_t medium, uint8_t dim)
{
  const int16_t cx = x + 26;
  const int16_t cy = y + 22;
  lcd.drawCircle(cx, cy, 20, medium);
  lcd.drawCircle(cx, cy, 16, dim);

  lcd.drawLine(x + 7, cy, x + 15, cy, dim);
  lcd.drawLine(x + 15, cy, x + 20, cy, bright);
  lcd.drawLine(x + 20, cy, x + 23, y + 15, bright);
  lcd.drawLine(x + 23, y + 15, x + 28, y + 31, bright);
  lcd.drawLine(x + 28, y + 31, x + 33, y + 11, bright);
  lcd.drawLine(x + 33, y + 11, x + 38, cy, bright);
  lcd.drawLine(x + 38, cy, x + 45, cy, bright);
}
}

void startup_logo_begin(bool forceReset)
{
  if (forceReset)
  {
    persist(STARTUP_LOGO_DEFAULT);
    return;
  }

  StartupLogoStore loaded = {};
  EEPROM_readAnything(LOGO_EEPROM_ADDR, loaded);
  if (storeIsValid(loaded))
  {
    store = loaded;
    return;
  }

  // First firmware containing selectable logos: preserve the V3.24 visual by
  // choosing Logo 6 (RF waveform) on upgrade.
  persist(STARTUP_LOGO_DEFAULT);
}

bool startup_logo_set(uint8_t index)
{
  if (index >= STARTUP_LOGO_COUNT) return false;
  persist(index);
  return true;
}

uint8_t startup_logo_get(void)
{
  return storeIsValid(store) ? store.index : STARTUP_LOGO_DEFAULT;
}

const char *startup_logo_name(uint8_t index)
{
  if (index >= STARTUP_LOGO_COUNT) index = STARTUP_LOGO_DEFAULT;
  return kLogoNames[index];
}

void startup_logo_draw(int16_t x, int16_t y, uint8_t index,
                       uint8_t bright, uint8_t medium, uint8_t dim)
{
  if (index >= STARTUP_LOGO_COUNT) index = STARTUP_LOGO_DEFAULT;

  switch (index)
  {
    case 0: drawLogo1Tower(x, y, bright, medium, dim); break;
    case 1: drawLogo2ScopeWave(x, y, bright, medium, dim); break;
    case 2: drawLogo3SwrMeter(x, y, bright, medium, dim); break;
    case 3: drawLogo4Coupler(x, y, bright, medium, dim); break;
    case 4: drawLogo5FwdRev(x, y, bright, medium, dim); break;
    case 5: drawLogo6Wave(x, y, bright, medium, dim); break;
    case 6: drawLogo7AntennaDiamond(x, y, bright, medium, dim); break;
    case 7: drawLogo8RfBars(x, y, bright, medium, dim); break;
    default: drawLogo9PulseCircle(x, y, bright, medium, dim); break;
  }
}
