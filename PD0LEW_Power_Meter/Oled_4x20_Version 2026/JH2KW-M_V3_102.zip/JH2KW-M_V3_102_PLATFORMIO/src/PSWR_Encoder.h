/*
 * JH2KW-M - POWER AND SWR METER
 *
 * Copyright (c) 2016-2026 J.G. Holstein, PD0LEW
 *
 * Based on the original Power and SWR Meter project and firmware by
 * Loftur E. Jonasson, TF3LJ / VE2AO.
 * Project reference: https://sites.google.com/site/lofturj/
 *
 * With thanks and additional project credit to:
 * Paul Davis, K9MR
 *
 * This firmware is a derivative of GPL-licensed Power/SWR Meter code.
 * It is distributed under the GNU General Public License, version 3
 * or (at your option) any later version. Existing original copyright
 * and license notices in the source files are retained.
 */

#pragma once

#include <Arduino.h>

// Read the physical encoder directly. A complete movement returns exactly
// +1 or -1 and the raw counter is then reset, matching the older proven menu
// behaviour. Incomplete movement returns 0 and remains accumulated.
int16_t encoderTakeSteps(void);

// Calibration-only acceleration support. Returns the recommended adjustment
// step in tenths of a dB.
int16_t encoderCalibrationStepDb10(void);
