#include "app_state.h"

AppState gState;
SemaphoreHandle_t gStateMutex = nullptr;