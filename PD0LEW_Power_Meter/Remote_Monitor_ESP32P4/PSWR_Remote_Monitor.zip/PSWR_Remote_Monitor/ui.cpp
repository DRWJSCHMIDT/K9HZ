#include "ui.h"
#include "app_state.h"
#include "prefs.h"
#include "api_client.h"
#include <Preferences.h>
#include <Arduino.h>
#include <Waveshare_HX8394_DSI.h>
#include <lvgl.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cstring>
extern Waveshare_HX8394_DSI tft;
extern Preferences prefs;
extern float latitude;
extern float longitude;
extern volatile bool weatherRequestPending;

LV_FONT_DECLARE(droid_sans_mono_120);

static constexpr int SCR_W = 1280;
static constexpr int SCR_H = 720;

static constexpr int BAR_X1 = 25;
static constexpr int BAR_X2 = 1225;
static constexpr int BAR_W = BAR_X2 - BAR_X1;

static lv_obj_t* lblCall;
static lv_obj_t* lblLive;
static lv_obj_t* lblUtc;
static lv_obj_t* lblRssi;

static lv_obj_t* lblPep;
static lv_obj_t* lblVswr;
static lv_obj_t* lblPk;
static lv_obj_t* lblAvg;
static lv_obj_t* lblRef;
static lv_obj_t* lblDbm;

static lv_obj_t* barPower;
static lv_obj_t* barSwr;

static lv_obj_t* lblPwrScale0;
static lv_obj_t* lblPwrScale25;
static lv_obj_t* lblPwrScale50;
static lv_obj_t* lblPwrScale75;
static lv_obj_t* lblPwrScale100;

static lv_obj_t* btnBand[4];
static lv_obj_t* lblBand[4];
static lv_obj_t* btnPep;
static lv_obj_t* lblPepBtn;
static lv_obj_t* btnCpl;
static lv_obj_t* lblCpl;
static lv_obj_t* btnPeak;
static lv_obj_t* lblPeak;
static lv_obj_t* btnSetup;
static lv_obj_t* lblSetup;
const int yBtn = 635;
const int xHF    = 25;
const int x6M    = 165;
const int x2M    = 305;
const int x70cm  = 445;
const int xPep   = 585;
const int xCpl   = 800;
const int xPeak  = 950;
const int xSetup = 1134;

static void createMainScreen();
static void createSetupScreen();
static void setupEvent(lv_event_t* e);
static void backEvent(lv_event_t* e);
static void create_brightness_slider(lv_obj_t* parent);
static void slider_event_cb(lv_event_t* e);
static void createScreenSaverTimeScreen();
static void screensaverEvent(lv_event_t* e);
static void createCoordinatesScreen();
void latLonToMaidenhead(float lat, float lon, char* grid);

static lv_obj_t *forecast_screen = NULL;
static lv_obj_t *forecast_status_label = NULL;
static lv_obj_t *forecast_advice_label = NULL;
static lv_obj_t *forecast_title_label = NULL;
static lv_obj_t *forecast_body_label = NULL;
static lv_obj_t* lblForecastStatus = NULL;
static String lastForecastStatus = "OK";
static String lastForecastAdvice = "";
static lv_obj_t *forecast_timer_label = NULL;
static lv_obj_t* lblLocator = nullptr;

static lv_obj_t* txtLatitude = nullptr;
static lv_obj_t* txtLongitude = nullptr;
static lv_obj_t* txtActiveCoord = nullptr;

static lv_obj_t* slider_label = nullptr;
static int brightness_value = 255;

static void createDisplayScreen();
static void displayEvent(lv_event_t* e);
static bool meterScreenActive = false;

static uint32_t lastTouchMs = 0;
static bool screenDimmed = false;
static int screensaverDelaySec = 30;  // time before dim
static int screensaverDimValue = 25;  // brightness when dimmed, 0-255

static lv_obj_t* txtScreenSaverTime = nullptr;
extern float latitude;
extern float longitude;
static String lastLocator = "JO33iu";

static bool uiReady = false;
static float peakVal = 0.0f;
static lv_obj_t* lblSwrt;

static lv_color_t colBg;
static lv_color_t colPanel;
static lv_color_t colCard;
static lv_color_t colText;
static lv_color_t colMuted;
static lv_color_t colGreen;
static lv_color_t colGold;
static lv_color_t colAccent;
static lv_color_t colAlarm;

struct PowerScale {
  float max;
  const char* label;
  float ticks[5];
};

static PowerScale powerScaleFor(float val, const char* s) {
  if (strstr(s, "nW")) return { 1000, "0-1000nW", { 0, 250, 500, 750, 1000 } };
  if (strstr(s, "µW") || strstr(s, "uW")) return { 1000, "0-1000uW", { 0, 250, 500, 750, 1000 } };
  if (strstr(s, "mW")) return { 1000, "0-1000mW", { 0, 250, 500, 750, 1000 } };
  if (strstr(s, "kW")) return { 10, "0-10kW", { 0, 2.5, 5, 7.5, 10 } };
  if (val < 10) return { 10, "0-10W", { 0, 2.5, 5, 7.5, 10 } };
  if (val < 100) return { 100, "0-100W", { 0, 25, 50, 75, 100 } };
  if (val < 500) return { 500, "0-500W", { 0, 125, 250, 375, 500 } };
  return { 1000, "0-1kW", { 0, 250, 500, 750, 1000 } };
}

static float extractPower(const char* s) {
  float v = 0;
  sscanf(s, "%f", &v);
  return v;
}

static int swrToPct(float swr) {
  if (swr <= 0.0f) return 0;
  if (swr < 1.0f) swr = 1.0f;
  if (swr > 10.0f) swr = 10.0f;
  return (int)((log10f(swr) / log10f(10.0f)) * 100.0f);
}

static bool swrAlarmActive(float swr) {
  char* end = nullptr;
  float limit = strtof(gState.swrt, &end);
  if (end == gState.swrt) return false;
  return swr >= limit;
}

static void applyThemeColors() {
  if (gPrefs.darkTheme) {
    colBg = lv_color_hex(0x1a1a2e);
    colPanel = lv_color_hex(0x16213e);
    colCard = lv_color_hex(0x0f3460);
    colText = lv_color_hex(0xffffff);
    colMuted = lv_color_hex(0xa0a0a0);
    colGreen = lv_color_hex(0x00d4aa);
    colGold = lv_color_hex(0xffd700);
    colAccent = lv_color_hex(0x4361ee);
    colAlarm = lv_color_hex(0xff3b30);
  } else {
    colBg = lv_color_hex(0xf0f0f8);
    colPanel = lv_color_hex(0xe8ebf5);
    colCard = lv_color_hex(0xffffff);
    colText = lv_color_hex(0x1a1a2e);
    colMuted = lv_color_hex(0x555577);
    colGreen = lv_color_hex(0x16a34a);
    colGold = lv_color_hex(0xca8a04);
    colAccent = lv_color_hex(0x4361ee);
    colAlarm = lv_color_hex(0xff3b30);
  }
}

static lv_obj_t* makeLabel(lv_obj_t* parent, int x, int y, const lv_font_t* font, lv_color_t color) {
  lv_obj_t* label = lv_label_create(parent);
  lv_obj_set_pos(label, x, y);
  lv_obj_set_style_text_font(label, font, 0);
  lv_obj_set_style_text_color(label, color, 0);
  return label;
}

static lv_obj_t* makeScaleLabel(lv_obj_t* parent, int x, int y, const char* txt, lv_align_t align = LV_ALIGN_TOP_MID) {
  lv_obj_t* l = lv_label_create(parent);
  lv_label_set_text(l, txt);
  lv_obj_set_style_text_font(l, &lv_font_montserrat_28, 0);
  lv_obj_set_style_text_color(l, colMuted, 0);

  if (align == LV_ALIGN_TOP_LEFT) {
    lv_obj_set_pos(l, x, y);
  } else if (align == LV_ALIGN_TOP_RIGHT) {
    lv_obj_align(l, LV_ALIGN_TOP_LEFT, x - lv_obj_get_width(l), y);
  } else {
    lv_obj_align(l, LV_ALIGN_TOP_LEFT, x - lv_obj_get_width(l) / 2, y);
  }

  return l;
}

static lv_obj_t* makePanel(lv_obj_t* parent, int x, int y, int w, int h) {
  lv_obj_t* obj = lv_obj_create(parent);
  lv_obj_set_pos(obj, x, y);
  lv_obj_set_size(obj, w, h);
  lv_obj_set_style_bg_color(obj, colCard, 0);
  lv_obj_set_style_border_color(obj, colAccent, 0);
  lv_obj_set_style_border_width(obj, 2, 0);
  lv_obj_set_style_radius(obj, 12, 0);
  lv_obj_clear_flag(obj, LV_OBJ_FLAG_SCROLLABLE);
  return obj;
}

static void bandEvent(lv_event_t* e) {
  int band = (int)(intptr_t)lv_event_get_user_data(e);
  char cmd[32];
  snprintf(cmd, sizeof(cmd), "{\"band\":%d}", band);
  sendCommand(cmd);
}

static void pepEvent(lv_event_t* e) {
  int nv = (gState.pep_val % 3) + 1;
  char cmd[32];
  snprintf(cmd, sizeof(cmd), "{\"pepset\":%d}", nv);
  sendCommand(cmd);
}

static void cplEvent(lv_event_t* e) {
  sendCommand("{\"cpl\":true}");
}

static void peakEvent(lv_event_t* e) {
  gPrefs.peakHold = !gPrefs.peakHold;
  if (!gPrefs.peakHold) peakVal = 0;
  prefsSave();
  uiRenderUpdates();
}

static void themeEvent(lv_event_t* e) {
  gPrefs.darkTheme = !gPrefs.darkTheme;
  prefsSave();
  uiRenderAll();
}
static void styleButton(lv_obj_t* btn) {
  lv_obj_set_style_bg_color(btn, colCard, 0);
  lv_obj_set_style_bg_opa(btn, LV_OPA_COVER, 0);
}

static void backEvent(lv_event_t* e) {
  if (lv_event_get_code(e) == LV_EVENT_CLICKED) {
    createMainScreen();
    uiRenderUpdates();
  }
}


static void setupEvent(lv_event_t* e) {
  if (lv_event_get_code(e) == LV_EVENT_CLICKED) {
    createSetupScreen();
  }
}

static void displayEvent(lv_event_t* e) {
  if (lv_event_get_code(e) == LV_EVENT_CLICKED) {
    createDisplayScreen();
  }
}
static void updateBrightnessLabel() {
  if (!slider_label) return;

  int brightness_percent = map(brightness_value, 5, 255, 5, 100);  // we stay safe

  lv_label_set_text_fmt(slider_label,
                        "Brightness: %d%%",
                        brightness_percent);
}

static void slider_event_cb(lv_event_t* e) {
  lv_obj_t* slider = (lv_obj_t*)lv_event_get_target(e);

  brightness_value = lv_slider_get_value(slider);

  updateBrightnessLabel();

  tft.setBrightness((uint8_t)brightness_value);
  prefs.putInt("brightness", brightness_value);
}

static void create_brightness_slider(lv_obj_t* parent) {
  // IMPORTANT: load stored value before creating label and slider
  brightness_value = prefs.getInt("brightness", 128);

  slider_label = lv_label_create(parent);

  lv_obj_set_style_text_color(slider_label, colText, 0);
  lv_obj_set_style_text_font(slider_label,
                             &lv_font_montserrat_32,
                             0);

  updateBrightnessLabel();

  lv_obj_align(slider_label,
               LV_ALIGN_CENTER,
               0,
               -80);

  lv_obj_t* slider = lv_slider_create(parent);

  lv_obj_set_width(slider, 900);
  lv_obj_set_height(slider, 15);

  lv_obj_align(slider,
               LV_ALIGN_CENTER,
               0,
               20);

  lv_slider_set_range(slider, 5, 255);
  lv_slider_set_value(slider,
                      brightness_value,
                      LV_ANIM_OFF);

  lv_obj_add_event_cb(slider,
                      slider_event_cb,
                      LV_EVENT_VALUE_CHANGED,
                      nullptr);
}


static void coordKeypadEvent(lv_event_t* e) {
  lv_obj_t* btn = (lv_obj_t*)lv_event_get_target(e);
  lv_obj_t* lbl = lv_obj_get_child(btn, 0);
  const char* key = lv_label_get_text(lbl);

  if (!txtActiveCoord) return;

  if (strcmp(key, "CLR") == 0) {
    lv_textarea_set_text(txtActiveCoord, "");
    return;
  }

  if (strcmp(key, "DEL") == 0) {
  lv_textarea_delete_char(txtActiveCoord);
  return;
  }

  if (strcmp(key, "OK") == 0) {

  if (txtLatitude && txtLongitude) {

    float newLat = atof(lv_textarea_get_text(txtLatitude));
    float newLon = atof(lv_textarea_get_text(txtLongitude));

    if (newLat >= -90.0f && newLat <= 90.0f &&
        newLon >= -180.0f && newLon <= 180.0f) {

      latitude = newLat;
      longitude = newLon;

      prefs.putFloat("wxLat", latitude);
      prefs.putFloat("wxLon", longitude);

      weatherRequestPending = true;

      createSetupScreen();
    }
  }

  return;
}

lv_textarea_add_text(txtActiveCoord, key);
}

static void coordTextAreaEvent(lv_event_t* e) {
  txtActiveCoord = (lv_obj_t*)lv_event_get_target(e);
}





void uiNotifyTouchReleased() {
  lastTouchMs = millis();

  if (screenDimmed) {
    screenDimmed = false;
    tft.setBrightness((uint8_t)brightness_value);
  }
}
void uiHandleScreensaver() {
  if (screensaverDelaySec <= 0) return;

  if (!screenDimmed && millis() - lastTouchMs > (uint32_t)screensaverDelaySec * 1000UL) {
    screenDimmed = true;
    tft.setBrightness((uint8_t)screensaverDimValue);
  }
}
void uiWakeScreen() {
  lastTouchMs = millis();

  if (screenDimmed) {
    screenDimmed = false;
    tft.setBrightness((uint8_t)brightness_value);
  }
}


static void screensaverEvent(lv_event_t* e) {
  if (lv_event_get_code(e) == LV_EVENT_CLICKED) {
    createScreenSaverTimeScreen();
  }
}
static void keypadEvent(lv_event_t* e) {
  lv_obj_t* btn = (lv_obj_t*)lv_event_get_target(e);

  lv_obj_t* lbl = lv_obj_get_child(btn, 0);

  const char* key = lv_label_get_text(lbl);

  if (!txtScreenSaverTime) return;

  // -------------------------------------------------------------------------
  // OK
  // -------------------------------------------------------------------------

  if (strcmp(key, "OK") == 0) {

    const char* txt = lv_textarea_get_text(txtScreenSaverTime);

    int minutes = atoi(txt);

    if (minutes < 1) minutes = 1;
    if (minutes > 120) minutes = 120;

    // Internal value remains seconds
    screensaverDelaySec = minutes * 60;

    // Reset screensaver timer
    lastTouchMs = millis();
    screenDimmed = false;

    // ---------------------------------------------------------------------
    // Save to Preferences
    // ---------------------------------------------------------------------

    Preferences p;

    bool ok = p.begin("settings", false);
    size_t written = 0;

    if (ok) {
      written = p.putInt("ssMin", minutes);
      p.end();
    }

    Serial.printf("Saved ssMin=%d begin=%d written=%d\n",
                  minutes,
                  ok,
                  written);

    createSetupScreen();

    return;
  }

  // -------------------------------------------------------------------------
  // CLR
  // -------------------------------------------------------------------------

  if (strcmp(key, "CLR") == 0) {
    lv_textarea_set_text(txtScreenSaverTime, "");
    return;
  }

  // -------------------------------------------------------------------------
  // DEL
  // -------------------------------------------------------------------------

  if (strcmp(key, "DEL") == 0) {
    lv_textarea_delete_char(txtScreenSaverTime);
    return;
  }

  // -------------------------------------------------------------------------
  // Add key
  // -------------------------------------------------------------------------

  lv_textarea_add_text(txtScreenSaverTime, key);
}






static lv_obj_t* makeKey(lv_obj_t* parent,
                         int x,
                         int y,
                         const char* txt) {
  lv_obj_t* btn = lv_btn_create(parent);

  lv_obj_set_pos(btn, x, y);
  lv_obj_set_size(btn, 120, 70);

  lv_obj_add_event_cb(btn,
                      keypadEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btn);

  lv_obj_t* lbl = lv_label_create(btn);
  lv_label_set_text(lbl, txt);
  lv_obj_set_style_text_font(lbl,
                             &lv_font_montserrat_32,
                             0);

  lv_obj_center(lbl);

  return btn;
}


void uiSetScreensaverDelay(int seconds) {
  screensaverDelaySec = seconds;
}
static void createScreenSaverTimeScreen() {
  uiReady = false;
  meterScreenActive = false;

  applyThemeColors();

  lv_obj_t* scr = lv_scr_act();

  lv_obj_clean(scr);

  lv_obj_set_style_bg_color(scr, colBg, 0);

  // -------------------------------------------------------------------------
  // Title
  // -------------------------------------------------------------------------

  lv_obj_t* lblTitle = makeLabel(scr,
                                 30,
                                 20,
                                 &lv_font_montserrat_32,
                                 colText);

  lv_label_set_text(lblTitle,
                    "Screen Saver Time");

  // -------------------------------------------------------------------------
  // Info
  // -------------------------------------------------------------------------

  lv_obj_t* lblInfo = makeLabel(scr,
                                30,
                                90,
                                &lv_font_montserrat_28,
                                colMuted);

  lv_label_set_text(lblInfo,
                    "Enter delay in minutes");

  // -------------------------------------------------------------------------
  // Text area
  // -------------------------------------------------------------------------

  txtScreenSaverTime = lv_textarea_create(scr);

  lv_obj_set_pos(txtScreenSaverTime,
                 30,
                 150);

  lv_obj_set_size(txtScreenSaverTime,
                  300,
                  70);

  lv_textarea_set_one_line(txtScreenSaverTime,
                           true);

  lv_textarea_set_accepted_chars(txtScreenSaverTime,
                                 "0123456789");

  lv_textarea_set_max_length(txtScreenSaverTime,
                             4);

  char ssBuf[16];
  snprintf(ssBuf,
           sizeof(ssBuf),
           "%d",
           screensaverDelaySec / 60);
  lv_textarea_set_text(txtScreenSaverTime, ssBuf);

  lv_obj_set_style_text_font(txtScreenSaverTime,
                             &lv_font_montserrat_32,
                             0);

  // -------------------------------------------------------------------------
  // Keypad
  // -------------------------------------------------------------------------

  int x0 = 500;
  int y0 = 120;

  int dx = 140;
  int dy = 90;

  makeKey(scr, x0 + 0 * dx, y0 + 0 * dy, "1");
  makeKey(scr, x0 + 1 * dx, y0 + 0 * dy, "2");
  makeKey(scr, x0 + 2 * dx, y0 + 0 * dy, "3");

  makeKey(scr, x0 + 0 * dx, y0 + 1 * dy, "4");
  makeKey(scr, x0 + 1 * dx, y0 + 1 * dy, "5");
  makeKey(scr, x0 + 2 * dx, y0 + 1 * dy, "6");

  makeKey(scr, x0 + 0 * dx, y0 + 2 * dy, "7");
  makeKey(scr, x0 + 1 * dx, y0 + 2 * dy, "8");
  makeKey(scr, x0 + 2 * dx, y0 + 2 * dy, "9");

  makeKey(scr, x0 + 0 * dx, y0 + 3 * dy, "CLR");
  makeKey(scr, x0 + 1 * dx, y0 + 3 * dy, "0");
  makeKey(scr, x0 + 2 * dx, y0 + 3 * dy, "DEL");

  makeKey(scr, x0 + 1 * dx, y0 + 4 * dy, "OK");

  // -------------------------------------------------------------------------
  // Back button
  // -------------------------------------------------------------------------

  lv_obj_t* btnBack = lv_btn_create(scr);

  lv_obj_set_pos(btnBack,
                 1130,
                 635);

  lv_obj_set_size(btnBack,
                  135,
                  60);

  lv_obj_add_event_cb(btnBack,
                      setupEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btnBack);

  lv_obj_t* lblBack = lv_label_create(btnBack);

  lv_label_set_text(lblBack,
                    "Back");

  lv_obj_center(lblBack);
}

// -----------------------------------------------------------------------------
// Display Brightness screen
// -----------------------------------------------------------------------------

static void createDisplayScreen() {
  uiReady = false;
  meterScreenActive = false;

  applyThemeColors();

  lv_obj_t* scr = lv_scr_act();
  lv_obj_clean(scr);
  lv_obj_set_style_bg_color(scr, colBg, 0);

  lv_obj_t* lblTitle = makeLabel(scr,
                                 30,
                                 20,
                                 &lv_font_montserrat_32,
                                 colText);

  lv_label_set_text(lblTitle, "Display Brightness");

  create_brightness_slider(scr);

  lv_obj_t* btnBack = lv_btn_create(scr);
  lv_obj_set_pos(btnBack, 1130, 635);
  lv_obj_set_size(btnBack, 135, 60);
  lv_obj_add_event_cb(btnBack,
                      setupEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btnBack);

  lv_obj_t* lblBack = lv_label_create(btnBack);
  lv_label_set_text(lblBack, "Back");
  lv_obj_center(lblBack);
}


static void createSetupScreen() {
  uiReady = false;
  meterScreenActive = false;

  applyThemeColors();

  lv_obj_t* scr = lv_scr_act();
  lv_obj_clean(scr);
  lv_obj_set_style_bg_color(scr, colBg, 0);

  // -------------------------------------------------------------------------
  // Title
  // -------------------------------------------------------------------------

  lv_obj_t* lblTitle = makeLabel(scr,
                                 30,
                                 20,
                                 &lv_font_montserrat_32,
                                 colText);

  lv_label_set_text(lblTitle, "Setup");

  // -------------------------------------------------------------------------
  // Display button
  // -------------------------------------------------------------------------

  lv_obj_t* btnDisplay = lv_btn_create(scr);
  lv_obj_set_pos(btnDisplay, 30, 120);
  lv_obj_set_size(btnDisplay, 220, 60);

  lv_obj_add_event_cb(btnDisplay,
                      displayEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btnDisplay);

  lv_obj_t* lblDisplay = lv_label_create(btnDisplay);
  lv_label_set_text(lblDisplay, "Display");
  lv_obj_set_style_text_font(lblDisplay,
                             &lv_font_montserrat_32,
                             0);
  lv_obj_center(lblDisplay);

  // -------------------------------------------------------------------------
  // Screen Saver Time button
  // -------------------------------------------------------------------------

  lv_obj_t* btnScreenSaver = lv_btn_create(scr);
  lv_obj_set_pos(btnScreenSaver, 30, 230);
  lv_obj_set_size(btnScreenSaver, 220, 60);

  lv_obj_add_event_cb(btnScreenSaver,
                      screensaverEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btnScreenSaver);

  lv_obj_t* lblScreenSaver = lv_label_create(btnScreenSaver);
  lv_label_set_text(lblScreenSaver, "Saver Time");
  lv_obj_set_style_text_font(lblScreenSaver,
                             &lv_font_montserrat_32,
                             0);
  lv_obj_center(lblScreenSaver);
  
  
  // -------------------------------------------------------------------------
  // Forecast button
  // -------------------------------------------------------------------------

  lv_obj_t* btnForecast = lv_btn_create(scr);
  lv_obj_set_pos(btnForecast, 30, 340);
  lv_obj_set_size(btnForecast, 220, 60);

  lv_obj_add_event_cb(
    btnForecast,
    [](lv_event_t *e) {
      uiShowForecast();
    },
    LV_EVENT_CLICKED,
    nullptr);

  styleButton(btnForecast);

  lv_obj_t* lblForecast = lv_label_create(btnForecast);
  lv_label_set_text(lblForecast, "Forecast");
  lv_obj_set_style_text_font(lblForecast,
                             &lv_font_montserrat_32,
                             0);
  lv_obj_center(lblForecast);


// -------------------------------------------------------------------------
// Coordinates button
// -------------------------------------------------------------------------

lv_obj_t* btnCoords = lv_btn_create(scr);
lv_obj_set_pos(btnCoords, 30, 450);
lv_obj_set_size(btnCoords, 220, 60);

lv_obj_add_event_cb(btnCoords,
                    [](lv_event_t *e) {
                      createCoordinatesScreen();
                    },
                    LV_EVENT_CLICKED,
                    nullptr);

styleButton(btnCoords);

lv_obj_t* lblCoords = lv_label_create(btnCoords);
lv_label_set_text(lblCoords, "Set Coords");
lv_obj_set_style_text_font(lblCoords,
                           &lv_font_montserrat_32,
                           0);
lv_obj_center(lblCoords);

  // -------------------------------------------------------------------------
  // Back button
  // -------------------------------------------------------------------------

  lv_obj_t* btnBack = lv_btn_create(scr);
  lv_obj_set_pos(btnBack, 1130, 635);
  lv_obj_set_size(btnBack, 135, 60);

  lv_obj_add_event_cb(btnBack,
                      backEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btnBack);

  lv_obj_t* lblBack = lv_label_create(btnBack);
  lv_label_set_text(lblBack, "Back");
  lv_obj_center(lblBack);
}

static void createMainScreen() {
  meterScreenActive = false;
  uiReady = false;

  applyThemeColors();

  lv_obj_t* scr = lv_scr_act();
  lv_obj_clean(scr);
  lv_obj_set_style_bg_color(scr, colBg, 0);

  lv_obj_t* header = lv_obj_create(scr);
  lv_obj_set_pos(header, 0, 0);
  lv_obj_set_size(header, SCR_W, 73);
  lv_obj_set_style_bg_color(header, colPanel, 0);
  lv_obj_set_style_border_width(header, 0, 0);
  lv_obj_clear_flag(header, LV_OBJ_FLAG_SCROLLABLE);

  lblCall = makeLabel(header, 20, 2, &lv_font_montserrat_32, colGreen);
  lblLive = makeLabel(header, 350, 2, &lv_font_montserrat_32, colMuted);
  lblUtc = makeLabel(header, 650, 2, &lv_font_montserrat_32, colGold);
  lblRssi = makeLabel(header, 1000, 2, &lv_font_montserrat_32, colMuted);

  makePanel(scr, 20, 95, 760, 170);
  makePanel(scr, 805, 95, 455, 170);

  lblPep = makeLabel(scr, 45, 130, &droid_sans_mono_120, colText);
  lblVswr = makeLabel(scr, 835, 130, &droid_sans_mono_120, colText);

  lv_obj_t* pLabel = makeLabel(scr, 25, 275, &lv_font_montserrat_30, colMuted);
  lv_label_set_text(pLabel, "POWER");

  barPower = lv_bar_create(scr);
  lv_obj_set_pos(barPower, BAR_X1, 320);
  lv_obj_set_size(barPower, BAR_W, 40);
  lv_bar_set_range(barPower, 0, 100);
  lv_bar_set_value(barPower, 0, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(barPower, lv_color_hex(0x2a2a4a), LV_PART_MAIN);
  lv_obj_set_style_bg_opa(barPower, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_border_color(barPower, lv_color_hex(0x505050), LV_PART_MAIN); // -------------------------------------------------------------------------
  
  
  
  lv_obj_set_style_border_width(barPower, 2, LV_PART_MAIN);
  lv_obj_set_style_bg_color(barPower, lv_color_hex(0x00d4aa), LV_PART_INDICATOR);
  lv_obj_set_style_bg_opa(barPower, LV_OPA_COVER, LV_PART_INDICATOR);
  lv_obj_set_style_radius(barPower, 6, LV_PART_MAIN);
  lv_obj_set_style_radius(barPower, 6, LV_PART_INDICATOR);

  lblPwrScale0 = makeScaleLabel(scr, BAR_X1, 370, "0", LV_ALIGN_TOP_LEFT);
  lblPwrScale25 = makeScaleLabel(scr, BAR_X1 + (BAR_W * 1) / 4, 370, "2.5");
  lblPwrScale50 = makeScaleLabel(scr, BAR_X1 + (BAR_W * 2) / 4, 370, "5");
  lblPwrScale75 = makeScaleLabel(scr, BAR_X1 + (BAR_W * 3) / 4, 370, "7.5");
  lblPwrScale100 = makeScaleLabel(scr, BAR_X2 - 40, 370, "10W", LV_ALIGN_TOP_RIGHT);
  lv_obj_t* sLabel = makeLabel(scr, 25, 415, &lv_font_montserrat_30, colMuted);
  lv_label_set_text(sLabel, "SWR");

  barSwr = lv_bar_create(scr);
  lv_obj_set_pos(barSwr, BAR_X1, 455);
  lv_obj_set_size(barSwr, BAR_W, 40);
  lv_bar_set_range(barSwr, 0, 100);
  lv_bar_set_value(barSwr, 0, LV_ANIM_OFF);
  lv_obj_set_style_bg_color(barSwr, lv_color_hex(0x2a2a4a), LV_PART_MAIN);
  lv_obj_set_style_bg_opa(barSwr, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_border_color(barSwr, lv_color_hex(0x505050), LV_PART_MAIN);
  lv_obj_set_style_border_width(barSwr, 2, LV_PART_MAIN);
  lv_obj_set_style_bg_color(barSwr, lv_color_hex(0xffd700), LV_PART_INDICATOR);
  lv_obj_set_style_bg_opa(barSwr, LV_OPA_COVER, LV_PART_INDICATOR);
  lv_obj_set_style_radius(barSwr, 6, LV_PART_MAIN);
  lv_obj_set_style_radius(barSwr, 6, LV_PART_INDICATOR);

  makeScaleLabel(scr, BAR_X1 + (int)(BAR_W * swrToPct(1.0f) / 100.0f), 500, "1", LV_ALIGN_TOP_LEFT);
  makeScaleLabel(scr, BAR_X1 + (int)(BAR_W * swrToPct(1.5f) / 100.0f), 500, "1.5");
  makeScaleLabel(scr, BAR_X1 + (int)(BAR_W * swrToPct(2.0f) / 100.0f), 500, "2");
  makeScaleLabel(scr, BAR_X1 + (int)(BAR_W * swrToPct(3.0f) / 100.0f), 500, "3");
  makeScaleLabel(scr, BAR_X1 + (int)(BAR_W * swrToPct(5.0f) / 100.0f), 500, "5");
  makeScaleLabel(scr, BAR_X2 - 15, 500, "10", LV_ALIGN_TOP_RIGHT);

  lblPk = makeLabel(scr, 60, 535, &lv_font_montserrat_32, colText);
  lblAvg = makeLabel(scr, 310, 535, &lv_font_montserrat_32, colText);
  lblRef = makeLabel(scr, 560, 535, &lv_font_montserrat_32, colText);
  lblDbm = makeLabel(scr, 820, 535, &lv_font_montserrat_32, colText);

  lv_label_set_text(makeLabel(scr, 80, 585, &lv_font_montserrat_32, colMuted), "PK");
  lv_label_set_text(makeLabel(scr, 330, 585, &lv_font_montserrat_32, colMuted), "AVG");
  lv_label_set_text(makeLabel(scr, 580, 585, &lv_font_montserrat_32, colMuted), "REF");
  lv_label_set_text(makeLabel(scr, 830, 585, &lv_font_montserrat_32, colMuted), "dBm");

  // -------------------------------------------------------------------------
  // HF / 6M / 2M / 70cm
  // -------------------------------------------------------------------------

  const char* bands[] = { "HF", "6M", "2M", "70cm" };

  int bandX[4] = {
    xHF,
    x6M,
    x2M,
    x70cm
  };

  for (int i = 0; i < 4; i++) {

    btnBand[i] = lv_btn_create(scr);

    lv_obj_set_pos(btnBand[i], bandX[i], yBtn);

    lv_obj_set_size(btnBand[i], 125, 60);

    lv_obj_add_event_cb(btnBand[i],
                        bandEvent,
                        LV_EVENT_CLICKED,
                        (void*)(intptr_t)i);

    lblBand[i] = lv_label_create(btnBand[i]);

    lv_label_set_text(lblBand[i], bands[i]);

    lv_obj_center(lblBand[i]);
  }

  // -------------------------------------------------------------------------
  // PEP
  // -------------------------------------------------------------------------

  btnPep = lv_btn_create(scr);

  lv_obj_set_pos(btnPep, xPep, yBtn);

  lv_obj_set_size(btnPep, 200, 60);

  lv_obj_add_event_cb(btnPep,
                      pepEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  lblPepBtn = lv_label_create(btnPep);

  lv_obj_center(lblPepBtn);

  // -------------------------------------------------------------------------
  // CPL
  // -------------------------------------------------------------------------

  btnCpl = lv_btn_create(scr);

  lv_obj_set_pos(btnCpl, xCpl, yBtn);

  lv_obj_set_size(btnCpl, 135, 60);

  lv_obj_add_event_cb(btnCpl,
                      cplEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  lblCpl = lv_label_create(btnCpl);

  lv_obj_center(lblCpl);

  // -------------------------------------------------------------------------
  // PEAK
  // -------------------------------------------------------------------------

  btnPeak = lv_btn_create(scr);

  lv_obj_set_pos(btnPeak, xPeak, yBtn);lv_obj_t *back_btn = lv_button_create(forecast_screen);

lv_obj_set_size(back_btn, 140, 70);

lv_obj_align(
  back_btn,
  LV_ALIGN_BOTTOM_LEFT,
  30,
  -30);

lv_obj_t *back_label = lv_label_create(back_btn);

lv_label_set_text(back_label, "Back");

lv_obj_center(back_label);

lv_obj_add_event_cb(
  back_btn,
  [](lv_event_t *e) {
    createSetupScreen();
  },
  LV_EVENT_CLICKED,
  NULL);

  lv_obj_set_size(btnPeak, 170, 60);

  lv_obj_add_event_cb(btnPeak,
                      peakEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  lblPeak = lv_label_create(btnPeak);

  lv_obj_center(lblPeak);

  // -------------------------------------------------------------------------
  // SETUP
  // -------------------------------------------------------------------------

  btnSetup = lv_btn_create(scr);

  lv_obj_set_pos(btnSetup, xSetup, yBtn);

  lv_obj_set_size(btnSetup, 135, 60);

  lv_obj_add_event_cb(btnSetup,
                      setupEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  lblSetup = lv_label_create(btnSetup);

  lv_label_set_text(lblSetup, "Setup");

  lv_obj_center(lblSetup);

  styleButton(btnSetup);

  styleButton(btnPep);
  styleButton(btnCpl);
  styleButton(btnPeak);
  styleButton(btnSetup);  // Setup jhn

  lblSwrt = makeLabel(scr, 865, 275,&lv_font_montserrat_30, colGold);
  
  lblForecastStatus = makeLabel(scr, 490, 275, &lv_font_montserrat_30, colMuted);
  String txt = "WX : " + lastForecastStatus;
  lv_label_set_text(lblForecastStatus, txt.c_str());
  
  lblLocator = makeLabel(scr, 230, 275, &lv_font_montserrat_30, colMuted);
  String locTxt = "LOC: " + lastLocator;
  lv_label_set_text(lblLocator, locTxt.c_str());

  meterScreenActive = true;
  uiReady = true;
}


static lv_obj_t* makeCoordKey(lv_obj_t* parent,
                              int x,
                              int y,
                              const char* txt) {

  lv_obj_t* btn = lv_btn_create(parent);

  lv_obj_set_pos(btn, x, y);
  lv_obj_set_size(btn, 100, 60);

  lv_obj_add_event_cb(btn,
                      coordKeypadEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btn);

  lv_obj_t* lbl = lv_label_create(btn);

  lv_label_set_text(lbl, txt);

  lv_obj_set_style_text_font(lbl,
                             &lv_font_montserrat_30,
                             0);

  lv_obj_center(lbl);

  return btn;
}


static void createCoordinatesScreen() {

  uiReady = false;
  meterScreenActive = false;
  
  applyThemeColors();

  lv_obj_t* scr = lv_scr_act();
  lv_obj_clean(scr);
  lv_obj_set_style_bg_color(scr, colBg, 0);

  lv_label_set_text(
      makeLabel(scr,
                30,
                20,
                &lv_font_montserrat_32,
                colText),
      "Set Coordinates");

  // -----------------------------------------------------------------------
  // Latitude
  // -----------------------------------------------------------------------

  lv_label_set_text(
      makeLabel(scr,
                30,
                100,
                &lv_font_montserrat_28,
                colMuted),
      "Latitude");

  txtLatitude = lv_textarea_create(scr);

  lv_obj_set_pos(txtLatitude, 30, 145);
  lv_obj_set_size(txtLatitude, 360, 65);

  lv_textarea_set_one_line(txtLatitude, true);
  lv_textarea_set_accepted_chars(txtLatitude, "0123456789.-");
  char buf[32];

snprintf(buf,
         sizeof(buf),
         "%.4f",
         latitude);

lv_textarea_set_text(txtLatitude, buf);

  lv_obj_add_event_cb(txtLatitude,
                      coordTextAreaEvent,
                      LV_EVENT_FOCUSED,
                      nullptr);

  // -----------------------------------------------------------------------
  // Longitude
  // -----------------------------------------------------------------------

  lv_label_set_text(
      makeLabel(scr,
                30,
                235,
                &lv_font_montserrat_28,
                colMuted),
      "Longitude");

  txtLongitude = lv_textarea_create(scr);

  lv_obj_set_pos(txtLongitude, 30, 280);
  lv_obj_set_size(txtLongitude, 360, 65);

  lv_textarea_set_one_line(txtLongitude, true);
  lv_textarea_set_accepted_chars(txtLongitude, "0123456789.-");
  snprintf(buf,
         sizeof(buf),
         "%.4f",
         longitude);

  lv_textarea_set_text(txtLongitude, buf);
  lv_obj_add_event_cb(txtLongitude,
                      coordTextAreaEvent,
                      LV_EVENT_FOCUSED,
                      nullptr);

  // First active field

  txtActiveCoord = txtLatitude;

  // -----------------------------------------------------------------------
  // Keypad
  // -----------------------------------------------------------------------

  int x0 = 520;
  int y0 = 120;

  int dx = 120;
  int dy = 75;

  makeCoordKey(scr, x0 + 0 * dx, y0 + 0 * dy, "7");
  makeCoordKey(scr, x0 + 1 * dx, y0 + 0 * dy, "8");
  makeCoordKey(scr, x0 + 2 * dx, y0 + 0 * dy, "9");

  makeCoordKey(scr, x0 + 0 * dx, y0 + 1 * dy, "4");
  makeCoordKey(scr, x0 + 1 * dx, y0 + 1 * dy, "5");
  makeCoordKey(scr, x0 + 2 * dx, y0 + 1 * dy, "6");

  makeCoordKey(scr, x0 + 0 * dx, y0 + 2 * dy, "1");
  makeCoordKey(scr, x0 + 1 * dx, y0 + 2 * dy, "2");
  makeCoordKey(scr, x0 + 2 * dx, y0 + 2 * dy, "3");

  makeCoordKey(scr, x0 + 0 * dx, y0 + 3 * dy, "-");
  makeCoordKey(scr, x0 + 1 * dx, y0 + 3 * dy, "0");
  makeCoordKey(scr, x0 + 2 * dx, y0 + 3 * dy, ".");

  makeCoordKey(scr, x0 + 0 * dx, y0 + 4 * dy, "CLR");
  makeCoordKey(scr, x0 + 1 * dx, y0 + 4 * dy, "DEL");
  makeCoordKey(scr, x0 + 2 * dx, y0 + 4 * dy, "OK");
  // -----------------------------------------------------------------------
  // Back button
  // -----------------------------------------------------------------------

  lv_obj_t* btnBack = lv_btn_create(scr);

  lv_obj_set_pos(btnBack, 1130, 635);
  lv_obj_set_size(btnBack, 135, 60);

  lv_obj_add_event_cb(btnBack,
                      setupEvent,
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btnBack);

  lv_obj_t* lblBack = lv_label_create(btnBack);

  lv_label_set_text(lblBack, "Back");

  lv_obj_center(lblBack);

  uiReady = true;
}


void uiShowForecast() {
  uiReady = false;
  meterScreenActive = false;

  applyThemeColors();

  lv_obj_t* scr = lv_scr_act();
  lv_obj_clean(scr);
  lv_obj_set_style_bg_color(scr, lv_color_hex(0x0B1220), 0);

  // Title
  lv_obj_t* title = makeLabel(scr, 30, 20, &lv_font_montserrat_32, colText);
  lv_label_set_text(title, "Weather Forecast");

  // Main panel
  lv_obj_t* panel = lv_obj_create(scr);
  lv_obj_set_pos(panel, 40, 95);
  lv_obj_set_size(panel, 1200, 470);
  lv_obj_set_style_bg_color(panel, lv_color_hex(0x162033), 0);
  lv_obj_set_style_border_color(panel, lv_color_hex(0x304060), 0);
  lv_obj_set_style_border_width(panel, 2, 0);
  lv_obj_set_style_radius(panel, 28, 0);
  lv_obj_clear_flag(panel, LV_OBJ_FLAG_SCROLLABLE);

  // Status
  forecast_status_label = lv_label_create(panel);
  lv_label_set_text(forecast_status_label, "Loading...");
  lv_obj_set_style_text_font(forecast_status_label, &lv_font_montserrat_48, 0);
  lv_obj_set_style_text_color(forecast_status_label, lv_color_hex(0x00FFAA), 0);
  lv_obj_align(forecast_status_label, LV_ALIGN_TOP_MID, 0, 65);

  // Advice
  forecast_advice_label = lv_label_create(panel);
  lv_label_set_text(forecast_advice_label, "Waiting for forecast data...");
  lv_obj_set_width(forecast_advice_label, 1000);
  lv_label_set_long_mode(forecast_advice_label, LV_LABEL_LONG_WRAP);
  lv_obj_set_style_text_align(forecast_advice_label, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_set_style_text_font(forecast_advice_label, &lv_font_montserrat_32, 0);
  lv_obj_set_style_text_color(forecast_advice_label, lv_color_hex(0xD0D8E8), 0);
  lv_obj_align(forecast_advice_label, LV_ALIGN_CENTER, 0, 70);

  // Countdown timer
  forecast_timer_label = makeLabel(scr,
                                   30,
                                   585,
                                   &lv_font_montserrat_30,
                                   colMuted);

  lv_label_set_text(forecast_timer_label,
                    "Next update in --:--");

  // Back button
  lv_obj_t* btnBack = lv_btn_create(scr);
  lv_obj_set_pos(btnBack, 1130, 635);
  lv_obj_set_size(btnBack, 135, 60);

  lv_obj_add_event_cb(btnBack,
                      [](lv_event_t *e) {
                        forecast_status_label = NULL;
                        forecast_advice_label = NULL;
                        forecast_timer_label = NULL;
                        createSetupScreen();
                      },
                      LV_EVENT_CLICKED,
                      nullptr);

  styleButton(btnBack);

  lv_obj_t* lblBack = lv_label_create(btnBack);
  lv_label_set_text(lblBack, "Back");
  lv_obj_center(lblBack);

  uiReady = true;
}
void uiUpdateForecastTimer(unsigned long remainingMs) {

  if (!forecast_timer_label) {
    return;
  }

  if (!lv_obj_is_valid(forecast_timer_label)) {
    return;
  }

  unsigned long totalSec = remainingMs / 1000UL;

  int minutes = totalSec / 60;
  int seconds = totalSec % 60;

  char buf[64];

  snprintf(
      buf,
      sizeof(buf),
      "Next update in %02d:%02d",
      minutes,
      seconds);

  lv_label_set_text(
      forecast_timer_label,
      buf);
}
void uiInit() {
  lastTouchMs = millis();
  createMainScreen();
}

Screen uiCurrentScreen() {
  return SCR_METER;
}



void uiShowConnecting(const char* msg) {

  uiReady = false;
  meterScreenActive = false;

  lv_obj_t* scr = lv_scr_act();

  lv_obj_clean(scr);

  lv_obj_set_style_bg_color(
      scr,
      lv_color_hex(0x1a1a2e),
      0);

  // -----------------------------------------------------------------------
  // Copyright / version
  // -----------------------------------------------------------------------

  lv_obj_t* lblCopy = makeLabel(
      scr,
      18,
      12,
      &lv_font_montserrat_30,
      lv_color_hex(0x707090));

  lv_label_set_text(
      lblCopy,
      "Version 1.01 (c) 2026");

  // -----------------------------------------------------------------------
  // Designers
  // -----------------------------------------------------------------------

  lv_obj_t* lblDesign = makeLabel(
      scr,
      18,
      60,
      &lv_font_montserrat_30,
      lv_color_hex(0x9090b0));

  lv_label_set_text(
    lblDesign,
    "Designed by\n\nPaul Davis\nJohan Holstein");

  // -----------------------------------------------------------------------
  // Main title
  // -----------------------------------------------------------------------

  lv_obj_t* title = makeLabel(
      scr,
      0,
      0,
      &droid_sans_mono_120,
      lv_color_hex(0x00d4aa));

  lv_label_set_text(
      title,
      "PowerMeter");

  lv_obj_align(
      title,
      LV_ALIGN_CENTER,
      0,
      -40);

  // -----------------------------------------------------------------------
  // Status message
  // -----------------------------------------------------------------------

  lv_obj_t* label = makeLabel(
      scr,
      0,
      0,
      &lv_font_montserrat_48,
      lv_color_hex(0xa0a0a0));

  lv_label_set_text(
      label,
      msg);

  lv_obj_align(
      label,
      LV_ALIGN_CENTER,
      0,
      50);

  // -----------------------------------------------------------------------
  // Bottom glow line
  // -----------------------------------------------------------------------

  lv_obj_t* line = lv_obj_create(scr);

  lv_obj_set_size(line, 1000, 3);

  lv_obj_align(
      line,
      LV_ALIGN_BOTTOM_MID,
      0,
      -25);

  lv_obj_set_style_bg_color(
      line,
      lv_color_hex(0x00d4aa),
      0);

  lv_obj_set_style_border_width(
      line,
      0,
      0);

  lv_obj_set_style_radius(
      line,
      2,
      0);

  lv_timer_handler();
}


void uiShowPortalActive(const char* apName) {
  lv_obj_t* scr = lv_scr_act();
  lv_obj_clean(scr);
  lv_obj_set_style_bg_color(scr, lv_color_hex(0x1a1a2e), 0);

  //lv_obj_t* title = makeLabel(scr, 0, 0, &lv_font_montserrat_48, lv_color_hex(0xffd700));
  //lv_label_set_text(title, "Setup Mode");
  //lv_obj_align(title, LV_ALIGN_CENTER, 0, -80);

  lv_obj_t* label = makeLabel(scr, 0, 0, &lv_font_montserrat_28, lv_color_white());
  lv_label_set_text_fmt(label, "Connect to WiFi:\n%s\n\nOpen 192.168.4.1", apName);
  lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_CENTER, 0);
  lv_obj_align(label, LV_ALIGN_CENTER, 0, 30);
}

void uiShowBootHoldProgress(float progress) {
  lv_obj_t* bar = lv_bar_create(lv_scr_act());
  lv_obj_set_size(bar, SCR_W - 80, 20);
  lv_obj_align(bar, LV_ALIGN_BOTTOM_MID, 0, -30);
  lv_bar_set_range(bar, 0, 100);
  lv_bar_set_value(bar, (int)(progress * 100.0f), LV_ANIM_OFF);
}

void uiRenderAll() {
  createMainScreen();
  uiRenderUpdates();
}

void uiRenderUpdates() {
  if (!uiReady) return;
  if (!meterScreenActive) return;

  if (!lblCall || !lblLive || !lblUtc || !lblRssi || !lblPep || !lblVswr || !lblPk || !lblAvg || !lblRef || !lblDbm || !barPower || !barSwr || !lblPwrScale0 || !lblPwrScale25 || !lblPwrScale50 || !lblPwrScale75 || !lblPwrScale100) {
    return;
  }

  char buf[64];
  char sbuf[16];

  float pw = extractPower(gState.pep);
  if (pw < 0.1f) pw = 0.0f;

  PowerScale ps = (pw <= 0.0f)
                    ? PowerScale{ 10, "0-10W", { 0, 2.5, 5, 7.5, 10 } }
                    : powerScaleFor(pw, gState.pep);

  lv_bar_set_range(barPower, 0, (int)ps.max);
  lv_bar_set_value(barPower, (int)pw, LV_ANIM_OFF);

  snprintf(sbuf, sizeof(sbuf), "%.4g", ps.ticks[0]);
  lv_label_set_text(lblPwrScale0, sbuf);
  snprintf(sbuf, sizeof(sbuf), "%.4g", ps.ticks[1]);
  lv_label_set_text(lblPwrScale25, sbuf);
  snprintf(sbuf, sizeof(sbuf), "%.4g", ps.ticks[2]);
  lv_label_set_text(lblPwrScale50, sbuf);
  snprintf(sbuf, sizeof(sbuf), "%.4g", ps.ticks[3]);
  lv_label_set_text(lblPwrScale75, sbuf);
  snprintf(sbuf, sizeof(sbuf), "%.4gW", ps.ticks[4]);
  lv_label_set_text(lblPwrScale100, sbuf);

  lv_label_set_text(lblCall, gState.callsign);
  lv_label_set_text(lblLive, gState.sseConnected ? "Connected" : "Offline");

  char utcBuf[32];
  snprintf(utcBuf, sizeof(utcBuf), "%s UTC", gState.utc);
  lv_label_set_text(lblUtc, utcBuf);

  snprintf(buf, sizeof(buf), "WiFi %d dBm", gState.rssi);
  lv_label_set_text(lblRssi, buf);

  const char* pep = gState.pep;
  while (*pep == ' ') pep++;
  lv_label_set_text(lblPep, pep);

  snprintf(buf, sizeof(buf), "%.2f", gState.vswr);
  lv_label_set_text(lblVswr, buf);

  lv_label_set_text(lblPk, gState.pk);
  lv_label_set_text(lblAvg, gState.avg_p);
  lv_label_set_text(lblRef, gState.ref_p);
  lv_label_set_text(lblDbm, gState.dbm);
  char swrtBuf[32];

  snprintf(swrtBuf,
          sizeof(swrtBuf),
          "SWR Alarm trigger:  %s",
          gState.swrt);

  lv_label_set_text(lblSwrt, swrtBuf);
  int swrPct = swrToPct(gState.vswr);
  lv_bar_set_value(barSwr, swrPct, LV_ANIM_OFF);

  if (swrAlarmActive(gState.vswr)) {
    lv_obj_set_style_bg_color(barSwr, colAlarm, LV_PART_INDICATOR);
  } else if (gState.vswr < 2.0f) {
    lv_obj_set_style_bg_color(barSwr, colGreen, LV_PART_INDICATOR);
  } else {
    lv_obj_set_style_bg_color(barSwr, colGold, LV_PART_INDICATOR);
  }

  const char* pepLabels[] = { "PEP 100ms", "PEP 1s", "PEP 2s" };
  int idx = (gState.pep_val >= 1 && gState.pep_val <= 3) ? gState.pep_val - 1 : 0;
  lv_label_set_text(lblPepBtn, pepLabels[idx]);

  snprintf(buf, sizeof(buf), "CPL %d", gState.cpl);
  lv_label_set_text(lblCpl, buf);

  lv_label_set_text(lblPeak, gPrefs.peakHold ? "Peak ON" : "Peak OFF");
  // change to Setup jhn
  lv_label_set_text(lblSetup, "Setup");

  for (int i = 0; i < 4; i++) {
    lv_obj_set_style_bg_color(btnBand[i], i == gState.band ? colAccent : colCard, 0);
  }
  // Button colors same as HF, 6M, 2M, 70cm
  lv_obj_set_style_bg_color(btnPep, colCard, 0);
  lv_obj_set_style_bg_color(btnCpl, colCard, 0);
  lv_obj_set_style_bg_color(btnPeak, colCard, 0);
  lv_obj_set_style_bg_color(btnSetup, colCard, 0);
}
void uiSetForecast(String status, String advice) {
  
  
  lastForecastStatus = status;
  lastForecastAdvice = advice;

  lv_color_t c = lv_color_hex(0x00FFAA);

  if (status == "RAIN/WIND") {
    c = lv_color_hex(0xFFD000);
  }
  else if (status == "STORM") {
    c = lv_color_hex(0xFF7A00);
  }
  else if (status == "DANGER") {
    c = lv_color_hex(0xFF1010);
  }
  else if (status == "ERROR") {
    c = lv_color_hex(0xFF1010);
  }

  if (forecast_status_label && lv_obj_is_valid(forecast_status_label)) {
    lv_label_set_text(forecast_status_label, status.c_str());
    lv_obj_set_style_text_color(forecast_status_label, c, 0);
    lv_obj_set_style_text_opa(forecast_status_label, LV_OPA_COVER, 0);
  }

  if (forecast_advice_label && lv_obj_is_valid(forecast_advice_label)) {
    lv_label_set_text(forecast_advice_label, advice.c_str());
  }

  if (lblForecastStatus && lv_obj_is_valid(lblForecastStatus)) {
    String txt = "WX: " + status;
    lv_label_set_text(lblForecastStatus, txt.c_str());
    lv_obj_set_style_text_color(lblForecastStatus, c, 0);
  }
 char grid[7];

  latLonToMaidenhead(
      latitude,
      longitude,
      grid);

  lastLocator = grid;

  if (lblLocator && lv_obj_is_valid(lblLocator)) {

    String txt = "LOC: ";
    txt += grid;

    lv_label_set_text(
        lblLocator,
        txt.c_str());
  }
}

void uiHandleTouch(int x, int y) {
  // LVGL handles touch through its input driver.
}