@echo off
cd /d %~dp0
g++ -std=c++17 -O2 -I stubs -I ..\src wav_benchmark.cpp -o wav_benchmark.exe
if errorlevel 1 exit /b 1
echo Built: host_checks\wav_benchmark.exe
